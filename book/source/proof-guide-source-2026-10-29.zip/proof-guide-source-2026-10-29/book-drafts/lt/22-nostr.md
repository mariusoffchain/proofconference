# 7 skyrius: Nostr: atviras tinklas, kurio nevaldo jokia įmonė

## Trumpai

Platformoje tavo profilis, įrašai ir auditorija priklauso ją valdančiai įmonei. Nostr yra atvirasis pasirašytų duomenų protokolas: tapatybė čia yra raktų pora, kurią turi tu, o tai, ką skelbi, perduoda daug nepriklausomų retransliatorių (angl. relays) ir programėlių, todėl programėlę ar retransliatorių gali bet kada pakeisti, o vardas ir sekėjai lieka. Šiandien jo pagrindu daugiausia kuriamos socialinių platformų alternatyvos, nuo trumpų įrašų iki nuotraukų, ilgų straipsnių, tiesioginių vaizdo transliacijų, muzikos ir prekyviečių. Tinklas mažesnis ir ne toks nugludintas kaip didžiosios platformos, o paskyrą tokioje programėlėje kaip „Primal“, „Damus“ ar „Amethyst“ susikursi per kelias minutes.

## Viešoji aikštė, priklausanti kažkam kitam

Socialinis tinklas atrodo kaip viešoji aikštė, bet veikia kaip privatus pastatas, kurio savininkas nustato taisykles ir gali jas pakeisti per naktį. 2022 m. gruodžio 18 d. bendrovė „Twitter“ [paskelbė, kad šalins nuorodas į „Facebook“, „Instagram“, „Mastodon“ ir Nostr](https://techcrunch.com/2022/12/18/twitter-wont-let-you-post-your-facebook-instagram-and-mastodon-handles/) ir sustabdys jas reklamuojančias paskyras, o kilus protestų bangai šios taisyklės atsisakė nepraėjus nė parai.

Tas pats savininkas gali pašalinti paskyrą, nurodęs priežastį arba ne, ir kartu su ja dingsta daugelio metų įrašai ir kontaktai. Jis taip pat gali tau nieko nepranešęs padaryti taip, kad tave matytų mažiau žmonių, ir tai dažnai vadinama šešėliniu blokavimu (angl. shadow ban). Įprastu metu tai, ką matai, parenka algoritmas, kuriam svarbiausia platformoje praleistas laikas ir reklama, o kaskart jam pasikeitus pasikeičia ir tai, kiek žmonių tave pamato.

Auditorija irgi ne tavo, nes sekėjų į kitą paslaugą nepasiimsi, ir didele dalimi todėl išeiti taip sunku. Tai, ką skaitai, kas tau patinka ir ką rašai, dar ir papildo reklamos profilį. 2025 m. balandį Europos Komisija pagal Skaitmeninių rinkų aktą [skyrė bendrovei „Meta“ 200 mln. eurų baudą](https://ec.europa.eu/commission/presscorner/detail/en/ip_25_1085), nes „Facebook“ ir „Instagram“ naudotojai turėjo arba sutikti, kad jų asmens duomenys būtų jungiami reklamos tikslais, arba mokėti už prenumeratą.

## Retransliatoriai viską užfiksuoja, o klientai yra langai

Nostr yra protokolas, kaip el. paštas ar žiniatinklis, vadinasi, jis nepriklauso jokiai įmonei ir jo neapibrėžia nė viena atskira programėlė. Juo perduodami bet kokie pasirašyti duomenys, o trumpas įrašas yra tik 1 atvejis iš daugelio. Pagrindą sudaro 3 dalys:

- **Tavo tapatybė yra raktų pora** (žr. 6 skyrių). Viešasis raktas, prasidedantis raidėmis **npub**, yra tavo adresas, ir juo gali laisvai dalytis. Privatusis raktas, prasidedantis raidėmis **nsec**, yra tavo paslaptis, nes jis įrodo, kad tu esi tu.
- **Viskas, ką skelbi, yra pasirašytas įvykis (angl. event).** Įrašas, nuotrauka, ilgas straipsnis, prekės skelbimas ar pranešimas apie tiesioginę transliaciją turi parašą, sukurtą tavo nsec raktu, todėl bet kas gali patikrinti, ar tai tikrai tavo ir ar niekas to nepakeitė.
- **Zapai (angl. zaps)** yra nedideli Lightning mokėjimai (žr. 3 dalį), siunčiami tiesiai žmogui arba įrašui. Jais gali ką nors paremti be reklamos ir be platformos, kuri pasiimtų savo dalį.

Kad suprastum, kur čia retransliatorių ir klientų vieta, įsivaizduok, kad viskas, ką žmonės skelbia, vyksta lauke, gamtoje. **Retransliatoriai** užfiksuoja ir saugo tai, kas ten vyksta. Tai paprasti serveriai, kuriuos gali paleisti bet kas, o skelbi iš karto keliuose. **Klientas** yra langas, pro kurį žiūri į lauką, ir langai būna įvairūs. Pro vienus matyti beveik viskas, kiti dalį vaizdo filtruoja ar uždengia, o kurį nors langą galima uždaryti langinėmis ar net užkalti lentomis, nors kiti lieka atviri. Visada gali nueiti prie kito lango, nes tai, kas vyksta lauke, nė vienam langui nepriklauso, o naujas klientas gali atsisiųsti pasirašytą profilį, įrašus ir kontaktų sąrašus iš tų retransliatorių, kuriuose jie dar saugomi. Svarbų turinį eksportuok ir pasilik savo įrenginyje, nes retransliatoriai ir medijos serveriai nežada jo saugoti visam laikui.

2023 m. vasarį bendrovė „Apple“ Kinijos interneto priežiūros institucijos prašymu [pašalino klientą „Damus“ iš savo programėlių parduotuvės „App Store“ Kinijoje](https://techcrunch.com/2023/02/02/damus-pulled-from-apples-app-store-in-china-after-two-days/) praėjus 2 dienoms nuo jo pasirodymo. Tas langas buvo užkaltas 1 šalyje, o retransliatoriai ir kiti klientai veikė toliau.

## Retransliatoriai negali suklastoti, bet gali paslėpti

Klientas yra tik langas, todėl gali filtruoti brukalą ar paslėpti paskyrą, ir dažnai tai tau tik į naudą, bet visų kopijų iš tinklo ištrinti negali. Retransliatoriai įvykius pašalinti gali, taip pat ir gavę pasirašytą prašymą juos ištrinti, o kitas klientas gali parodyti tik tas kopijas, kurias dar pavyksta gauti. Retransliatorius saugo tai, kas užfiksuota, todėl gali tavo įvykių nepriimti, vėliau juos išmesti arba kuriam nors skaitytojui jų niekada neparodyti. Rašyti tavo vardu ar pakeisti to, ką parašei, jis negali, nes parašas nebeatitiktų tavo npub rakto, o tai patikrinti gali bet kuris klientas. Todėl prieinamumas priklauso nuo to, ar skelbi keliuose retransliatoriuose, kuriuos valdo skirtingi operatoriai, o tavo [retransliatorių sąrašas](https://github.com/nostr-protocol/nips/blob/master/65.md) kitiems klientams nurodo, kur tavęs ieškoti.

Lieka 2 patikimos trečiosios šalys. Pirmoji yra tai, kas tau pasako, kad npub raktas priklauso tam žmogui, apie kurį galvoji. NIP-05 adresas rodo tik tai, kad raktas įrašytas kuriame nors domene, o [jo specifikacijoje](https://github.com/nostr-protocol/nips/blob/master/05.md) sakoma, kad jis naudotoją identifikuoja, bet jo nepatikrina, todėl tau svarbaus žmogaus npub raktą gauk tiesiai iš jo paties. Antroji yra bet kokia programinė įranga, kurioje laikomas tavo nsec raktas, nes ji galėtų tavo vardu pasirašyti bet ką. Šią riziką mažina toliau aprašytos pasirašymo programėlės (angl. signers), nes raktas į klientus nepatenka. Tačiau klientas vis tiek gali piktnaudžiauti tavo suteiktais leidimais pasirašyti.

## Kaip pasirinkti klientą

Nostr dažnai pristatomas kaip tinklo „X“ alternatyva, tačiau tai tik 1 iš jo naudojimo būdų. Vieni klientai veikia kaip „Instagram“, kiti kaip „Medium“, „Twitch“, tinklalaidžių ar muzikos programėlė, prekyvietė, grupės pokalbis ar programėlių parduotuvė, ir visiems tinka tas pats raktas.

Svarbu aiškiai suprasti, ką gauni. Tinklas daug mažesnis už didžiąsias platformas, brukalo pasitaiko, o kai kurios programėlės atrodo nebaigtos. Slaptažodžio atkūrimo nėra, tikro ištrynimo taip pat, nes retransliatorių gali paprašyti ištrinti įvykį, bet jie gali to prašymo ir nepaisyti. Laikykis nuostatos, kad kiekvienas įrašas yra viešas ir lieka visam laikui.

Išskyrus „Fountain“, kurio kodas neskelbiamas, ir dalį „Wavlake“, toliau išvardyti klientai programos kodą skelbia pagal laisvąją licenciją (patikrinta jų viešose kodo saugyklose 2026 m. rugsėjį). Atvirasis kodas negarantuoja, kad programėlių parduotuvėje esanti versija atitinka viešą kodą, bet leidžia kiekvienam tai patikrinti.

| Klientas | Į ką panašus | Turinio tipas | Platformos | Kuo tenka pasitikėti |
|---|---|---|---|---|
| [**Primal**](https://primal.net/) | Į „X“. Pradėti čia lengviausia, yra įtaisyta piniginė. | Trumpi įrašai, straipsniai, medijos srautai | „iOS“, „Android“, naršyklė | Kas tave pasiekia, parenka „Primal“ podėlio serveris (angl. caching server). Jis yra [atvirojo kodo](https://github.com/PrimalHQ/primal-server), o nustatymuose galima nurodyti kitą. |
| [**Damus**](https://damus.io/) | Į „X“, primena tai, kaip kadaise atrodė „Twitter“. Paprastas. | Trumpi įrašai | „iOS“ | Su tavo retransliatoriais bendrauja tiesiogiai. Tavo nsec raktą telefone laiko pati programėlė. |
| [**Amethyst**](https://amethyst.social/) | Į „X“. Funkcijų turi daugiausia, todėl iš pradžių jų gausa gali trikdyti. | Trumpi įrašai ir dauguma kitų rūšių įvykių | „Android“ | Su tavo retransliatoriais bendrauja tiesiogiai. Naudojant pasirašymo programėlę „Amber“ nsec raktas į šį klientą išvis nepatenka. |
| [**Yakihonne**](https://yakihonne.com/) | Į „Medium“. | Ilgi straipsniai, atrinktas turinys, trumpi įrašai | „iOS“, „Android“, naršyklė | Viena bendrovė kuria programėles ir valdo savo retransliatorius. Galima naudoti nuotolinę pasirašymo programėlę. |
| [**Olas**](https://olas.app/) | Į „Instagram“. Naujos versijos pasirodo retai: parduotuvėje esanti „iPhone“ versija išleista 2025 m. kovą, o programėlė šiuo metu perrašoma. | Nuotraukos ir trumpi vaizdo įrašai | „iOS“, „Android“ | Su tavo retransliatoriais bendrauja tiesiogiai. Vaizdų failai laikomi medijos serveriuose, kurie gali juos pašalinti. |
| [**zap.stream**](https://zap.stream/) | Į „Twitch“. | Tiesioginės vaizdo transliacijos su pokalbiu ir zapais | Naršyklė, „iOS“, „Android“ | Pokalbis ir pranešimai apie transliacijas yra pasirašyti įvykiai. Vaizdas keliauja per srautinio perdavimo serverį, o numatytasis yra „zap.stream“ serveris. |
| [**Fountain**](https://fountain.fm/) | Į tinklalaidžių programėlę su komentarais ir mokėjimais laidoms. | Tinklalaidės, muzika | „iOS“, „Android“ | Viena bendrovė. Kodas neskelbiamas, o įtaisyta piniginė yra depozitinė (angl. custodial), t. y. raktus laiko įmonė. |
| [**Wavlake**](https://wavlake.com/) | Į „Spotify“ arba „Bandcamp“, tik nepriklausomiems atlikėjams. | Muzika, už kurią mokama tiesiai atlikėjams | Naršyklė, „iOS“, „Android“ | Viena bendrovė laiko muziką savo serveriuose ir tvarko mokėjimus atlikėjams. Naujausia „iPhone“ programėlės versija išleista 2025 m. lapkritį. |
| [**Shopstr**](https://shopstr.store/) | Į skelbimų prekyvietę. | Prekių skelbimai, atsiskaitoma bitkoinais | Naršyklė | Skelbimai yra pasirašyti įvykiai. Mokėjimas keliauja tiesiai pardavėjui, be sąlyginio deponavimo (angl. escrow), todėl pasitikrink, iš ko perki. |
| [**0xchat**](https://www.0xchat.com/) | Į „Telegram“ arba „WhatsApp“. | Privatūs ir grupių pokalbiai | „iOS“, „Android“, kompiuteris | Retransliatoriai perduoda šifruotas žinutes. Projektas jaunas ir laiko dar neišbandytas taip, kaip 1 skyriuje aprašytos susirašinėjimo programėlės. |
| [**Zapstore**](https://zapstore.dev/) | Į „Google Play“ arba „F-Droid“. | „Android“ programėlės | „Android“ | Kiekviena versija pasirašoma kūrėjo Nostr raktu ir prieš įdiegiant patikrinama. Kuriais katalogais ir kūrėjais pasitikėti, renkiesi tu. |
| [**Iris**](https://iris.to/), [**Coracle**](https://coracle.social/), [**noStrudel**](https://nostrudel.ninja/) | Į „X“ naršyklėje. „Coracle“ leidžia smulkiai valdyti retransliatorius, o „noStrudel“ išbando viską, ką protokolas gali. | Trumpi įrašai, o „noStrudel“ ir daugiau | Naršyklė („Iris“ veikia ir telefone) | Pasitiki svetaine, kuri per kiekvieną apsilankymą pateikia kodą. Prisijunk per plėtinį arba nuotolinę pasirašymo programėlę, o ne nsec raktu. „noStrudel“ galima paleisti nuosavame serveryje. |

Daugumai žmonių protingas derinys būtų toks: **mobilusis klientas** kasdieniam naudojimui („Primal“, „Damus“ arba „Amethyst“), **naršyklėje veikiantis klientas** kompiuteryje, naudojamas per pasirašymo programėlę, ir dar 1 ar 2 specializuoti klientai pagal tai, ką skaitai ir žiūri ar ko klausaisi.

## Apsaugok savo nsec raktą

Visa tavo tapatybė yra nsec raktas. Jei jis nutekėtų, kas nors galėtų tavo vardu skelbti tol, kol panorės, o pakeisti jo taip, kaip keiti slaptažodį, negali. Iš to kyla taisyklė: **niekada neįklijuok nsec rakto į svetainę, kurios nepažįsti**, ir apskritai klijuok jį į kuo mažiau vietų.

Tvarkingiausias sprendimas yra **pasirašymo programėlė**, nedidelė programėlė, kuri laiko raktą ir pasirašo už tavo klientus. Klientas paprašo, pasirašymo programėlė pasirašo, o rakto klientas taip ir nepamato. Patikrink, kokių leidimų prašoma, nepažįstamiems klientams nesuteik bendro leidimo viskam, o ryšius su klientais, kuriais nebesinaudoji, nutrauk. Galimybių yra keletas:

- **Amber**, skirta „Android“ sistemai: atvirojo kodo pasirašymo programėlė, kurią kitos Nostr programėlės iškviečia, kai joms reikia parašo.
- **Naršyklės plėtinys**, pavyzdžiui, „nos2x“ arba „Alby“, skirtas naršyklėje veikiantiems klientams kompiuteryje.
- **Nuotolinė pasirašymo programėlė**, dažnai vadinama „nsec bunker“: raktas lieka viename įrenginyje ar serveryje, o programėlės prie jo jungiasi per Nostr. Ji veikia visose platformose.

Telefonuose „iPhone“ tikslaus „Amber“ atitikmens kol kas nėra, nes sistemoje „iOS“ programėlės turi mažiau būdų iškviesti viena kitą. Yra kelios pasirašymo programėlės ir naršyklės „Safari“ plėtiniai, o naujausių sąrašą rasi kataloge nostrapps.com. Kitu atveju įprasta išeitis yra nuotolinė pasirašymo programėlė.

Tada pasidaryk nsec rakto atsarginę kopiją kaip ir bet kurio kito 6 skyriuje aprašyto rakto: popieriuje 2 vietose arba slaptažodžių tvarkyklėje, kol paskyros vertė maža.

## Žingsnis po žingsnio

Pavyzdžiu pasirinktas mobilusis klientas, o visuose kituose logika ta pati.

1. **Susikurk raktus kliente.** Įdiek jį ir pasirink „Create account“ (sukurti paskyrą). Nereikia nei el. pašto, nei telefono numerio, nes raktų porą programėlė sugeneruoja tavo telefone.
2. **Iš karto pasidaryk nsec rakto atsarginę kopiją.** Raktą rasi nustatymuose, prie raktų arba paskyros. Padaryk tai, kol dar nieko nepaskelbei.
3. **Užpildyk profilį**: įrašyk vardą, pridėk nuotrauką ir trumpą aprašymą ir nepamiršk, kad visa tai vieša.
4. **Jei nori, pridėk žmogui suprantamą adresą** (vadinamąjį NIP-05). Jis atrodo kaip el. pašto adresas, vardas@domenas, ir rodo, kad tavo raktas įrašytas tame domene, ir nieko daugiau. Kai kurios paslaugos tokį adresą suteikia, arba gali naudoti nuosavą domeną. Prisijungti juo negalima.
5. **Sek žmones.** Pagal vardą susirask PROOF pranešėjus, pridėk kelias paskyras, kurias klientas siūlo pradedantiesiems, ir sek kelias grotažymes. 1-ąją dieną srautas būna tuščias, ir tai normalu. Tau svarbių paskyrų npub raktą palygink su tuo, kurį žmogus nurodo savo svetainėje arba pasako gyvai: būtent šis žingsnis pasitikėjimą paieškos rezultatu pakeičia patikrinimu.
6. **Pridėk antrą klientą su pasirašymo programėle.** Sistemoje „Android“ įdiek programėlę „Amber“. Kompiuteryje įdiek naršyklės plėtinį, pavyzdžiui, „nos2x“ arba „Alby“. Telefone „iPhone“ išsirink pasirašymo programėlę arba „Safari“ plėtinį iš nostrapps.com arba nusistatyk nuotolinę pasirašymo programėlę. Vieną kartą importuok nsec raktą į pasirašymo programėlę, tada atverk naršyklėje veikiantį klientą ir pasirink prisijungimą per plėtinį arba pasirašymo programėlę. Patikrink, ar antrasis klientas randa tavo profilį ir kontaktų sąrašus ir ar skelbi keliuose nepriklausomuose retransliatoriuose. Perkeliamumas priklauso nuo to, ar šie duomenys lieka prieinami.
7. **Prijunk Lightning piniginę zapams.** Kad galėtum gauti, profilyje nurodyk Lightning adresą, o kad galėtum siųsti, susiek piniginę. Apie pinigines rašoma 3 dalyje.

## Klaidos, kurių verta vengti

- **Klijuoti nsec raktą į kiekvieną naują programėlę, kurią išbandai.** Kiekviena kopija yra rizika. Naudok pasirašymo programėlę arba naujas programėles bandyk su antru, vienkartiniu raktu.
- **Manyti, kad Nostr yra privatus.** Įrašai vieši, nes taip sumanyta. Asmeninės žinutės skirtingose programėlėse veikia skirtingai ir gali atskleisti, kas kam rašo. Privatiems pokalbiams naudok 1 skyriuje aprašytą susirašinėjimo programėlę.
- **Skelbti tai, ką galbūt norėsi ištrinti.** Retransliatoriai gauna prašymą ištrinti ir gali jo nepaisyti, o kopijų jau gali būti kitur.
- **Priklausyti nuo vieno retransliatoriaus.** Skelbk keliuose, valdomuose skirtingų operatorių, nes būtent iš to kyla atsparumas cenzūrai.
- **1-ąją dieną tikėtis to, ką randi didžiosiose platformose.** Tinklas mažesnis, o įdomus jis tampa tada, kai seki 30 ar 40 aktyvių žmonių.
- **Laikyti pinigus zapams skirtoje piniginėje.** Zapų piniginė skirta mažoms sumoms, net jei ji yra savarankiško saugojimo. Pavyzdžiui, įtaisyta „Primal“ piniginė iki 2026 m. buvo depozitinė. Nuo 3.0 versijos (2026 m. kovas) ji yra [savarankiško saugojimo](https://breez.technology/case-studies/primal), taigi atkūrimo žodžius turi tu, o veikia ji Spark pagrindu: tai neseniai sukurtas, su Lightning suderinamas Bitcoin sluoksnis, kurio garantijos iš dalies priklauso nuo Spark operatorių. Senesnėse apžvalgose vis dar aprašoma depozitinė versija, o įtaisyta „Fountain“ piniginė yra depozitinė. Santaupoms vieta kitur (žr. 3 dalį).

## Norintiems daugiau

- **PROOF konferencijoje:** „Kaip perkurti socialinius tinklus be juos valdančios įmonės naudojant Nostr“, pranešimą skaito Marius Off-Chain.
- **Vadovas pradedantiesiems:** nostr.how.
- **Klientų, pasirašymo programėlių ir įrankių katalogas:** nostrapps.com.
- **Pats protokolas**, smalsiems: NIP saugykla (github.com/nostr-protocol/nips).
- **Kitas skyrius:** kaip po vieną pakeisti technologijų milžinių paslaugas.

## Šaltiniai

- [NIP-09, event deletion requests](https://github.com/nostr-protocol/nips/blob/master/09.md), Nostr protokolo saugykla, tikrinta 2026 m. spalio 22 d.
- [NIP-46, remote signing and permissions](https://github.com/nostr-protocol/nips/blob/master/46.md), Nostr protokolo saugykla, tikrinta 2026 m. spalio 22 d.
- [Twitter won't let you post your Facebook, Instagram and Mastodon handles](https://techcrunch.com/2022/12/18/twitter-wont-let-you-post-your-facebook-instagram-and-mastodon-handles/), „TechCrunch“, 2022 m. gruodžio 18 d.
- [Commission finds Apple and Meta in breach of the Digital Markets Act](https://ec.europa.eu/commission/presscorner/detail/en/ip_25_1085), Europos Komisija, 2025 m. balandžio 23 d.
- [Damus pulled from Apple's App Store in China after two days](https://techcrunch.com/2023/02/02/damus-pulled-from-apples-app-store-in-china-after-two-days/), „TechCrunch“, 2023 m. vasario 2 d.
- [NIP-05: mapping Nostr keys to DNS-based internet identifiers](https://github.com/nostr-protocol/nips/blob/master/05.md), Nostr protokolo saugykla, žiūrėta 2026 m. rugsėjį.
- [NIP-65: relay list metadata](https://github.com/nostr-protocol/nips/blob/master/65.md), Nostr protokolo saugykla, žiūrėta 2026 m. rugsėjį.
- [Zapstore, an open app store](https://zapstore.dev/), „Zapstore“, žiūrėta 2026 m. rugsėjį.
- [Shopstr, a marketplace built on Nostr](https://shopstr.store/), „Shopstr“, žiūrėta 2026 m. rugsėjį.
- [Olas on the App Store](https://apps.apple.com/us/app/olas/id6738208592), „Apple“, 0.4.0 versija paskelbta 2025 m. kovo 11 d., žiūrėta 2026 m. rugsėjį.
- [Primal Server](https://github.com/PrimalHQ/primal-server), „PrimalHQ“ platformoje „GitHub“, žiūrėta 2026 m. rugsėjį.
- [Primal case study](https://breez.technology/case-studies/primal), „Breez“, 2026 m.
- [Primal for Android, release notes](https://github.com/PrimalHQ/primal-android-app/releases), „PrimalHQ“ platformoje „GitHub“, 3.0.7 versija paskelbta 2026 m. kovo 17 d.

## Tavo veiksmų sąrašas

- [ ] Įdiek klientą ir susikurk raktus (5 min.)
- [ ] Pasidaryk nsec rakto atsarginę kopiją popieriuje arba slaptažodžių tvarkyklėje (5 min.)
- [ ] Užpildyk profilį ir pradėk sekti PROOF pranešėjus (5 min.)
- [ ] Įdiek pasirašymo programėlę ir per ją prisijunk prie antro kliento (5 min.)
- [ ] Kai turėsi Lightning piniginę (žr. 13 ir 15 skyrius), profilyje nurodyk Lightning adresą ir nusiųsk pirmąjį zapą (1 val.)
