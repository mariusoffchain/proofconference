# Žodynėlis

Visoje knygoje pasikartojantys žodžiai, paaiškinti paprasta kalba.

## Privatumas

**Atpažinimas pagal skaitmeninį atspaudą (angl. fingerprinting).** Naršyklės ar įrenginio atpažinimas iš techninių jo savybių (ekrano, šriftų, nustatymų), net ir be slapukų.

**Atvirasis kodas (angl. open source).** Programinė įranga, kurios programos kodas viešas, o licencija leidžia ją naudoti, keisti ir platinti toliau. Vien viešo kodo nepakanka: licencijų skirtumai aptariami 10 ir 11 skyriuose.

**Autentiškumas (angl. authenticity).** Garantija, kad kitame gale tikrai yra tas žmogus, apie kurį galvoji, ir kad žinutė pakeliui nebuvo pakeista. Vien šifravimas jos nesuteikia.

**Dviejų veiksnių autentifikavimas, 2FA (angl. two-factor authentication).** Antras įrodymas šalia slaptažodžio: programėlės sugeneruotas kodas arba fizinis raktas.

**El. pašto pseudonimas (angl. email alias).** Vienkartinis adresas, iš kurio laiškai persiunčiami į tikrąją pašto dėžutę. Kiekvienai paslaugai skiriamas atskiras, todėl galima nustatyti, iš kur nutekėjo duomenys, ir tą adresą išjungti.

**Grėsmių modelis (angl. threat model).** Sąžiningas atsakymas į klausimą „nuo ko noriu apsisaugoti?“. Nuo jo priklauso, kiek apsaugos priemonių tau reikia.

**Išankstinis slaptumas (angl. forward secrecy).** Toks sprendimas, kai kada nors pavogtu raktu neįmanoma atrakinti anksčiau siųstų žinučių.

**Ištisinis šifravimas (angl. end-to-end encryption).** Šifravimas, kai raktus turi tik tu ir tavo pašnekovas. Tarpininkaujanti paslauga žinutę perduoda, bet perskaityti jos negali.

**Konfidencialumas (angl. confidentiality).** Žinutės negali perskaityti niekas, išskyrus 2 bendraujančius žmones.

**Maišymo tinklas (angl. mixnet).** Tinklas, kuris srautą ne tik siunčia per kelis šuolius, bet ir maišo bei vėlina, kad paslėptų laiko dėsningumus.

**Metaduomenys (angl. metadata).** Ne tai, ką sakai, o tai, su kuo bendrauji, kada, iš kur ir kaip dažnai. Dažnai jie pasako daugiau nei pats turinys.

**Patikima trečioji šalis (angl. trusted third party).** Tarpininkas, nuo kurio sąžiningumo priklauso visa sistema. Tokia yra ir susirašinėjimo programėlė, kuri naudotojų raktus dalija iš savo katalogo, net jei šifruoja ištisiniu būdu.

**Sekiklis (angl. tracker).** Svetainėje ar programėlėje esantis kodo fragmentas, kuris apie tavo veiksmus praneša trečiajai šaliai, dažniausiai reklamos bendrovei.

**SIM kortelės perėmimas (angl. SIM swap).** Sukčiavimas, kai kas nors įtikina tavo operatorių perkelti telefono numerį į sukčiaus SIM kortelę ir tada gauna tavo SMS kodus.

**Slaptažodžių tvarkyklė (angl. password manager).** Šifruota saugykla, kuri kiekvienai svetainei sukuria ir įsimena atskirą stiprų slaptažodį. Tau reikia prisiminti tik vieną.

**Šifravimas (angl. encryption).** Informacijos pavertimas neįskaitoma, kad ją perskaityti galėtų tik tas, kas turi tinkamą raktą.

**Tor.** Tinklas, kuris tavo srautą siunčia per kelis nepriklausomus savanorius taip, kad nė vienas iš jų nežinotų ir kas tu, ir ką lankai.

**VPN (angl. virtual private network).** Paslauga, kuri tavo srautą siunčia per savo serverį. Ji paslepia tavo veiklą nuo interneto paslaugų teikėjo, o tavo adresą nuo lankomų svetainių, tačiau pačia VPN bendrove tenka pasitikėti.

## Autonomija

**Decentralizuotas (angl. decentralised).** Valdomas daugelio nepriklausomų dalyvių, kai niekas negali vienas jo išjungti, cenzūruoti ar pakeisti taisyklių.

**Nostr.** Atvirasis socialinių tinklų protokolas. Tavo tapatybė yra raktų pora, o įrašai keliauja per retransliatorius, kuriuos gali paleisti bet kas.

**npub ir nsec.** Tavo viešasis raktas (npub, vieša tapatybė) ir slaptasis raktas (nsec, niekada juo nesidalyk) Nostr tinkle.

**Paslaugų laikymas nuosavame serveryje (angl. self-hosting).** Paslaugą paleidi kompiuteryje, kurį valdai tu, o ne nuomojiesi ją iš įmonės.

**Prieigos raktas (angl. passkey).** Raktų pora, kuria prisijungiama prie svetainės ar programėlės. Viešąją pusę saugo paslauga. Privačioji pusė lieka įrenginyje arba gali būti sinchronizuojama šifruotu pavidalu per prieigos raktų teikėją, o aparatinis saugos raktas ją laiko savyje.

**Privatusis raktas (angl. private key).** Ilgas slaptas skaičius, kurį turi tik tu. Jis įrodo, kad tu esi tu, o kas jį turi, tas valdo su juo susietą tapatybę arba pinigus.

**Retransliatorius (angl. relay).** Paprastas serveris, kuris saugo ir persiunčia Nostr įrašus. Gali naudotis keliais ir bet kada juos pakeisti.

**Viešasis raktas (angl. public key).** Privatųjį raktą atitinkantis skaičius, kuriuo gali laisvai dalytis. Kiti juo patikrina tavo parašą arba rašo tau žinutes.

**Zapas (angl. zap).** Nedidelis Lightning mokėjimas, siunčiamas kam nors Nostr tinkle kaip arbatpinigiai arba padėka.

## Pinigai ir santaupos

**CBDC, centrinio banko skaitmeninė valiuta (angl. central bank digital currency).** Centrinio banko skaitmeniniu pavidalu leidžiami pinigai. Kas gali matyti ar kontroliuoti mokėjimus, priklauso nuo valiutos sandaros ir įstatymų. Siūlomam skaitmeniniam eurui [ECB aprašo](https://www.ecb.europa.eu/euro/digital_euro/features/privacy/html/index.en.html) atsiskaitymų neprisijungus privatumą ir savo prieigos prie asmenį identifikuojančių mokėjimų duomenų apribojimus. Tai projektavimo įsipareigojimai, o ne jau veikianti sistema.

**Depozitinė piniginė, depozitinė paslauga (angl. custodial).** Piniginė ar paslauga, kai turtą už tave laiko įmonė. Patogu, tačiau tau priklauso tik pažadas.

**Infliacija (angl. inflation).** Kainų kilimas laikui bėgant, kitaip tariant, pinigų perkamosios galios mažėjimas. Nacionalinės valiutos sukurtos taip, kad kasmet netektų šiek tiek vertės.

**KYC, „pažink savo klientą“ (angl. know your customer).** Privalomas tapatybės tikrinimas, kurį atlieka finansų įmonės. Duomenų bazėje jis susieja tavo vardą ir pavardę su tuo, ką turi.

**Monero.** Skaitmeninė valiuta, kurios paskirtis panaši į Bitcoin (pinigai, kuriuos gali laikyti savarankiškai), tačiau joje sumos, siuntėjai ir gavėjai automatiškai paslėpti. Kai kurie pažengę naudotojai ją naudoja kaip privatų Bitcoin papildymą. Ji daug mažiau likvidi ir daug rečiau priimama, gerokai mažesnį jos tinklą kam nors iš šalies lengviau užpulti, kaip parodė 2025 m. blokų grandinės pertvarkymai (angl. reorg), o jos kūrimas labiau centralizuotas (žr. 12 skyrių).

**Sandorio šalies rizika (angl. counterparty risk).** Rizika, kad tas, kas už tave laiko turtą (bankas, finansų maklerio įmonė, birža), žlugs arba atsisakys jį grąžinti.

**Savarankiškas saugojimas (angl. self-custody).** Turtą laikai tu, be jokio tarpininko: monetos tavo rankoje, raktai tavo žinioje. Jokia įmonė negali jo įšaldyti, paskolinti ar prarasti už tave.

## Bitcoin

**Aparatinė piniginė (angl. hardware wallet).** Mažas specialus įrenginys, kuris raktus laiko atjungtus nuo interneto ir transakcijas pasirašo taip, kad kompiuteris ar telefonas raktų nepamatytų.

**Atkūrimo frazė (angl. seed phrase).** Žodžiai, kuriais atkuriami piniginės raktai. Pagal BIP39 dažniausiai jų būna 12 arba 24, tačiau yra ir kitų formatų, pavyzdžiui, 20 žodžių SLIP39 ir programos „Electrum“ savosios atkūrimo frazės. Atkuriant reikia suderinamos programinės įrangos ir papildomos slaptafrazės, jei ji naudojama, o žymėms, kelių parašų piniginės konfigūracijai ir Lightning būsenai gali prireikti atskirų atsarginių kopijų (žr. 14 skyrių).

**Bitcoin.** Skaitmeniniai pinigai be emitento, kurių kiekis iš anksto nustatytas: 21 mln. Taisyklių laikymąsi užtikrina tūkstančiai nepriklausomų kompiuterių.

**Darbo įrodymas (angl. proof of work).** Energija, kurią kasėjai turi išeikvoti, kad pridėtų bloką. Dėl jo perrašyti transakcijų istoriją būtų nepaprastai brangu.

**Lightning.** Ant Bitcoin pagrindo sukurtas mokėjimų tinklas, skirtas kasdienėms sumoms: mokėjimai įvyksta akimirksniu ir beveik nieko nekainuoja.

**Lygiarangis (angl. peer-to-peer, P2P).** Vykstantis tiesiogiai tarp 2 žmonių, kai tarp jų nėra lėšas laikančios įmonės.

**Mazgas (angl. node).** Kompiuteris, kuris laiko savo Bitcoin registro kopiją ir kiekvieną transakciją patikrina pagal taisykles.

**Pagrindinės grandinės transakcija (angl. on-chain).** Transakcija, įrašyta tiesiai į Bitcoin registrą. Patvirtinimo laikas ir mokesčiai skiriasi. Kuo daugiau patvirtinimų, tuo mažesnė rizika, kad transakcija bus atšaukta, tačiau absoliutaus galutinumo nėra. Dažnai tinka didesnėms sumoms.

**Piniginė (angl. wallet).** Programėlė arba įrenginys, kuris laiko tavo raktus ir pasirašo transakcijas. Monetų joje nėra, nes monetos yra įrašai bendrame registre.

**Satošis (angl. sat, satoshi).** Mažiausias bitkoino vienetas. 1 bitkoinas yra 100 mln. satošių.
