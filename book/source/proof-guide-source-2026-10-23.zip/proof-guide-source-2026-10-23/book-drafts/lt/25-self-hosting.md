# 10 skyrius: Kaip paleisti paslaugas nuosavame serveryje

## Trumpai

„Debesija“ yra svetimas kompiuteris. Paslaugų laikymas nuosavame serveryje reiškia, kad dalis paslaugų, pavyzdžiui, failai, nuotraukos, užrašai, o vėliau ir Bitcoin mazgas, veikia mažame tau priklausančiame kompiuteryje, kuris stovi namie. Pradedantiesiems skirtose platformose įdiegti programėlę dabar beveik taip pat lengva kaip telefone, tačiau apie atsargines kopijas, naujinius ir nuotolinę prieigą vis tiek teks pasiskaityti, ir visa tai taps tavo rūpesčiu. Protingiausia pradėti nuo 1 paslaugos, pasiekti, kad ji veiktų patikimai, ir tik tada plėstis.

## Svetimoje debesijoje tik nuomojiesi

Kai failai, nuotraukos ir kalendorius laikomi kurios nors bendrovės debesijoje, taisykles nustato ta bendrovė. Ji gali perskaityti viską, kas nešifruojama ištisiniu būdu, pakelti kainą, uždaryti produktą arba automatiniu sprendimu užblokuoti paskyrą, o tau tada belieka pildyti pagalbos tarnybos formą. Sąlygas ji gali pakeisti ir tada, kai jau persikėlei. „Google Photos“ daugelį metų siūlė nemokamą neribotą saugyklą, o 2020 m. lapkritį paskelbė, kad nuo 2021 m. birželio 1 d. [kiekviena nauja nuotrauka bus įskaičiuojama į 15 GB limitą](https://blog.google/products-and-platforms/products/photos/storage-changes/).

8 skyriuje parodyta, kaip pereiti prie teikėjų, kurie naudotojus gerbia labiau, ir tai jau didelis žingsnis, tačiau ir ten tik nuomojiesi.

Su nuosavu serveriu žengi dar vieną žingsnį, nes paslauga veikia tavo namuose stovinčiame įrenginyje, o duomenys laikomi tavo diske. Nebėra nei paskyros, kurią teikėjas galėtų sustabdyti, nei trečiosios šalies tarp tavęs ir failų.

Tačiau tai nėra nemokama. Moki už įrangą, elektrą ir atsarginę kopiją kitoje vietoje, moki savo laiku, o kai kas nors sugenda, atsakomybė tenka tau.

## Serveris yra kompiuteris, kuris lieka įjungtas

Serveris tėra kompiuteris, kuris visą laiką įjungtas ir atsako į kitų įrenginių užklausas, o namų ūkiui tam nereikia duomenų centro. Pakanka seno nešiojamojo kompiuterio, mažo mini kompiuterio arba „Raspberry Pi“. Patogiausia paprastai pradėti nuo mini kompiuterio arba nešiojamojo kompiuterio su SSD disku, o kompiuteriui „Raspberry Pi“ SSD diskas tinka labiau nei atminties kortelė, nes kortelės linkusios greitai susidėvėti.

Šiame kompiuteryje įdiegi **platformą**, t. y. sistemą, kuri pateikia tinklalapį su programėlių parduotuve. Atveri jį naršyklėje, prie „Nextcloud“ ar „Immich“ spusteli „Install“ (įdiegti), o platforma programėlę įdiegia ir ją valdo. Kai kurios platformos programėles viena nuo kitos atskiria konteineriais, tačiau „Linux“ konteineriai naudoja bendrą kompiuterio operacinės sistemos branduolį, o jų saugumas priklauso nuo konfigūracijos, todėl sandariomis saugumo dėžėmis jų laikyti negalima.

Tada telefonas ir nešiojamasis kompiuteris bendrauja ne su bendrove, o su šiuo kompiuteriu. Namie ryšys vyksta per tavo belaidį tinklą („Wi-Fi“), o būnant kitur reikia saugaus kelio į vidų, ir jam toliau skirtas atskiras skirsnis.

Technologijos yra mažesnioji šio pokyčio dalis, nes atsarginėmis kopijomis, naujiniais ir saugumu dabar rūpiniesi tu.

## Patikima trečiąja šalimi tampi tu

Kai paslaugos veikia nuosavame serveryje, konfidencialumas nebepriklauso nuo bendrovės, nes duomenų niekas kitas neturi, o visa kita tampa tavo rūpesčiu. Prieinamumas dabar priklauso nuo tavo disko, elektros ir atsarginių kopijų, o vietoj teikėjo inžinierių lieka tik tai, ką nepamiršti padaryti tu. Pradedantiesiems saugesnis pasirinkimas gali būti gerai tvarkomas teikėjas, taikantis ištisinį šifravimą. Visai geras rezultatas yra ir toks, kai kelios paslaugos veikia nuosavame serveryje, o kitos nuomojamos.

Kai kurios trečiosios šalys lieka, ir naudinga jas įvardyti. Platformos kūrėjas skelbia sistemos naujinius ir prižiūri programėlių parduotuvę, todėl neatsargus ar kenkėjiškas naujinys iškart pasiektų visus serverius. Atviras programos kodas ir galimybė pridėti kitą parduotuvę arba įdiegti programėlę ne iš parduotuvės leidžia šią šalį pakeisti kita. Nuotolinei prieigai naudojamos paslaugos „Tailscale“ koordinavimo serveris kiekvienam tavo įrenginiui perduoda kitų įrenginių viešuosius raktus. Duomenų srauto turinys tarp tavo įrenginių lieka šifruotas, net kai jį perduoda retransliatorius, tačiau „Tailscale“ dokumentacijoje [pripažįstama](https://tailscale.com/kb/1226/tailnet-lock), kad kenkėjiškas koordinatorius galėtų į tavo tinklą įterpti svetimą įrenginį, ir siūloma funkcija „Tailnet Lock“: ją įjungus kiekvieną naują įrenginį turi pasirašyti tavo įrenginiai. Naudojant „Headscale“ arba vien WireGuard šios trečiosios šalies nebelieka, tačiau tenka daugiau konfigūruoti.

## Kaip pasirinkti platformą

Visos šios platformos sukurtos žmonėms, kurie nėra sistemų administratoriai, o skiriasi paskirtimi, licencija ir tuo, kas jas kuria. Knygoje, kurioje pirmenybė teikiama atvirajam kodui, licencija svarbi. Sistema „StartOS“ platinama pagal [MIT licenciją](https://github.com/Start9Labs/start-technologies/blob/master/LICENSE), platforma „YunoHost“ taip pat yra laisvoji programinė įranga, o sistema „umbrelOS“ naudoja [licenciją „PolyForm Noncommercial“](https://github.com/getumbrel/umbrel/blob/master/LICENSE.md): pagal ją asmeniniais tikslais kodą galima skaityti ir keisti, tačiau tai nėra atvirojo kodo licencija. Ir bendrovė „Start9“, ir bendrovė „Umbrel“ parduoda savo serverius, tačiau nė viena jų pirkti nereikalauja, nes abi sistemas galima nemokamai įdiegti jau turimame kompiuteryje.

| Platforma | Kas kuria | Privalumas | Kompromisas | Kas valdo programėles ir naujinius |
|---|---|---|---|---|
| **Start9 (StartOS)** | Viena bendrovė, kuri parduoda ir serverius | Atvirasis kodas. Kuriama galvojant apie suverenitetą: Tor tinklas naudojamas automatiškai, o šifruotos atsarginės kopijos jau įtaisytos | Mažesnis programėlių katalogas, šiek tiek daugiau reikia išmokti | Sistemą valdo „Start9“. Yra 2 numatytieji registrai (angl. registries), [galima pridėti kitų](https://docs.start9.com/start-os/0.4.0.x/marketplace.html), o paketus galima įdiegti ir ne iš registro |
| **YunoHost** | Savanorių bendruomenė, ne pelno organizacija | Atvirasis kodas, pagrįsta „Debian“, daug programėlių, vienas prisijungimas prie jų visų | Skirta paslaugoms, pasiekiamoms iš interneto, todėl domenų ir el. pašto klausimai iškyla anksti. Sąsaja kuklesnė | Sistemą ir katalogą prižiūri savanoriai. Bet kurią programėlę galima [įdiegti ir iš URL adreso](https://doc.yunohost.org/en/admin/apps/custom_apps/) |
| **Umbrel (umbrelOS)** | Viena bendrovė, kuri parduoda ir savo įrangą | Labiausiai išbaigta sąsaja, didelė programėlių parduotuvė, stiprios Bitcoin ir Lightning programėlės | Kodas viešas, tačiau licencija nėra tikra atvirojo kodo licencija (komerciškai naudoti negalima) | Sistemą ir oficialią parduotuvę valdo „Umbrel“. Galima pridėti [bendruomenės programėlių parduotuvių](https://umbrel.com/support/apps/how-to-add-a-community-app-store), kurių „Umbrel“ netikrina |
| **CasaOS** | Viena bendrovė („IceWhale“) | Atvirasis kodas. Paprastas sluoksnis, kurį pridedi prie jau veikiančios „Linux“ sistemos | 2026 m. rugsėjo mėn. duomenimis, veikia tik priežiūros režimu, nes bendrovė dabar daugiausia dėmesio skiria naujesnei sistemai „ZimaOS“. Įtaisytų atsarginių kopijų nėra | Sluoksnį ir jo parduotuvę, kuri priima ir kitus programėlių šaltinius, valdo „IceWhale“. Sistemą valdo tavo „Linux“ distribucija |
| **Debian arba Ubuntu su Docker** | Tu | Visiška kontrolė, išmoksti, kaip viskas veikia iš tikrųjų, nepriklausai nuo jokios platformos | Komandų eilutė, ir nėra ko kaltinti. Smalsiems | Sistemos paketus valdo „Debian“ arba „Ubuntu“, o konteinerius kiekvieno atsisiunčiamo konteinerio atvaizdo (angl. image) leidėjas |

Ką paleisti pirmiausia:

| Programėlė | Ką pakeičia | Pastaba |
|---|---|---|
| **Nextcloud** | Debesų saugyklą, kalendorių, kontaktus | Klasikinė pirmoji programėlė. Nesudėtingink ir nediek visų priedų |
| **Immich** | Debesijos nuotraukų bibliotekas | Automatiškai daro telefono nuotraukų atsargines kopijas. Greitai keičiasi, todėl skaityk naujinių aprašus |
| **Jellyfin** | Savų filmų ir muzikos srautinį perdavimą | Maža rizika, geras mokomasis projektas |
| **Home Assistant** | Išmaniųjų namų debesijos paslaugas | Namų įrenginiai lieka vietiniame tinkle |
| **Vaultwarden** | Slaptažodžių tvarkyklės serverio dalį | Veikia su „Bitwarden“ programėlėmis. Ne pradedančiųjų projektas, nes sugedus serveriui be išbandytos atsarginės kopijos gali netekti visų slaptažodžių. Palauk, kol atkūrimas iš kopijos taps įprastu dalyku |
| **Bitcoin mazgas** | Pasitikėjimą svetimu mazgu | Vėliau. Žr. 18 skyrių |

Daugumai žmonių protingas derinys būtų atvirojo kodo platforma, pavyzdžiui, „StartOS“ arba „YunoHost“, mini kompiuteryje ir „Nextcloud“ arba „Immich“ kaip pirmoji programėlė. Labiausiai išbaigta alternatyva yra „umbrelOS“, jei tau tinka jos licencija.

## Kaip saugiai pasiekti serverį iš išorės

Namų maršrutizatorius paprastai atmeta iš interneto inicijuojamus prisijungimus, todėl už jo esantis serveris iš išorės tiesiogiai nepasiekiamas. Tačiau ši apsauga turi žinomų spragų. Daugelis maršrutizatorių parduodami su įjungta UPnP funkcija, leidžiančia bet kuriam tavo tinklo įrenginiui ar programėlei savarankiškai atidaryti prievadą, o naudojant IPv6 kiekvienas įrenginys gali gauti viešąjį adresą, kurį uždarytą laiko tik maršrutizatoriaus užkarda (ugniasienė). Verta atverti maršrutizatoriaus nustatymus, išjungti UPnP ir įsitikinti, kad IPv6 užkarda įjungta.

Klasikinė klaida yra tyčia atidaryti prievadą, kad failus būtų galima pasiekti iš bet kur. Tai veikia, tačiau kartu prisijungimo puslapį parodo kiekvienai internetą automatiškai skenuojančiai programai.

Saugesni būdai, nuo labiausiai nepriklausomo iki patogiausio:

- **WireGuard VPN į namus.** Telefonas atidaro šifruotą tunelį į tavo tinklą ir veikia taip, lyg būtų namie. Atvirasis kodas, jokių tarpininkų. Reikia šiek tiek sukonfigūruoti maršrutizatorių, be to, CGNAT (kai vienu viešuoju adresu dalijasi keli klientai) gali neleisti tiesioginio įeinančio ryšio, nebent pasirūpini kitu iš interneto pasiekiamu tašku arba veikiančiu IPv6 ryšiu. Tokiu atveju 2 toliau aprašyti būdai dažnai paprastesni.
- **Tor onion paslaugos.** Platformose „Umbrel“ ir „Start9“ jos įtaisytos, todėl serveris gauna privatų .onion adresą, pasiekiamą per Tor tinklą, ir nereikia atidaryti jokio prievado. Lėčiau, bet paprasta ir privatu.
- **Tailscale.** Sukurta WireGuard pagrindu ir labai lengvai įdiegiama serveryje ir telefone. Duomenų srautas tarp tavo įrenginių lieka šifruotas, tačiau prisijungimus ir paskyras koordinuoja bendrovė. **Headscale** yra atvirojo kodo šios koordinavimo dalies pakaitalas, kurį paleidi savo serveryje.

Kad ir ką pasirinktum, pirmiausia pakeisk visus numatytuosius slaptažodžius.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta sistema „StartOS“, nes ji yra atvirojo kodo ir įdiegiama įprastoje įrangoje. Platformose „YunoHost“ ir „umbrelOS“ logika ta pati.

1. **Pasirink įrangą.** Visiškai pakanka nenaudojamo nešiojamojo kompiuterio arba mini kompiuterio su 8 GB atminties ir SSD disku. Prie maršrutizatoriaus jį prijunk kabeliu, o ne per belaidį tinklą („Wi-Fi“).
2. **Įdiek platformą.** Iš projekto svetainės atsisiųsk sistemos atvaizdą, įrašyk jį į USB atmintuką, paleisk kompiuterį iš jo ir vykdyk diegimo programos nurodymus. Jei projektas skelbia kontrolinę sumą (angl. checksum), t. y. failo skaitmeninį atspaudą, kaip tai daro „Start9“ savo versijų puslapyje, sutikrink ją dar prieš įrašant atvaizdą, nes būtent šiuo žingsniu pasitikėjimą atsisiųstu failu pakeiti patikrinimu. Diegiant kompiuterio diskas ištrinamas.
3. **Susikurk paskyrą.** Iš kito to paties tinklo įrenginio atverk adresą, parodytą diegimo pabaigoje. Pasirink ilgą unikalų slaptažodį ir išsaugok jį slaptažodžių tvarkyklėje. Jei platforma siūlo dviejų veiksnių autentifikavimą (2FA), kaip „umbrelOS“ savo nustatymuose, įjunk jį.
4. **Įdiek 1 programėlę.** Tik 1. Pradėti verta nuo „Nextcloud“ arba „Immich“: įdiek telefono programėlę, įvesk savo serverio adresą ir leisk jai nukopijuoti nuotraukas.
5. **Nustatyk atsarginį kopijavimą.** Laikykis 3-2-1 taisyklės: 3 duomenų kopijos, 2 skirtinguose įrenginiuose, 1 kopija kitoje vietoje. Praktiškai tai serveris, antras diskas ir šifruota kopija kitur (diskas giminaičių namuose arba šifruota debesijos atsarginė kopija). „StartOS“ šifruotas atsargines kopijas įrašo į išorinį diską arba tinklo aplanką, o „umbrelOS“ gali [jas daryti automatiškai kas valandą](https://umbrel.com/support/backups-and-recovery/backing-up-your-data). Jei tavo platforma jų pagal tvarkaraštį nedaro, kalendoriuje susikurk pasikartojantį priminimą.
6. **Išbandyk atkūrimą.** Atkurk 1 failą iš atsarginės kopijos, nes kopija patikrinta tik tada, kai iš jos pavyko ką nors atkurti.
7. **Nuolat atnaujink.** Platformos ir programėlių naujinius peržiūrėk bent kartą per mėnesį, skaityk naujinių aprašus ir rūpinkis, kad atsarginės kopijos būtų naujausios. Svarbias saugumo pataisas įdiek iš karto: jei tavo sistemoje yra žinoma saugumo spraga, mėnesinės peržiūros nelauk.
8. **Tik tada pridėk antrą programėlę.** Kelias savaites pagyvenk su pirmąja ir tik tada plėskis.

## Klaidos, kurių verta vengti

- **Neturėti atsarginių kopijų.** Diskai genda be įspėjimo, ir profesionalūs prieglobos teikėjai nuo to neapsaugoti. 2021 m. kovo 10 d. gaisras Strasbūre [sunaikino „OVHcloud“ duomenų centrą SBG2](https://corporate.ovhcloud.com/en/newsroom/news/informations-site-strasbourg/), nukentėjo apie 120 000 paslaugų, o klientai, neturėję kopijos kitur, duomenis prarado. Namie atsarginėmis kopijomis rūpiniesi tu, todėl sutvarkyk jas anksčiau, nei patikėsi serveriui ką nors, ko negali prarasti.
- **Atverti paslaugas internetui su numatytaisiais slaptažodžiais.** Internetą automatiškai skenuojančios programos atviras paslaugas randa greitai. Naudok vieną iš pirmiau aprašytų saugių būdų ir visur unikalius slaptažodžius.
- **Pirmuoju projektu pasirinkti el. paštą arba slaptažodžius.** El. paštas yra sunkiausiai prižiūrima paslauga, nes dideli teikėjai dažnai atmeta laiškus iš namų serverių, o klaida reiškia prarastus laiškus. Jei slaptažodžių serveris sugenda, o išbandytos atsarginės kopijos nėra, nebepasieki ir viso kito. Naudokis geru teikėju (žr. 2 ir 4 skyrius), o savo serveryje pirmiausia paleisk kitas paslaugas.
- **Leisti šeimai priklausyti nuo serverio, kol jis dar nestabilus.** 1 ar 2 mėnesius naudokis juo tik savo reikmėms. Šeimos nuotraukas perkelk tik tada, kai atsarginės kopijos ir naujiniai taps įprastu dalyku.
- **Per anksti ištrinti debesijos kopiją.** Senąja paslauga naudokis lygiagrečiai, kol bent kartą atkursi duomenis iš savo atsarginės kopijos.
- **Pirmą savaitę įdiegti 20 programėlių.** Kiekvieną programėlę reikia atnaujinti ir apsaugoti, o pamirštosios tampa silpnąja serverio vieta.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kaip „kareivis-pilietis“ gali padėti decentralizuoti pasaulį: Rusijos invazijos į Ukrainą pamokos“, pranešimą skaito Alexis Roussel. Daug mažų serverių daugelyje namų išjungti sunkiau nei vieną didelį duomenų centrą.
- **Platformos:** start9.com, yunohost.org, umbrel.com, casaos.zimaspace.com.
- **Didelis katalogas programinės įrangos, kurią gali paleisti savo serveryje:** sąrašas „awesome-selfhosted“ (awesome-selfhosted.net).
- **Nuotolinė prieiga:** wireguard.com, tailscale.com ir „Headscale“ (headscale.net).
- **Kitas skyrius:** kaip naudotis DI ir neišsiduoti. Jame tame pačiame serveryje gali veikti kalbos modelis visai šeimai. Dar kartą serveris sugrįš 18 skyriuje, jau kaip Bitcoin mazgas.

## Šaltiniai

- [Docker Engine security](https://docs.docker.com/engine/security/), „Docker“ dokumentacija, tikrinta 2026 m. spalio 22 d.
- [Updating Google Photos' storage policy to build for the future](https://blog.google/products-and-platforms/products/photos/storage-changes/), „Google“, 2020 m. lapkričio 11 d.
- [Strasbourg datacentre: latest information](https://corporate.ovhcloud.com/en/newsroom/news/informations-site-strasbourg/), „OVHcloud“, 2021 m. kovo 18 d., atnaujinta iki 2021 m. balandžio mėn.
- [Umbrel licence (PolyForm Noncommercial 1.0.0)](https://github.com/getumbrel/umbrel/blob/master/LICENSE.md), „Umbrel“ platformoje „GitHub“, žiūrėta 2026 m. rugsėjį.
- [StartOS licence (MIT)](https://github.com/Start9Labs/start-technologies/blob/master/LICENSE), „Start9 Labs“ platformoje „GitHub“, žiūrėta 2026 m. rugsėjį.
- [Backing up your data](https://umbrel.com/support/backups-and-recovery/backing-up-your-data), „umbrelOS Support“, žiūrėta 2026 m. rugsėjį.
- [Tailnet Lock](https://tailscale.com/kb/1226/tailnet-lock), „Tailscale“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [Marketplace](https://docs.start9.com/start-os/0.4.0.x/marketplace.html), „StartOS“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [Adding a community app store](https://umbrel.com/support/apps/how-to-add-a-community-app-store), „umbrelOS Support“, žiūrėta 2026 m. rugsėjį.
- [Installing custom apps](https://doc.yunohost.org/en/admin/apps/custom_apps/), „YunoHost“ dokumentacija, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Surask kompiuterį, kuris gali likti įjungtas, pavyzdžiui, seną nešiojamąjį kompiuterį, mini kompiuterį arba „Raspberry Pi“ (5 min.)
- [ ] Įdiek platformą ir pirmąją programėlę (savaitgalis)
- [ ] Nustatyk automatinį atsarginį kopijavimą į antrą diską ir kopiją kitoje vietoje (1 val.)
- [ ] Atkurk failą iš atsarginės kopijos ir patikrink, ar tai veikia (5 min.)
- [ ] Pasirink saugų būdą pasiekti serverį iš išorės ir pakeisk visus numatytuosius slaptažodžius (1 val.)
