# 4 skyrius: Tavo el. paštas ir pseudonimai

## Trumpai

El. pašto adresas yra raktas į visas kitas tavo paskyras ir žymė, pagal kurią visame internete susiejami tavo profiliai. Perkelk paštą į paslaugą, kurios teikėjas išsilaiko iš prenumeratos, o ne iš reklamos, ir gali pašto dėžutę užšifruoti taip, kad jos neperskaitytų net pati bendrovė. Tada liaukis visiems dalyti tikrąjį adresą ir naudok pseudonimus, kiekvienai paslaugai vis kitą adresą. Matysi, kas tavo adresą nutekina ar parduoda, ir galėsi išjungti 1 pseudonimą, o visi kiti veiks kaip veikę.

## Adresas, siejantis visas tavo paskyras

Beveik kiekvienos paskyros slaptažodį galima atkurti el. paštu, todėl tas, kas valdo tavo pašto dėžutę, gali spustelėti „pamiršau slaptažodį“ banko, socialinių tinklų ir debesų saugyklos svetainėse. Pašto dėžutė yra dar ir tavo gyvenimo archyvas: joje sąskaitos, bilietai, registracijos pas gydytojus ir daugelio metų susirašinėjimas.

Populiariausios pašto dėžutės nemokamos todėl, kad tavo laiškus pristatanti bendrovė verčiasi ir reklama. Bendrovė „Google“ [2017 m. birželį paskelbė](https://blog.google/products/gmail/g-suite-gains-traction-in-the-enterprise-g-suites-gmail-and-consumer-gmail-to-more-closely-align/), kad reklamai pritaikyti nebeskenuos asmeninių „Gmail“ pašto dėžučių turinio, tačiau pašto dėžutė tebėra susieta su paskyra, kurioje gali būti saugomos dar ir paieškos užklausos, vaizdo įrašai, buvimo vietų istorija.

Dar lieka pats adresas, kurį nurodai parduotuvėms, naujienlaiškiams, programėlėms ir valstybės įstaigoms. Jis niekada nesikeičia, todėl duomenų prekeiviai (angl. data brokers) pagal jį gali sujungti atskiras duomenų bazes į vieną tavo profilį. Kai į kurią nors iš tų paslaugų įsilaužiama, adresas patenka į sąrašus, naudojamus brukalui siųsti ir sukčiauti apsimetant (angl. phishing), t. y. siųsti netikrus laiškus, kuriais siekiama išvilioti slaptažodžius. 2020 m. iš aparatinių piniginių gamintojos „Ledger“ rinkodaros duomenų bazės [nutekėjo apie 1 mln. klientų el. pašto adresų](https://www.ledger.com/message-ledgers-ceo-data-leak) ir maždaug 272 000 klientų siuntų pristatymo duomenys, o paskui prasidėjo sukčiavimo apsimetant kampanijos el. paštu ir SMS žinutėmis.

## Šifruota pašto dėžutė ir visur vis kitas adresas

**Šifruoto el. pašto paslaugos teikėjas** pašto dėžutę saugo tokiu pavidalu, kad bendrovė jos perskaityti negali. Paslaugose „Proton Mail“ ir „Tuta“ taip yra visada, o laiškai, kuriais keičiasi 2 to paties teikėjo naudotojai, šifruojami ištisiniu būdu. Paslaugose „Mailbox.org“ ir „Posteo“ šifravimą įsijungi tu.

Laiškas, išsiųstas įprastu „Gmail“ ar „Outlook“ adresu, ištisiniu būdu nešifruojamas ir ten lieka perskaitomas. Šifravimas saugo turinį, o ne metaduomenis (kas kam rašo ir kada), be to, teismas vis tiek gali įpareigoti teikėją atiduoti tai, ką jis turi. 2021 m. rugsėjį bendrovė „Proton“ [patvirtino, kad Šveicarijos institucijų nurodymu privalėjo fiksuoti vieno klimato aktyvisto IP adresą](https://proton.me/blog/climate-activist-arrest) (skaičių, identifikuojantį interneto ryšį), o laiškų turinys liko nepasiekiamas. Privatiems pokalbiams naudok kurią nors susirašinėjimo programėlę iš 1 skyriaus.

**Pseudonimas** yra persiuntimo adresas, pavyzdžiui, parduotuves-pavadinimas@pseudonimu-paslauga, sukurtas vienai parduotuvei. Į jį siunčiami laiškai atkeliauja į tavo pašto dėžutę, o tikrojo adreso parduotuvė taip ir nepamato. Jei į tą pseudonimą ima plūsti brukalas, žinai, kas jį nutekino ar pardavė, ir išjungi jį 1 spustelėjimu. Duomenų prekeiviams sunkiau susieti tavo paskyras, nes kiekviena paslauga tave pažįsta vis kitu adresu.

## Kas gali tavo laiškus perskaityti, suklastoti ar užrakinti

El. paštas sukurtas be šifravimo ir be siuntėjo tapatybės įrodymo, todėl ir jo konfidencialumas, ir autentiškumas, ir prieinamumas priklauso nuo teikėjo. Iš įprastos pašto dėžutės siunčiamas laiškas teikėją pasiekia perskaitomas ir tik paskui užšifruojamas saugoti, taigi tenka pasikliauti tuo, kad bendrovė nepasiliks kopijos, platins sąžiningas programėles ir neuždarys tavo paskyros. Pseudonimų paslaugos operatorius yra antra tokia pati trečioji šalis, nes per jo serverius keliauja kiekvienas persiunčiamas laiškas.

Ištisinis šifravimas atriboja teikėją nuo turinio tik tada, kai raktus turi abu galai, t. y. kai abu žmonės naudojasi to paties teikėjo paslauga arba kai tarp 2 teikėjų taikomas PGP. Tada kito žmogaus raktą pateikia teikėjas, kaip ir susirašinėjimo programėlės katalogas (žr. 1 skyrių). Paslaugoje „Proton“ galima [pažymėti, kad kontakto raktas patikimas](https://proton.me/support/address-verification), o „Tuta“ [2025 m. rugpjūtį pridėjo raktų patvirtinimą QR kodu](https://tuta.com/blog/key-verification). Jei naudoji PGP, rakto atspaudą (angl. fingerprint) turi palyginti kitu kanalu.

Prieinamumas yra ta savybė, kurią galima decentralizuoti pigiai. Turint nuosavą domeną teikėją galima pakeisti kitu, o stebėti tada reikia jau domenų registratorių. Paleisti nuosavą el. pašto serverį įmanoma, tačiau jį reikia apsaugoti ir dar pasiekti, kad jo laiškus priimtų kiti serveriai, todėl pirmajam projektui jis menkai tinka.

## Kaip pasirinkti el. pašto paslaugos teikėją

Visus toliau išvardytus variantus finansuoja jų naudotojai, o ne reklama. Skiriasi kaina, šifravimo būdas ir tai, ar galima naudotis įprasta el. pašto programa.

| Teikėjas | Kur įsikūręs | Kuo tenka pasitikėti | Kaina | Kompromisai |
|---|---|---|---|---|
| **[Proton Mail](https://proton.me/mail)** | Šveicarija | Bendrovė „Proton“ mato įprastus gaunamus laiškus prieš juos užšifruodama ir pateikia tavo kontaktų raktus. Pažymėti raktus patikimais neprivaloma, tai pasirenkama patikra. | Nemokamas planas, mokami planai | Pašto dėžutė šifruojama visada. Programėlės atvirojo kodo, ekosistema didelė (kalendorius, debesų saugykla, VPN). Laiškų temos ištisiniu būdu nešifruojamos. Norint naudotis įprastomis el. pašto programomis reikia mokamo plano ir papildomos programos „Bridge“ (tiltas). |
| **[Tuta](https://tuta.com/)** | Vokietija | Bendrovė „Tuta“ mato įprastus gaunamus laiškus prieš juos užšifruodama ir pateikia tavo kontaktų raktus. Raktų patvirtinimas pasirenkamas. | Nemokamas planas, mokami planai | Pašto dėžutė šifruojama visada. Programėlės atvirojo kodo, šifruojamos ir laiškų temos. Naudoja savo šifravimo sistemą, todėl neveikia nei su įprastomis el. pašto programomis, nei su PGP (senesniu el. pašto šifravimo standartu). |
| **[Mailbox.org](https://mailbox.org/en/)** | Vokietija | Bendrovė „Mailbox.org“ gali skaityti saugomus laiškus tol, kol neįjungi gautų laiškų šifravimo. Jei naudoji PGP, raktus tikrini tu. | Mokama, kaina nedidelė | Klasikinė pašto dėžutė, veikianti su bet kuria el. pašto programa. Gautų laiškų šifravimas (naudojant PGP) pasirenkamas, jį įsijungi tu. Mobiliuosiuose įrenginiuose ne tokia išbaigta. |
| **[Posteo](https://posteo.de/en)** | Vokietija | Bendrovė „Posteo“ gali skaityti saugomus laiškus tol, kol neįjungi šifravimo. Jei naudoji PGP, raktus tikrini tu. | Mokama, kaina nedidelė | Veikia su bet kuria el. pašto programa, sumokėti galima anonimiškai, net paštu siunčiamais grynaisiais pinigais. Saugomų laiškų šifravimas pasirenkamas, jį įsijungi tu. Nuosavo domeno naudoti negalima. |
| **Nuosavas domenas** | Ten, kur veikia tavo pašto dėžutė | Turinį patiki tam pačiam teikėjui, o dar tenka pasitikėti domenų registratoriumi. Joks teikėjas negali pasilikti tavo adreso. | Metinis domeno mokestis ir mokama pašto dėžutė | Adresas vardas@tavo-pavarde.lt, o pašto dėžutę aptarnauja vienas iš pirmiau išvardytų teikėjų. Vėliau teikėją galėsi pakeisti, o adresas liks tas pats. Jokiu būdu nepamiršk pratęsti domeno galiojimo. |

Daugumai žmonių protingas derinys būtų toks: 1 pašto dėžutė iš šio sąrašo (jei šifravimas joje pasirenkamas, jį įjunk) ir pseudonimų paslauga. Jei tą patį adresą ketini naudoti dar 20 metų, apie nuosavą domeną pagalvok iš karto.

## Kaip pasirinkti pseudonimų paslaugą

Pseudonimų paslauga yra tarpininkė tarp pasaulio ir tavo pašto dėžutės. Ji persiunčia tavo paštą ir techniškai gali matyti per ją keliaujančius laiškus, todėl rinkis operatorių, kuriuo pasitiki tiek pat, kiek ir el. pašto paslaugos teikėju.

| Paslauga | Kas ją valdo | Kaina | Kompromisai |
|---|---|---|---|
| **[SimpleLogin](https://simplelogin.io/)** | „Proton“ (Šveicarija) | Nemokamame plane pseudonimų skaičius ribotas, mokamame neribotas | Kodas atviras. Iš pseudonimo galima ir atsakyti, ir siųsti laiškus. Veikia su bet kuria pašto dėžute, ne tik su „Proton“. Įtraukta į kai kuriuos mokamus „Proton“ planus. |
| **[Įtaisyti „Proton“ pseudonimai](https://proton.me/pass/aliases)** („hide-my-email“, t. y. „paslėpk mano el. paštą“) | „Proton“ (Šveicarija), naudojama „SimpleLogin“ technologija | Nemokamame ir „Mail Plus“ planuose pseudonimų skaičius ribotas (2026 m. rugsėjo mėn. duomenimis, 10), su „Pass Plus“ arba „Proton Unlimited“ planu neribotas | Kuriami tiesiog paslaugoje „Proton Mail“ arba slaptažodžių tvarkyklėje „Proton Pass“. Labai patogu, jei tavo pašto dėžutė yra „Proton“ paslaugoje. Tada ir pašto dėžutė, ir pseudonimai atsiduria tos pačios bendrovės rankose, taigi praradus šią paskyrą arba ją užblokavus netenki abiejų. |
| **[addy.io](https://addy.io/)** | Mažas nepriklausomas operatorius | Dosnus nemokamas planas, mokami planai | Kodas atviras, paslaugą galima paleisti ir nuosavame serveryje. Maža komanda kartu yra ir vienintelis gedimo taškas (angl. single point of failure). |
| **[DuckDuckGo Email Protection](https://duckduckgo.com/email/)** | „DuckDuckGo“ (JAV) | Nemokama | Naudotis labai paprasta. Pašalina el. laiškuose paslėptus sekiklius. Reikia programėlės „DuckDuckGo“ arba jos naršyklės plėtinio. |
| **[Firefox Relay](https://relay.firefox.com/)** | „Mozilla“ (JAV) | Nemokamas planas su keliais pseudonimais, už didesnį skaičių reikia mokėti | Paprasta, įtaisyta naršyklėje „Firefox“. Nemokamame plane pseudonimų nedaug. |
| **Papildomi el. pašto paslaugos teikėjo adresai** | Tavo el. pašto paslaugos teikėjas | Paprastai įtraukta į mokamus planus | „Proton Mail“, „Tuta“, „Mailbox.org“ ir „Posteo“ leidžia prie tos pačios pašto dėžutės pridėti dar kelis adresus. Nereikia pasitikėti niekuo nauju, bet adresų skaičius ribotas. |
| **Adresas su pliuso ženklu (angl. plus addressing)** | Bet kuris teikėjas | Nemokama | vardas+parduotuve@domenas.com. Praverčia laiškams rūšiuoti, bet privatumą saugo menkai, nes jame matomas tikrasis adresas, o dalį „+parduotuve“ lengva pašalinti. |

Daugumai žmonių protingas derinys būtų atskira pseudonimų paslauga su naršyklės plėtiniu, kad kur nors registruojantis pseudonimą būtų galima sukurti 1 spustelėjimu. Jei pasirinksi ne tą operatorių, kuris teikia tau el. pašto paslaugą, abu dalykai nepriklausys nuo vienos bendrovės.

## Vienkartinės pašto dėžutės, kai adreso reikia tik kartą

Į kai kurias svetaines daugiau niekada nebegrįši, pavyzdžiui, kai reikia vieną kartą atsisiųsti failą, prisijungti prie belaidžio tinklo („Wi-Fi“) per jo portalą ar paskaityti forumą, į kurį užsuki vieną kartą. Tokiais atvejais pakanka vienkartinės pašto dėžutės. Registruotis nereikia. Adresą sugalvoji čia pat, įrašai jį į formą, o tada paslaugos svetainėje atveri pašto dėžutę ir perskaitai laišką.

Tokiose viešose paslaugose slaptažodžio nėra, todėl pašto dėžutę gali skaityti kiekvienas, kas adresą atspėja arba žino. Laiškai greitai ištrinami, tikėtis vėliau juos rasti negalima, o daugelis svetainių tokių domenų nepriima. Taigi vienkartinė pašto dėžutė tinka patvirtinimo kodui, kuris nesaugo nieko svarbaus. Ji netinka nei paskyrai, kurią nori išlaikyti, nei tam, kur yra asmens duomenų, nei ten, kur vėliau galėtų būti atsiųstas slaptažodžio atkūrimo laiškas, nes jį gautų kiekvienas, įvedęs tą patį adresą. Visais kitais atvejais pseudonimas tinka geriau.

| Paslauga | Kaip gauni adresą | Kiek laiko saugomi laiškai | Kompromisai |
|---|---|---|---|
| **[Mailinator](https://www.mailinator.com/)** | Sugalvoji bet kokį vardą jos viešajame domene | Kelias valandas | Visiškai vieša, todėl kiekvienas, įvedęs tą patį vardą, skaito tą pačią pašto dėžutę. Laiškus galima tik gauti. Sukurta daugiausia programinės įrangos testuotojams, yra mokamų privačių planų. Daug svetainių ją blokuoja. |
| **[Guerrilla Mail](https://www.guerrillamail.com/)** | Gauni atsitiktinį adresą arba susigalvoji savo | 1 valandą | Slaptažodžio nėra, todėl pašto dėžutę saugo tik tai, kad jos pavadinimą sunku atspėti. Siūlo „sumaišytą“ adresą (angl. scrambled), kad atspėti būtų sunkiau. |
| **[Maildrop](https://maildrop.cc/)** | Sugalvoji bet kokį vardą jos viešajame domene | Ne daugiau kaip 10 laiškų, pašto dėžutė išvaloma, jei 24 valandas negaunama naujų laiškų | Visiškai vieša, slaptažodžio nėra. Priedai pašalinami. |

## Kai svetainė reikalauja telefono numerio

Telefono numeris yra dar stipresnis identifikatorius nei el. pašto adresas. Jo nekeiti daugelį metų, jis susieja tavo paskyras, pritraukia nepageidaujamų skambučių, o dar į jį taikosi SIM kortelės perėmimo (angl. SIM swap) atakos (žr. 2 skyrių). Pirmiausia patikrink, ar laukelis tikrai privalomas. Jei taip, turi keletą variantų, tik nė vienas nėra tobulas.

| Variantas | Kaip tai veikia | Kompromisai |
|---|---|---|
| **Antra SIM arba eSIM kortelė, naudojama tik registracijoms** | Tikras įprasto operatoriaus mobiliojo ryšio numeris, laikomas atskirai nuo asmeninio | Priimamas visur. Išankstinio mokėjimo numeriai nustoja galioti, jei sąskaitos nepapildai. Daugelyje ES šalių SIM kortelei įsigyti reikia asmens dokumento, taip pat ir [Lietuvoje nuo 2025 m. sausio perkant naujas išankstinio mokėjimo korteles](https://www.lrt.lt/en/news-in-english/19/2412964/end-to-anonymity-lithuania-to-require-users-to-register-phone-sim-cards). Taisyklės skiriasi, o šis variantas atskiria tavo numerius, bet anonimiškumo nesuteikia. |
| **Virtualiųjų (VoIP) numerių programėlės:** [„JMP.chat“](https://jmp.chat/), [„Hushed“](https://hushed.com/), [„MySudo“](https://mysudo.com/) | Mokamas numeris, veikiantis internetu per programėlę | „JMP.chat“ kodas atviras, bet siūlomi tik JAV ir Kanados numeriai. „Hushed“ (kodas uždaras) siūlo JAV, Kanados ir Jungtinės Karalystės numerius. „MySudo“ (kodas uždaras) galima įdiegti tik keliose šalyse, todėl pirma pasitikrink, o tik tada ja pasikliauk. Daugelis paslaugų VoIP numerių nepriima, o Europos svetainė gali nepriimti užsienio numerio. |
| **Bitkoinais apmokama duomenų eSIM kortelė,** pavyzdžiui, [„Silent.link“](https://silent.link/) | Paskyros nereikia. Į kai kuriuos planus įeina JAV arba Jungtinės Karalystės mobiliojo ryšio numeris, kuriuo galima gauti SMS žinutes | Kainuoja daugiau nei įprasta SIM kortelė. Numeris nuomojamas metams ir dingsta, jei nuomos nepratęsi. Paslaugą teikia vienas mažas operatorius. |
| **Mokamos paslaugos vienkartinei SMS žinutei gauti** | Kelioms minutėms išsinuomoji numerį, kad gautum vieną kodą | Paskui numeris atitenka kam nors kitam, ir tas žmogus galėtų juo pasinaudoti paskyrai perimti. Kokybė labai nevienoda, o daugelis svetainių savo sąlygose tai draudžia. |
| **Nemokamos viešos svetainės SMS žinutėms gauti internetu (angl. „receive SMS online“)** | Bendri numeriai, kuriais gautos žinutės rodomos tinklalapyje | Tavo kodą mato visi. Numeriai naudojami pakartotinai, ir dauguma jų jau užblokuoti. Tinka tik tam, kas visiškai nesvarbu. |

Šie variantai taip pat turi ribas. Praradus prieigą prie numerio galima prarasti ir paskyrą, todėl nei bankui, nei dviejų veiksnių autentifikavimui (2FA), nei kuriai nors kitai svarbiai paskyrai niekada nenaudok numerio, kurio nevaldai. Laikykis svetainės naudojimo sąlygų ir savo šalies įstatymų. Siekiama tik to, kad asmeninio numerio nereikėtų duoti kiekvienai parduotuvei ir programėlei.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta pašto dėžutė „Proton Mail“ ir pseudonimų paslauga „SimpleLogin“, nes jos dažnai būna pirmasis žingsnis. Abi priklauso bendrovei „Proton“, ir tai patogu, tačiau tada ir pašto dėžutė, ir pseudonimai priklauso nuo vienos bendrovės. Jei nori riziką paskirstyti, pasilik šią pašto dėžutę, o pseudonimams pasirink „addy.io“, arba pasilik „SimpleLogin“ ir pasirink kitą pašto dėžutę, nes žingsniai tie patys.

1. **Susikurk naują pašto dėžutę.** Pasirink adresą, kurį galėsi naudoti daugelį metų. Apsaugok ją ilgu unikaliu slaptažodžiu iš slaptažodžių tvarkyklės ir antruoju veiksniu (žr. 2 skyrių). Įjunk atkūrimo frazę ir užsirašyk ją ant popieriaus. Ja galima atkurti ir prieigą, ir šifruotus duomenis, o vien slaptažodžio atkūrimas el. paštu ar SMS žinute senų laiškų neiššifruos. Kad galėtum ja pasikliauti, pirmiausia patikrink teikėjo atkūrimo instrukcijas.
2. **Paruošk pseudonimų paslaugą.** Susikurk paskyrą, susiek ją su naująja pašto dėžute ir įdiek paslaugos naršyklės plėtinį (ir programėlę telefonui, jei tokia yra).
3. **Pirmiausia perkelk svarbiausias paskyras.** Tai bankas, valstybės paslaugos, mobiliojo ryšio operatorius, „Apple“ arba „Google“ paskyra ir slaptažodžių tvarkyklė. Kiekvienoje pakeisk el. pašto adresą. Gali nurodyti tikrąjį naująjį adresą arba atskirą pseudonimą, kaip tau labiau patinka, tik pasižymėk pasirinkimą slaptažodžių tvarkyklėje.
4. **Įjunk persiuntimą iš senosios pašto dėžutės.** Jos nustatymuose įjunk automatinį persiuntimą į naująją. Dauguma šifruoto pašto teikėjų siūlo ir importavimo įrankį, kuris nukopijuoja senus laiškus ir kontaktus.
5. **Visa kita perkelk pamažu.** Kaskart, kai persiųstas laiškas ateina iš paslaugos, kuria vis dar naudojiesi, pakeisk ten adresą nauju pseudonimu. Nebenaudojamas paskyras ištrink.
6. **Kiekvienai naujai registracijai kurk naują pseudonimą.** Parduotuvė, naujienlaiškis ar belaidžio tinklo portalas gauna po atskirą adresą. Pseudonimą pavadink pagal paslaugą, kad būtų lengva atsekti nutekėjimą.
7. **Senąjį adresą pasilik bent metams.** Neištrink jo, nes į jį dar ilgai eis pamirštų paskyrų, senų kontaktų ir slaptažodžių atkūrimo laiškai.

## Klaidos, kurių verta vengti

- **Manyti, kad pasirinkus šifruoto pašto teikėją visas el. paštas tampa privatus.** Jis apsaugo tavo pašto dėžutę, o į įprastą pašto dėžutę išsiųstas laiškas kitame gale lieka perskaitomas.
- **Per anksti ištrinti senąjį adresą.** Kai kurie teikėjai apleistus adresus atiduoda naujiems naudotojams, ir tada pamirštų paskyrų slaptažodžių atkūrimo laiškus galėtų gauti nepažįstamas žmogus.
- **Pamesti atkūrimo frazę.** Vien atkūrus slaptažodį seni laiškai gali likti neperskaitomi. Duomenų atkūrimo būdą nustatyk ir apsaugok iš anksto. Bendrovė „Proton“ siūlo atkūrimo frazę ir kitus būdus.
- **Leisti nuosavam domenui nustoti galioti.** Tas, kas jį užregistruos po tavęs, gaus tavo paštą ir galės atkurti tavo paskyrų slaptažodžius. Įjunk automatinį pratęsimą ir žiūrėk, kad mokėjimo kortelės duomenys nebūtų pasenę.
- **Visur naudoti tą patį pseudonimą.** Pseudonimas, kuriuo dalijasi 10 paslaugų, tėra antras tikrasis adresas, nes nauda atsiranda tik tada, kai kiekvienai paslaugai skiriamas vis kitas pseudonimas.
- **Banko paskyrą patikėti pseudonimų paslaugai, kuria iki galo nepasitiki.** Kelioms svarbiausioms paskyroms visiškai tinka ir tikrasis adresas, kurį tau suteikė el. pašto paslaugos teikėjas.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl nuo tavo raktų priklauso tavo interneto sauga“, pranešimą skaito Satoshine. Šifruota pašto dėžutė veikia todėl, kad ją atrakinantį raktą turi tik tu.
- **Išsamiai palygink teikėjus:** „Privacy Guides“, [„Email Services“](https://www.privacyguides.org/en/email/) ir [„Email Aliasing“](https://www.privacyguides.org/en/email-aliasing/).
- **Patikrink, ar tavo adresas jau nutekėjo:** [„Have I Been Pwned“](https://haveibeenpwned.com/).
- **Kitas skyrius:** tavo tinklas.

## Šaltiniai

- [Proton Account recovery explained](https://proton.me/support/set-account-recovery-methods), „Proton Support“, tikrinta 2026 m. spalio 22 d.
- [As G Suite gains traction in the enterprise, G Suite's Gmail and consumer Gmail to more closely align](https://blog.google/products/gmail/g-suite-gains-traction-in-the-enterprise-g-suites-gmail-and-consumer-gmail-to-more-closely-align/), „Google“, 2017 m. birželio 23 d.
- [Message by Ledger's CEO: update on the July data breach](https://www.ledger.com/message-ledgers-ceo-data-leak), „Ledger“, 2020 m. gruodžio 21 d.
- [Important clarifications regarding arrest of climate activist](https://proton.me/blog/climate-activist-arrest), „Proton“, 2021 m. rugsėjo 6 d.
- [Address verification with trusted keys](https://proton.me/support/address-verification), „Proton“, žiūrėta 2026 m. rugsėjį.
- [Tuta introduces key verification](https://tuta.com/blog/key-verification), „Tuta“, 2025 m. rugpjūčio 26 d.
- [End to anonymity: Lithuania to require users to register phone SIM cards](https://www.lrt.lt/en/news-in-english/19/2412964/end-to-anonymity-lithuania-to-require-users-to-register-phone-sim-cards), LRT, 2024 m. lapkričio 14 d.

## Tavo veiksmų sąrašas

- [ ] Susikurk pašto dėžutę paslaugoje, kurią finansuoja jos naudotojai (1 val.)
- [ ] Paruošk pseudonimų paslaugą ir įdiek jos naršyklės plėtinį (1 val.)
- [ ] Susikurk pirmąjį pseudonimą ir panaudok jį per kitą registraciją (5 min.)
- [ ] 5 svarbiausiose paskyrose nurodyk naująjį adresą (1 val.)
- [ ] Įjunk persiuntimą iš senosios pašto dėžutės ir perkelk likusias paskyras (savaitgalis)
