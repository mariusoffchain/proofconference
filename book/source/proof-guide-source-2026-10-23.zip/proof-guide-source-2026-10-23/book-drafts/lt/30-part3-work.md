# 3 dalis: Darbo įrodymas

## Kodėl svarbu apsaugoti savo darbą

### Santaupos yra sukauptas darbas

Gyvenimo valandas mainai į pinigus, o ko neišleidi šiandien, pasilieki vėlesniam laikui: būstui, vaikams, sunkiems metams ar senatvei. Taupyti reiškia siųsti savo darbą į ateitį.

Kad tai pavyktų, vieta, kurioje laikai santaupas, turi išlaikyti 2 išbandymus. Kai santaupų prireiks, jos turi būti dar ko nors vertos ir tą dieną vis dar tavo, tai yra pasiekiamos ir tinkamos naudoti. Daugiausia dėmesio sulaukia pirmasis išbandymas, o antrasis paprastai pamirštamas, kol kam nors neužblokuojama sąskaita arba apie kurį nors banką neprabyla žiniasklaida.

Šios dalies pavadinimas turi 2 reikšmes. Pirmoji yra tavo darbo įrodymas: tai, ką uždirbai, ir kaip tai išsaugoti. Antroji yra „darbo įrodymas“ (angl. „proof of work“), mechanizmas, saugantis Bitcoin tinklą. Bitcoin yra vienas iš tolesniuose skyriuose atidžiai nagrinėjamų įrankių, tačiau į visus klausimus jis neatsako, ir šioje dalyje taip neteigiama.

### Pinigai, sukurti taip, kad nuvertėtų

Euro, kaip ir bet kurios nacionalinės valiutos, kiekis nėra fiksuotas. Naujų pinigų sukuria centriniai bankai, o skolindami ir komerciniai bankai. Kai pinigų daugėja greičiau nei prekių ir paslaugų, kurias už juos galima nusipirkti, kainos paprastai kyla.

Lėtas kainų kilimas yra viešai skelbiamas tikslas. Nuo 2021 m. liepos Europos Centrinis Bankas (ECB) siekia, kad [vidutiniu laikotarpiu infliacija būtų 2 % per metus](https://www.ecb.europa.eu/press/pr/date/2021/html/ecb.pr210708~dc78cc4b0d.en.html). Skaičius atrodo mažas, tačiau jo poveikis kaupiasi, nes kiekvienų metų 2 % skaičiuojami nuo jau pakilusių kainų. Lentelėje parodyta, kas nutinka grynaisiais arba sąskaitoje be palūkanų laikomiems pinigams, kai viskas vyksta pagal planą.

| Po kiek laiko | Kiek maždaug pakyla kainos | Kiek maždaug lieka perkamosios galios |
|---|---|---|
| Po 10 metų | 22 % | 82 % |
| Po 15 metų | 35 % | 74 % |
| Po 20 metų | 49 % | 67 % |
| Po 50 metų | 169 % | 37 % |

Tai palankusis scenarijus. Kitais laikotarpiais infliacija tikslą gerokai viršija: Eurostato duomenimis, 2022 m. spalį [metinė infliacija euro zonoje siekė 10,6 %, o Lietuvoje 22,1 %](https://ec.europa.eu/eurostat/documents/2995521/15265521/2-17112022-AP-EN.pdf/b6953137-786e-ed9c-5ee2-6812c0f8f07f).

Nekilnojamojo turto ar akcijų turintys žmonės iš dalies apsaugoti, nes šio turto kainos paprastai irgi kyla, o samdomi darbuotojai, pensininkai ir visi, kurie kas mėnesį po truputį atsideda pinigų, tokios apsaugos neturi. Be to, šią kainą moka ne tie, kurie sprendžia, kiek pinigų sukurti. Šią mintį PROOF konferencijoje pranešime „Kodėl centralizuoti pinigai neveikia: kaip Bitcoin tapo alternatyva“ plėtoja Piktas.

### Turtas, kuriam reikia leidimo

Europos Centrinio Banko duomenimis, 2024 m. euro zonoje [52 % mokėjimų parduotuvėse atlikta grynaisiais pinigais](https://www.ecb.europa.eu/press/pr/date/2024/html/ecb.pr241219~172b929461.en.html), o 2022 m. tokių mokėjimų buvo 59 %. Įprasti banko ir kortelių mokėjimai susiejami su tavo tapatybe, saugomi ne vienus metus, o juos analizuoja tavo bankas, kortelių tinklas arba mokėjimo programėlė. Iš mokėjimų sąrašo matyti, kur buvai, pas kurį gydytoją lankeisi ir kokią veiklą remi.

Tas pats pasakytina ir apie turtą. Banko sąskaitos likutis, akcija, fondas ar pensija yra įrašas tarpininko duomenų bazėje, o tas tarpininkas žino, kas esi, teikia duomenis institucijoms ir gali atsisakyti tave aptarnauti. Prie kiekvieno įėjimo laukia tapatybės tikrinimas (KYC, angl. „know your customer“, t. y. „pažink savo klientą“), o dalis per jį surinktų pasų kopijų galiausiai nuteka.

Įvedus centrinių bankų skaitmenines valiutas (CBDC) pinigų emitentas atsidurtų pačiame mokėjimo kelyje. 2025 m. spalio 30 d. ECB [perkėlė skaitmeninio euro projektą į kitą etapą](https://www.ecb.europa.eu/press/pr/date/2025/html/ecb.pr251030~8c5b5beef0.en.html): bandomasis etapas numatytas nuo 2027 m. vidurio, o pirmoji emisija galima 2029 m., jei bus priimtas ES reglamentas, dėl kurio, 2026 m. rugsėjo mėn. duomenimis, dar deramasi. Šią temą PROOF konferencijoje pranešime „CBDC, KYC ir kova dėl monetarinio privatumo“ nagrinėja Linas K.

### Tobulo turto nėra

Tobulos vietos darbo vaisiams laikyti nėra. Grynieji pinigai privatūs, bet juos graužia infliacija. Banko indėlis patogus, tačiau teisiškai tai paskola bankui, pagal ES teisę apdrausta [iki 100 000 eurų vienam indėlininkui viename banke](https://eur-lex.europa.eu/EN/legal-content/summary/deposit-guarantee-schemes.html), bet ne daugiau. Nusipirkus akcijų tau priklauso dalis tikrų įmonių, tačiau akcijos laikomos per tarpininkų grandinę, o ši yra centralizuota, stebima ir lengvai įšaldoma. Auksas neturi emitento ir labai ilgai išlaikė vertę, tačiau jis sunkus, jį nelengva pervežti ir juo nelengva atsiskaityti. Bitcoin kiekis fiksuotas, ir bitkoinus gali laikyti visiškai savarankiškai, tačiau ši sistema jauna, kaina smarkiai svyruoja, o klaidų ji neatleidžia. Monero paskirtis panaši: tai pinigai, kuriuos gali laikyti savarankiškai ir kurie automatiškai užtikrina stiprų privatumą, tačiau Monero daug mažiau likvidus ir priimamas daug rečiau, gerokai mažesnį jo tinklą pašalinei jėgai lengviau užpulti, o jo kūrimas labiau centralizuotas (žr. 12 skyrių).

Todėl klausimas „kokia investicija geriausia?“ nenaudingas, ir ši knyga į jį neatsakys, nes joje nėra jokių investavimo patarimų. Naudinga klausti apie kontrolę: kas turtą laiko, kas gali jį įšaldyti, kas jį stebi, kas gali jo sukurti daugiau ir ar gali jį pasiimti su savimi.

### Įgūdis, kuriam išmokti pakanka mažų sumų

Pirmiausia išsiaiškink, kokia tavo padėtis, o tada išmok to, ko reikia, kad dalį santaupų galėtum laikyti savarankiškai. Tam pakanka labai mažų sumų: tai įgūdis, kurį verta įgyti, o ne lažybos. Įprastos teisinės ir mokestinės prievolės ir toliau galioja.

7 šios dalies skyriai:

12. **Kur laikyti savo darbo vaisius:** grynieji pinigai, bankai, akcijos, auksas, Bitcoin ir Monero palyginami pagal klausimus, svarbius tavo suverenitetui.
13. **Tavo pirmoji piniginė ir pirmieji satošiai:** įdiek Bitcoin piniginę, kurios raktus laikai tu, ir gauk pirmą nedidelį mokėjimą.
14. **Kaip pasidaryti atkūrimo frazės atsarginę kopiją:** atkūrimo žodžiai, saugantys tavo raktus, ir kaip jų neprarasti.
15. **Lightning ir eurai kasdienybėje:** momentiniai smulkūs mokėjimai ir bitkoinų keitimas į eurus bei atgal.
16. **Privatumas Bitcoin tinkle:** kiekviena transakcija vieša, todėl sužinok, ką ji atskleidžia ir kaip tai apriboti.
17. **Aparatinės piniginės:** atskiras įrenginys sumoms, kurių telefone nelaikytum.
18. **Kaip paleisti savo mazgą:** viską tikrink savarankiškai ir nebeklausk svetimo serverio.

12 skyriuje pateikiamas bendras vaizdas. 13-18 skyriuose išsamiai nagrinėjamas Bitcoin, nes iš visų sąrašo įrankių būtent jam reikia daugiausia naujų įgūdžių ir jis sukurtas taip, kad viską galėtum laikyti ir tikrinti visiškai savarankiškai.

## Šaltiniai

- [ECB's Governing Council approves its new monetary policy strategy](https://www.ecb.europa.eu/press/pr/date/2021/html/ecb.pr210708~dc78cc4b0d.en.html), Europos Centrinis Bankas, 2021 m. liepos 8 d.
- [Annual inflation up to 10.6% in the euro area](https://ec.europa.eu/eurostat/documents/2995521/15265521/2-17112022-AP-EN.pdf/b6953137-786e-ed9c-5ee2-6812c0f8f07f), Eurostatas, 2022 m. lapkričio 17 d.
- [Digital payments continue to rise, albeit at a slower pace; cash remains a key payment method](https://www.ecb.europa.eu/press/pr/date/2024/html/ecb.pr241219~172b929461.en.html), Europos Centrinis Bankas, 2024 m. gruodžio 19 d.
- [Eurosystem moving to next phase of digital euro project](https://www.ecb.europa.eu/press/pr/date/2025/html/ecb.pr251030~8c5b5beef0.en.html), Europos Centrinis Bankas, 2025 m. spalio 30 d.
- [Deposit guarantee schemes, summary of Directive 2014/49/EU](https://eur-lex.europa.eu/EN/legal-content/summary/deposit-guarantee-schemes.html), „EUR-Lex“, žiūrėta 2026 m. rugsėjį.
