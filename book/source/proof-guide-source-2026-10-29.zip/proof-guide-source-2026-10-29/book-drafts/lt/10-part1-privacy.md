# 1 dalis: Privatumo įrodymas

## Kodėl privatumas svarbus

### „Neturiu ko slėpti“

Niekam neatrodo įtartina, kad žmonės užsidaro vonios duris, užklijuoja voką ar neviešina algos ir ligos istorijos, tačiau tie patys žmonės dažnai sako, kad internete neturi ko slėpti. Privatumas nėra slaptumas. Tai galia rinktis, kuo, su kuo ir kada dalijiesi, kitaip tariant, įprasta riba tarp tavęs ir likusio pasaulio.

Kai šio pasirinkimo nebelieka, žmonės paprastai ima elgtis kitaip. Po to, ką 2013 m. birželį paviešino Snowdenas, tyrėjas Jon Penney nustatė, kad [enciklopedijos „Wikipedia“ straipsnių su terorizmu susijusiomis temomis lankomumas statistiškai reikšmingai sumažėjo](https://btlj.org/data/articles2016/vol31/31_1/0117_0182_Penney_ChillingEffects_WEB.pdf). Tyrimo rezultatai 2016 m. paskelbti žurnale „Berkeley Technology Law Journal“. Tų puslapių niekas nebuvo uždraudęs. Skaitytojai, pasijutę stebimi, juos atverdavo rečiau, o tas pats refleksas gali sulaikyti ir žmones, kurie norėtų paprieštarauti, pranešti apie piktnaudžiavimą ar tiesiog būti kitokie.

Teiginys „neturiu ko slėpti“ remiasi dar ir 2 prielaidomis: kad taisyklės niekada nepasikeis ir kad tas, kieno rankose tavo duomenys, visada bus geranoriškas, kompetentingas ir niekada nenukentės nuo įsilaužėlių. Šio regiono istorija, dar gyva žmonių atmintyje, duoda pagrindo abejoti pirmąja prielaida. Toliau aprašytas Suomijos atvejis duoda pagrindo abejoti antrąja.

### Metaduomenys pasako daugiau nei žodžiai

Beveik viskas, ką darai internete, palieka pėdsaką: paieškos užklausos, buvimo vieta, žmonės, kuriems rašai, ir laikas, kada tai darai.

Net kai žinutės turinys užšifruotas, metaduomenys paprastai lieka nešifruoti, o jie rodo, kas su kuo bendrauja, kaip dažnai ir iš kur. Skambutis onkologui, paskui advokatui, o tada draudimo bendrovei papasakoja istoriją, nors niekas neperskaitė nė sakinio. Generolas Michael Hayden, vadovavęs ir JAV Nacionalinio saugumo agentūrai (NSA), ir Centrinei žvalgybos valdybai (CŽV), 2014 m. viešuose debatuose Johnso Hopkinso universitete apie tai pasakė taip: [„Mes žudome žmones remdamiesi metaduomenimis.“](https://www.nybooks.com/online/2014/05/10/we-kill-people-based-metadata/) Šį sakinį žurnale „The New York Review of Books“ pacitavo tą dieną su juo diskutavęs teisės profesorius David Cole.

Šie pėdsakai nelieka ten, kur atsirado. Duomenų prekeiviai (angl. data brokers) sujungia juos į profilius ir parduoda reklamos užsakovams, draudikams ar politinių kampanijų organizatoriams, o dalis sukauptų duomenų galiausiai nuteka. Suomijoje iš psichoterapijos centrų tinklo „Vastaamo“ pavogtos dešimtys tūkstančių terapijos įrašų, o nuo 2020 m. spalio apie 22 000 pacientų pranešė gavę [el. laiškus, kuriuose reikalauta 500 eurų](https://krebsonsecurity.com/2024/04/man-who-mass-extorted-psychotherapy-patients-gets-six-years/) už tai, kad jų seansų užrašai nebūtų paviešinti. Nutekėjusį slaptažodį galima pakeisti, o gimimo datos, namų adreso, veido ar ligos istorijos nepakeisi.

### 5 įpročiai, dėl kurių svetimos akys mato gerokai mažiau

Nereikia nei išnykti, nei turėti eksperto žinių, nes privatumas nėra „viskas arba nieko“ ir su kiekvienu žingsniu kiti apie tave mato vis mažiau.

Pirmiausia paklausk savęs, nuo ko iš tikrųjų nori apsisaugoti: nuo reklamos užsakovų ir duomenų prekeivių, nuo sukčių, nuo buvusio partnerio, nuo darbdavio ar nuo valstybės. Nuo atsakymo priklauso, kiek apsaugos priemonių tau reikia. Daugumai žmonių aktualiausios pirmosios 2 grupės, o kad apie tave būtų matoma gerokai mažiau, pakanka kelių įpročių:

1. privati susirašinėjimo programėlė,
2. unikalūs slaptažodžiai ir antrasis veiksnys,
3. sekimą blokuojanti naršyklė,
4. el. pašto pseudonimai,
5. apsaugotas tinklo ryšys.

Apie juos ir yra 5 šios dalies skyriai. Jie vienas nuo kito nepriklauso, todėl pradėk nuo to, kuris atrodo lengviausias, o ne nuo to, kuris atrodo svarbiausias. Kiekvienas baigiasi 5 veiksmų sąrašu, ir kiekviename skyriuje bent 1 iš tų veiksmų atliksi per 5 minutes.

## Šaltiniai

- [Chilling Effects: Online Surveillance and Wikipedia Use](https://btlj.org/data/articles2016/vol31/31_1/0117_0182_Penney_ChillingEffects_WEB.pdf), Jonathon W. Penney, „Berkeley Technology Law Journal“, 2016 m.
- [„We Kill People Based on Metadata“](https://www.nybooks.com/online/2014/05/10/we-kill-people-based-metadata/), David Cole, „The New York Review of Books“, 2014 m. gegužės 10 d.
- [Man Who Mass-Extorted Psychotherapy Patients Gets Six Years](https://krebsonsecurity.com/2024/04/man-who-mass-extorted-psychotherapy-patients-gets-six-years/), „Krebs on Security“, 2024 m. balandžio 30 d.
