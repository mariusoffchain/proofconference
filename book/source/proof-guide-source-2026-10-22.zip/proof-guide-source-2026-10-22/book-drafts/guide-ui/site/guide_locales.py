"""Interface strings of the 2 site editions of A Guide to Autonomy (/book/en/ and /book/), read by build_integration.py.

Every word of the interface the build writes, and every word the browser script (dist/app.js, SITE mode) shows later,
comes from one of the 2 classes below: English reproduces the strings of the English-only build, Lithuanian follows
book-drafts/lt/LT-TRANSLATION-GUIDE.md (tu, gender-neutral, no em or en dash, „ “ quotation marks, digits, the noun
form required by each number). Sentences that contain a number are methods, so that each language builds its own
grammar instead of filling an English pattern. The texts of the book itself come from the Markdown sources.

Lithuanian plural forms: 1, 21, 31... take the 1st form, 2 to 9, 22 to 29... the 2nd, 10 to 20 and round numbers the
3rd (genitive plural). The same rule is in dist/app.js for the strings it receives.
"""

import html
import re


def esc(s):
    return html.escape(str(s), quote=True)


def plural_index(lang, n):
    if lang == 'lt':
        d, h = n % 10, n % 100
        if d == 1 and h != 11:
            return 0
        if 2 <= d <= 9 and not 11 <= h <= 19:
            return 1
        return 2
    return 0 if n == 1 else 1


class English:
    lang = 'en'
    og_locale = 'en_US'
    title_sep = ' — '
    site_home = '/en/'                      # PROOF <conference> link
    title_lang = ''                         # lang attribute around the English book title: none in English
    lang_link = {'code': 'LT', 'lang': 'lt', 'name': 'Lietuvių', 'aria': 'LT, lietuviška versija'}

    FORMS = {
        'chapter': ('chapter', 'chapters'), 'action': ('action', 'actions'), 'term': ('term', 'terms'),
        'option': ('option', 'options'), 'row': ('row', 'rows'), 'column': ('column', 'columns'),
        'part_opening': ('part opening', 'part openings'), 'path': ('reading path', 'reading paths'),
    }

    storage = 'Your ticks and read marks are saved in this browser only, on this device, with no account.'
    noscript_ticks = 'Ticking an action needs JavaScript. The list stays readable without it.'
    noscript_read = 'Marking this chapter as read requires JavaScript.'

    kind_label = {'brief': '', 'explain': 'Understand', 'compare': 'Compare', 'steps': 'Tutorial',
                  'pitfalls': 'Watch out', 'further': 'Go further', 'sources': 'References',
                  'checklist': 'Act', 'glossary': 'Terms'}
    in_brief = 'In brief'
    # Markdown IDs of the structural headings of a chapter (lt/LT-TRANSLATION-GUIDE.md, part E, for Lithuanian).
    kind_by_id = {'in-brief': 'brief', 'step-by-step': 'steps', 'mistakes-to-avoid': 'pitfalls',
                  'go-further': 'further', 'sources': 'sources', 'your-checklist': 'checklist'}
    sources_id = 'sources'
    # Verified first-column labels of the 33 source tables: their first cells become row headers.
    row_header_columns = {'client', 'app source', 'system', 'provider', 'option', 'device', 'route', 'messenger',
                          'manager', 'family', 'asset', 'need', 'wallet', 'browser', 'service', 'search engine',
                          'where', 'app', 'method', 'after', 'key', 'platform', 'habit', 'tool', 'approach'}

    cited = 'Cited in this section'
    scroll_hint = 'Scroll sideways →'
    effort_sr = ', effort: '
    see_all_actions_link = 'See all actions on one page'
    reference = 'Reference'
    before_chapters = 'Before the chapters'
    global_checklist = 'Global checklist'
    all_actions = 'All actions'
    cover = 'Cover'
    back_to_cover = 'Back to the cover'
    book_kicker = 'Book'
    on_this_page = 'On this page'
    previous = 'Previous'
    next = 'Next'
    pager_chapters = 'Chapters of the book'
    pager_pages = 'Pages of the book'
    start_reading = 'Start reading'
    read_intro = 'Read the introduction'
    where_to_start = 'Where to start?'
    general_contents = 'General contents'
    contents = 'Contents'
    edition_coverage = 'Edition coverage'
    this_edition = 'This edition'
    stat_chapters_here = 'chapters readable here'
    stat_actions_here = 'checklist actions usable here'
    in_this_browser = 'In this browser'
    your_progress = 'Your progress'
    stat_actions_done = 'actions done'
    stat_chapters_read = 'chapters marked as read'
    progress_help = ('Tick actions in a chapter checklist, or on the page of all actions, to update the actions count. '
                     'Use the "I have read this chapter" checkbox at the end of a chapter to update the reading count. '
                     'Scrolling through a page does not mark it as read.')
    open_checklist = 'Open a checklist'
    ticks_removable = 'Ticks can be removed at any time from each checklist.'
    shared_progress = 'The English and Lithuanian pages of the book share these ticks and read marks.'
    clear_progress = 'Clear my progress in this browser'
    colophon_kicker = 'Colophon'
    about_edition = 'About this edition'
    no_ads = 'No ads and no account. Only the source links you open lead to other sites.'
    talk_recordings = 'Talk recordings'
    replays_intro = 'Recordings of the talks of PROOF 2026. Each one links to the page of the book on its subject.'
    to_go_deeper = 'To go deeper'
    orientation = 'Orientation'
    start_lead = ('Autonomy is built gradually.',
                  'Pick a concrete need, explore its chapter, then start with 1 action suited to your situation.')
    method = 'Method'
    how_chapters_work = 'How each chapter works'
    anatomy = (('The need', 'What is at stake, and why it concerns you.'),
               ('Options and limits', 'Tools compared side by side, with what each one asks of you.'),
               ('Steps', 'A step-by-step tutorial for one reasonable setup.'),
               ('Sources', 'Linked next to the passages they support, and listed at the end.'))
    read_this = 'I have read this chapter'
    part_chapters_title = 'The chapters of this part'
    drawer_aria = 'Book contents'
    skip = 'Skip to content'
    search_button = 'Search'
    site_sr = ' &lt;conference&gt;, the conference site'
    search_title = 'Search the guide'
    close = 'Close'
    search_label = 'Questions, tools, steps and words'
    search_scope = ('Full text covers every page of this edition: the chapters, the introduction, the part openings, '
                    'the glossary, the checklist actions and the guide pages.')
    search_progress_text = 'Actions done and chapters read, saved in this browser. Open a checklist. Clear progress.'
    search_how_text = 'The need, options and limits, steps, sources. Checklist with effort tags, 1 action at a time.'
    path_kicker = 'Where to start? · Path'

    # Strings shown later by dist/app.js (published in site-data*.js). Plural forms are lists.
    js = {
        'readLabel': ' · read',
        'readState': 'Marked as read',
        'resetCleared': 'Your progress in this browser has been cleared.',
        'resetConfirm': 'Confirm: clear all ticks and read marks',
        'resetPress': 'Press again to confirm.',
        'searchLoading': 'Loading the search index.',
        'searchError': 'The search index could not be loaded. Check the connection and open the search again.',
        'searchTry': 'Try',
        'searchResults': 'Results',
        'searchNone': 'No match in the pages of this edition.',
        'searchCount': ['{n} result', '{n} results'],
        'searchShown': ', the first {shown} shown',
        'resume': 'Continue reading: ',
        'resumeChapter': 'Chapter {n} · {title}',
        'offlineReady': ('Offline copy: saved in this browser. Every page of the English and Lithuanian editions, the '
                         'search, the glossary and all actions open without a connection, chapters not opened yet '
                         'included. Links to other sites need a connection.'),
        'offlineSaving': 'Offline copy: being saved in this browser. Keep this page open and online for a moment.',
        'offlineFailed': 'Offline copy: not saved. Reload this page while online to try again.',
        'offlineNone': 'Offline copy: not available in this browser. The pages work online.',
    }

    # Texts of config.js for this language: English keeps config.js as it is.
    config = None

    # ----- numbers -----

    def form(self, n, key):
        return self.FORMS[key][plural_index(self.lang, n)]

    def n(self, n, key):
        return '%d %s' % (n, self.form(n, key))

    # ----- labels of pages and sections -----

    def doc_label_chapter(self, n):
        return 'Ch. %d' % n

    def part_opening(self, n):
        return 'Part %d opening' % n

    def chapter_n(self, n):
        return 'Chapter %d' % n

    def part_n(self, n):
        return 'Part %d' % n

    def part_label(self, n, name):
        return 'Part %d · %s' % (n, name)

    def chapter_kicker(self, n, part_name):
        return 'Chapter %d · %s' % (n, part_name)

    def part_kicker(self, n, name):
        return 'Part %d · %s · Opening essay' % (n, name)

    def opening_essay_of(self, n):
        return 'Opening essay of part %d' % n

    def sr_chapter(self, n):
        return 'Chapter %d: ' % n

    def sr_part(self, n):
        return 'Part %d: ' % n

    def part_title(self, n, title):
        return 'Part %d: %s' % (n, title)

    def chapter_of(self, n, total):
        return 'Chapter %d of %d' % (n, total)

    def part_opens(self, n, link_html):
        return 'Part %d opens with an essay: %s' % (n, link_html)

    def step_title(self, i, name):
        return 'Step %d: %s' % (i, name)

    def compared_in(self, title):
        return 'Compared in “%s”' % title

    def checklist_action(self, effort):
        return 'Checklist action' + (', ' + effort if effort else '')

    def count_done(self, stat_html, total):
        """'<strong ...>0</strong> of 5 actions done'"""
        return '%s of %d actions done' % (stat_html, total)

    def table_caption(self, rows, cols, compare):
        return (self.n(rows, 'option') if compare else self.n(rows, 'row')) + ' · ' + self.n(cols, 'column')

    def table_aria(self, title, compare, i, total):
        return (('Comparison table: ' if compare else 'Table: ') + title
                + (', %d of %d' % (i, total) if total > 1 else ''))

    def checklist_hint(self, href):
        return ('One action at a time is enough. ' + esc(self.storage)
                + ' <a href="' + esc(href) + '">' + self.see_all_actions_link + '</a>.')

    def extras_sentence(self, intro, n_parts, glossary):
        parts = []
        if intro:
            parts.append('the introduction')
        if n_parts:
            parts.append('the ' + self.n(n_parts, 'part_opening'))
        if glossary:
            parts.append('the glossary')
        return ', '.join(parts[:-1]) + ' and ' + parts[-1] if len(parts) > 1 else ''.join(parts)

    def range_label(self, nums, capital=False):
        if not nums:
            return ''
        if len(nums) == 1:
            out = 'chapter %d' % nums[0]
        elif all(i == 0 or n == nums[i - 1] + 1 for i, n in enumerate(nums)):
            out = 'chapters %d to %d' % (nums[0], nums[-1])
        else:
            out = 'chapters ' + ', '.join(map(str, nums))
        return re.sub(r'^c', 'C', out) if capital else out

    # ----- cover -----

    def parts_aria(self, n):
        return 'The %d parts of the book' % n

    def begin_with(self, n):
        return 'Or begin with chapter %d' % n

    def see_all_chapters(self, n):
        return 'See all %d chapters' % n

    def initiative(self, name_html):
        return 'An initiative of %s' % name_html

    def block_lead(self, n_ch, n_parts, extras, n_act):
        return '%s in %d parts%s%s.' % (self.n(n_ch, 'chapter'), n_parts, ', with ' + extras if extras else '',
                                        ', and all %d actions on one page' % n_act if n_act else '')

    def plan_text(self, plan_ch, plan_act, n_ch, n_act, extras):
        return ('The plan of the book counts %d chapters and %d checklist actions. This edition contains %d chapters with '
                'their %d actions%s. These numbers describe the available content, not your completion.'
                % (plan_ch, plan_act, n_ch, n_act, ', plus ' + extras if extras else ''))

    def language_html(self, href):
        return ('The text is in English. The same book is also available in Lithuanian, in this layout: '
                '<a href="%s" hreflang="lt" lang="lt">Lietuvių</a>.' % href)

    def see_all_actions(self, n):
        return 'See all %d actions on one page' % n

    def colophon(self, label_html, title_html, initiative_html):
        return ('%s of %s, in the identity of the PROOF Conference. The initiative is carried by %s. Later editions are '
                'independent: a community can fork the book and adapt its look, layout, navigation, structure, content '
                'and code.' % (label_html, title_html, initiative_html))

    def watch_on(self, links_html):
        return 'Watch on %s' % links_html

    # ----- Where to start? -----

    def path_no(self, no):
        return 'Path %s' % no

    def path_avail(self, n_ch, n_act):
        return self.n(n_ch, 'chapter') + ' · ' + self.n(n_act, 'action')

    def guide_intro(self, href):
        return 'The <a href="%s">introduction</a> explains why the book exists and how to use it.' % href

    def guide_parts(self, links_html):
        return 'Each part opens with a short essay: ' + links_html + '.'

    def guide_glossary(self, href):
        return 'The <a href="%s">glossary</a> explains the words that come back.' % href

    def guide_actions(self, n, href):
        return 'All %d actions are also gathered on <a href="%s">one page</a>.' % (n, href)

    def method_text(self):
        return ('Each chapter ends with a checklist where every action is tagged with its effort, such as 5 min or 1 hour. '
                'Do 1 action at a time. ' + esc(self.storage))

    # ----- other pages -----

    def intro_meta(self, n_ch, n_parts):
        return self.n(n_ch, 'chapter') + ' in %d parts' % n_parts

    def actions_intro(self, n_act, n_ch):
        return ('The %d actions of the %d chapters on a single page. A tick here is the same tick as in the chapter '
                'checklist, so each action counts once.' % (n_act, n_ch))

    def drawer_scope(self, n_ch, n_act):
        return '%d chapters and %d actions, in English.' % (n_ch, n_act)

    def footer_line(self, label_html, name_html, initiative_html, n_ch, n_act):
        return '%s, %s. An initiative of %s: %d chapters and %d actions.' % (label_html, name_html, initiative_html, n_ch, n_act)

    def footer_licence(self, content_html, code_html, note_html):
        return 'Text %s · original code %s. %s' % (content_html, code_html, note_html)

    def brand_sub(self, wordmark_html):
        return '<span class="wm">%s</span> edition' % wordmark_html

    # ----- legal page (legal/) and the footer links to it and to the source archive -----

    legal_title = 'Licences and source'
    legal_kicker = 'Legal information'
    legal_lead = 'Who made this book, what you may do with it, and where to get the exact source of these pages.'

    def file_size(self, n):
        return '%.1f MB' % (n / 1e6) if n >= 1e6 else '%d kB' % max(1, round(n / 1e3))

    def source_link(self, size):
        return 'Source code (ZIP, %s)' % size

    def legal_desc(self, title):
        return ('Licences, credits and source code of the English and Lithuanian editions of %s: CC BY-SA 4.0 text, '
                'AGPL code, fonts and a source archive.' % title)

    def legal_sections(self, d):
        """(id, title, paragraphs) of the legal page. d: the addresses and facts of the legal files and the archive."""
        a = lambda href, text: '<a href="%s">%s</a>' % (esc(href), text)
        x = lambda href, text: '<a class="ext" rel="noopener noreferrer" href="%s">%s</a>' % (esc(href), text)
        return (
            ('attribution', 'Credits and changes', (
                '%s was written for the first PROOF conference (Vilnius, 2026) and is carried as a community project by '
                'Cypher Baltics. Copyright (C) 2026 the contributors of A Guide to Autonomy.' % d['title_html'],
                'This English and Lithuanian edition was modified on %s: the Markdown sources were revised and rendered as '
                'these static pages, with shared checklist actions, search, an offline copy, this page and a source '
                'archive. The full notice is in %s.' % (d['date'], a(d['notice'], 'NOTICE.txt')))),
            ('licences', 'Licences', (
                'The book text and the editorial wording of the interface are under %s; full text: %s. You may copy, '
                'translate, adapt and sell it if you credit the source, state your changes and share your adaptation of '
                'the text under the same licence.' % (x(d['cc_url'], 'CC BY-SA 4.0'), a(d['content_licence'], 'LICENSE-CONTENT.txt')),
                'The code (generator, browser script, styles, service worker, packaging scripts) is under %s; full text: '
                '%s. If you distribute a modified version, or let people use it over a network, offer them its '
                'corresponding source under the same licence.' % (x(d['agpl_url'], 'AGPL-3.0-or-later'), a(d['licence'], 'LICENSE.txt')),
                'Each page combines both layers: the book text stays under CC BY-SA 4.0, the markup and scripts come from '
                'AGPL code. Neither licence relicenses the other.')),
            ('source', 'Source code', (
                'The exact source of these pages, in both languages: %s (ZIP, %s). It contains the 46 Markdown sources, '
                'the generator, the interface, the action registries, the other build inputs, the licences and a README '
                'with the rebuild commands (Python 3 and Python-Markdown 3.9). It does not contain the rest of the '
                'conference site.' % (a(d['zip'], esc(d['zip_name'])), d['zip_size']),
                'SHA-256 of the archive: <code class="legal-hash">%s</code>' % d['zip_sha'],
                'The archive downloads online only and is not part of the offline copy. The licence texts linked on '
                'this page are.')),
            ('third-party', 'Fonts and other resources', (
                'The JetBrains Mono and Righteous fonts are under the SIL Open Font License 1.1: %s, %s. “Righteous” is a '
                'Reserved Font Name.' % (a(d['ofl_jb'], 'JetBrains Mono licence'), a(d['ofl_r'], 'Righteous licence')),
                'The pages are built with Python-Markdown 3.9 (BSD 3-Clause licence, text in the source archive); it is '
                'not served to readers.',
                'Linked websites, product names and brands belong to their owners and are not licensed by this book.')),
            ('branding', 'Names and logos', (
                'These licences give no right to the names, logos or visual identity of PROOF, the PROOF conference or '
                'Cypher Baltics. The other pages of proofconference.com, its photographs, videos, recordings and sponsor '
                'logos are not covered by them. A fork chooses its own name, logo and colours.',)),
            ('review', 'Resource note', (
                'A licence and publication review of this edition was carried out on %s. It records the chosen licences '
                'and the terms of the resources above. It does not guarantee who owns every resource, nor clear every '
                'quotation, link or name. To report a problem: %s.'
                % (d['date'], a('mailto:contact@proofconference.com', 'contact@proofconference.com')),)),
        )

    # ----- titles and descriptions -----

    def cover_desc(self, title, name):
        return '%s, a learning book on privacy, digital autonomy and money. %s.' % (title, name)

    def actions_desc(self, n_act, n_ch, title):
        return ('The %d actions of the %d chapters of %s on one page, with the same ticks as the chapter checklists, '
                'saved in this browser only.' % (n_act, n_ch, title))

    def start_desc(self, n_paths, title, path_titles):
        return '%d reading paths through %s: %s.' % (n_paths, title, '; '.join(path_titles))

    # ----- search entries of the guide pages -----

    def search_edition_text(self, n_ch, n_act, extras):
        return ('Edition coverage: %d chapters and %d actions available, with %s. Languages: English here; the same book '
                'is also available in Lithuanian, in this layout.' % (n_ch, n_act, extras))

    def search_about_text(self, initiative):
        return 'PROOF Conference, %s, licence, fork, independent editions.' % initiative

    def search_actions_text(self, n_act, n_ch):
        return 'The %d checklist actions of the %d chapters on a single page, grouped by chapter, with the same ticks.' % (n_act, n_ch)


class Lithuanian(English):
    lang = 'lt'
    og_locale = 'lt_LT'
    title_sep = ' · '
    site_home = '/'
    title_lang = ' lang="en"'
    lang_link = {'code': 'EN', 'lang': 'en', 'name': 'English', 'aria': 'EN, English version'}

    # (1, 21...) (2-9, 22-29...) (10-20, round numbers): one tuple per case where a sentence needs it.
    FORMS = {
        'chapter': ('skyrius', 'skyriai', 'skyrių'),
        'chapter_gen': ('skyriaus', 'skyrių', 'skyrių'),
        'chapter_acc': ('skyrių', 'skyrius', 'skyrių'),
        'action': ('veiksmas', 'veiksmai', 'veiksmų'),
        'action_gen': ('veiksmo', 'veiksmų', 'veiksmų'),
        'action_acc': ('veiksmą', 'veiksmus', 'veiksmų'),
        'term': ('terminas', 'terminai', 'terminų'),
        'option': ('variantas', 'variantai', 'variantų'),
        'row': ('eilutė', 'eilutės', 'eilučių'),
        'column': ('stulpelis', 'stulpeliai', 'stulpelių'),
        'part_loc': ('dalyje', 'dalyse', 'dalių'),
        'part_opening': ('dalies įžanga', 'dalių įžangos', 'dalių įžangų'),
        'path': ('skaitymo kelias', 'skaitymo keliai', 'skaitymo kelių'),
    }

    storage = 'Atliktų veiksmų ir perskaitytų skyrių žymės saugomos tik šioje naršyklėje, šiame įrenginyje, be jokios paskyros.'
    noscript_ticks = 'Veiksmus pažymėti galima tik įjungus JavaScript. Skaityti sąrašą galima ir be jo.'
    noscript_read = 'Pažymėti skyrių kaip perskaitytą galima tik įjungus JavaScript.'

    kind_label = {'brief': '', 'explain': 'Suprask', 'compare': 'Palygink', 'steps': 'Instrukcija',
                  'pitfalls': 'Atsargiai', 'further': 'Norintiems daugiau', 'sources': 'Šaltiniai',
                  'checklist': 'Veik', 'glossary': 'Terminai'}
    in_brief = 'Trumpai'
    # Python-Markdown IDs of "## Trumpai", "## Žingsnis po žingsnio"... (accents dropped).
    kind_by_id = {'trumpai': 'brief', 'zingsnis-po-zingsnio': 'steps', 'klaidos-kuriu-verta-vengti': 'pitfalls',
                  'norintiems-daugiau': 'further', 'saltiniai': 'sources', 'tavo-veiksmu-sarasas': 'checklist'}
    sources_id = 'saltiniai'
    # First-column labels of the 33 tables of lt/, read on 2026-10-22 (the same tables as in English).
    row_header_columns = {'programa', 'programėlė', 'paslauga', 'šeima', 'įrankis', 'klientas', 'teikėjas', 'variantas',
                          'būdas', 'kelias', 'sistema', 'programėlių šaltinis', 'piniginė', 'tvarkyklė', 'raktas',
                          'naršyklė', 'paieškos sistema', 'platforma', 'po kiek laiko', 'kur', 'turtas', 'įrenginys',
                          'įprotis', 'poreikis'}

    cited = 'Šiame skirsnyje cituojami šaltiniai'
    scroll_hint = 'Slink į šoną →'
    effort_sr = ', trukmė: '
    see_all_actions_link = 'Peržiūrėk visus veiksmus viename puslapyje'
    reference = 'Žinynas'
    before_chapters = 'Prieš skyrius'
    global_checklist = 'Bendras veiksmų sąrašas'
    all_actions = 'Visi veiksmai'
    cover = 'Viršelis'
    back_to_cover = 'Grįžti į viršelį'
    book_kicker = 'Knyga'
    on_this_page = 'Šiame puslapyje'
    previous = 'Ankstesnis'
    next = 'Kitas'
    pager_chapters = 'Knygos skyriai'
    pager_pages = 'Knygos puslapiai'
    start_reading = 'Pradėti skaityti'
    read_intro = 'Skaityti įvadą'
    where_to_start = 'Nuo ko pradėti?'
    general_contents = 'Bendras turinys'
    contents = 'Turinys'
    edition_coverage = 'Leidimo apimtis'
    this_edition = 'Šis leidimas'
    stat_chapters_here = 'skyrių galima skaityti čia'
    stat_actions_here = 'veiksmų galima pažymėti čia'
    in_this_browser = 'Šioje naršyklėje'
    your_progress = 'Tavo pažanga'
    stat_actions_done = 'atliktų veiksmų'
    stat_chapters_read = 'perskaitytų skyrių'
    progress_help = ('Atliktų veiksmų skaičius pasikeičia, kai pažymi veiksmą skyriaus veiksmų sąraše arba visų veiksmų '
                     'puslapyje. Perskaitytų skyrių skaičius pasikeičia, kai skyriaus pabaigoje pažymi langelį '
                     '„Perskaičiau šį skyrių“. Vien perslinkus puslapį jis nepažymimas kaip perskaitytas.')
    open_checklist = 'Atverti veiksmų sąrašą'
    ticks_removable = 'Žymes bet kada gali nuimti kiekviename veiksmų sąraše.'
    shared_progress = 'Lietuviški ir angliški knygos puslapiai naudoja tas pačias žymes.'
    clear_progress = 'Išvalyti pažangą šioje naršyklėje'
    colophon_kicker = 'Metrika'
    about_edition = 'Apie šį leidimą'
    no_ads = 'Nėra nei reklamų, nei paskyrų. Į kitas svetaines veda tik tos šaltinių nuorodos, kurias atveri.'
    talk_recordings = 'Pranešimų įrašai'
    replays_intro = 'PROOF 2026 konferencijos pranešimų įrašai. Prie kiekvieno pateikta nuoroda į knygos puslapį ta pačia tema.'
    to_go_deeper = 'Norintiems pasigilinti'
    orientation = 'Orientyrai'
    start_lead = ('Autonomija kuriama palaipsniui.',
                  'Pasirink konkretų poreikį, susipažink su jam skirtu skyriumi ir pradėk nuo vieno tavo situacijai '
                  'tinkamo veiksmo.')
    method = 'Metodas'
    how_chapters_work = 'Kaip sudarytas kiekvienas skyrius'
    anatomy = (('Poreikis', 'Kas gresia ir kodėl tai svarbu tau.'),
               ('Galimybės ir ribos', 'Greta palyginti įrankiai ir tai, ko kiekvienas iš jų iš tavęs reikalauja.'),
               ('Žingsniai', 'Žingsnis po žingsnio parodyta, kaip įdiegti ir nustatyti vieną protingą variantą.'),
               ('Šaltiniai', 'Nuorodos pateiktos šalia teiginių, kuriuos jos pagrindžia, ir surašytos skyriaus pabaigoje.'))
    read_this = 'Perskaičiau šį skyrių'
    part_chapters_title = 'Šios dalies skyriai'
    drawer_aria = 'Knygos turinys'
    skip = 'Pereiti prie turinio'
    search_button = 'Paieška'
    site_sr = ' &lt;conference&gt;, konferencijos svetainė'
    search_title = 'Paieška knygoje'
    close = 'Uždaryti'
    search_label = 'Klausimai, įrankiai, žingsniai ir žodžiai'
    search_scope = ('Ieškoma visame šio leidimo tekste: skyriuose, įvade, dalių įžangose, žodynėlyje, veiksmų sąrašuose '
                    'ir pagalbiniuose puslapiuose.')
    search_progress_text = ('Atliktų veiksmų ir perskaitytų skyrių žymės, saugomos šioje naršyklėje. Atverti veiksmų sąrašą. '
                            'Išvalyti pažangą.')
    search_how_text = ('Poreikis, galimybės ir ribos, žingsniai, šaltiniai. Veiksmų sąrašas su trukmės žymėmis, po vieną '
                       'veiksmą.')
    path_kicker = 'Nuo ko pradėti? · Kelias'

    js = {
        'readLabel': ' · perskaitytas',
        'readState': 'Pažymėtas kaip perskaitytas',
        'resetCleared': 'Pažanga šioje naršyklėje išvalyta.',
        'resetConfirm': 'Taip, išvalyti visas žymes',
        'resetPress': 'Paspausk dar kartą, kad patvirtintum.',
        'searchLoading': 'Įkeliama paieškos rodyklė.',
        'searchError': 'Nepavyko įkelti paieškos rodyklės. Patikrink interneto ryšį ir vėl atverk paiešką.',
        'searchTry': 'Pabandyk',
        'searchResults': 'Rezultatai',
        'searchNone': 'Šio leidimo puslapiuose nieko nerasta.',
        'searchCount': ['Rezultatų: {n}', 'Rezultatų: {n}', 'Rezultatų: {n}'],
        'searchShown': ', rodoma {shown}',
        'resume': 'Skaityti toliau: ',
        'resumeChapter': '{n} skyrius · {title}',
        'offlineReady': ('Knyga be interneto: išsaugota šioje naršyklėje. Visi lietuviško ir angliško leidimų puslapiai, '
                         'paieška, žodynėlis ir visi veiksmai atsidaro ir be ryšio, net dar neatverti skyriai. '
                         'Nuorodos į kitas svetaines veikia tik prisijungus prie interneto.'),
        'offlineSaving': ('Knyga be interneto: išsaugoma šioje naršyklėje. Kurį laiką palik šį puslapį atvertą ir '
                          'neatsijunk nuo interneto.'),
        'offlineFailed': 'Knyga be interneto: neišsaugota. Kol veikia interneto ryšys, įkelk šį puslapį iš naujo ir bandyk dar kartą.',
        'offlineNone': 'Knyga be interneto: šioje naršyklėje ši funkcija nepasiekiama. Puslapiai veikia, kai yra interneto ryšys.',
    }

    # Lithuanian texts of config.js. The title stays "A Guide to Autonomy" (agreed); the part names translate the
    # English theme names of config.js, the part openings keep their own titles (Privatumo įrodymas...).
    config = {
        'book': {
            'kicker': 'Mokomoji knyga',
            'lang': 'lt',
            'intro': [
                'Mokomoji knyga visiems apie asmeninę ir skaitmeninę autonomiją: kaip išsaugoti pokalbių ir paskyrų '
                'privatumą, kaip rinktis įrankius, nuo kurių priklausai, ir kaip savarankiškai laikyti savo pinigus, '
                'taip pat ir bitkoinus.',
                'Kiekvienas skyrius prasideda nuo konkretaus poreikio, paaiškina, kuo įrankis padeda ir kur jo galimybės '
                'baigiasi, o tada žingsnis po žingsnio parodo, ką daryti. Šaltiniai pateikiami šalia teiginių, kuriuos '
                'jie pagrindžia.',
            ],
        },
        'edition': {'name': 'PROOF leidimas', 'label': 'Pirmasis leidimas'},
        'parts': {1: 'Privatumas', 2: 'Autonomija', 3: 'Pinigai ir Bitcoin'},
        'startPaths': {
            'path-accounts': {'title': 'Apsaugoti savo paskyras',
                              'text': 'Pirmiausia slaptažodžiai ir paskyrų sauga, tada el. paštas ir pseudonimai.'},
            'path-conversations': {'title': 'Apsaugoti pokalbius ir naršymą',
                                   'text': 'Susirašinėjimo programėlės, tada naršyklė ir paieška, o po to tinklas.'},
            'path-data': {'title': 'Valdyti savo duomenis ir įrenginius',
                          'text': 'Technologijų milžinių paslaugų pakaitalai, telefono nustatymai, o tada paslaugos '
                                  'nuosavame serveryje.',
                          'deeperTitle': 'Norintiems pasigilinti'},
            'path-bitcoin': {'title': 'Suprasti Bitcoin',
                             'text': 'Santaupos, pirmoji piniginė, atkūrimo frazės atsarginė kopija, kasdieniai mokėjimai, '
                                     'privatumas, aparatinės piniginės ir nuosavas mazgas.'},
        },
        'searchSuggestions': ['slaptafrazė', 'Signal', 'uBlock Origin', 'SIM kortelės perėmimas', 'saugumo numeriai',
                              'piniginė'],
        'licenceNote': ('Šriftams ir kitiems trečiųjų šalių ištekliams galioja jų pačių sąlygos. Licencijos netaikomos '
                        'pavadinimams, logotipams ir konferencijos medžiagai.'),
    }

    # ----- labels of pages and sections -----

    def doc_label_chapter(self, n):
        return '%d sk.' % n

    def part_opening(self, n):
        return '%d dalies įžanga' % n

    def chapter_n(self, n):
        return '%d skyrius' % n

    def part_n(self, n):
        return '%d dalis' % n

    def part_label(self, n, name):
        return '%d dalis · %s' % (n, name)

    def chapter_kicker(self, n, part_name):
        return '%d skyrius · %s' % (n, part_name)

    def part_kicker(self, n, name):
        return '%d dalis · %s · Įžanga' % (n, name)

    def opening_essay_of(self, n):
        return '%d dalies įžanga' % n

    def sr_chapter(self, n):
        return '%d skyrius: ' % n

    def sr_part(self, n):
        return '%d dalis: ' % n

    def part_title(self, n, title):
        return '%d dalis: %s' % (n, title)

    def chapter_of(self, n, total):
        return '%d skyrius iš %d' % (n, total)

    def part_opens(self, n, link_html):
        return '%d dalis prasideda įžanga: %s' % (n, link_html)

    def step_title(self, i, name):
        return '%d žingsnis: %s' % (i, name)

    def compared_in(self, title):
        return 'Palyginta skirsnyje „%s“' % title

    def checklist_action(self, effort):
        return 'Veiksmas' + (', ' + effort if effort else '')

    def count_done(self, stat_html, total):
        """'Atlikta <strong ...>0</strong> iš 5 veiksmų'"""
        return 'Atlikta %s iš %d %s' % (stat_html, total, self.form(total, 'action_gen'))

    def table_aria(self, title, compare, i, total):
        return (('Palyginimo lentelė: ' if compare else 'Lentelė: ') + title
                + (', %d iš %d' % (i, total) if total > 1 else ''))

    def checklist_hint(self, href):
        return ('Užtenka atlikti po vieną veiksmą. ' + esc(self.storage)
                + ' <a href="' + esc(href) + '">' + self.see_all_actions_link + '</a>.')

    def extras_sentence(self, intro, n_parts, glossary):
        parts = []
        if intro:
            parts.append('įvadas')
        if n_parts:
            parts.append(self.n(n_parts, 'part_opening'))
        if glossary:
            parts.append('žodynėlis')
        return ', '.join(parts[:-1]) + ' ir ' + parts[-1] if len(parts) > 1 else ''.join(parts)

    def range_label(self, nums, capital=False):
        # Ranges with a hyphen (house rule), never a dash. Starts with a digit: no capital needed.
        if not nums:
            return ''
        if len(nums) == 1:
            return '%d skyrius' % nums[0]
        if all(i == 0 or n == nums[i - 1] + 1 for i, n in enumerate(nums)):
            return '%d-%d skyriai' % (nums[0], nums[-1])
        return 'Skyriai ' + ', '.join(map(str, nums)) if capital else 'skyriai ' + ', '.join(map(str, nums))

    # ----- cover -----

    def parts_aria(self, n):
        return 'Knygos dalys'

    def begin_with(self, n):
        return 'Arba pradėk nuo %d skyriaus' % n

    def see_all_chapters(self, n):
        return 'Peržiūrėk %d %s' % (n, self.form(n, 'chapter_acc'))

    def initiative(self, name_html):
        return '„%s“ iniciatyva' % name_html

    def block_lead(self, n_ch, n_parts, extras, n_act):
        out = '%s %d %s' % (self.n(n_ch, 'chapter'), n_parts, self.form(n_parts, 'part_loc'))
        out += (', taip pat ' + extras if extras else '') + '.'
        if n_act:
            out += ' %d %s rasi viename puslapyje.' % (n_act, self.form(n_act, 'action_acc'))
        return out

    def plan_text(self, plan_ch, plan_act, n_ch, n_act, extras):
        return ('Knygos plane yra %s ir %s. Šiame leidime yra %s ir %s%s. '
                'Šie skaičiai rodo turinio apimtį, o ne tavo pažangą.'
                % (self.n(plan_ch, 'chapter'), self.n(plan_act, 'action'), self.n(n_ch, 'chapter'),
                   self.n(n_act, 'action'), ', taip pat ' + extras if extras else ''))

    def language_html(self, href):
        return ('Tekstas lietuvių kalba. Ta pati knyga tokiu pat išdėstymu yra ir anglų kalba: '
                '<a href="%s" hreflang="en" lang="en">English</a>.' % href)

    def see_all_actions(self, n):
        return 'Peržiūrėk %d %s viename puslapyje' % (n, self.form(n, 'action_acc'))

    def colophon(self, label_html, title_html, initiative_html):
        return ('%s: knyga „%s“, apipavidalinta pagal PROOF konferencijos vizualinį stilių. Iniciatyvą įgyvendina „%s“. '
                'Vėlesni leidimai yra nepriklausomi: bendruomenė gali sukurti knygos atšaką (angl. fork) ir pritaikyti '
                'jos išvaizdą, išdėstymą, naršymą, struktūrą, turinį ir kodą.' % (label_html, title_html, initiative_html))

    def watch_on(self, links_html):
        return 'Žiūrėti: %s' % links_html

    # ----- Where to start? -----

    def path_no(self, no):
        return 'Kelias %s' % no

    def guide_intro(self, href):
        return '<a href="%s">Įvade</a> paaiškinta, kodėl ši knyga atsirado ir kaip ja naudotis.' % href

    def guide_parts(self, links_html):
        return 'Kiekviena dalis prasideda trumpa įžanga: ' + links_html + '.'

    def guide_glossary(self, href):
        return '<a href="%s">Žodynėlyje</a> paaiškinti dažnai pasikartojantys žodžiai.' % href

    def guide_actions(self, n, href):
        return '%d %s rasi ir <a href="%s">viename puslapyje</a>.' % (n, self.form(n, 'action_acc'), href)

    def method_text(self):
        return ('Kiekvienas skyrius baigiasi veiksmų sąrašu. Prie kiekvieno veiksmo nurodyta, kiek laiko jis užtruks, '
                'pavyzdžiui, 5 min. arba 1 val. Atlik po vieną veiksmą. ' + esc(self.storage))

    # ----- other pages -----

    def intro_meta(self, n_ch, n_parts):
        return '%s %d %s' % (self.n(n_ch, 'chapter'), n_parts, self.form(n_parts, 'part_loc'))

    def actions_intro(self, n_act, n_ch):
        return ('%s iš %d %s viename puslapyje. Čia pažymėtas veiksmas pažymimas ir skyriaus veiksmų sąraše, todėl '
                'kiekvienas veiksmas skaičiuojamas tik vieną kartą.' % (self.n(n_act, 'action'), n_ch, self.form(n_ch, 'chapter_gen')))

    def drawer_scope(self, n_ch, n_act):
        return '%s ir %s, lietuvių kalba.' % (self.n(n_ch, 'chapter'), self.n(n_act, 'action'))

    def footer_line(self, label_html, name_html, initiative_html, n_ch, n_act):
        return '%s, %s. „%s“ iniciatyva: %s ir %s.' % (label_html, name_html, initiative_html,
                                                       self.n(n_ch, 'chapter'), self.n(n_act, 'action'))

    def footer_licence(self, content_html, code_html, note_html):
        return 'Tekstas %s · originalus kodas %s. %s' % (content_html, code_html, note_html)

    def brand_sub(self, wordmark_html):
        return '<span class="wm">%s</span> leidimas' % wordmark_html

    # ----- legal page (legal/) and the footer links to it and to the source archive -----

    legal_title = 'Licencijos ir šaltinio kodas'
    legal_kicker = 'Teisinė informacija'
    legal_lead = 'Kas sukūrė šią knygą, ką su ja gali daryti ir kur rasti tikslų šių puslapių šaltinio kodą.'

    def file_size(self, n):
        return ('%.1f MB' % (n / 1e6)).replace('.', ',') if n >= 1e6 else '%d kB' % max(1, round(n / 1e3))

    def source_link(self, size):
        return 'Šaltinio kodas (ZIP, %s)' % size

    def legal_desc(self, title):
        return ('„%s“ anglų ir lietuvių kalbų leidimų licencijos, autoriai ir šaltinio kodas: tekstas pagal CC BY-SA 4.0, '
                'kodas pagal AGPL, šriftai ir šaltinio kodo archyvas.' % title)

    def legal_sections(self, d):
        a = lambda href, text: '<a href="%s">%s</a>' % (esc(href), text)
        x = lambda href, text: '<a class="ext" rel="noopener noreferrer" href="%s">%s</a>' % (esc(href), text)
        return (
            ('attribution', 'Autoriai ir pakeitimai', (
                'Knyga „%s“ parašyta pirmajai PROOF konferencijai (Vilnius, 2026) ir įgyvendinama kaip „Cypher Baltics“ '
                'bendruomenės projektas. Autorių teisių pranešimas: <span lang="en">Copyright (C) 2026 the contributors '
                'of A Guide to Autonomy.</span>' % d['title_html'],
                'Šis anglų ir lietuvių kalbų leidimas pakeistas %s: Markdown šaltiniai peržiūrėti ir paversti šiais '
                'statiniais puslapiais su bendrais veiksmų sąrašais, paieška, kopija naudoti be interneto, šiuo puslapiu '
                'ir šaltinio kodo archyvu. Visas pranešimas pateiktas faile %s.' % (d['date'], a(d['notice'], 'NOTICE.txt')))),
            ('licences', 'Licencijos', (
                'Knygos tekstui ir sąsajos redakciniams tekstams taikoma licencija %s, visas jos tekstas: %s. Tekstą gali '
                'kopijuoti, versti, pritaikyti ir parduoti, jei nurodai šaltinį, pažymi savo pakeitimus ir savo '
                'pritaikytą tekstą platini pagal tą pačią licenciją.'
                % (x(d['cc_url'], 'CC BY-SA 4.0'), a(d['content_licence'], 'LICENSE-CONTENT.txt')),
                'Kodui, t. y. generatoriui, naršyklės scenarijui, stiliams, foniniam scenarijui (angl. service worker) ir '
                'pakavimo scenarijams, taikoma licencija %s, visas jos tekstas: %s. Jei platini pakeistą versiją arba '
                'leidi ja naudotis per tinklą, pasiūlyk jos atitinkamą šaltinio kodą pagal tą pačią licenciją.'
                % (x(d['agpl_url'], 'AGPL-3.0-or-later'), a(d['licence'], 'LICENSE.txt')),
                'Kiekviename puslapyje yra abu sluoksniai: knygos tekstui ir toliau taikoma CC BY-SA 4.0, o žymėjimą ir '
                'scenarijus sukuria kodas, kuriam taikoma AGPL licencija. Nė viena licencija nepakeičia kitos.')),
            ('source', 'Šaltinio kodas', (
                'Tikslus šių puslapių šaltinio kodas abiem kalbomis: %s (ZIP, %s). Jame yra 46 Markdown šaltiniai, '
                'generatorius, sąsaja, veiksmų registrai, kiti puslapiams sukurti reikalingi failai, licencijos ir '
                'README su komandomis puslapiams atkurti (Python 3 ir Python-Markdown 3.9). Likusios konferencijos '
                'svetainės jame nėra.' % (a(d['zip'], esc(d['zip_name'])), d['zip_size']),
                'Archyvo SHA-256: <code class="legal-hash">%s</code>' % d['zip_sha'],
                'Archyvą galima atsisiųsti tik prisijungus prie interneto, jis neįtraukiamas į kopiją naudoti be '
                'interneto. Šiame puslapyje nurodyti licencijų tekstai įtraukiami.')),
            ('third-party', 'Šriftai ir kiti ištekliai', (
                'Šriftams JetBrains Mono ir Righteous taikoma SIL Open Font License 1.1: %s, %s. „Righteous“ yra '
                'rezervuotas šrifto pavadinimas (angl. Reserved Font Name).'
                % (a(d['ofl_jb'], 'JetBrains Mono licencija'), a(d['ofl_r'], 'Righteous licencija')),
                'Puslapiai sukurti naudojant Python-Markdown 3.9 (BSD 3-Clause licencija, jos tekstas yra šaltinio kodo '
                'archyve), tačiau skaitytojams ši programa neteikiama.',
                'Svetainės, į kurias veda nuorodos, produktų pavadinimai ir prekių ženklai priklauso jų savininkams. Ši '
                'knyga jiems licencijos nesuteikia.')),
            ('branding', 'Pavadinimai ir logotipai', (
                'Šios licencijos nesuteikia teisių į PROOF, PROOF konferencijos ar „Cypher Baltics“ pavadinimus, '
                'logotipus ar vizualinį stilių. Jos netaikomos kitiems proofconference.com puslapiams, nuotraukoms, '
                'vaizdo įrašams, pranešimų įrašams ir rėmėjų logotipams. Atšaka (angl. fork) pasirenka savo pavadinimą, '
                'logotipą ir spalvas.',)),
            ('review', 'Pastaba apie išteklius', (
                '%s atlikta šio leidimo licencijų ir publikavimo peržiūra. Joje užfiksuotos pasirinktos licencijos ir '
                'pirmiau nurodytų išteklių sąlygos. Ji negarantuoja, kam priklauso kiekvienas išteklius, ir nepatvirtina '
                'kiekvienos citatos, nuorodos ar pavadinimo. Jei pastebėjai problemą, rašyk: %s.'
                % (d['date'], a('mailto:contact@proofconference.com', 'contact@proofconference.com')),)),
        )

    # ----- titles and descriptions -----

    def cover_desc(self, title, name):
        return '„%s“: mokomoji knyga apie privatumą, skaitmeninę autonomiją ir pinigus. %s.' % (title, name)

    def actions_desc(self, n_act, n_ch, title):
        return ('%s iš %d %s knygoje „%s“ viename puslapyje, su tomis pačiomis žymėmis kaip skyrių veiksmų sąrašuose. '
                'Žymės saugomos tik šioje naršyklėje.' % (self.n(n_act, 'action'), n_ch, self.form(n_ch, 'chapter_gen'), title))

    def start_desc(self, n_paths, title, path_titles):
        return '%s knygoje „%s“: %s.' % (self.n(n_paths, 'path'), title, '; '.join(path_titles))

    # ----- search entries of the guide pages -----

    def search_edition_text(self, n_ch, n_act, extras):
        return ('Leidimo apimtis: %s ir %s, taip pat %s. Tekstas lietuvių kalba, ta pati knyga tokiu pat išdėstymu yra '
                'ir anglų kalba.' % (self.n(n_ch, 'chapter'), self.n(n_act, 'action'), extras))

    def search_about_text(self, initiative):
        return 'PROOF konferencija, „%s“, licencija, atšaka, nepriklausomi leidimai.' % initiative

    def search_actions_text(self, n_act, n_ch):
        return ('%s iš %d %s viename puslapyje, sugrupuoti pagal skyrius, su tomis pačiomis žymėmis.'
                % (self.n(n_act, 'action'), n_ch, self.form(n_ch, 'chapter_gen')))


LOCALES = {'en': English(), 'lt': Lithuanian()}


def get(lang):
    return LOCALES[lang]


# ---------- self-check of the Lithuanian strings ----------

_DASH = re.compile('[–—]')
_YOU_PLURAL = re.compile(r'\b(jūs|Jūs|jūsų|Jūsų)\b|\w+kite\b')
_STRAIGHT = re.compile(r'"(?![^<>]*>)')            # a straight double quote outside an HTML tag


def sample_strings(loc):
    """Every string of a locale, with the methods called on the numbers that exercise each plural form."""
    out = []

    def walk(v):
        if isinstance(v, str):
            out.append(v)
        elif isinstance(v, dict):
            for x in v.values():
                walk(x)
        elif isinstance(v, (list, tuple, set)):
            for x in v:
                walk(x)

    for name in dir(type(loc)):
        if name.startswith('_') or name in ('FORMS', 'kind_by_id', 'sources_id', 'row_header_columns', 'lang',
                                             'og_locale', 'site_home', 'title_lang', 'lang_link'):
            continue
        v = getattr(loc, name)
        if not callable(v):
            walk(v)
    nums = (1, 2, 5, 10, 11, 12, 21, 22, 90, 101)
    extras = loc.extras_sentence(True, 3, True)
    for n in nums:
        for key in loc.FORMS:
            out.append(loc.n(n, key))
        out += [loc.doc_label_chapter(n), loc.part_opening(n), loc.chapter_n(n), loc.part_n(n), loc.part_label(n, 'X'),
                loc.chapter_kicker(n, 'X'), loc.part_kicker(n, 'X'), loc.opening_essay_of(n), loc.sr_chapter(n),
                loc.sr_part(n), loc.part_title(n, 'X'), loc.chapter_of(n, 18), loc.part_opens(n, 'X'),
                loc.step_title(n, 'X'), loc.count_done('0', n), loc.table_caption(n, n, True),
                loc.table_caption(n, n, False), loc.table_aria('X', True, 1, n), loc.extras_sentence(True, n, True),
                loc.range_label([n]), loc.range_label([n, n + 1], True), loc.range_label([n, n + 2]),
                loc.parts_aria(n), loc.begin_with(n), loc.see_all_chapters(n), loc.block_lead(n, n, extras, n),
                loc.plan_text(n, n, n, n, extras), loc.see_all_actions(n), loc.path_avail(n, n), loc.guide_actions(n, '#'),
                loc.intro_meta(n, n), loc.actions_intro(n, n), loc.drawer_scope(n, n), loc.footer_line('a', 'b', 'c', n, n),
                loc.actions_desc(n, n, 'T'), loc.start_desc(n, 'T', ['a', 'b']), loc.search_edition_text(n, n, extras),
                loc.search_actions_text(n, n)]
    out += [loc.compared_in('X'), loc.checklist_action('5 min.'), loc.checklist_hint('#'), loc.initiative('X'),
            loc.language_html('#'), loc.colophon('a', 'b', 'c'), loc.watch_on('x'), loc.path_no('01'),
            loc.guide_intro('#'), loc.guide_parts('x'), loc.guide_glossary('#'), loc.method_text(),
            loc.footer_licence('a', 'b', 'c'), loc.brand_sub('PROOF'), loc.cover_desc('T', 'N'),
            loc.search_about_text('X'), loc.source_link(loc.file_size(1234567)), loc.source_link(loc.file_size(98765)),
            loc.legal_desc('T')]
    sample = dict.fromkeys(('notice', 'cc_url', 'content_licence', 'agpl_url', 'licence', 'zip', 'ofl_jb', 'ofl_r'), '#')
    sample.update(title_html='T', date='2026-10-22', zip_name='a.zip', zip_size='1 MB', zip_sha='0' * 64)
    walk(loc.legal_sections(sample))
    return out


def typography_problems(loc):
    """House rules that a machine can check (lt/LT-TRANSLATION-GUIDE.md): no em or en dash, no straight double
    quote in text, no plural "you" forms. Grammar and naturalness still need a native editor."""
    problems = []
    for s in sample_strings(loc):
        if _DASH.search(s):
            problems.append('dash: %s' % s)
        if _YOU_PLURAL.search(s):
            problems.append('jūs form: %s' % s)
        if _STRAIGHT.search(re.sub(r'<[^>]+>', '', s)):
            problems.append('straight quote: %s' % s)
        if s.count('„') != s.count('“'):
            problems.append('unbalanced „ “: %s' % s)
    return sorted(set(problems))
