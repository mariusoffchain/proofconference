# 17 skyrius: Aparatinės piniginės

## Trumpai

Piniginė telefone tinka smulkioms išlaidoms, o santaupoms reikia ko nors patikimesnio. Aparatinė piniginė yra mažas specialus įrenginys, kuris privačiuosius raktus laiko atjungtus nuo interneto ir transakcijas pasirašo savo viduje, todėl kompiuteryje ar telefone esanti kenkėjiška programa raktų nepamato. Gerų įrenginių yra keletas, jų kompromisai skirtingi, ir nė vienas nėra nepažeidžiamas. Atkūrimo frazės atsarginės kopijos (žr. 14 skyrių) įrenginys nepakeičia, nes jis gali sugesti arba pasimesti, ir tada lėšas atkursi būtent iš atsarginės kopijos.

## Raktai įrenginyje, kuris visada prijungtas prie interneto

Telefonas prie interneto prijungtas visą dieną. Jame veikia dešimtys programėlių, į jį ateina nuorodos iš nepažįstamų žmonių, jis jungiasi prie viešų belaidžių tinklų („Wi-Fi“) ir diegia daugelio įmonių naujinius, o kompiuteryje padėtis ne geresnė. Kiekvienas toks dalykas yra durys, o tame pačiame įrenginyje veikianti piniginės programėlė raktus laiko už tų durų.

Sumai, kurią nešiotumeisi tikroje piniginėje, tokia rizika priimtina, o patogumas jos vertas. Su santaupomis skaičiavimas kitoks. Kenkėjiškų programų, kurios nuskaito piniginės failą, pakeičia adresą iškarpinėje arba įrašinėja ekraną, tikrai yra, ir jos parduodamos kaip gatavas produktas. Bitcoin transakcijos atšaukti neįmanoma, o pagalbos tarnybos, kuriai galėtum paskambinti, nėra.

Kad su tuo susitvarkytum, saugumo eksperto žinių nereikia. Praktiška išeitis yra raktus iš šių įrenginių perkelti į tokį, kuris sukurtas taip, kad tokios programos jų nepasiektų.

## Mažas kompiuteris, kuris tik pasirašo

Aparatinė piniginė, tiksliau vadinama **pasirašymo įrenginiu**, yra mažytis kompiuteris su vienintele užduotimi. Jis sugeneruoja atkūrimo frazę, privačiuosius raktus laiko savo luste ir sukurtas taip, kad niekada jų neišduotų.

Kai nori išsiųsti bitkoinų, darbas padalijamas į 2 dalis:

1. Transakciją parengia programa kompiuteryje arba programėlė telefone. Ji žino tik viešąją informaciją, todėl gali parodyti likutį ir parengti mokėjimą, bet išleisti lėšų negali.
2. Transakcija perduodama įrenginiui kabeliu, per „Bluetooth“, QR kodu arba atminties kortele. Įrenginys savo ekrane parodo sumą ir gavėjo adresą. Viską patikrini, patvirtini įrenginyje, ir jis pasirašo savo viduje. Atgal grįžta tik parašas.

Jei kompiuteris užkrėstas, kenkėjiška programa mato pasirašytą transakciją, o ne raktą. Ji vis tiek gali kompiuterio ekrane parodyti netikrą adresą, todėl žiūrėti reikia į įrenginio ekraną.

Tikroji piniginė ir toliau yra atkūrimo frazė, o įrenginys tėra saugesnis būdas ja naudotis. 14 skyriuje aprašytos atsarginės kopijos vis tiek reikia, o atkūrimo frazė patikima tik tiek, kiek patikimas buvo atsitiktinumas, iš kurio įrenginys ją sukūrė. 2023 m. rugpjūtį [tyrėjų paskelbtas „Milk Sad“ spragos aprašymas](https://milksad.info/disclosure.html) parodė, kad programinis įrankis „Libbitcoin Explorer“ atkūrimo frazes kūrė tik iš 32 bitų atsitiktinumo, nors turėtų būti nuo 128 iki 256 bitų, ir juo sukurtos piniginės 2023 m. liepos 12 d. buvo ištuštintos. Jokiu naujiniu tų atkūrimo frazių pataisyti nebuvo galima, todėl savininkams teko susikurti naujas ir perkelti lėšas. Panašus gedimas 2026 m. liepą pasitaikė ir aparatinėje piniginėje, kai bendrovė „Coinkite“ [paskelbė, kad nuo 2021 m. išleista „COLDCARD“ įrenginių programinė įranga](https://blog.coinkite.com/coldcard-mk3-seed-generation-warning/) kūrė silpnas atkūrimo frazes (žr. lentelę).

## Gamintojas, kuriuo vis tiek tenka pasitikėti

Nuo interneto atjungti raktai apsaugoti nuo tavo kompiuterio, tačiau pasitikėti dabar tenka įrenginio gamintoju. Gamintojas rašo programinę aparatinę įrangą (angl. firmware), kuri sukuria atkūrimo frazę ir pasirašo transakcijas. Jis taip pat kontroliuoja tiekimo grandinę ir dažniausiai valdo kartu su įrenginiu naudojamą programą, kurios serveriai gali matyti tavo adresus ir IP adresą. Bendrovės „Ledger“ duomenys (žr. lentelę) nutekėjo net ne iš įrenginio, o iš gamintojo parduotuvės klientų sąrašo.

Jei įrenginio programinė įranga yra atvirojo kodo, ją gali perskaityti pašaliniai žmonės, o [atkartojamas programos surinkimas (angl. reproducible build)](https://github.com/BitBoxSwiss/bitbox02-firmware/blob/master/releases/README.md) leidžia bet kam įsitikinti, kad diegi būtent paskelbtą kodą. Parašo patikra įrodo, kad programinė įranga gauta iš gamintojo, bet ne tai, kad ji veikia tinkamai. Kai pasirašoma visiškai atjungtu nuo tinklų įrenginiu (angl. air-gapped), kompiuteris jam gali nusiųsti mažiau duomenų. Saugusis lustas (angl. secure element) atsilaiko prieš žmogų, laikantį įrenginį rankose, tačiau tokiems lustams dažnai taikoma konfidencialumo sutartis, ir [dėl to bendrovė „Ledger“ dalį savo sistemos laiko uždarą](https://www.ledger.com/blog-ledger-is-95-opensource-why-not-100). Kai kurie įrenginiai kaip atsitiktinumo šaltinį priima kauliukų metimus, tad prie lusto atsitiktinumo gali pridėti savo.

Nė viena iš šių priemonių neleidžia apsieiti be gamintojo. Kelių parašų schema (angl. multisig) su 2 gamintojų įrenginiais (ji paaiškinta toliau) šį pasitikėjimą paskirsto, tačiau pirmajam įrenginiui saugesnis kelias tebėra gamintojo programa ir jos automatinės patikros.

## Kaip pasirinkti įrenginį

Toliau išvardyti įrenginiai skiriasi atvirumu, kaina, patogumu ir izoliacija. „Visiškai atjungtas nuo tinklų“ reiškia, kad įrenginio niekada nereikia jungti prie kompiuterio, nes transakcijos perduodamos QR kodu arba atminties kortele. Gamintojų asortimentas greitai keičiasi, o ši lentelė atspindi 2026 m. rugsėjo mėn. padėtį.

| Įrenginys | Gamintojas | Privalumai | Kompromisai | Pasitikėjimas gamintoju ir ką gali patikrinti |
|---|---|---|---|---|
| **BitBox02** | „BitBox“ („Shift Crypto“), Šveicarija | Atvirojo kodo, paprastas, yra vien Bitcoin skirta versija. [2025 m. birželį pristatytas modelis „BitBox02 Nova“](https://bitcoinmagazine.com/news/bitbox-announces-bitbox02-nova-a-new-hardware-wallet-for-bitcoin) dar turi „Bluetooth“ ryšį ir veikia su „iPhone“ telefonais | Nėra visiškai atjungtas nuo tinklų. Jungiamas per USB-C, o modelis „Nova“ ir per „Bluetooth“ | Įrenginio programinė įranga atvirojo kodo, jos surinkimas atkartojamas, o parašą tikrina programa „BitBoxApp“. Vien saugiuoju lustu nepasikliaujama |
| **Trezor** | „SatoshiLabs“, Čekija | Atvirojo kodo piniginių pradininkas, lengva naudotis, veikia su daugeliu piniginių programų | Senesni modeliai jungiami tik kabeliu, o [2025 m. pabaigoje išleistas modelis „Safe 7“](https://trezor.io/guides/trezor-devices/trezor-safe-7/trezor-safe-7-faqs) turi ir „Bluetooth“. Palaiko daug kitų kriptovaliutų, nebent pasirenki vien Bitcoin skirtą įrenginio programinę įrangą | Atvirojo kodo įrenginio programinė įranga, kurios surinkimas atkartojamas ir kurią tikrina programa „Trezor Suite“. Modelyje „Safe 7“ atsirado audituojamas saugusis lustas (TROPIC01) |
| **COLDCARD** (Mk ir Q serijos) | „Coinkite“, Kanada | Skirtas tik Bitcoin, sukurtas pasirašyti be kabelio, per atminties kortelę arba, modelyje Q, per QR kodą. Turi 2 skirtingų gamintojų saugiuosius lustus. Daug pažangių funkcijų | Pradedantiesiems meniu ir nustatymų daugiau, nei reikia. 2026 m. liepą dėl įrenginio programinės įrangos spragos, susilpninusios nuo 2021 m. sukurtas atkūrimo frazes, lėšos buvo pavogtos iš daugiau kaip 5 200 adresų, [preliminariais skaičiavimais, apie 1 800 bitkoinų](https://www.trmlabs.com/resources/blog/the-largest-hardware-wallet-exploit-of-2026-inside-the-usd-116-million-coldcard-hack). [Atnaujinus įrenginį paveikta atkūrimo frazė nepataisoma](https://coldcard.com/resources/security/coldcard-security-and-verification), ją reikia pakeisti nauja | Šaltinio kodas paskelbtas, surinkimas atkartojamas, tačiau [licencija draudžia programinę įrangą parduoti](https://github.com/Coldcard/firmware/blob/master/COPYING-CC), todėl griežtąja prasme tai nėra atvirasis kodas. Įrenginį patikrinti padeda numeruotas maišelis ir žalia lemputė paleidžiant |
| **Blockstream Jade** | „Blockstream“ | Nebrangus, atvirojo kodo, naudojant QR kodus gali veikti visiškai atjungtas nuo tinklų | PIN kodo apsauga priklauso nuo serverio (bendrovės „Blockstream“ arba nuosavo) | Įrenginio programinė įranga atvirojo kodo. Saugiojo lusto nėra, todėl pasitikėti tenka ir PIN serveriu, nebent paleidi jį savo serveryje |
| **Foundation Passport** | „Foundation Devices“, JAV | Atvirojo kodo, patogus naudoti, pasirašo QR kodu | Vienas iš brangesnių. Naujasis modelis „Passport Prime“ naudoja ir „Bluetooth“, be to, skirtas ne vien Bitcoin (saugos raktai, 2FA kodai) | Atvirojo kodo įrenginio programinė įranga, kurios surinkimas atkartojamas, o maišos reikšmę (angl. hash) gali palyginti su paskelbtąja |
| **SeedSigner** | Bendruomenės projektas | Susirenki iš standartinių dalių, atvirojo kodo, nieko neįsimena (angl. stateless), t. y. nesaugo jokios atkūrimo frazės | Surinkti turi tu, o atkūrimo frazę reikia įkelti kaskart, kai juo naudojiesi. Netinka kaip pirmasis įrenginys | Jokios įmonės nėra. Programinės įrangos parašą tikrini tu, surinkimas atkartojamas, atsitiktinumo šaltinis yra kauliukai arba nuotrauka |
| **Ledger** | „Ledger“, Prancūzija | Populiarus, palaiko daug kriptovaliutų, turi saugųjį lustą | Įrenginio programinė įranga nėra visiškai atvirojo kodo. [2020 m. iš klientų duomenų bazės nutekėjo](https://www.ledger.com/blog/update-efforts-to-protect-your-data-and-prosecute-the-scammers) apie 1 mln. el. pašto adresų ir apie 272 000 pirkėjų vardai, pavardės, pašto adresai ir telefono numeriai | Dalis saugiajame luste veikiančios sistemos uždara, todėl pašaliniai negali iki galo patikrinti, ką daro įrenginio programinė įranga |

Dar reikia programos, su kuria įrenginys naudojamas. Tai gali būti paties gamintojo programa arba nepriklausoma atvirojo kodo piniginė, pavyzdžiui, „Sparrow Wallet“, „Electrum“ (kompiuteriui), „Nunchuk“ (kompiuteriui ir telefonui) arba „BlueWallet“ (telefonui, daugiausia su įrenginiais, kurie pasirašo QR kodu). Su nepriklausoma pinigine nepriklausai nuo to, ar gamintojo programa ir toliau bus prieinama.

Didesnėms sumoms kitas lygmuo yra **kelių parašų piniginė**, kurioje pasirašyti turi, pavyzdžiui, 2 įrenginiai iš 3. Kai įrenginiai skirtingų gamintojų, 1 gamintojo spragos ar 1 įrenginio vagystės nepakanka jai ištuštinti. Pasidaryk pakankamo skaičiaus pasirašymo raktų atsargines kopijas ir išsaugok visą kelių parašų piniginės konfigūraciją arba deskriptorių (angl. output descriptor) su visų bendrai pasirašančių dalyvių išplėstiniais viešaisiais raktais (xpub) (žr. 14 skyrių). Patys šie viešieji raktai lėšų išleisti neleidžia, tačiau atskleidžia piniginės veiklą. Darbo čia daugiau, todėl pirmiausia gerai perprask 1 įrenginį.

Daugumai žmonių protingas derinys būtų toks: atvirojo kodo įrenginys, kuriame įdiegta vien Bitcoin skirta programinė įranga, pirktas naujas ir atnaujintas prieš pradedant naudotis, kartu su programa „Sparrow“ arba gamintojo programa. Kurį gamintoją rinktis, sprendi tu.

## Žingsnis po žingsnio

Su visais įrenginiais eiga iš esmės ta pati, tačiau 2 žingsnio patikra priklauso nuo gamintojo, todėl laikyk atvertą oficialų gamintojo vadovą.

1. **Pirk tiesiogiai iš gamintojo arba iš oficialaus platintojo.** Niekada nepirk naudoto įrenginio ir niekada nepirk iš pardavėjų elektroninėse prekyvietėse.
2. **Patikrink įrenginį taip, kaip nurodo gamintojas.** Kai kurie gamintojai įrenginį siunčia užplombuotame arba sunumeruotame apsauginiame maišelyje. O bendrovė „Ledger“ [teigia nenaudojanti jokių apsauginių plombų](https://donjon.ledger.com/threat-model/device-genuineness/), nes, jos vertinimu, jas lengva nukopijuoti, ir pasikliauja kriptografine patikra savo programoje. „BitBox“, „Trezor“ ir „Ledger“ programos patikrina įrenginį ir įdiegia pasirašytą įrenginio programinę įrangą. „SeedSigner“ programinę įrangą atsisiunti ir jos parašą patikrini tu. Visais atvejais pirmiausia įdiek naujausią įrenginio programinę įrangą ir tik tada kurk atkūrimo frazę. Būtent šiuo žingsniu pasitikėjimą pristatymo grandine pakeiti patikra, nors ji vis tiek remiasi paties gamintojo parašu.
3. **Naują atkūrimo frazę sugeneruok įrenginyje.** Žodžiai turi pirmą kartą pasirodyti įrenginio ekrane, tau matant. Niekada nenaudok žodžių, kuriuos radai atspausdintus dėžutėje.
4. **Pasidaryk jos atsarginę kopiją** popieriuje arba metale, kaip paaiškinta 14 skyriuje. Jei įrenginys tai palaiko, nustatyk PIN kodą. Būsenos nesaugantys (angl. stateless) įrenginiai, pavyzdžiui, „SeedSigner“, veikia kitaip.
5. **Patikrink gavimo adresą įrenginio ekrane ir tik tada išsiųsk visai mažą bandomąją sumą.** Tai daryk dar prieš perkeliant santaupas, o ne po to.
6. **Atkūrimą patikrink, kol rizikuoji tik visai mažu bandomuoju likučiu.** Įrenginyje vadovaukis gamintojo nurodyta atsarginės kopijos tikrinimo arba duomenų ištrynimo ir atkūrimo procedūra. Prieš bandymą įsitikink, kad atsarginės kopijos formatas suderinamas, ir užsirašyk slaptafrazę, jei ją naudoji. Prieš pervedant santaupas įsitikink, kad rodomi tie patys adresai ir tas pats bandomasis likutis. Atsarginės kopijos nevesk į įprastas telefono ar kompiuterio pinigines. Būsenos nesaugančio įrenginio duomenų trinti nereikia, į jį viskas tiesiog įkeliama iš naujo.
7. **Perkelk likusią sumą** 1 arba keliomis transakcijomis.
8. **Gavimo adresą kaskart patikrink įrenginio ekrane.** Kompiuterio ekrano vaizdą galima suklastoti, o su įrenginio ekranu tai padaryti daug sunkiau.

## Klaidos, kurių verta vengti

- **Pirkti elektroninėse prekyvietėse.** Per nežinomas rankas perėjęs įrenginys galėjo būti perdarytas, ir nedidelė sutaupyta suma tokios rizikos neverta.
- **Priimti atkūrimo frazės kortelę, kuri atkeliauja jau užpildyta.** Visais atvejais laikyk tai apgavyste, nes tuos žodžius atspausdinęs žmogus laukia tavo įmokos.
- **Įvesti atkūrimo frazę kompiuteryje, „kad būtų galima atnaujinti“.** Jokiam tikram naujiniui, programai ar pagalbos tarnybos darbuotojui atkūrimo frazės nereikia. Atkuriant piniginę vadovaukis patikrinta gamintojo procedūra ir paties įrenginio nurodymais. Jei įrenginys leidžia, žodžius vesk pačiame įrenginyje. Niekada nevesk jų svetainėje ir nevesk, kai to prašo naujinys ar pagalbos tarnyba.
- **Praleisti bandomąjį atkūrimą.** Neteisingą ar trūkstamą žodį geriau aptikti dabar, kai rizikuoji bandomąja suma, o ne po 5 metų, kai rizikuosi santaupomis.
- **Nepagalvojus nurodyti namų adresą kaip pristatymo vietą.** Klientų sąrašai nuteka, kaip parodė „Ledger“ atvejis, ir tada toks sąrašas nepažįstamiems žmonėms pasako, kur gyvena bitkoinų turėtojas. Pagalvok apie atsiėmimo punktą arba paštomatą.
- **Pasitikėti el. laiškais, kurių siuntėjas prisistato gamintoju.** Po „Ledger“ duomenų nutekėjimo pirkėjai gavo įtikinamų sukčiavimo apsimetant (angl. phishing) laiškų su netikrais saugumo įspėjimais ir netikrais naujiniais, o 2021 m. kai kuriems net buvo [paštu atsiųsti perdaryti įrenginiai](https://www.bleepingcomputer.com/news/cryptocurrency/criminals-are-mailing-altered-ledger-devices-to-steal-cryptocurrency/), pateikti kaip pakaitiniai. Oficialią svetainę atverk tiesiogiai, niekada per nuorodą.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl nuo tavo raktų priklauso tavo interneto sauga“, pranešimą skaito Satoshine. Pasirašymo įrenginys yra ta pati idėja, įgavusi fizinį pavidalą.
- **Nepriklausomos piniginių ir įrenginių patikros:** „WalletScrutiny“ (walletscrutiny.com) tikrina, ar paskelbtas kodas sutampa su tuo, ką iš tikrųjų įdiegi.
- **Kaip prijungti įrenginį prie nepriklausomos piniginės:** „Sparrow Wallet“ dokumentacija (sparrowwallet.com/docs).
- **Įrenginių vadovai žingsnis po žingsnio:** „Bitcoiner.Guide“ (bitcoiner.guide).
- **Kitas skyrius:** kaip paleisti savo mazgą.

## Šaltiniai

- [How to use a wallet backup](https://trezor.io/guides/backups-recovery/general-standards/how-to-use-a-wallet-backup), „Trezor“, tikrinta 2026 m. spalio 22 d.
- [Multisig backup warning and descriptor export](https://github.com/sparrowwallet/sparrow/blob/master/src/main/java/com/sparrowwallet/sparrow/wallet/MultisigBackupDialog.java), „Sparrow“ programos kodas, tikrinta 2026 m. spalio 22 d.
- [Update: efforts to protect your data and prosecute the scammers](https://www.ledger.com/blog/update-efforts-to-protect-your-data-and-prosecute-the-scammers), „Ledger“, 2021 m. sausio 13 d.
- [Threat model: device genuineness](https://donjon.ledger.com/threat-model/device-genuineness/), „Ledger Donjon“, žiūrėta 2026 m. rugsėjį.
- [Criminals are mailing altered Ledger devices to steal cryptocurrency](https://www.bleepingcomputer.com/news/cryptocurrency/criminals-are-mailing-altered-ledger-devices-to-steal-cryptocurrency/), „BleepingComputer“, 2021 m. birželio 16 d.
- [Milk Sad: technical write-up of CVE-2023-39910](https://milksad.info/disclosure.html), „Milk Sad“ tyrėjų komanda, 2023 m. rugpjūčio mėn.
- [BitBox Announces BitBox02 Nova](https://bitcoinmagazine.com/news/bitbox-announces-bitbox02-nova-a-new-hardware-wallet-for-bitcoin), „Bitcoin Magazine“, 2025 m. birželio 20 d.
- [Reproducible builds of the BitBox02 firmware](https://github.com/BitBoxSwiss/bitbox02-firmware/blob/master/releases/README.md), „BitBox“ platformoje „GitHub“, žiūrėta 2026 m. rugsėjį.
- [Ledger is 95% open source, why not 100%?](https://www.ledger.com/blog-ledger-is-95-opensource-why-not-100), „Ledger“, žiūrėta 2026 m. rugsėjį.
- [Coldcard Security Advisory](https://blog.coinkite.com/coldcard-mk3-seed-generation-warning/), „Coinkite“, 2026 m. liepos 30 d., tikrinta 2026 m. spalio 29 d.
- [COLDCARD security and verification](https://coldcard.com/resources/security/coldcard-security-and-verification) (2 saugieji lustai, numeruotas maišelis, paveiktų atkūrimo frazių keitimas), „Coinkite“, tikrinta 2026 m. spalio 29 d.
- [The Largest Hardware Wallet Exploit of 2026: Inside the USD 116 Million Coldcard Hack](https://www.trmlabs.com/resources/blog/the-largest-hardware-wallet-exploit-of-2026-inside-the-usd-116-million-coldcard-hack), „TRM Labs“, 2026 m. rugpjūčio 5 d., preliminarūs „Galaxy Research“ duomenys.
- [COLDCARD firmware licence, MIT with the Commons Clause](https://github.com/Coldcard/firmware/blob/master/COPYING-CC), „Coinkite“ platformoje „GitHub“, tikrinta 2026 m. spalio 29 d.

## Tavo veiksmų sąrašas

- [ ] Nuspręsk, kokia suma tau jau yra santaupos ir telefone nebeturėtų būti laikoma (5 min.)
- [ ] Išsirink įrenginį iš lentelės ir užsisakyk jį iš gamintojo su pristatymu į atsiėmimo punktą (1 val.)
- [ ] Patikrink įrenginį ir jo programinę įrangą taip, kaip nurodo gamintojas, susikurk naują atkūrimo frazę, pasidaryk atsarginę kopiją ir išsiųsk bandomąją sumą (1 val.)
- [ ] Kol įrenginyje tik visai mažas bandomasis likutis, atlik gamintojo nurodytą aparatinės piniginės atsarginės kopijos tikrinimo ar atkūrimo procedūrą, dar prieš pervedant santaupas (1 val.)
- [ ] Kaskart, kai gauni lėšų, patikrink adresą įrenginio ekrane (5 min.)
