#!/usr/bin/env python3
"""English and Lithuanian editions of the PROOF book in the guide UI, for proofconference.com.

For each language, renders the 23 pages of the book (18 chapters, the introduction, the 3 part openings and the
glossary), the cover, the page of all actions (/checklist/) and the "Where to start?" page as complete static HTML,
in the markup that dist/app.js builds in the local edition, each with its own title, description, canonical and
hreflang links: English under /book/en/, Lithuanian under /book/. dist/app.js then enhances the page in place
(ticks, progress, search, contents, former #/ routes, migration of the former checklist) without building it again.
Both editions share the interface files, the service worker, the storage keys and the 90 action IDs, so a tick made
in one language is the same tick in the other. The interface strings come from site/guide_locales.py.

Default command, from book-drafts (see guide-ui/INTEGRATION.md):

    python3 build.py
    python3 build.py --dry-run          render and check everything, write nothing

or directly: python3 guide-ui/build_integration.py [--dry-run] [--site-dir PATH]

Each edition also gets a legal page (legal/: credits, modification notice, licences, fonts, names and logos, source),
linked from every footer with the source archive. The full licence and notice texts are served offline with the
interface files (book/guide-assets/legal/); the source archive (book/source/, written by source_archive.py from an
explicit file list) is online only.

Writes only an explicit list of files: the 27 index.html of each language, the files of book/guide-assets/ named
below, the source archive, book/sw.js, sitemap.xml and guide-ui/integration-report.json (private, never exported).
Never deletes a file: every other file of the site (outside .git and book-drafts) is hashed before and after the
build, and the build fails if one changed.
"""

import argparse
import copy
import hashlib
import html
import json
import os
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
from html.entities import name2codepoint
from pathlib import Path
from urllib.parse import quote, urlsplit

PROJECT = Path(__file__).resolve().parent           # book-drafts/guide-ui
DRAFTS = PROJECT.parent                             # book-drafts: Markdown sources, build.py, site/
DIST = PROJECT / 'dist'
SCRIPTS = PROJECT / 'scripts'
LOCALE_DIR = PROJECT / 'site'
for _p in (str(SCRIPTS), str(DRAFTS), str(LOCALE_DIR), str(PROJECT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import import_book as ib   # noqa: E402  the sources of both languages, the content filter and the action registries
import build as legacy     # noqa: E402  summary() and autolink() of the former renderer, the replays data
import guide_locales       # noqa: E402  interface strings of both editions
import lt_sources          # noqa: E402  Lithuanian filter markers
import source_archive      # noqa: E402  the source archive and the licence files of guide-ui/legal/

SITE_URL = legacy.SITE                              # https://proofconference.com
LANGS = ('en', 'lt')
BASES = {'en': '/book/en/', 'lt': '/book/'}
ASSET_URL = '/book/guide-assets/'
ASSET_DIR = ('book', 'guide-assets')
REPORT = PROJECT / 'integration-report.json'
LEGACY_MAP = SCRIPTS / 'legacy-action-map.json'
INTEGRATION_CSS = PROJECT / 'site' / 'integration.css'
# Talk recordings of the cover: the replay styles of the conference home page scoped to .guide-replays (appended to
# guide.css) and the host /replays.js with an embed-only referrer policy (its own asset, loaded by the covers only). The host
# replays.js at the site root is only read by the legacy imports; the guide runs the snapshot.
REPLAYS_CSS = PROJECT / 'site' / 'replays.css'
REPLAYS_JS = PROJECT / 'site' / 'replays.js'

# Sitemap <lastmod> floor of the book pages: the day they moved to the guide UI (English 2026-10-22, Lithuanian the same
# day, both locally; a later publication does not change it).
UI_CHANGED_ON = '2026-10-22'

# Same addresses as the former renderer, in both languages: the part openings keep their slugs, "All actions" stays
# /checklist/. /start/ is the only address the former renderer did not have.
PAGE_PATHS = {'introduction': 'introduction/', 'part-1': 'privacy/', 'part-2': 'autonomy/',
              'part-3': 'work/', 'glossary': 'glossary/'}
ACTIONS_PATH = 'checklist/'
START_PATH = 'start/'
LEGAL_PATH = 'legal/'
NEW_PATHS = (START_PATH, LEGAL_PATH)                # the only book addresses the former renderer did not have
LEGACY_KEYS = {'actions': 'proof-book-v2', 'read': 'proof-book-read', 'last': 'proof-book-last'}

# Interface files of /book/guide-assets/: shared, except the search index and the site data of each language.
SHARED_ASSETS = ('guide.css', 'guide.js', 'config.js', 'replays.js')
SITE_DATA = {'en': 'site-data.js', 'lt': 'site-data-lt.js'}
SEARCH_INDEX = {'en': 'search-index.js', 'lt': 'search-index-lt.js'}
# Full licence and notice texts, served with the interface files (so precached, readable offline): asset name ->
# file of guide-ui/legal/. Python-Markdown is a build tool, not served: its licence is in the source archive only.
LEGAL_ASSETS = {'legal/LICENSE.txt': 'LICENSE', 'legal/LICENSE-CONTENT.txt': 'LICENSE-CONTENT',
                'legal/NOTICE.txt': 'NOTICE.txt', 'legal/OFL-JetBrainsMono.txt': 'OFL-JetBrainsMono.txt',
                'legal/OFL-Righteous.txt': 'OFL-Righteous.txt'}
# Precached besides the pages and the interface files: the icon every page links to. The source archive is not.
EXTRA_CORE = ('/favicon.svg',)

# Effort tag of an action in English and in Lithuanian (lt/LT-TRANSLATION-GUIDE.md, part E).
EFFORT_PAIRS = {'5 min': '5 min.', '1 hour': '1 val.', 'weekend': 'savaitgalis'}
FILTER_MARKERS = {'en': ('At PROOF:', 'sponsors this conference'), 'lt': lt_sources.FILTERED_MARKERS}

# Without JavaScript the "On this page" toggle of narrow screens cannot open: it is hidden and the list shows in the
# page flow. In <noscript>, so pages with the script never show the open list before it runs.
NOSCRIPT_CSS = ('@media (max-width: 1023px) { .toc-toggle { display: none; } .toc-aside { position: static; } '
                '.page-toc, .page-toc .toc-title { display: block; } .page-toc { position: static; max-height: none; box-shadow: none; } }')

CSP_TEMPLATE = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                "font-src 'self'; connect-src 'none'; %s; object-src 'none'; base-uri 'none'; form-action 'none'")
CSP = CSP_TEMPLATE % "frame-src 'none'"             # every page except the covers: no frame, no media but its own
YOUTUBE_ORIGIN = 'https://www.youtube-nocookie.com'
# Blossom GET/Range requests redirect here (verified 2026-10-23); HEAD alone does not show it.
REPLAY_CDN_ORIGINS = ('https://r2a.primal.net',)


def replay_media_origins():
    """Origins of the MP4 files of site/content.json (video and video_sd): the only third-party media the cover allows."""
    out = []
    for it in legacy.REPLAYS['items']:
        for key in ('video', 'video_sd'):
            url = it.get(key)
            if url and re.search(r'\.mp4(?:[?#]|$)', url, re.I):
                parts = urlsplit(url)
                origin = '%s://%s' % (parts.scheme, parts.netloc)
                if parts.scheme != 'https' or origin in out:
                    if parts.scheme != 'https':
                        raise IntegrationError('Replay video %s is not https.' % url)
                    continue
                out.append(origin)
    return sorted(set(out) | set(REPLAY_CDN_ORIGINS))


def cover_csp():
    """CSP of the covers only: the click-to-play recordings need the YouTube no-cookie frame and the MP4 origins."""
    return CSP_TEMPLATE.replace("object-src 'none'", "media-src 'self' %s; object-src 'none'" % ' '.join(replay_media_origins())) \
        % ("frame-src " + YOUTUBE_ORIGIN)


def csp_of(page):
    return cover_csp() if page['path'] == '' else CSP


class IntegrationError(Exception):
    pass


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def esc(s):
    return html.escape(str(s), quote=True)


def squash(s):
    return ' '.join(str(s).split())


def pad(n):
    return '%02d' % n


def fold(s):
    return ''.join(ch for ch in unicodedata.normalize('NFD', s) if not '̀' <= ch <= 'ͯ').lower()


def slug(s):
    return re.sub(r'^-|-$', '', re.sub(r'[^a-z0-9]+', '-', fold(s)))


def host_of(url):
    try:
        host = urlsplit(url).hostname
    except ValueError:
        return url
    if not host:
        return url
    return host[4:] if host.startswith('www.') else host


def lang_of(url_path):
    """Edition of a /book/ address: en under /book/en/, lt elsewhere under /book/ (the interface files excepted)."""
    if url_path.startswith(BASES['en']):
        return 'en'
    if url_path.startswith(BASES['lt']) and not url_path.startswith(ASSET_URL):
        return 'lt'
    return None


def page_paths():
    """The 27 page paths of each edition, relative to its base: the 26 book pages and the legal page."""
    return ([''] + [PAGE_PATHS['introduction']] + [PAGE_PATHS['part-%d' % n] for n in (1, 2, 3)]
            + [c[2] + '/' for c in ib.CHAPTERS] + [ACTIONS_PATH, PAGE_PATHS['glossary'], START_PATH, LEGAL_PATH])


def asset_names():
    return (list(SHARED_ASSETS) + [SITE_DATA[l] for l in LANGS] + [SEARCH_INDEX[l] for l in LANGS]
            + ['fonts/' + f.name for f in sorted((DIST / 'assets' / 'fonts').glob('*.woff2'))] + list(LEGAL_ASSETS))


def planned_writes():
    """Every file the build may write, relative to the site folder. Nothing else is ever written."""
    out = set()
    for lang in LANGS:
        for p in page_paths():
            out.add(BASES[lang].lstrip('/') + p + 'index.html')
    out.update('/'.join(ASSET_DIR) + '/' + name for name in asset_names())
    out.update(('book/sw.js', 'sitemap.xml', source_archive.ARCHIVE_REL))
    return out


# ---------- config.js, read as data ----------

_WORD = re.compile(r'[A-Za-z_$][\w$]*|-?\d+(?:\.\d+)?')


def read_config(path):
    """window.GUIDE_CONFIG of dist/config.js. The object literal is tokenized into JSON, never executed."""
    src = path.read_text(encoding='utf-8')
    marker = 'window.GUIDE_CONFIG ='
    if marker not in src:
        raise IntegrationError('%s: "%s" not found.' % (path, marker))
    i, n, depth, out = src.index(marker) + len(marker), len(src), 0, []
    while i < n:
        c = src[i]
        if c.isspace():
            i += 1
        elif src.startswith('//', i):
            j = src.find('\n', i)
            i = n if j == -1 else j
        elif src.startswith('/*', i):
            i = src.index('*/', i) + 2
        elif c in '\'"':
            j, buf = i + 1, []
            while src[j] != c:
                if src[j] == '\\':
                    buf.append({'n': '\n', 't': '\t'}.get(src[j + 1], src[j + 1]))
                    j += 2
                else:
                    buf.append(src[j])
                    j += 1
            out.append(json.dumps(''.join(buf)))
            i = j + 1
        elif c in '{[':
            depth += 1
            out.append(c)
            i += 1
        elif c in '}]':
            depth -= 1
            if out and out[-1] == ',':
                out.pop()                            # trailing comma
            out.append(c)
            i += 1
            if depth == 0:
                break
        elif c in ':,':
            out.append(c)
            i += 1
        else:
            m = _WORD.match(src, i)
            if not m:
                raise IntegrationError('%s: unexpected character %r at offset %d.' % (path, c, i))
            w = m.group(0)
            out.append(w if w in ('true', 'false', 'null') or w[0] in '-0123456789' else json.dumps(w))
            i = m.end()
    try:
        return json.loads(''.join(out))
    except ValueError as e:
        raise IntegrationError('%s: could not read the configuration (%s).' % (path, e))


def localized_config(config, loc):
    """config.js with the texts of one language. Every part and every path of config.js needs its translation."""
    cfg = copy.deepcopy(config)
    o = loc.config
    if not o:
        return cfg
    cfg.setdefault('book', {}).update(o['book'])
    cfg.setdefault('edition', {}).update(o['edition'])
    problems = []
    for p in cfg.get('parts') or []:
        if p['number'] not in o['parts']:
            problems.append('part %d has no %s name' % (p['number'], loc.lang))
        else:
            p['name'] = o['parts'][p['number']]
    ids = {p['id'] for p in cfg.get('startPaths') or []}
    for p in cfg.get('startPaths') or []:
        if p['id'] not in o['startPaths']:
            problems.append('path %s has no %s text' % (p['id'], loc.lang))
        else:
            p.update(o['startPaths'][p['id']])
    problems += ['%s text for unknown path %s' % (loc.lang, k) for k in sorted(set(o['startPaths']) - ids)]
    if problems:
        raise IntegrationError('site/guide_locales.py does not match dist/config.js: ' + '; '.join(problems) + '.')
    cfg['searchSuggestions'] = list(o['searchSuggestions'])
    cfg.setdefault('licence', {})['note'] = o['licenceNote']
    return cfg


# ---------- HTML trees (stdlib ElementTree on the well-formed output of Python-Markdown) ----------

_ENTITY = re.compile(r'&([A-Za-z][A-Za-z0-9]*);')


def parse(fragment, where):
    def numeric(m):
        name = m.group(1)
        if name in ('amp', 'lt', 'gt', 'quot', 'apos') or name not in name2codepoint:
            return m.group(0)
        return '&#%d;' % name2codepoint[name]
    try:
        return ET.fromstring('<div>' + _ENTITY.sub(numeric, fragment) + '</div>')
    except ET.ParseError as e:
        raise IntegrationError('%s: the HTML is not well-formed (%s).' % (where, e))


def inner(el, method='html'):
    return html.escape(el.text or '', quote=False) + ''.join(
        ET.tostring(c, encoding='unicode', method=method) for c in el)


def text_of(el, skip=None):
    """textContent of el, without the elements for which skip() is true."""
    parts = []

    def walk(e):
        if e.text:
            parts.append(e.text)
        for c in e:
            if not (skip and skip(c)):
                walk(c)
            if c.tail:
                parts.append(c.tail)
    walk(el)
    return ''.join(parts)


def classes(el):
    return (el.get('class') or '').split()


def add_class(el, c):
    if c not in classes(el):
        el.set('class', ' '.join(classes(el) + [c]))


def parent_map(root):
    return {c: p for p in root.iter() for c in p}


def replace(parents, old, new):
    p = parents[old]
    i = list(p).index(old)
    new.tail, old.tail = old.tail, None
    p.remove(old)
    p.insert(i, new)
    parents[new] = p


def is_todo(li):
    return re.match(r'\s*\[ \]', text_of(li)) is not None


# ---------- the book ----------

class Guide:
    """Port of the page building and views of dist/app.js, with the real addresses of one edition of the site."""

    def __init__(self, book, config, legacy_map, loc):
        self.L = loc
        self.lang = loc.lang
        self.base = BASES[loc.lang]
        self.other_base = BASES['lt' if loc.lang == 'en' else 'en']
        self.cfg = config
        self.BOOK = config.get('book') or {'title': 'A Guide to Autonomy'}
        self.EDITION = config.get('edition') or {}
        self.PARTS = config.get('parts') or []
        self.chapters = sorted(book['chapters'], key=lambda c: c['number'])
        self.pages = book['pages']
        self.by_id = {c['id']: c for c in self.chapters}
        self.page_by_id = {p['id']: p for p in self.pages}
        self.legacy_of = {e['id']: e['legacy_id'] for e in legacy_map['actions']}
        self.legal = None   # addresses and facts of the licence files and the source archive, set by run()
        self.tool_links = 0
        self.built = {c['id']: self.build_doc(c, True) for c in self.chapters}
        self.built_pages = {p['id']: self.build_doc(p, False) for p in self.pages}
        self.total_actions = sum(len(b['actions']) for b in self.built.values())
        self.intro = self.page_of('introduction')
        self.glossary = self.page_of('glossary')
        self.part_pages = [p for p in (self.part_page(x['number']) for x in self.PARTS) if p]
        self.term_count = sum(1 for e in self.built_pages[self.glossary['id']]['index'] if e['type'] == 'term') \
            if self.glossary else 0
        self.sequence = ([self.nav_page(self.intro)] if self.intro else []) + [
            item for p in self.PARTS for item in
            ([self.nav_page(self.part_page(p['number']))] if self.part_page(p['number']) else [])
            + [self.nav_chapter(c) for c in self.part_chapters(p['number'])]
        ] + ([self.nav_actions()] if self.total_actions else []) + ([self.nav_page(self.glossary)] if self.glossary else [])

    # addresses

    @staticmethod
    def at(path, section=None):
        return path + ('#' + quote(section, safe='-_.~') if section else '')

    def chapter_href(self, cid, section=None):
        return self.at(self.base + cid + '/', section)

    def page_href(self, pid, section=None):
        return self.at(self.base + PAGE_PATHS[pid], section)

    def actions_href(self, section=None):
        return self.at(self.base + ACTIONS_PATH, section)

    def start_href(self, section=None):
        return self.at(self.base + START_PATH, section)

    def legal_href(self, section=None):
        return self.at(self.base + LEGAL_PATH, section)

    def home_href(self, section=None):
        return self.at(self.base, section)

    def title_html(self):
        """The book title, marked as English inside a Lithuanian page."""
        t = esc(self.BOOK['title'])
        return '<span%s>%s</span>' % (self.L.title_lang, t) if self.L.title_lang else t

    # lookups

    def part_of(self, n):
        return next((p for p in self.PARTS if p['number'] == n), {'number': n, 'name': self.L.part_n(n)})

    def part_chapters(self, n):
        return [c for c in self.chapters if c['part'] == n]

    def page_of(self, kind, part=None):
        return next((p for p in self.pages if p['kind'] == kind and (part is None or p['part'] == part)), None)

    def part_page(self, n):
        return self.page_of('part', n)

    def actions_of(self, chapters):
        return sum(len(self.built[c['id']]['actions']) for c in chapters)

    # ----- page building (buildDoc of app.js) -----

    def build_doc(self, doc, is_chapter):
        L = self.L
        where = doc['source']
        # Tool names and bare domains become links as in the former renderer (links.json). The links already in the
        # sources are marked first, so that the added ones can be told apart: they stay out of "Cited in this section".
        marked = re.sub(r'<a href=', '<a data-src="" href=', doc['html'])
        tpl = parse(legacy.autolink(marked), where)
        root = ET.Element('div')
        root.text = tpl.text
        sec, count = None, 0
        for node in list(tpl):
            if node.tag == 'h2':
                count += 1
                sec = ET.SubElement(root, 'section', {'class': 'sec', 'data-no': pad(count)})
            (sec if sec is not None else root).append(node)

        for a in root.iter('a'):
            if 'data-src' in a.attrib:
                del a.attrib['data-src']
            else:
                add_class(a, 'tool-link')
                self.tool_links += 1
            if re.match(r'https?://', a.get('href', ''), re.I):
                add_class(a, 'ext')
                a.set('rel', 'noopener noreferrer')

        href = (lambda s=None: self.chapter_href(doc['id'], s)) if is_chapter else (lambda s=None: self.page_href(doc['id'], s))
        label = L.doc_label_chapter(doc['number']) if is_chapter else (
            L.part_opening(doc['part']) if doc['kind'] == 'part' else doc['title'])
        ctx = {'doc': doc, 'chapter': is_chapter, 'href': href, 'label': label, 'actions': [], 'index': [],
               'ids': {e.get('id') for e in root.iter() if e.get('id')}, 'steps': 0, 'checklist_id': None,
               'where': where}

        for s in [e for e in root if e.tag == 'section']:
            h2 = s[0]
            hid = h2.get('id')
            kind = self.section_kind(s, hid, ctx)
            title = squash(text_of(h2))
            add_class(s, 'sec--' + kind)
            s.set('aria-labelledby', hid)
            h2.set('tabindex', '-1')
            kicker = ET.Element('p', {'class': 'sec-kicker'})
            no = ET.SubElement(kicker, 'span', {'class': 'sec-no'})
            no.text = s.get('data-no')
            if L.kind_label[kind]:
                ET.SubElement(kicker, 'span', {'class': 'sec-kind'}).text = L.kind_label[kind]
            s.insert(0, kicker)

            self.index_subsections(s, title, ctx)
            if kind == 'explain':
                self.add_cited(s)
            if kind == 'compare' or (not is_chapter and s.find('.//table') is not None):
                self.wrap_tables(s, title, ctx, kind == 'compare')
            if kind == 'steps':
                self.mark_steps(s, title, ctx)
            if kind == 'checklist':
                self.build_checklist(s, ctx)
                ctx['checklist_id'] = hid
            if kind == 'glossary':
                self.mark_terms(s, title, ctx)
            if kind in ('sources', 'further'):
                for ul in s.iter('ul'):
                    add_class(ul, 'refs')

            skip = lambda e: (e.tag in ('h2', 'noscript') or bool(set(classes(e)) & {
                'sec-kicker', 'compare-cap', 'sec-cited', 'cl-head', 'cl-hint', 'effort', 'legacy-anchor'}))
            ctx['index'].append({
                'type': 'section', 'part': doc['part'], 'title': title,
                'kicker': label + ' · ' + (L.kind_label[kind] or L.in_brief) if is_chapter else label,
                'text': squash(text_of(s, skip)), 'href': href(hid)})

        def toc_map(items):
            out = []
            for i, h in enumerate(items or []):
                el = root.find(".//*[@id='%s']" % h['id'])
                out.append({'id': h['id'], 'no': pad(i + 1) if h['level'] == 2 else '',
                            'label': squash(text_of(el)) if el is not None else h['name'],
                            'href': href(h['id']), 'children': toc_map(h['children'])})
            return out
        toc = toc_map(doc['headings'])

        first = {'type': 'chapter', 'part': doc['part'], 'title': doc['title'],
                 'kicker': L.chapter_kicker(doc['number'], self.part_of(doc['part'])['name'])} if is_chapter else {
            'type': 'page', 'part': doc['part'], 'title': doc['title'],
            'kicker': (L.part_kicker(doc['part'], self.part_of(doc['part'])['name'])
                       if doc['kind'] == 'part' else L.book_kicker)}
        first.update(text=' · '.join(t['label'] for t in toc), href=href())
        ctx['index'].insert(0, first)
        return {'html': inner(root), 'actions': ctx['actions'], 'index': ctx['index'], 'toc': toc,
                'checklist_id': ctx['checklist_id'], 'ids': ctx['ids']}

    def section_kind(self, sec, hid, ctx):
        if not ctx['chapter']:
            if hid == self.L.sources_id:
                return 'sources'
            return 'glossary' if ctx['doc']['kind'] == 'glossary' else 'explain'
        if any(is_todo(li) for li in sec.iter('li')):
            return 'checklist'
        if hid in self.L.kind_by_id:
            return self.L.kind_by_id[hid]
        if sec.find('.//table') is not None:
            return 'compare'
        return 'explain'

    @staticmethod
    def claim(ctx, base):
        new, k = base, 2
        while new in ctx['ids']:
            new, k = '%s-%d' % (base, k), k + 1
        ctx['ids'].add(new)
        return new

    def index_subsections(self, sec, parent_title, ctx):
        parents = parent_map(sec)
        for h3 in [e for e in sec.iter('h3') if e.get('id')]:
            h3.set('tabindex', '-1')
            sibs = list(parents[h3])
            text = []
            for n in sibs[sibs.index(h3) + 1:]:
                if n.tag in ('h2', 'h3'):
                    break
                text.append(text_of(n))
            ctx['index'].append({'type': 'section', 'part': ctx['doc']['part'], 'title': squash(text_of(h3)),
                                 'kicker': ctx['label'] + ' · ' + parent_title, 'text': squash(' '.join(text)),
                                 'href': ctx['href'](h3.get('id'))})

    def add_cited(self, sec):
        urls = []
        for a in sec.iter('a'):
            if 'ext' in classes(a) and 'tool-link' not in classes(a) and a.get('href') not in urls:
                urls.append(a.get('href'))
        if not urls:
            return
        box = ET.SubElement(sec, 'div', {'class': 'sec-cited'})
        ET.SubElement(box, 'p', {'class': 'sec-cited-label'}).text = self.L.cited
        ul = ET.SubElement(box, 'ul')
        seen = {}
        for url in urls:
            host = host_of(url)
            seen[host] = seen.get(host, 0) + 1
            a = ET.SubElement(ET.SubElement(ul, 'li'), 'a', {'class': 'ext', 'rel': 'noopener noreferrer', 'href': url})
            a.text = host + (' (%d)' % seen[host] if seen[host] > 1 else '')

    def wrap_tables(self, sec, title, ctx, index_rows):
        L = self.L
        tables = list(sec.iter('table'))
        parents = parent_map(sec)
        for i, table in enumerate(tables):
            tbody, thead = table.find('tbody'), table.find('thead')
            rows = tbody.findall('tr') if tbody is not None else []
            head_row = thead.find('tr') if thead is not None else None
            heads = [squash(text_of(c)) for c in head_row] if head_row is not None else []
            for th in (thead.iter('th') if thead is not None else []):
                th.set('scope', 'col')
            if heads and heads[0].lower() in L.row_header_columns:
                for tr in rows:
                    cell = next(iter(tr), None)
                    if cell is not None and squash(text_of(cell)):
                        cell.tag = 'th'
                        cell.set('scope', 'row')
            fig = ET.Element('figure', {'class': 'compare'})
            cap = ET.SubElement(fig, 'figcaption', {'class': 'compare-cap'})
            ET.SubElement(cap, 'span').text = L.table_caption(len(rows), len(heads), index_rows)
            ET.SubElement(cap, 'span', {'class': 'compare-hint', 'aria-hidden': 'true'}).text = L.scroll_hint
            scroller = ET.SubElement(fig, 'div', {
                'class': 'table-scroll', 'role': 'region', 'tabindex': '0',
                'aria-label': L.table_aria(title, index_rows, i + 1, len(tables))})
            replace(parents, table, fig)
            scroller.append(table)
            if not index_rows:
                continue
            for tr in rows:
                cells = list(tr)
                name = squash(text_of(cells[0]))
                tr.set('id', self.claim(ctx, 'row-' + (slug(name) or 'item')))
                ctx['index'].append({
                    'type': 'tool', 'part': ctx['doc']['part'], 'title': name,
                    'kicker': ctx['label'] + ' · ' + L.compared_in(title),
                    'text': ' · '.join((heads[j + 1] + ': ' if j + 1 < len(heads) and heads[j + 1] else '')
                                       + squash(text_of(c)) for j, c in enumerate(cells[1:])),
                    'href': ctx['href'](tr.get('id'))})

    def mark_steps(self, sec, title, ctx):
        for ol in list(sec.iter('ol')):
            ctx['steps'] += 1
            prefix = 'step-' if ctx['steps'] == 1 else 'step-%d-' % ctx['steps']
            add_class(ol, 'steps')
            for i, li in enumerate([c for c in ol if c.tag == 'li']):
                li.set('id', self.claim(ctx, prefix + str(i + 1)))
                lead = next(li.iter('strong'), None)
                name = re.sub(r'[.:]$', '', squash(text_of(lead) if lead is not None else text_of(li)[:64]))
                ctx['index'].append({'type': 'step', 'part': ctx['doc']['part'], 'title': self.L.step_title(i + 1, name),
                                     'kicker': ctx['label'] + ' · ' + title, 'text': squash(text_of(li)),
                                     'href': ctx['href'](li.get('id'))})

    def mark_terms(self, sec, group, ctx):
        for p in list(sec.iter('p')):
            if p.text or not len(p) or p[0].tag != 'strong':
                continue
            lead = text_of(p[0])
            term = re.sub(r'[.:]$', '', squash(lead))
            p.set('id', self.claim(ctx, 'term-' + (slug(term) or 'item')))
            add_class(p, 'term')
            ctx['index'].append({'type': 'term', 'part': None, 'title': term, 'kicker': ctx['label'] + ' · ' + group,
                                 'text': squash(text_of(p)[len(lead):]), 'href': ctx['href'](p.get('id'))})

    def build_checklist(self, sec, ctx):
        L = self.L
        items = [li for li in sec.iter('li') if is_todo(li)]
        if not items:
            return
        ch = ctx['doc']
        known = ch['actions']
        if len(known) != len(items):
            raise IntegrationError('%s: %d checklist items rendered, %d actions imported.' % (ctx['where'], len(items), len(known)))
        parents = parent_map(sec)
        list_el = parents[items[0]]
        for i, li in enumerate(items):
            h = re.sub(r'^\s*\[ \]\s*', '', inner(li, 'xml'))
            effort = ''
            m = re.search(r'\s*\(([^()<>]+)\)\s*$', h)
            if m:
                effort, h = m.group(1).strip(), h[:m.start()]
            text = squash(html.unescape(re.sub(r'<[^>]+>', '', h)))
            if ib.normalize(text) != ib.normalize(known[i]['text']):
                raise IntegrationError('%s: action %d reads "%s", the importer gave "%s".' % (ctx['where'], i + 1, text, known[i]['text']))
            aid = known[i]['id']
            if aid in self.legacy_of:
                alias = self.legacy_of[aid]
                if alias in ctx['ids']:
                    raise IntegrationError('%s: the former anchor #%s is already an ID of the page.' % (ctx['where'], alias))
                ctx['ids'].add(alias)
            ctx['actions'].append({'id': aid, 'text': text, 'effort': effort, 'html': h})
            ctx['index'].append({'type': 'action', 'part': ch['part'], 'title': text,
                                 'kicker': ctx['label'] + ' · ' + L.checklist_action(effort),
                                 'text': '', 'href': self.chapter_href(ch['id'], 'action-' + aid)})
        wrap = parse('<div class="checklist">' + self.checklist_head(ch['id'], len(items))
                     + '<ul class="actions">' + ''.join(self.action_item(a) for a in ctx['actions']) + '</ul>'
                     + '<p class="cl-hint">' + L.checklist_hint(self.actions_href()) + '</p>'
                     + '<noscript><p class="cl-hint">' + esc(L.noscript_ticks) + '</p></noscript></div>',
                     ctx['where'])[0]
        replace(parents, list_el, wrap)
        # The page of all actions inserts the same HTML as text: back to HTML serialization (no XML short tags).
        for a in ctx['actions']:
            a['html'] = inner(parse(a['html'], ctx['where']))

    def checklist_head(self, cid, total):
        return ('<div class="cl-head"><p class="cl-count">%s</p><span class="bar" data-bar="ch" data-ch="%s" '
                'aria-hidden="true"><i></i></span></div>'
                % (self.L.count_done('<strong data-stat="ch-done" data-ch="%s">0</strong>' % cid, total), cid))

    def action_item(self, a):
        """Same markup as actionItem() of app.js, plus an empty anchor with the former checkbox ID of the action."""
        alias = self.legacy_of.get(a['id'])
        return ('<li class="action" id="action-%s">' % esc(a['id'])
                + ('<span class="legacy-anchor" id="%s" aria-hidden="true"></span>' % esc(alias) if alias else '')
                + '<label class="action-row"><input type="checkbox" class="action-cb" data-action="%s" disabled="disabled" />' % esc(a['id'])
                + '<span class="action-text">' + a['html'] + '</span>'
                + ('<span class="effort"><span class="sr-only">%s</span>%s</span>' % (self.L.effort_sr, esc(a['effort'])) if a['effort'] else '')
                + '</label></li>')

    # ----- sequence -----

    def nav_chapter(self, c):
        return {'key': 'chapter/' + c['id'], 'href': self.chapter_href(c['id']), 'dir': self.L.chapter_n(c['number']),
                'title': c['title'], 'part': c['part']}

    def nav_page(self, p):
        return {'key': 'page/' + p['id'], 'href': self.page_href(p['id']), 'title': p['title'], 'part': p['part'],
                'dir': self.L.part_opening(p['part']) if p['kind'] == 'part'
                else self.L.reference if p['kind'] == 'glossary' else self.L.before_chapters}

    def nav_actions(self):
        return {'key': 'actions/', 'href': self.actions_href(), 'dir': self.L.global_checklist,
                'title': self.L.all_actions, 'part': None}

    def nav_cover(self):
        return {'key': 'home/', 'href': self.home_href(), 'dir': self.L.cover, 'title': self.L.back_to_cover, 'part': None}

    def neighbours(self, key):
        i = next(k for k, s in enumerate(self.sequence) if s['key'] == key)
        return (self.sequence[i - 1] if i > 0 else self.nav_cover(),
                self.sequence[i + 1] if i + 1 < len(self.sequence) else self.nav_cover())

    # ----- shared fragments -----

    def chapter_item(self, ch, current=None):
        b = self.built[ch['id']]
        return ('<li class="ch-item part-%d" data-ch-item="%s"><a class="ch-row" href="%s"%s><span class="ch-n">%s</span>'
                '<span class="ch-t">%s</span><span class="ch-s">%s<span data-read-label="%s"></span></span></a></li>'
                % (ch['part'], ch['id'], self.chapter_href(ch['id']), ' aria-current="page"' if ch['id'] == current else '',
                   pad(ch['number']), esc(ch['title']),
                   self.L.count_done('<span data-stat="ch-done" data-ch="%s">0</span>' % ch['id'], len(b['actions'])),
                   ch['id']))

    def extra_item(self, key, current=None):
        L = self.L
        part = None
        if key == 'actions':
            no, title, href = '✓', L.all_actions, self.actions_href()
            sub = L.count_done('<span data-stat="actions-done">0</span>', self.total_actions)
        else:
            p = self.page_by_id[key]
            href, title = self.page_href(p['id']), p['title']
            if p['kind'] == 'part':
                no, part, sub = '··', p['part'], L.opening_essay_of(p['part'])
            elif p['kind'] == 'glossary':
                no, sub = 'Az', L.n(self.term_count, 'term')
            else:
                no, sub = '00', L.before_chapters
        return ('<li class="ch-item%s"><a class="ch-row" href="%s"%s><span class="ch-n">%s</span><span class="ch-t">%s</span>'
                '<span class="ch-s">%s</span></a></li>'
                % (' part-%d' % part if part else '', href, ' aria-current="page"' if key == current else '', no, esc(title), sub))

    def before_keys(self):
        return [self.intro['id']] if self.intro else []

    def after_keys(self):
        return (['actions'] if self.total_actions else []) + ([self.glossary['id']] if self.glossary else [])

    def extra_list(self, keys, current=None, cls=''):
        return ('<ol class="ch-list%s">%s</ol>' % (' ' + cls if cls else '', ''.join(self.extra_item(k, current) for k in keys))
                if keys else '')

    def part_list(self, n, current=None):
        pp = self.part_page(n)
        return ('<ol class="ch-list">' + (self.extra_item(pp['id'], current) if pp else '')
                + ''.join(self.chapter_item(c, current) for c in self.part_chapters(n)) + '</ol>')

    def toc_block(self, items):
        if not items:
            return ''
        L = self.L
        return ('<div class="toc-aside"><button type="button" class="toc-toggle" aria-expanded="false" aria-controls="page-toc">'
                '<span class="toc-toggle-label">%s</span><span class="toc-current" aria-hidden="true"></span>'
                '<span class="toc-chevron" aria-hidden="true"></span></button>'
                '<nav class="page-toc" id="page-toc" aria-labelledby="page-toc-title">'
                '<p class="toc-title" id="page-toc-title">%s</p>' % (L.on_this_page, L.on_this_page)
                + self.toc_list(items, 0) + '</nav></div>')

    def toc_list(self, items, depth):
        return ('<ol class="toc-list%s">' % (' toc-sub' if depth else '') + ''.join(
            '<li><a href="%s" data-target="%s">%s<span class="toc-label">%s</span></a>%s</li>'
            % (it['href'], esc(it['id']), '<span class="toc-no">%s</span>' % it['no'] if it.get('no') else '', esc(it['label']),
               self.toc_list(it['children'], depth + 1) if it.get('children') else '')
            for it in items) + '</ol>')

    def layout(self, items, main, extra=''):
        return ('<div class="page-layout%s%s">' % ('' if items else ' no-toc', ' ' + extra if extra else '')
                + self.toc_block(items) + '<div class="page-main">' + main + '</div></div>')

    @staticmethod
    def stat(value, total, label, bar=None):
        return ('<div class="stat"><p class="stat-n">%s<small> / %d</small></p><p class="stat-l">%s</p>%s</div>'
                % (value, total, label, '<span class="bar" data-bar="%s" aria-hidden="true"><i></i></span>' % bar if bar else ''))

    def pager(self, prev, nxt, label):
        def link(it, d, cls):
            return ('<a class="%s%s" href="%s"><span class="pager-dir">%s · %s</span><span class="pager-title">%s</span></a>'
                    % (cls, ' part-%d' % it['part'] if it.get('part') else '', it['href'], d, esc(it['dir']), esc(it['title'])))
        return '<nav class="pager" aria-label="%s">%s%s</nav>' % (
            label, link(prev, self.L.previous, 'pager-prev'), link(nxt, self.L.next, 'pager-next'))

    def extras_sentence(self):
        return self.L.extras_sentence(bool(self.intro), len(self.part_pages), bool(self.glossary))

    def range_label(self, chapters, capital=False):
        return self.L.range_label([c['number'] for c in chapters], capital)

    # ----- views -----

    def start_chapter(self):
        """Chapter opened by "Start reading": startChapter of config.js when it names a chapter. Otherwise None when
        there is an introduction (the button opens it), else the first chapter."""
        return self.by_id.get(self.cfg.get('startChapter')) or (None if self.intro else self.chapters[0])

    def view_home(self):
        B, E, L = self.BOOK, self.EDITION, self.L
        start = self.start_chapter()
        first = self.chapters[0]
        # "Open a checklist" always opens a chapter checklist: the start chapter, or the first chapter.
        checklist_ch = start or first
        lines = ' '.join('<span class="cover-line%s">%s</span>' % (' is-outlined' if i == B.get('outlinedLine') else '', esc(l))
                         for i, l in enumerate(B.get('titleLines') or [B['title']]))
        cover_parts = ''.join(
            '<li class="part-%d"><span class="cp-no">%s</span><span class="cp-name">%s</span>'
            '<span class="cp-range">%s</span></li>'
            % (p['number'], L.part_n(p['number']), esc(p['name']),
               self.range_label(self.part_chapters(p['number']), True))
            for p in self.PARTS)
        href, sub = ((self.chapter_href(start['id']), L.chapter_n(start['number']) + ' · ' + esc(start['title'])) if start
                     else (self.page_href(self.intro['id']), esc(self.intro['title'])))
        actions = ('<a class="btn btn--dark" href="%s"><span class="btn-main">%s <span aria-hidden="true">→</span></span>'
                   '<span class="btn-sub">%s</span></a>' % (href, L.start_reading, sub))
        alt = []
        if self.intro and start:
            alt.append('<a href="%s">%s</a>' % (self.page_href(self.intro['id']), L.read_intro))
        if not start or first['id'] != start['id']:
            alt.append('<a href="%s">%s</a>' % (self.chapter_href(first['id']), L.begin_with(first['number'])))
        alt.append('<a href="%s">%s</a>' % (self.home_href('contents'), L.see_all_chapters(len(self.chapters))))

        cover = ('<section class="cover" aria-labelledby="page-title"><div class="cover-main">'
                 '<p class="cover-kicker">%s</p><h1 class="cover-title" id="page-title" tabindex="-1"%s>%s</h1>'
                 '<ol class="cover-parts" aria-label="%s">%s</ol></div>'
                 '<div class="cover-side"><div class="edition">'
                 '<p class="wordmark"><span class="wm-big">%s</span><span class="wm-conf">%s</span></p>'
                 '<p class="edition-line">%s · %s</p><p class="edition-by">%s</p></div>'
                 '<div class="cover-intro">%s</div>'
                 '<div class="cover-actions">%s<a class="btn btn--line" href="%s">%s</a></div>'
                 '<p class="cover-alt">%s</p><p class="cover-alt cover-resume" data-resume hidden></p></div></section>'
                 % (esc(B.get('kicker', '')), L.title_lang, lines, L.parts_aria(len(self.PARTS)), cover_parts,
                    esc(E.get('wordmark', '')), esc(E.get('wordmarkSuffix', '')), esc(E.get('label', '')),
                    esc(E.get('name', '')), L.initiative(esc(E.get('initiative', ''))),
                    ''.join('<p>%s</p>' % esc(p) for p in B.get('intro', [])),
                    actions, self.start_href(), L.where_to_start, '<span aria-hidden="true"> · </span>'.join(alt)))

        parts = ''.join('<section class="part-col part-%d" aria-labelledby="part-%d"><h3 id="part-%d" tabindex="-1">'
                        '<span class="part-no">%s</span><span class="part-name">%s</span></h3>%s</section>'
                        % (p['number'], p['number'], p['number'], L.part_n(p['number']), esc(p['name']),
                           self.part_list(p['number']))
                        for p in self.PARTS)
        extras = self.extras_sentence()
        n_ch, n_act = len(self.chapters), self.total_actions
        main = (
            '<section class="block" aria-labelledby="contents"><p class="block-kicker">%s</p>'
            '<h2 id="contents" tabindex="-1">%s</h2>'
            '<p class="block-lead">%s</p>%s<div class="parts-grid">%s</div>%s</section>'
            % (L.general_contents, L.contents, L.block_lead(n_ch, len(self.PARTS), extras, n_act),
               self.extra_list(self.before_keys(), None, 'contents-extra'), parts,
               self.extra_list(self.after_keys(), None, 'contents-extra'))
            # #preview keeps its anchor. Plain facts about the content: no score, fraction or bar, which would read as
            # the reader's progress (that is the next section).
            + '<section class="block" aria-labelledby="preview"><p class="block-kicker">%s</p>'
            '<h2 id="preview" tabindex="-1">%s</h2><div class="block-text">'
            '<p>%s</p><p>%s</p></div></section>'
            % (L.coverage_kicker, L.in_this_guide, L.coverage_facts(n_ch, n_act, extras),
               L.language_html(self.other_base))
            + '<section class="block" aria-labelledby="progress"><p class="block-kicker">%s</p>'
            '<h2 id="progress" tabindex="-1">%s</h2><div class="stats">%s%s</div>'
            '<div class="block-text"><p>%s</p>'
            '<p><a class="btn" href="%s">%s</a></p><p><a href="%s">%s</a></p>'
            '<p>%s %s %s</p>'
            '<p><button type="button" class="btn-quiet" data-reset data-js-only hidden>%s</button></p>'
            '<p class="sr-only" id="progress-status" aria-live="polite"></p></div></section>'
            % (L.in_this_browser, L.your_progress,
               self.stat('<span data-stat="actions-done">0</span>', n_act, L.stat_actions_done, 'actions'),
               self.stat('<span data-stat="chapters-read">0</span>', n_ch, L.stat_chapters_read, 'read'),
               L.progress_help, self.chapter_href(checklist_ch['id'], self.built[checklist_ch['id']]['checklist_id']),
               L.open_checklist,
               self.actions_href(), L.see_all_actions(n_act), esc(L.storage), L.ticks_removable, L.shared_progress,
               L.clear_progress)
            + self.replays_block()
            + '<section class="block" aria-labelledby="edition"><p class="block-kicker">%s</p>'
            '<h2 id="edition" tabindex="-1">%s</h2><div class="block-text">'
            '<p>%s</p><p>%s</p><p class="offline-state" data-offline hidden></p></div></section>'
            % (L.colophon_kicker, L.about_edition,
               L.colophon(esc(E.get('label', '')), self.title_html(), esc(E.get('initiative', ''))), L.no_ads))
        toc = [{'id': 'contents', 'label': L.contents, 'href': self.home_href('contents'),
                'children': [{'id': 'part-%d' % p['number'], 'label': L.part_label(p['number'], p['name']),
                              'href': self.home_href('part-%d' % p['number'])} for p in self.PARTS]},
               {'id': 'preview', 'label': L.in_this_guide, 'href': self.home_href('preview')},
               {'id': 'progress', 'label': L.your_progress, 'href': self.home_href('progress')},
               {'id': 'replays', 'label': L.talk_recordings, 'href': self.home_href('replays')},
               {'id': 'edition', 'label': L.about_edition, 'href': self.home_href('edition')}]
        return cover + self.layout(toc, main, 'is-home')

    def replay_target(self, slug_):
        if slug_ in self.by_id:
            return self.chapter_href(slug_), self.by_id[slug_]['title']
        pid = next((k for k, v in PAGE_PATHS.items() if v == slug_ + '/'), None)
        if pid and pid in self.page_by_id:
            return self.page_href(pid), self.page_by_id[pid]['title']
        return None

    def replays_block(self):
        """Keeps #replays on the cover: the conference recordings with the same cards as the home page (the shared
        replay_item of site/build_site.py, site/content.json). The player is created by replays.js only after a click:
        no video and no frame in the page before. The "In the book" line links to the first listed chapter that exists."""
        L = self.L
        R = legacy.REPLAYS
        T = lambda f: legacy._T(f, self.lang)
        items = []
        for it in R['items']:
            book = next((t for t in (self.replay_target(c) for c in it.get('chapters') or []) if t), None)
            link = (book[0], esc(book[1])) if book else None
            items.append(legacy.replay_item(it, R, self.lang, indent='', book_link=link))
        return ('<section class="block" aria-labelledby="replays"><p class="block-kicker">%s</p>'
                '<h2 id="replays" tabindex="-1">%s</h2><div class="block-text"><p>%s</p></div>'
                '<div class="guide-replays"><ul class="rp-list">%s</ul></div></section>'
                % (T(R['label']), L.talk_recordings, L.replays_intro, '\n'.join(items)))

    def view_start(self):
        L = self.L
        paths = self.cfg.get('startPaths') or []
        out = []
        for i, p in enumerate(paths):
            main = [self.by_id[c] for c in p.get('chapters', []) if c in self.by_id]
            deeper = [self.by_id[c] for c in p.get('deeper', []) if c in self.by_id]
            part = main[0]['part'] if main else 1
            out.append(
                '<section class="path part-%d" aria-labelledby="%s"><p class="path-no">%s</p>'
                '<h2 id="%s" tabindex="-1">%s</h2><p class="path-desc">%s</p><ol class="ch-list">%s</ol>%s'
                '<p class="path-avail">%s</p></section>'
                % (part, esc(p['id']), L.path_no(pad(i + 1)), esc(p['id']), esc(p['title']), esc(p['text']),
                   ''.join(self.chapter_item(c) for c in main),
                   '<h3 class="path-sub">%s</h3><ol class="ch-list">%s</ol>' % (
                       esc(p.get('deeperTitle') or L.to_go_deeper), ''.join(self.chapter_item(c) for c in deeper)) if deeper else '',
                   L.path_avail(len(main + deeper), self.actions_of(main + deeper))))
        guides = []
        if self.intro:
            guides.append(L.guide_intro(self.page_href(self.intro['id'])))
        if self.part_pages:
            guides.append(L.guide_parts(', '.join(
                '<a href="%s">%s</a>' % (self.page_href(p['id']), esc(p['title'])) for p in self.part_pages)))
        if self.glossary:
            guides.append(L.guide_glossary(self.page_href(self.glossary['id'])))
        if self.total_actions:
            guides.append(L.guide_actions(self.total_actions, self.actions_href()))
        main = (
            '<header class="page-head"><p class="block-kicker">%s</p>'
            '<h1 id="page-title" class="page-title" tabindex="-1">%s</h1>'
            '<div class="start-lead">%s</div></header>'
            % (L.orientation, L.where_to_start, ''.join('<p>%s</p>' % s for s in L.start_lead))
            + '<div class="paths">' + ''.join(out) + '</div>'
            '<section class="block" aria-labelledby="how-chapters-work"><p class="block-kicker">%s</p>'
            '<h2 id="how-chapters-work" tabindex="-1">%s</h2><ol class="anatomy">%s</ol>'
            '<div class="block-text"><p>%s</p>'
            % (L.method, L.how_chapters_work, ''.join(
                '<li><span class="an-no">%s</span><span class="an-t">%s</span><span class="an-d">%s</span></li>'
                % (pad(i + 1), t, d) for i, (t, d) in enumerate(L.anatomy)), L.method_text())
            + ('<p>' + ' '.join(guides) + '</p>' if guides else '') + '</div></section>')
        toc = [{'id': p['id'], 'no': pad(i + 1), 'label': p['title'], 'href': self.start_href(p['id'])} for i, p in enumerate(paths)]
        toc.append({'id': 'how-chapters-work', 'label': L.how_chapters_work, 'href': self.start_href('how-chapters-work')})
        return self.layout(toc, main, 'is-start')

    def view_chapter(self, ch):
        L = self.L
        b = self.built[ch['id']]
        part = self.part_of(ch['part'])
        i = self.chapters.index(ch)
        seq_prev, seq_next = self.neighbours('chapter/' + ch['id'])
        prev_ch = self.chapters[i - 1] if i > 0 else None
        next_ch = self.chapters[i + 1] if i + 1 < len(self.chapters) else None
        prev = self.nav_chapter(prev_ch) if prev_ch else seq_prev
        nxt = self.nav_chapter(next_ch) if next_ch else seq_next
        opening = self.part_page(ch['part'])
        next_opening = self.part_page(next_ch['part']) if next_ch and next_ch['part'] != ch['part'] else None
        part_label = L.part_label(part['number'], esc(part['name']))
        main = (
            '<article class="chapter part-%d" aria-labelledby="page-title"><header class="chapter-head">'
            '<p class="ch-kicker">%s</p>'
            '<h1 class="ch-title" id="page-title" tabindex="-1"><span class="sr-only">%s</span>%s</h1>'
            '<p class="ch-bignum" aria-hidden="true">%s</p><div class="ch-meta"><span>%s</span>%s'
            '<span class="ch-readstate" data-read-state="%s"></span></div></header>'
            '<div class="prose">%s</div><footer class="chapter-end">'
            '<label class="read-row"><input type="checkbox" class="read-cb" data-read="%s" disabled><span>%s</span></label>'
            '<noscript><p class="cl-hint">%s</p></noscript>'
            '%s%s</footer></article>'
            % (ch['part'], '<a href="%s">%s</a>' % (self.page_href(opening['id']), part_label) if opening else part_label,
               L.sr_chapter(ch['number']), esc(ch['title']), pad(ch['number']), L.chapter_of(ch['number'], len(self.chapters)),
               '<a href="%s"><span>%s</span></a>' % (
                   self.chapter_href(ch['id'], b['checklist_id']),
                   L.count_done('<span data-stat="ch-done" data-ch="%s">0</span>' % ch['id'], len(b['actions'])))
               if b['checklist_id'] else '',
               ch['id'], b['html'], ch['id'], L.read_this, L.noscript_read, self.pager(prev, nxt, L.pager_chapters),
               '<p class="pager-note">%s</p>' % L.part_opens(next_opening['part'], '<a href="%s">%s</a>' % (
                   self.page_href(next_opening['id']), esc(next_opening['title']))) if next_opening else ''))
        return self.layout(b['toc'], main, 'is-chapter part-%d' % ch['part'])

    def view_page(self, p):
        L = self.L
        b = self.built_pages[p['id']]
        is_part = p['kind'] == 'part'
        chapters = self.part_chapters(p['part']) if is_part else []
        prev, nxt = self.neighbours('page/' + p['id'])
        if is_part:
            part = self.part_of(p['part'])
            kicker = L.part_kicker(part['number'], esc(part['name']))
            meta = L.path_avail(len(chapters), self.actions_of(chapters))
        elif p['kind'] == 'glossary':
            kicker, meta = L.reference, L.n(self.term_count, 'term')
        else:
            kicker, meta = L.before_chapters, L.intro_meta(len(self.chapters), len(self.PARTS))
        block = ('<section class="block" aria-labelledby="part-chapters"><p class="block-kicker">%s</p>'
                 '<h2 id="part-chapters" tabindex="-1">%s</h2><ol class="ch-list">%s</ol></section>'
                 % (L.part_n(p['part']), L.part_chapters_title, ''.join(self.chapter_item(c) for c in chapters))) if is_part else ''
        main = ('<article class="chapter page-doc%s" aria-labelledby="page-title"><header class="chapter-head">'
                '<p class="ch-kicker">%s</p><h1 class="ch-title" id="page-title" tabindex="-1">%s%s</h1>'
                '<div class="ch-meta"><span>%s</span></div></header><div class="prose">%s</div>%s'
                '<footer class="chapter-end">%s</footer></article>'
                % (' part-%d' % p['part'] if is_part else '', kicker,
                   '<span class="sr-only">%s</span>' % L.sr_part(p['part']) if is_part else '', esc(p['title']), meta, b['html'],
                   block, self.pager(prev, nxt, L.pager_pages)))
        toc = b['toc'] + ([{'id': 'part-chapters', 'label': L.part_chapters_title,
                            'href': self.page_href(p['id'], 'part-chapters')}] if is_part else [])
        return self.layout(toc, main, 'is-chapter is-page' + (' part-%d' % p['part'] if is_part else ''))

    def view_actions(self):
        L = self.L
        prev, nxt = self.neighbours('actions/')
        groups = []
        for p in self.PARTS:
            chapters = self.part_chapters(p['number'])
            if not chapters:
                continue
            groups.append(
                '<section class="sec part-%d" aria-labelledby="actions-part-%d"><p class="sec-kicker"><span class="sec-no">%s</span>'
                '<span class="sec-kind">%s</span></p><h2 id="actions-part-%d" tabindex="-1">%s</h2>%s</section>'
                % (p['number'], p['number'], L.part_n(p['number']), L.n(self.actions_of(chapters), 'action'),
                   p['number'], esc(p['name']), ''.join(
                       '<div class="checklist" id="actions-%s" tabindex="-1"><h3 class="cl-title"><a href="%s">'
                       '<span class="cl-title-n">%s</span>%s</a></h3>%s<ul class="actions">%s</ul></div>'
                       % (c['id'], self.chapter_href(c['id']), pad(c['number']), esc(c['title']),
                          self.checklist_head(c['id'], len(self.built[c['id']]['actions'])),
                          ''.join(self.action_item(a) for a in self.built[c['id']]['actions']))
                       for c in chapters)))
        n_ch, n_act = len(self.chapters), self.total_actions
        main = ('<header class="page-head"><p class="block-kicker">%s</p>'
                '<h1 id="page-title" class="page-title page-title--md" tabindex="-1">%s</h1>'
                '<div class="block-text"><p>%s</p><p>%s</p>'
                '<noscript><p>%s</p></noscript></div><div class="stats">%s%s</div></header>'
                '<div class="prose">%s</div><footer class="chapter-end">%s</footer>'
                % (L.global_checklist, L.all_actions, L.actions_intro(n_act, n_ch), esc(L.storage), esc(L.noscript_ticks),
                   self.stat('<span data-stat="actions-done">0</span>', n_act, L.stat_actions_done, 'actions'),
                   self.stat('<span data-stat="chapters-read">0</span>', n_ch, L.stat_chapters_read, 'read'),
                   ''.join(groups), self.pager(prev, nxt, L.pager_pages)))
        toc = [{'id': 'actions-part-%d' % p['number'], 'label': L.part_label(p['number'], p['name']),
                'href': self.actions_href('actions-part-%d' % p['number']),
                'children': [{'id': 'actions-' + c['id'], 'no': pad(c['number']), 'label': c['title'],
                              'href': self.actions_href('actions-' + c['id'])} for c in self.part_chapters(p['number'])]}
               for p in self.PARTS if self.part_chapters(p['number'])]
        return self.layout(toc, main, 'is-actions')

    def view_legal(self):
        """Credits, modification notice, licences, fonts, names and logos, source archive. The full texts are links to
        the files of book/guide-assets/legal/ (precached), the archive to book/source/ (online only)."""
        L = self.L
        sections = L.legal_sections(dict(self.legal, title_html=self.title_html() if self.L.title_lang
                                         else '<cite>%s</cite>' % self.title_html()))
        main = ('<header class="page-head"><p class="block-kicker">%s</p>'
                '<h1 id="page-title" class="page-title page-title--md" tabindex="-1">%s</h1>'
                '<div class="block-text"><p>%s</p></div></header>'
                % (L.legal_kicker, L.legal_title, L.legal_lead)
                + ''.join('<section class="block" aria-labelledby="%s"><h2 id="%s" tabindex="-1">%s</h2>'
                          '<div class="block-text">%s</div></section>'
                          % (sid, sid, esc(title), ''.join('<p>%s</p>' % p for p in paras))
                          for sid, title, paras in sections))
        toc = [{'id': sid, 'no': pad(i + 1), 'label': title, 'href': self.legal_href(sid)}
               for i, (sid, title, _) in enumerate(sections)]
        return self.layout(toc, main, 'is-start is-legal')

    def contents_html(self, current):
        L = self.L
        return ('<nav class="drawer" aria-label="%s"><ul class="drawer-links">'
                '<li><a href="%s">%s</a></li><li><a href="%s">%s</a></li><li><a href="%s">%s</a></li></ul>'
                % (L.drawer_aria, self.home_href(), L.cover, self.start_href(), L.where_to_start,
                   self.home_href('progress'), L.your_progress)
                + self.extra_list(self.before_keys(), current)
                + ''.join('<section class="drawer-part part-%d" aria-labelledby="dp-%d"><h3 class="drawer-part-title" id="dp-%d">'
                          '<span>%s</span> %s</h3>%s</section>'
                          % (p['number'], p['number'], p['number'], L.part_n(p['number']), esc(p['name']),
                             self.part_list(p['number'], current))
                          for p in self.PARTS)
                + '<div class="drawer-part">' + self.extra_list(self.after_keys(), current) + '</div>'
                + '<p class="drawer-scope">%s</p></nav>' % L.drawer_scope(len(self.chapters), self.total_actions))

    def footer_html(self, other_href):
        L = self.L
        Lic = self.cfg.get('licence') or {}
        lic = lambda x: '<a class="ext" rel="noopener noreferrer" href="%s">%s</a>' % (esc(x['url']), esc(x['label'])) if x else ''
        return ('<div class="footer-inner"><p class="footer-mark"><span class="wm">%s</span> %s</p>'
                '<p>%s</p><p>%s</p><p>%s</p>'
                '<p class="footer-links"><a href="%s">%s</a> · <a href="%s" type="application/zip">%s</a></p>'
                '<p class="footer-links"><a href="%s">PROOF &lt;conference&gt;</a> · '
                '<a href="%s" hreflang="%s" lang="%s">%s</a> · '
                '<a href="mailto:contact@proofconference.com">contact@proofconference.com</a></p></div>'
                % (esc(self.EDITION.get('wordmark', '')), self.title_html(),
                   L.footer_line(esc(self.EDITION.get('label', '')), esc(self.EDITION.get('name', '')),
                                 esc(self.EDITION.get('initiative', '')), len(self.chapters), self.total_actions),
                   L.footer_licence(lic(Lic.get('content')), lic(Lic.get('code')), esc(Lic.get('note', ''))),
                   esc(L.storage), self.legal_href(), L.legal_title, esc(self.legal['zip']),
                   L.source_link(self.legal['zip_size']),
                   L.site_home, other_href, L.lang_link['lang'], L.lang_link['lang'], L.lang_link['name']))

    # ----- search -----

    def search_index(self):
        L = self.L
        out = []
        if self.intro:
            out += self.built_pages[self.intro['id']]['index']
        for p in self.PARTS:
            pp = self.part_page(p['number'])
            if pp:
                out += self.built_pages[pp['id']]['index']
            for c in self.part_chapters(p['number']):
                out += self.built[c['id']]['index']
        if self.glossary:
            out += self.built_pages[self.glossary['id']]['index']
        T = lambda f: legacy._T(f, self.lang)
        n_ch, n_act = len(self.chapters), self.total_actions
        out += [
            {'type': 'page', 'title': L.contents, 'kicker': L.cover, 'href': self.home_href('contents'),
             'text': ' · '.join([c['title'] for c in self.chapters] + [p['title'] for p in self.pages])},
            {'type': 'page', 'title': L.in_this_guide, 'kicker': L.cover, 'href': self.home_href('preview'),
             'text': L.coverage_facts(n_ch, n_act, self.extras_sentence()) + ' '
                     + squash(html.unescape(re.sub(r'<[^>]+>', '', L.language_html(self.other_base))))},
            {'type': 'page', 'title': L.your_progress, 'kicker': L.cover, 'href': self.home_href('progress'),
             'text': L.search_progress_text},
            {'type': 'page', 'title': L.talk_recordings, 'kicker': L.cover, 'href': self.home_href('replays'),
             'text': ' · '.join(squash(html.unescape(re.sub(r'<[^>]+>', '', T(it['title'])))) for it in legacy.REPLAYS['items'])},
            {'type': 'page', 'title': L.about_edition, 'kicker': L.cover, 'href': self.home_href('edition'),
             'text': L.search_about_text(self.EDITION.get('initiative', ''))},
            {'type': 'page', 'title': L.where_to_start, 'kicker': L.orientation, 'href': self.start_href(),
             'text': ' '.join(L.start_lead)},
            {'type': 'page', 'title': L.how_chapters_work, 'kicker': L.where_to_start, 'href': self.start_href('how-chapters-work'),
             'text': L.search_how_text},
            {'type': 'page', 'title': L.all_actions, 'kicker': L.global_checklist, 'href': self.actions_href(),
             'text': L.search_actions_text(n_act, n_ch)},
        ]
        for p in self.cfg.get('startPaths') or []:
            titles = [self.by_id[c]['title'] for c in p.get('chapters', []) + p.get('deeper', []) if c in self.by_id]
            out.append({'type': 'page', 'title': p['title'], 'kicker': L.path_kicker,
                        'text': p['text'] + ' ' + ' · '.join(titles), 'href': self.start_href(p['id'])})
        return [{'type': e['type'], 'part': e.get('part'), 'title': e['title'], 'kicker': e['kicker'],
                 'text': e.get('text', ''), 'href': e['href']} for e in out]


# ---------- pages ----------

def description(markdown_text):
    body = markdown_text.lstrip('\n').split('\n', 1)[1] if '\n' in markdown_text.lstrip('\n') else ''
    return legacy.summary(body)


def page_list(g):
    """Every page of one edition: address (relative to its base), view, SEO data. Every page has a counterpart in the
    other language at the same relative address."""
    L, t, sep = g.L, g.BOOK['title'], g.L.title_sep
    out = [{'path': '', 'key': 'home/', 'current': None, 'title': t + sep + g.EDITION.get('name', ''),
            'desc': L.cover_desc(t, g.EDITION.get('name', '')),
            'og': 'website', 'part': None, 'reading': False, 'html': g.view_home}]
    if g.intro:
        p = g.intro
        out.append({'path': PAGE_PATHS[p['id']], 'key': 'page/' + p['id'], 'current': p['id'], 'title': p['title'] + sep + t,
                    'desc': description(p['markdown']), 'og': 'article', 'part': None,
                    'reading': True, 'html': (lambda p=p: g.view_page(p))})
    for part in g.PARTS:
        pp = g.part_page(part['number'])
        if pp:
            out.append({'path': PAGE_PATHS[pp['id']], 'key': 'page/' + pp['id'], 'current': pp['id'],
                        'title': L.part_title(pp['part'], pp['title']) + sep + t, 'desc': description(pp['markdown']),
                        'og': 'article', 'part': pp['part'], 'reading': True,
                        'html': (lambda p=pp: g.view_page(p))})
        for c in g.part_chapters(part['number']):
            out.append({'path': c['id'] + '/', 'key': 'chapter/' + c['id'], 'current': c['id'],
                        'title': c['title'] + sep + t, 'desc': description(c['markdown']), 'og': 'article',
                        'part': c['part'], 'reading': True, 'html': (lambda c=c: g.view_chapter(c))})
    out.append({'path': ACTIONS_PATH, 'key': 'actions/', 'current': 'actions', 'title': L.all_actions + sep + t,
                'desc': legacy.summary(L.actions_desc(g.total_actions, len(g.chapters), t)),
                'og': 'article', 'part': None, 'reading': False, 'html': g.view_actions})
    if g.glossary:
        p = g.glossary
        out.append({'path': PAGE_PATHS[p['id']], 'key': 'page/' + p['id'], 'current': p['id'], 'title': p['title'] + sep + t,
                    'desc': description(p['markdown']), 'og': 'article', 'part': None,
                    'reading': True, 'html': (lambda p=p: g.view_page(p))})
    paths = g.cfg.get('startPaths') or []
    out.append({'path': START_PATH, 'key': 'start/', 'current': None, 'title': L.where_to_start + sep + t,
                'desc': legacy.summary(L.start_desc(len(paths), t, [p['title'] for p in paths])),
                'og': 'article', 'part': None, 'reading': False, 'html': g.view_start})
    out.append({'path': LEGAL_PATH, 'key': 'legal/', 'current': None, 'title': L.legal_title + sep + t,
                'desc': legacy.summary(L.legal_desc(t)), 'og': 'article', 'part': None, 'reading': False,
                'html': g.view_legal})
    return out


def alternates(path):
    return ('<link rel="alternate" hreflang="lt" href="%s">\n<link rel="alternate" hreflang="en" href="%s">\n'
            '<link rel="alternate" hreflang="x-default" href="%s">\n'
            % (SITE_URL + BASES['lt'] + path, SITE_URL + BASES['en'] + path, SITE_URL + BASES['en'] + path))


def head_html(g, page, assets):
    url = SITE_URL + g.base + page['path']
    title, desc = esc(page['title']), esc(page['desc'])
    return ('<!doctype html>\n<html lang="%s">\n<head>\n<meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            '<meta name="referrer" content="no-referrer">\n'
            '<meta http-equiv="Content-Security-Policy" content="%s">\n'
            '<meta name="color-scheme" content="dark">\n'
            '<title>%s</title>\n<meta name="description" content="%s">\n<link rel="canonical" href="%s">\n%s'
            '<link rel="icon" type="image/svg+xml" href="/favicon.svg">\n'
            '<meta property="og:type" content="%s">\n<meta property="og:site_name" content="PROOF &lt;conference&gt;">\n'
            '<meta property="og:title" content="%s">\n<meta property="og:description" content="%s">\n'
            '<meta property="og:url" content="%s">\n<meta property="og:image" content="%s/thumbnail-proof-%s.jpg">\n'
            '<meta property="og:locale" content="%s">\n<meta name="twitter:card" content="summary_large_image">\n'
            '<meta name="twitter:title" content="%s">\n<meta name="twitter:description" content="%s">\n'
            '<meta name="twitter:image" content="%s/thumbnail-proof-%s.jpg">\n'
            '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>\n'
            '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>\n'
            '<link rel="stylesheet" href="%s">\n'
            '<noscript><style>%s</style></noscript>\n'
            '<script defer src="%s"></script>\n<script defer src="%s"></script>\n<script defer src="%s"></script>\n%s'
            '</head>\n'
            % (g.lang, csp_of(page), title, desc, url, alternates(page['path']), page['og'], title, desc, url, SITE_URL, g.lang,
               g.L.og_locale, title, desc, SITE_URL, g.lang,
               assets['fonts/righteous-latin.woff2'], assets['fonts/jetbrainsmono-latin.woff2'], assets['guide.css'],
               NOSCRIPT_CSS, assets['config.js'], assets[SITE_DATA[g.lang]], assets['guide.js'],
               '<script defer src="%s"></script>\n' % assets['replays.js'] if page['path'] == '' else ''))


def page_html(g, page, assets):
    L = g.L
    other_href = g.other_base + page['path']
    part_cls = ' part-%d' % page['part'] if page['part'] else ''
    return (head_html(g, page, assets)
            + '<body>\n<a class="skip-link" href="#main">%s</a>\n' % L.skip
            + '<header class="site-header"><div class="header-inner">'
            '<a class="brand" href="%s"><span class="brand-title"%s>%s</span>'
            '<span class="brand-sub">%s</span></a>'
            '<div class="header-actions">'
            '<a class="hbtn" href="%s" data-open="contents">'
            '<svg class="hbtn-icon" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M3 5h14M3 10h14M3 15h9" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
            '<span class="hbtn-label">%s</span></a>'
            '<button type="button" class="hbtn" data-open="search" aria-haspopup="dialog" aria-keyshortcuts="/ Control+K Meta+K" data-js-only hidden>'
            '<svg class="hbtn-icon" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><circle cx="8.5" cy="8.5" r="5.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12.6 12.6 17 17" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
            '<span class="hbtn-label">%s</span><kbd class="hbtn-kbd" aria-hidden="true">/</kbd></button>'
            '<a class="hbtn hbtn--site" href="%s" title="PROOF &lt;conference&gt;"><span class="wm">PROOF</span>'
            '<span class="sr-only">%s</span></a>'
            '<a class="hbtn hbtn--lang" href="%s" hreflang="%s" lang="%s" aria-label="%s">%s</a>'
            '</div></div></header>\n'
            '<div class="read-progress%s" id="read-progress" aria-hidden="true"%s><i></i></div>\n'
            '<main id="main" tabindex="-1" data-ssr="%s">%s</main>\n'
            '<footer class="site-footer" id="site-footer">%s</footer>\n'
            '<dialog class="dialog dialog--search" id="search-dialog" aria-labelledby="search-title"><div class="dialog-box">'
            '<div class="dialog-head"><h2 class="dialog-title" id="search-title">%s</h2>'
            '<button type="button" class="dialog-close" data-close>%s <span class="dialog-esc" aria-hidden="true">Esc</span></button></div>'
            '<form class="search-form" role="search" id="search-form"><label class="search-label" for="search-input">%s</label>'
            '<input class="search-input" id="search-input" type="search" autocomplete="off" spellcheck="false" aria-describedby="search-scope" aria-controls="search-results">'
            '<p class="search-scope" id="search-scope">%s</p></form>'
            '<p class="sr-only" id="search-status" aria-live="polite"></p><div class="dialog-scroll search-results" id="search-results"></div></div></dialog>\n'
            '<dialog class="dialog dialog--drawer" id="contents-dialog" aria-labelledby="contents-title"><div class="dialog-box">'
            '<div class="dialog-head"><h2 class="dialog-title" id="contents-title">%s</h2>'
            '<button type="button" class="dialog-close" data-close>%s <span class="dialog-esc" aria-hidden="true">Esc</span></button></div>'
            '<div class="dialog-scroll" id="contents-body">%s</div></div></dialog>\n'
            '</body>\n</html>\n'
            % (g.base, L.title_lang, esc(g.BOOK['title']), L.brand_sub(esc(g.EDITION.get('wordmark', ''))),
               g.home_href('contents'), L.contents, L.search_button, L.site_home, L.site_sr,
               other_href, L.lang_link['lang'], L.lang_link['lang'], L.lang_link['aria'], L.lang_link['code'],
               part_cls, '' if page['reading'] else ' hidden', page['key'], page['html'](), g.footer_html(other_href),
               L.search_title, L.close, L.search_label, L.search_scope, L.contents, L.close, g.contents_html(page['current'])))


# ---------- assets ----------

def build_assets(guides, legacy_map, configs, legal_texts):
    """Every file of /book/guide-assets/, with its versioned address."""
    files, urls = {}, {}

    def add(name, data):
        files[name] = data
        urls[name] = ASSET_URL + name + '?v=' + sha256(data)[:12]

    for f in sorted((DIST / 'assets' / 'fonts').glob('*.woff2')):
        add('fonts/' + f.name, f.read_bytes())
    for name, src in sorted(LEGAL_ASSETS.items()):
        add(name, legal_texts[src])
    css = (DIST / 'styles.css').read_text(encoding='utf-8')
    css, n = re.subn(r"url\('assets/fonts/([\w.-]+\.woff2)'\)", lambda m: "url('%s')" % urls['fonts/' + m.group(1)][len(ASSET_URL):], css)
    if n != 4:
        raise IntegrationError('styles.css: expected 4 local font URLs, found %d.' % n)
    add('guide.css', (css.rstrip('\n') + '\n\n' + INTEGRATION_CSS.read_text(encoding='utf-8').rstrip('\n') + '\n\n'
                      + REPLAYS_CSS.read_text(encoding='utf-8')).encode('utf-8'))
    add('guide.js', (DIST / 'app.js').read_bytes())
    add('replays.js', REPLAYS_JS.read_bytes())
    # The standalone preview may mention future editions. The integrated site exposes EN and LT only.
    shared_config = copy.deepcopy(configs['en'])
    shared_config['languages'] = [
        {'code': 'en', 'name': 'English'}, {'code': 'lt', 'name': 'Lietuvių'}]
    add('config.js', ('/* Generated for the EN and LT PROOF editions. */\nwindow.GUIDE_CONFIG = ' +
                      json.dumps(shared_config, ensure_ascii=True, indent=1) + ';\n').encode('utf-8'))
    names = {'en': 'English', 'lt': 'Lithuanian'}
    for lang in LANGS:
        g = guides[lang]
        search = ('/* Generated by guide-ui/build_integration.py: search index of the %s pages. */\n'
                  'window.GUIDE_SEARCH = %s;\n' % (names[lang], json.dumps(g.search_index(), ensure_ascii=True, separators=(',', ':'))))
        add(SEARCH_INDEX[lang], search.encode('utf-8'))
        site = {
            'lang': lang, 'base': g.base, 'search': urls[SEARCH_INDEX[lang]], 'sw': '/book/sw.js', 'swScope': '/book/',
            'chapters': [{'id': c['id'], 'number': c['number'], 'part': c['part'], 'title': c['title'],
                          'actions': [a['id'] for a in g.built[c['id']]['actions']]} for c in g.chapters],
            'routes': {'home': g.base, 'start': g.base + START_PATH, 'actions': g.base + ACTIONS_PATH,
                       'page': {pid: g.base + path for pid, path in PAGE_PATHS.items()},
                       'chapter': {c['id']: g.base + c['id'] + '/' for c in g.chapters}},
            'legacy': {'keys': LEGACY_KEYS, 'actions': {e['legacy_id']: e['id'] for e in legacy_map['actions']},
                       'chapters': [c['id'] for c in g.chapters]},
            'strings': g.L.js,
            'suggestions': configs[lang].get('searchSuggestions') or [],
        }
        add(SITE_DATA[lang], ('/* Generated by guide-ui/build_integration.py: addresses, actions, interface strings (%s) and '
                              'the mapping of the former checklist IDs. */\nwindow.GUIDE_SITE = %s;\n'
                              % (names[lang], json.dumps(site, ensure_ascii=True, indent=1))).encode('utf-8'))
    return files, urls


# ---------- action IDs: former checklist, both languages ----------

def load_legacy_map(books):
    data = json.loads(LEGACY_MAP.read_text(encoding='utf-8'))
    acts = data['actions']
    problems = []
    if len({e['legacy_id'] for e in acts}) != len(acts) or len({e['id'] for e in acts}) != len(acts):
        problems.append('a former ID or a registry ID is listed twice.')
    for lang in LANGS:
        book = books[lang]
        registry = {e['id']: e for e in book['entries']}
        produced = {a['id']: cid for cid, actions in book['chapter_actions'] for a in actions}
        reg = book['registry_file'].name
        if len(acts) != len(produced):
            problems.append('%s: %d entries for %d actions.' % (lang, len(acts), len(produced)))
        for e in acts:
            r = registry.get(e['id'])
            if r is None or r.get('retired'):
                problems.append('%s: %s ID %s is missing or retired.' % (e['legacy_id'], reg, e['id']))
                continue
            if not re.fullmatch(re.escape(r['chapter']) + r'-[1-5]', e['legacy_id']):
                problems.append('%s: not a former ID of chapter %s.' % (e['legacy_id'], r['chapter']))
            known = {ib.normalize(t) for t in [r['text']] + r.get('previous_texts', [])}
            if lang == 'en' and ib.normalize(e['legacy_text']) not in known:
                problems.append('%s: former text "%s" does not match %s "%s".' % (e['legacy_id'], e['legacy_text'], e['id'], r['text']))
            if lang != 'en' and (r.get('legacy_id') != e['legacy_id'] or r.get('legacy_effort') != e['legacy_effort']):
                problems.append('%s: %s gives former ID %s, effort %s.' % (e['legacy_id'], reg, r.get('legacy_id'), r.get('legacy_effort')))
            if e['id'] not in produced:
                problems.append('%s: %s is not a %s action of this build.' % (e['legacy_id'], e['id'], lang))
    if problems:
        raise IntegrationError('scripts/legacy-action-map.json no longer matches the registries:\n  - ' + '\n  - '.join(problems)
                               + '\nIf an action was reworded, add its former text to "previous_texts" of its registry entry.')
    return data


def cross_check(books):
    """The same 5 action IDs in every chapter of both languages, with the same effort. Order is reported, not imposed:
    the IDs come from the text, never from the position."""
    en = dict(books['en']['chapter_actions'])
    lt = dict(books['lt']['chapter_actions'])
    problems, order = [], []
    if set(en) != set(lt):
        problems.append('chapters differ: %s' % ', '.join(sorted(set(en) ^ set(lt))))
    for cid in sorted(set(en) & set(lt)):
        e_ids, l_ids = [a['id'] for a in en[cid]], [a['id'] for a in lt[cid]]
        if set(e_ids) != set(l_ids):
            problems.append('%s: English %s, Lithuanian %s' % (cid, sorted(set(e_ids) - set(l_ids)), sorted(set(l_ids) - set(e_ids))))
            continue
        if e_ids != l_ids:
            order.append({'chapter': cid, 'en': e_ids, 'lt': l_ids})
        lt_by = {a['id']: a for a in lt[cid]}
        for a in en[cid]:
            want = EFFORT_PAIRS.get(a['effort'])
            if want is None or lt_by[a['id']]['effort'] != want:
                problems.append('%s: effort "%s" in English, "%s" in Lithuanian' % (a['id'], a['effort'], lt_by[a['id']]['effort']))
    if problems:
        raise IntegrationError('The English and Lithuanian checklists disagree:\n  - ' + '\n  - '.join(problems))
    return {'chapters': len(en), 'actions': sum(len(v) for v in en.values()), 'same_ids_and_efforts': True,
            'order_differences': order}


_FORMER_ITEM = re.compile(r'<li class="bk-cl-item" data-id="([^"]+)" data-effort="(\d)">')
_FORMER_LABEL = re.compile(r'<label class="bk-cl-title" for="([^"]+)">([^<]*)</label>')


def compare_former(site, legacy_map, books):
    """Compare the mapping with the checklist pages of the former renderer, when they are still there (read only)."""
    out = {}
    lt_registry = {e['id']: e for e in books['lt']['entries']}
    for lang, rel in (('en', 'book/en/checklist/index.html'), ('lt', 'book/checklist/index.html')):
        f = site / rel
        text = f.read_text(encoding='utf-8') if f.is_file() else ''
        items = _FORMER_ITEM.findall(text)
        if not items:
            out[lang] = {'page': rel, 'status': 'not compared: no former checklist markup in this file'}
            continue
        labels = dict(_FORMER_LABEL.findall(text))
        problems = []
        if [i for i, _ in items] != [e['legacy_id'] for e in legacy_map['actions']]:
            problems.append('the IDs or their order differ')
        for (iid, effort), e in zip(items, legacy_map['actions']):
            if effort != e['legacy_effort']:
                problems.append('%s: effort %s, mapping %s' % (iid, effort, e['legacy_effort']))
            label = ib.normalize(html.unescape(labels.get(iid, '')))
            if lang == 'en' and label != ib.normalize(e['legacy_text']):
                problems.append('%s: label differs from the mapping' % iid)
            if lang == 'lt':
                r = lt_registry.get(e['id'], {})
                if label != ib.normalize(r.get('legacy_text', '')):
                    problems.append('%s: label differs from legacy_text of %s in action-registry-lt.json' % (iid, e['id']))
        if problems:
            raise IntegrationError('%s does not match the mapping: %s.' % (rel, '; '.join(problems[:10])))
        out[lang] = {'page': rel, 'status': 'compared', 'items': len(items),
                     'checked': 'IDs, order, effort and labels (%s)' % (
                         'legacy-action-map.json' if lang == 'en' else 'legacy_text of action-registry-lt.json')}
    return out


# ---------- service worker and sitemap ----------

def service_worker(site, outputs, assets_urls):
    """One worker for /book/: CORE is exactly the 54 pages of both editions (legal pages included), every interface file
    (both search indexes, both site data files, the fonts, the licence texts) and EXTRA_CORE. The source archive is
    never in CORE. A missing file would make the installation fail: checked here."""
    cur = (site / 'book' / 'sw.js').read_text(encoding='utf-8')
    m = re.search(r'const CORE = \[\n(.*?)\n\];', cur, re.S)
    if not m:
        raise IntegrationError('book/sw.js: CORE list not found.')
    before = re.findall(r"'([^']*)'", m.group(1))
    pages = sorted(BASES[lang] + p for lang in LANGS for p in outputs[lang])
    missing = [u for u in EXTRA_CORE if not (site / u.lstrip('/')).is_file()]
    if missing:
        raise IntegrationError('Files to precache not found in the site: %s' % ', '.join(missing))
    core = sorted(set(pages) | set(assets_urls.values()) | set(EXTRA_CORE))
    h = hashlib.sha1('\n'.join(core).encode('utf-8'))
    for url in pages:
        lang = lang_of(url)
        h.update(url.encode('utf-8'))
        h.update(outputs[lang][url[len(BASES[lang]):]])
    tpl = (DRAFTS / 'sw.template.js').read_text(encoding='utf-8')
    h.update(tpl.encode('utf-8'))
    sw = tpl.replace('__VERSION__', h.hexdigest()[:8]).replace('__CORE__', ',\n  '.join("'%s'" % u for u in core))
    return sw.encode('utf-8'), {'cache_before': re.search(r"const CACHE = '([^']+)'", cur).group(1),
                                'cache_after': 'proof-book-' + h.hexdigest()[:8], 'core_before': len(before),
                                'core_after': len(core), 'pages': len(pages),
                                'removed': [u for u in before if u not in core],
                                'added': [u for u in core if u not in before]}


_URL_BLOCK = re.compile(r'  <url>\n    <loc>([^<]+)</loc>\n(.*?)  </url>\n', re.S)
_LASTMOD = re.compile(r'    <lastmod>(\d{4}-\d{2}-\d{2})</lastmod>\n')


def sitemap(site, paths):
    """Exactly 1 entry per page of both editions, each with its lt, en and x-default (English) alternates and a
    <lastmod> no earlier than UI_CHANGED_ON. Entries outside /book/ are kept byte for byte. Only /start/ and /legal/
    (NEW_PATHS) may be new: every former book address must already be listed, and an unknown /book/ address stops the
    build."""
    text = (site / 'sitemap.xml').read_text(encoding='utf-8')
    wanted = {(lang, p) for lang in LANGS for p in paths}

    def entry(lang, path, date):
        return ('  <url>\n    <loc>%s</loc>\n    <lastmod>%s</lastmod>\n' % (SITE_URL + BASES[lang] + path, date)
                + ''.join('    <xhtml:link rel="alternate" hreflang="%s" href="%s"/>\n' % (h, SITE_URL + BASES[l] + path)
                          for h, l in (('lt', 'lt'), ('en', 'en'), ('x-default', 'en')))
                + '  </url>\n')

    out, seen, changed, problems, pos = [], {}, [], [], 0
    for m in _URL_BLOCK.finditer(text):
        out.append(text[pos:m.start()])
        pos = m.end()
        loc = m.group(1)
        path = loc[len(SITE_URL):] if loc.startswith(SITE_URL) else None
        lang = lang_of(path) if path else None
        if lang is None:
            out.append(m.group(0))
            continue
        rel = path[len(BASES[lang]):]
        if (lang, rel) not in wanted:
            problems.append('unknown book address %s' % loc)
            out.append(m.group(0))
            continue
        if (lang, rel) in seen:
            problems.append('%s listed twice' % loc)
            continue
        lm = _LASTMOD.search(m.group(2))
        date = max(lm.group(1), UI_CHANGED_ON) if lm else UI_CHANGED_ON
        new = entry(lang, rel, date)
        if new != m.group(0):
            changed.append({'loc': loc, 'lastmod_from': lm.group(1) if lm else None, 'lastmod_to': date,
                            'alternates_added': m.group(0).count('xhtml:link') != 3})
        seen[(lang, rel)] = len(out)
        out.append(new)
    out.append(text[pos:])

    added = []
    for lang, rel in sorted(wanted - set(seen), key=lambda x: (x[1], x[0] != 'lt')):
        if rel not in NEW_PATHS:
            problems.append('no entry for %s%s: the former addresses must all be listed' % (BASES[lang], rel))
            continue
        other = 'en' if lang == 'lt' else 'lt'
        new = entry(lang, rel, UI_CHANGED_ON)
        if (other, rel) in seen:
            i = seen[(other, rel)]
            # Lithuanian before English, as in every pair of the file.
            out[i] = new + out[i] if lang == 'lt' else out[i] + new
        else:
            i = seen.get((lang, ''), seen.get((other, '')))
            if i is None:
                problems.append('no cover entry to place %s%s after' % (BASES[lang], rel))
                continue
            out[i] = out[i] + new
        seen[(lang, rel)] = i
        added.append(SITE_URL + BASES[lang] + rel)
    if problems:
        raise IntegrationError('sitemap.xml: ' + '; '.join(problems[:10]) + '.')
    result = ''.join(out)
    book_locs = [l for l in re.findall(r'<loc>([^<]+)</loc>', result) if l.startswith(SITE_URL) and lang_of(l[len(SITE_URL):])]
    if sorted(book_locs) != sorted(SITE_URL + BASES[l] + p for l, p in wanted):
        raise IntegrationError('sitemap.xml: the book entries are not exactly the %d pages of both editions.' % len(wanted))
    return result.encode('utf-8'), {'changed': changed, 'added': added, 'entries': result.count('<loc>'),
                                    'book_entries': len(book_locs)}


# ---------- checks ----------

_ID = re.compile(r'\sid="([^"]*)"')
_HREF = re.compile(r'\shref="([^"]*)"')


def check_pages(site, outputs, legacy_map, guides, books, files=()):
    """files: addresses of the other files this build writes (the source archive), valid link targets before they
    exist on disk."""
    ids = {(lang, p): _ID.findall(h.decode('utf-8')) for lang in LANGS for p, h in outputs[lang].items()}
    problems, links = [], 0
    for lang in LANGS:
        base, g = BASES[lang], guides[lang]
        for path, data in outputs[lang].items():
            h = data.decode('utf-8')
            where = base + path
            mine = ids[(lang, path)]
            dup = sorted({i for i in mine if mine.count(i) > 1})
            if dup:
                problems.append('%s: duplicate IDs %s' % (where, ', '.join(dup[:8])))
            if not h.startswith('<!doctype html>\n<html lang="%s">' % lang):
                problems.append('%s: missing <html lang="%s">' % (where, lang))
            if h.count('<link rel="canonical" href="%s">' % (SITE_URL + where)) != 1 or h.count('rel="canonical"') != 1:
                problems.append('%s: canonical link' % where)
            if alternates(path) not in h or h.count('rel="alternate"') != 3:
                problems.append('%s: hreflang lt, en and x-default links' % where)
            if re.search(r'noindex', h, re.I):
                problems.append('%s: noindex' % where)
            if not re.search(r'<title>[^<]+</title>', h) or not re.search(r'<meta name="description" content="[^"]{50,}">', h):
                problems.append('%s: title or description' % where)
            if h.count('<h1') != 1:
                problems.append('%s: %d <h1>' % (where, h.count('<h1')))
            if 'href="#/' in h or "href='#/" in h:
                problems.append('%s: link to a #/ route' % where)
            footer = h.split('<footer class="site-footer"', 1)[-1].split('</footer>', 1)[0]
            if 'href="%s"' % (base + LEGAL_PATH) not in footer or any('href="%s"' % esc(f) not in footer for f in files):
                problems.append('%s: the footer lacks the legal page or the source archive link' % where)
            # House rule for Lithuanian: no em or en dash in the head (title, description), the header, the footer and the
            # dialogs. The page body may quote a foreign source title; its interface strings are checked in guide_locales.
            if lang != 'en' and re.search('[–—]', h.split('<main', 1)[0] + h.split('</main>', 1)[-1]):
                problems.append('%s: em or en dash in the title, the description, the header, the footer or a dialog' % where)
            plain = html.unescape(h)
            for marker in FILTER_MARKERS[lang]:
                if marker in plain:
                    problems.append('%s: a filtered promotional fragment came back (%s)' % (where, marker))
            for frag in books[lang]['fragments']:
                if frag['text'].strip(' ;,.') in plain:
                    problems.append('%s: fragment %s came back' % (where, frag['rule']))
            for href in _HREF.findall(h):
                href = html.unescape(href)
                if href.startswith(('http://', 'https://', 'mailto:')):
                    continue
                links += 1
                target, _, frag = href.partition('#')
                target = target.split('?')[0]
                if not target:
                    target = where
                if target in files:
                    continue
                tlang = lang_of(target)
                if tlang and target.endswith('/'):
                    rel = target[len(BASES[tlang]):]
                    if rel not in outputs[tlang]:
                        problems.append('%s: link to %s, not a page of the book' % (where, href))
                    elif frag and frag not in ids[(tlang, rel)]:
                        problems.append('%s: link to %s, no such ID' % (where, href))
                elif target.startswith(ASSET_URL):
                    continue
                elif tlang:
                    problems.append('%s: link to %s, not a page address' % (where, href))
                elif target.startswith('/'):
                    f = site / target.lstrip('/')
                    if not (f / 'index.html' if target.endswith('/') else f).is_file():
                        problems.append('%s: link to %s, file not found in the site' % (where, href))
                else:
                    problems.append('%s: relative link %s' % (where, href))
        aliases = {e['legacy_id'] for e in legacy_map['actions']}
        missing = aliases - set(ids[(lang, ACTIONS_PATH)])
        if missing:
            problems.append('%s%s: former anchors missing: %s' % (base, ACTIONS_PATH, ', '.join(sorted(missing)[:8])))
        for c in g.chapters:
            want = {g.legacy_of[a['id']] for a in g.built[c['id']]['actions']}
            if want - set(ids[(lang, c['id'] + '/')]):
                problems.append('%s%s/: former anchors missing' % (base, c['id']))
        for anchor in ('contents', 'replays', 'main'):
            if anchor not in ids[(lang, '')]:
                problems.append('%s: #%s missing' % (base, anchor))
    if set(outputs['en']) != set(outputs['lt']):
        problems.append('the 2 editions do not have the same pages: %s' % ', '.join(sorted(set(outputs['en']) ^ set(outputs['lt']))))
    if problems:
        raise IntegrationError('Checks of the generated pages failed:\n  - ' + '\n  - '.join(problems[:60]))
    return {'pages': sum(len(v) for v in outputs.values()), 'internal_links_checked': links,
            'ids': sum(len(v) for v in ids.values())}


def protected_snapshot(site, planned):
    """Hash of every file of the site except the planned writes, .git, book-drafts (sources, edited separately; the
    report is written there) and Finder's .DS_Store. No directory of the site is exempted as a whole."""
    out = {}
    skip_dirs = {site / '.git'}
    if DRAFTS.resolve() != site and site in DRAFTS.resolve().parents:
        skip_dirs.add(DRAFTS.resolve())
    for root, dirs, files in os.walk(site):
        r = Path(root)
        dirs[:] = sorted(d for d in dirs if d != '.git' and (r / d) not in skip_dirs)
        for name in sorted(files):
            if name == '.DS_Store':
                continue
            f = r / name
            rel = f.relative_to(site).as_posix()
            if rel not in planned and f.is_file():
                out[rel] = sha256(f.read_bytes())
    return out


def allowed(site, path, planned):
    rel = path.resolve().relative_to(site.resolve()).as_posix()
    return rel in planned


# ---------- main ----------

def run(args):
    site = Path(args.site_dir).expanduser().resolve()
    for rel in ('book/index.html', 'book/sw.js', 'sitemap.xml', 'en/index.html'):
        if not (site / rel).is_file():
            raise IntegrationError('Not the PROOF site folder (%s missing): %s' % (rel, site))
    planned = planned_writes()
    protected = protected_snapshot(site, planned)

    books = {lang: ib.load_book(DRAFTS, lang=lang) for lang in LANGS}
    for lang in LANGS:
        counts = (len(books[lang]['chapters']), len(books[lang]['pages']), len(books[lang]['ids']))
        if counts != (18, 5, 90):
            raise IntegrationError('%s: expected 18 chapters, 5 pages and 90 actions, found %d, %d and %d.' % ((lang,) + counts))
    if [c['id'] for c in books['en']['chapters']] != [c['id'] for c in books['lt']['chapters']]:
        raise IntegrationError('The English and Lithuanian chapters do not have the same IDs in the same order.')
    locs = {lang: guide_locales.get(lang) for lang in LANGS}
    typo = guide_locales.typography_problems(locs['lt'])
    if typo:
        raise IntegrationError('site/guide_locales.py, Lithuanian strings:\n  - ' + '\n  - '.join(typo[:30]))
    config = read_config(DIST / 'config.js')
    configs = {lang: localized_config(config, locs[lang]) for lang in LANGS}
    legacy_map = load_legacy_map(books)
    cross = cross_check(books)
    former = compare_former(site, legacy_map, books)

    sources = sorted(c[0] for c in ib.CHAPTERS) + sorted(p[0] for p in ib.PAGES)
    if sorted(sources) != sorted(source_archive.BOOK_SOURCES):
        raise IntegrationError('source_archive.BOOK_SOURCES differs from the sources of import_book.py.')
    try:
        legal_texts = source_archive.check_legal(DRAFTS)
        archive, archive_list = source_archive.build(page_paths(), BASES, DRAFTS)
    except source_archive.ArchiveError as e:
        raise IntegrationError(str(e))

    guides = {lang: Guide(books[lang], configs[lang], legacy_map, locs[lang]) for lang in LANGS}
    files, urls = build_assets(guides, legacy_map, configs, legal_texts)
    Lic = config.get('licence') or {}
    for lang in LANGS:
        guides[lang].legal = {
            'licence': urls['legal/LICENSE.txt'], 'content_licence': urls['legal/LICENSE-CONTENT.txt'],
            'notice': urls['legal/NOTICE.txt'], 'ofl_jb': urls['legal/OFL-JetBrainsMono.txt'],
            'ofl_r': urls['legal/OFL-Righteous.txt'],
            'cc_url': (Lic.get('content') or {}).get('url', 'https://creativecommons.org/licenses/by-sa/4.0/'),
            'agpl_url': (Lic.get('code') or {}).get('url', 'https://www.gnu.org/licenses/agpl-3.0.en.html'),
            'zip': source_archive.ARCHIVE_URL, 'zip_name': source_archive.ARCHIVE_NAME,
            'zip_size': locs[lang].file_size(len(archive)), 'zip_sha': sha256(archive),
            'date': source_archive.ARCHIVE_DATE, 'review_date': source_archive.REVIEW_DATE}
    pages = {lang: page_list(guides[lang]) for lang in LANGS}
    outputs = {lang: {p['path']: page_html(guides[lang], p, urls).encode('utf-8') for p in pages[lang]} for lang in LANGS}
    checks = check_pages(site, outputs, legacy_map, guides, books, files=(source_archive.ARCHIVE_URL,))
    sw, sw_report = service_worker(site, outputs, urls)
    sm, sm_report = sitemap(site, page_paths())

    writes = {}
    for lang in LANGS:
        for p, data in outputs[lang].items():
            writes[site.joinpath(*(BASES[lang] + p + 'index.html').strip('/').split('/'))] = data
    writes.update({site.joinpath(*ASSET_DIR, *name.split('/')): data for name, data in files.items()})
    writes[site / 'book' / 'sw.js'] = sw
    writes[site / 'sitemap.xml'] = sm
    writes[site.joinpath(*source_archive.ARCHIVE_REL.split('/'))] = archive
    rels = {p.relative_to(site).as_posix() for p in writes}
    if rels != planned:
        raise IntegrationError('The files to write differ from the planned list: %s'
                               % ', '.join(sorted(rels ^ planned)[:10]))
    for path in writes:
        if not allowed(site, path, planned):
            raise IntegrationError('Refusing to write outside the planned files: %s' % path)

    written, unchanged = [], []
    for path, data in sorted(writes.items()):
        rel = path.relative_to(site).as_posix()
        if path.is_file() and path.read_bytes() == data:
            unchanged.append(rel)
        elif args.dry_run:
            written.append(rel)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            written.append(rel)

    after = protected_snapshot(site, planned)
    if after != protected:
        changed = sorted(k for k in set(protected) | set(after) if protected.get(k) != after.get(k))
        raise IntegrationError('Files outside the planned writes changed during the build: %s' % ', '.join(changed[:10]))

    registries = {lang: {e['id']: e for e in books[lang]['entries']} for lang in LANGS}
    report = {
        'generator': 'guide-ui/build_integration.py',
        'python_markdown': ib.markdown.__version__,
        'dry_run': bool(args.dry_run),
        'counts': {'pages_written': sum(len(v) for v in outputs.values()), **{lang: {
            'chapters': len(books[lang]['chapters']), 'other_pages': len(books[lang]['pages']), 'actions': len(books[lang]['ids']),
            'pages': len(outputs[lang]),
            'excluded_lines': sum(1 for e in books[lang]['exclusions'] if e['rule'] == 'go-further-at-proof'),
            'excluded_fragments': sum(1 for e in books[lang]['exclusions'] if e['rule'] != 'go-further-at-proof'),
            'tool_links_added': guides[lang].tool_links, 'search_entries': len(guides[lang].search_index())}
            for lang in LANGS}},
        'sources': {lang: books[lang]['sources'] for lang in LANGS},
        'routes': {lang: [{'url': BASES[lang] + p['path'], 'view': p['key'], 'title': p['title'], 'description': p['desc'],
                           'counterpart': BASES['lt' if lang == 'en' else 'en'] + p['path'],
                           'sha256': sha256(outputs[lang][p['path']])} for p in pages[lang]] for lang in LANGS},
        'assets': {name: {'url': urls[name], 'bytes': len(data), 'sha256': sha256(data)} for name, data in files.items()},
        'fonts_identical_to_site_fonts': {name: (site / 'fonts' / name.split('/')[1]).is_file()
                                          and (site / 'fonts' / name.split('/')[1]).read_bytes() == data
                                          for name, data in files.items() if name.startswith('fonts/')},
        'actions': {'cross_language': cross,
                    'registries': {lang: 'scripts/' + books[lang]['registry_file'].name for lang in LANGS}},
        'legacy_migration': {
            'keys': LEGACY_KEYS, 'new_keys': {k: config.get('storagePrefix', '') + '.' + k for k in ('actions', 'read', 'last', 'migration')},
            'shared_by_en_and_lt': True, 'former_pages': former,
            'actions': [{'legacy_id': e['legacy_id'], 'id': e['id'], 'legacy_text': e['legacy_text'],
                         'registry_text': registries['en'][e['id']]['text'],
                         'legacy_text_lt': registries['lt'][e['id']].get('legacy_text'),
                         'registry_text_lt': registries['lt'][e['id']]['text'], 'legacy_effort': e['legacy_effort']}
                        for e in legacy_map['actions']]},
        'checks': checks,
        'service_worker': sw_report,
        'sitemap': sm_report,
        'source_archive': {'path': source_archive.ARCHIVE_REL, 'bytes': len(archive), 'sha256': sha256(archive),
                           'files': [{'name': n, 'bytes': b, 'sha256': d} for n, b, d in archive_list]},
        'protected_files_unchanged': len(protected),
        'written': written, 'unchanged': unchanged,
    }
    if not args.dry_run:
        with open(args.report, 'w', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

    verb = 'Would write' if args.dry_run else 'Wrote'
    print('%s %d files, %d already up to date (site: %s)' % (verb, len(written), len(unchanged), site))
    for lang in LANGS:
        c = report['counts'][lang]
        print('[%s] %d pages, %d chapters, %d other pages, %d actions' % (lang, c['pages'], c['chapters'], c['other_pages'], c['actions']))
    print('%d former IDs mapped in both languages, %d internal links checked, %d action order differences reported'
          % (len(legacy_map['actions']), checks['internal_links_checked'], len(cross['order_differences'])))
    print('Former checklist pages: ' + '; '.join('%s %s' % (k, v['status']) for k, v in former.items()))
    print('Service worker cache %s -> %s (%d addresses); sitemap: %d entries changed, %d added'
          % (sw_report['cache_before'], sw_report['cache_after'], sw_report['core_after'], len(sm_report['changed']),
             len(sm_report['added'])))
    print('Source archive %s: %d files, %d bytes, SHA-256 %s'
          % (source_archive.ARCHIVE_REL, len(archive_list), len(archive), sha256(archive)))
    print('%d other files of the site checked unchanged' % len(protected))
    if not args.dry_run:
        print('Report: %s' % Path(args.report).resolve())
    if not ib.markdown.__version__.startswith('3.9'):
        print('Note: Python-Markdown %s, the documented version is 3.9. The HTML may differ.' % ib.markdown.__version__)
    return report


def main(argv=None):
    p = argparse.ArgumentParser(description='Build the English and Lithuanian PROOF book pages in the guide UI.')
    p.add_argument('--site-dir', default=str(DRAFTS.parent), help='PROOF site repository (default: %(default)s)')
    p.add_argument('--dry-run', action='store_true', help='render and check everything, write nothing')
    p.add_argument('--report', default=str(REPORT), help='integration report (default: %(default)s)')
    args = p.parse_args(argv)
    try:
        run(args)
    except (IntegrationError, ib.ImportFailure) as e:
        sys.exit('Integration stopped.\n' + str(e))


if __name__ == '__main__':
    main()
