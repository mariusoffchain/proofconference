# 15 skyrius: Lightning ir eurai kasdienybėje

## Trumpai

Pagrindinis Bitcoin sluoksnis sukurtas saugumui, o ne kavai pirkti. Lightning yra virš jo veikiantis kasdienėms sumoms skirtas mokėjimų tinklas, kuriame mokėjimai labai pigūs ir įvyksta beveik akimirksniu. Šiame skyriuje parodyta, kaip mokėti ir gauti mokėjimus per Lightning tinklą, kur išleisti satošius ir kokiais keliais bitkoinus galima iškeisti į eurus ir atgal, o už kiekvieną iš jų savaip sumoki mokesčiais, patogumu ir privatumu. Šiame skyriuje nėra jokių investavimo patarimų, o tavo šalies mokesčių įstatymai galioja ir toliau.

## Registras, per lėtas kavai

Bitcoin blokų grandinė maždaug kas 10 minučių pasipildo nauju bloku, o vieta kiekviename bloke ribota. Riba nustatyta sąmoningai, nes dėl jos registras lieka toks mažas, kad paprasti žmonės gali jį patikrinti savo kompiuteryje (žr. 18 skyrių). Šio pasirinkimo kaina tokia: kol mokėjimas pagrindinėje grandinėje (angl. on-chain) sulaukia patvirtinimų, paprastai praeina nuo kelių minučių iki kelių valandų (absoliutaus galutinumo nėra), o mokestis kyla, kai vietos bloke vienu metu prireikia daugeliui. Perkeliant santaupas tai priimtina, o perkant kavą neprotinga.

Antrasis sunkumas yra tiltas. Algos, nuoma ir mokesčiai valstybei skaičiuojami eurais, todėl norint apskritai naudotis bitkoinais reikia kelio į juos ir kelio atgal. Geriausiai žinomas kelias yra didelė kriptovaliutų birža, kuri laiko tavo bitkoinus, asmens dokumentus ir visą veiksmų istoriją. Yra ir kitų kelių, aprašytų toliau, o jų mokesčiai, patogumas ir privatumas labai skiriasi.

## Kanalai, į blokų grandinę įrašomi tik 2 kartus

Lightning remiasi **mokėjimo kanalais**. 2 dalyviai pagrindinės grandinės transakcija kartu užrakina šiek tiek bitkoinų ir nuo tada gali kiek nori kartų, beveik akimirksniu, perskirstyti likutį tarpusavyje keisdamiesi pasirašytais atnaujinimais, kurie į blokų grandinę niekada nepatenka. Pagrindinėje grandinėje įrašomas tik kanalo atidarymas ir uždarymas. Kanalai jungiasi į tinklą, todėl gali sumokėti ir tam, su kuo bendro kanalo neturi, o tada mokėjimas keliauja per tarpinius mazgus, kurie negali jo pasilikti ir paprastai uždirba cento dalį.

Praktikoje matai 2 dalykus:

- **Mokėjimo prašymas** (angl. invoice), kuris rodomas kaip QR kodas arba ilgas tekstas. Įprasti BOLT11 mokėjimo prašymai prasideda raidėmis „lnbc“, o naujesni BOLT12 prašymai turi kitokį formatą. Paprastai jame nurodyta fiksuota suma, jis naudojamas vieną kartą ir galioja ribotą laiką.
- **Lightning adresas**, kuris atrodo kaip el. pašto adresas (you@provider.com) ir kurį galima naudoti daug kartų, todėl jis patogus arbatpinigiams ir kitiems mokėjimams gauti. Dauguma tokių adresų veikia per teikėjo žiniatinklio serverį. Piniginės „Phoenix“ adresas pagrįstas naujesniu standartu BOLT12, ir į tokį adresą kol kas gali sumokėti tik dalis piniginių.

Šiuolaikinės piniginės arba tvarko kanalus už tave, arba apsieina be jų ir lėšas keičia (angl. swap) per išorinę paslaugą (žr. 13 skyrių).

## Kur išleisti satošius

- **Gyvai.** Vietų ieškok žemėlapyje [„BTC Map“](https://btcmap.org/) (btcmap.org). Tai nemokamas bendruomenės tvarkomas žemėlapis, kuriame pažymėtos bitkoinus priimančios kavinės, parduotuvės, viešbučiai ir laisvai samdomi specialistai. Vilniuje, kur vyksta konferencija, 2026 m. rugsėjo mėn. duomenimis, pažymėtos kelios vietos, pavyzdžiui, kavinė [„Baltic Brew“](https://btcmap.org/merchant/24824) (L. Asanavičiūtės g. 29), prie kurios nurodyti Lightning ir pagrindinės grandinės mokėjimai, ir [„Zolak“](https://zolak.lt/), buvusioje elektronikos gamykloje (Vytenio g. 50D) įsikūrusi meno rezidencija su baru „Zolak Micro Art Residence“, savo svetainėje skelbianti, kad priima Lightning mokėjimus. Įrašas gali būti pasenęs, todėl pažiūrėk, kada jis paskutinį kartą patikrintas, prieš užsisakant pasiteirauk, o atradus naują vietą pridėk ją į žemėlapį.
- **Arbatpinigiai ir zapai (angl. zaps).** Nostr tinkle (žr. 7 skyrių) patikusio įrašo autoriui gali tiesiogiai nusiųsti kelis satošius, ir jokia platforma nepasiima savo dalies. Lightning adresą skelbia ir daug tinklalaidžių bei nepriklausomų autorių.
- **Žmonės.** Pirmą kartą iš tikrųjų panaudoti Lightning dažnai tenka dalijantis sąskaitą ar grąžinant skolą draugui.
- **Internetu.** Kelios įmonės už bitkoinus parduoda dovanų korteles, telefono sąskaitos papildymus, eSIM korteles ar keliones, ir tai netiesioginis būdas gyventi atsiskaitant satošiais ten, kur prekybininkai jų dar nepriima. Kiekviena toliau lentelėje išvardyta paslauga (2026 m. rugsėjo mėn. duomenimis) yra parduotuvė, o ne piniginė, todėl sumokėk už tai, ko reikia, ir nepalik ten likučio.

| Paslauga | Ką gali nusipirkti | Ar priima Lightning? | Tapatybės tikrinimas |
|---|---|---|---|
| **[Bitrefill](https://www.bitrefill.com/)** | Dovanų kortelės, telefono sąskaitos papildymai, eSIM kortelės | Taip | Įprastiems pirkiniams paskyros nereikia. Patvirtinus tapatybę padidėja pirkimo limitai. |
| **[CoinsBee](https://www.coinsbee.com/en/)** („Coinsbee GmbH“) | Dovanų kortelės, mokėjimo kortelės, telefono sąskaitos papildymai | Taip | [Netikrinama, kol vienas užsakymas neviršija 1 000 eurų, o visi kartu 10 000 eurų](https://www.coinsbee.com/en/kyc-aml/), didesnėms sumoms tapatybę reikia patvirtinti. |
| **[Cryptorefills](https://www.cryptorefills.com/)** („Big Dream Ventures B.V.“, Amsterdamas) | Dovanų kortelės, sąskaitos papildymai, eSIM kortelės, skrydžiai, nakvynė | Taip | Netikrinama, kaip teigiama jos svetainėje |
| **[CoinGate dovanų kortelės](https://coingate.com/gift-cards)** (parduoda Lietuvos įmonė UAB „Rewards distributed“) | Maždaug 6 000 prekių ženklų dovanų kortelės | Taip | Registruotis nereikia, kaip teigiama jos svetainėje |
| **[Travala](https://www.travala.com/)** | Viešbučiai, skrydžiai, pramogos | Taip | Užsakant reikia keliautojo duomenų, o oro linijų bendrovė ar viešbutis asmens dokumentą tikrina kaip įprasta |

## Kas laiko lėšas ir kas gali jas užblokuoti

Apie kiekvieną kelią keliami tie patys klausimai kaip ir visoje knygoje: kas laiko lėšas, kol vyksta mokėjimas, ir kas gali jį sustabdyti.

Depozitinėje programėlėje (angl. custodial) bitkoinus, kol jų neišsiimi, laiko įmonė, ir ji gali įšaldyti likutį arba atsisakyti įvykdyti mokėjimą. Savarankiško saugojimo Lightning piniginėje raktai yra tavo, tačiau mokėjimai keliauja per Lightning paslaugų teikėją (piniginės „Phoenix“ teikėjas yra „ACINQ“, piniginės „Bitkit“ teikėjas „Blocktank“) arba, taikant kitokį modelį, per nedidelę operatorių grupę (Spark). Šios paslaugos gali atsisakyti atlikti pervedimus. Lightning saugumui reikia tinkamai tvarkyti kanalus ir turėti atsargines kopijas, o Spark dar remiasi prielaida, kad [pervedimų metu sąžiningai elgsis bent nustatytas operatorių skaičius](https://docs.spark.money/learn/trust-model). Pasitraukimas į blokų grandinę turi savų sąlygų, mokesčių ir vėlavimų, o vien raktų turėjimas nuo visų gedimų neapsaugo.

Tarpininkas (angl. broker), tikrinantis tapatybę pagal KYC taisykles, pirkimo metu laiko tavo eurus ir gali atsisakyti vykdyti užsakymą, paklausti, iš kur pinigai, arba uždaryti paskyrą, o tą patį gali ir bankas, iš kurio siunčiamas pavedimas. Lygiarangės (angl. peer-to-peer) platformos stengiasi apsieiti be lėšų laikytojo. Platformoje „Bisq“ bitkoinai užrakinami [2 iš 2 kelių parašų adrese](https://bisq.wiki/Security_deposit), kurį bendrai valdo 2 sandorio dalyviai, o platformoje „Hodl Hodl“ [2 iš 3 adrese](https://hodlhodl.com/blog/en/escrow-explained), kurio 1 raktą turi platforma, todėl nė viena šalis negali jų perkelti viena. Platforma „RoboSats“ naudoja [sulaikytą Lightning mokėjimą](https://learn.robosats.org/docs/escrow/), skirtą koordinatoriui, kurio serveryje paskelbtas užsakymas. Pasitikėti vis tiek tenka kita sandorio šalimi ir tuo, kas sprendžia ginčą.

## Kaip pasirinkti tiltą į eurus

Nė vienas kelias nėra geriausias visais atžvilgiais, nes kiekviename paprastumas, mokesčiai ir privatumas suderinti vis kitaip. **KYC** (angl. know your customer, „pažink savo klientą“) reiškia, kad paslauga patikrina tavo tapatybę pagal asmens dokumentą. Europoje reguliuojamos įmonės dabar privalo tai daryti, o ką tai reiškia tavo privatumui, aiškinama 16 skyriuje. Ši rinka greitai keičiasi. Pavyzdžiui, Šveicarijos tarpininkas „Pocket Bitcoin“ [2025 m. gruodį atsisakė supaprastinto tapatybės tikrinimo](https://pocketbitcoin.com/blog/posts/full-verification-coming-to-pocket). Lygiarangėse platformose [„Hodl Hodl“](https://hodlhodl.com/), [„Bisq“](https://bisq.network/) ir [„RoboSats“](https://learn.robosats.org/) gali keistis su kitu žmogumi ir bitkoinų neatiduoti jokiai įmonei, o sandoriui taikomos ankstesniame skirsnyje aprašytos sąlyginio deponavimo (angl. escrow) schemos. Lentelėje pateikta 2026 m. rugsėjo mėn. padėtis, o tu kiekvienu atveju pasitikrink, ar paslauga aptarnauja tavo šalies gyventojus.

| Kelias | Pavyzdžiai | Tapatybės tikrinimas (KYC) | Kas laiko bitkoinus | Kas gali užblokuoti | Kompromisas be pagražinimų |
|---|---|---|---|---|---|
| **Užsidirbti satošių** | Už darbą, parduotas prekes ar turinį gauti atlygį arba arbatpinigių bitkoinais | Nėra | Tu | Tik Lightning paslaugų teikėjas vienoje ar kitoje pusėje, jei atsisako persiųsti mokėjimą | Nėra jokio tarpininko. Reikia žmogaus, kuris sutiktų taip mokėti, o pajamos lieka apmokestinamos. |
| **Lygiarangiai mainai** | „Hodl Hodl“ (žiniatinklis), „Bisq“ (kompiuterio programa), „RoboSats“ (Lightning, per Tor tinklą) | Pati platforma paprastai netikrina. „Hodl Hodl“ gali paprašyti patvirtinti tapatybę, jei kyla ginčas. | Tu. Bitkoinai tik sandorio metu užrakinami sąlyginio deponavimo adrese, jei platforma tokį siūlo. | Kita sandorio šalis, jei nesumoka, ir abiejų pusių bankai. Ginčus sprendžia mediatorius arba arbitras. | Keitiesi su žmogumi banko pavedimu. Privačiau, bet paprastai brangiau, lėčiau ir reikia daugiau išmokti. |
| **Europos tarpininkas, periodiniai pirkimai** | „Relai“, „Pocket Bitcoin“ (abi Šveicarijos bendrovės) | Taip | Tu. Bitkoinus jie atsiunčia į tavo piniginę. | Tarpininkas, kuris gali atsisakyti vykdyti užsakymą arba uždaryti paskyrą, ir tavo bankas, kuris gali užblokuoti pavedimą | Labai paprasta ir automatiška. Už kiekvieną pirkimą imamas mokestis, o įmonė žino, kas tu ir ką pirkai. |
| **Sąskaita eurais ir bitkoinų piniginė** | „Bringin“ (IBAN sąskaita eurais ir pasirenkama „Visa“ kortelė šalia savarankiško saugojimo piniginės; „Bringin“ yra šios konferencijos rėmėja), „Strike“ (SEPA įmokos, visiškai depozitinė paslauga) | Taip | „Bringin“: bitkoinus laikai tu. „Strike“: viską laiko įmonė, kol neišsiimi į savo piniginę. | „Bringin“ gali užblokuoti sąskaitą eurais ir kortelę, kaip bet kuri reguliuojama mokėjimo įmonė, bet ne bitkoinus, kurie laikomi savarankiško saugojimo piniginėje. „Strike“ yra depozitinė paslauga, todėl įmonė laiko ir tavo eurų, ir tavo bitkoinų raktus ir gali jais visiškai disponuoti: įšaldyti likutį, atsisakyti įvykdyti mokėjimą arba uždaryti paskyrą. | Patogu keisti satošius į eurus ir atgal. Abi puses mato viena įmonė, už kiekvieną keitimą imamas mokestis, o eurų pusė yra tokia pat reguliuojama sąskaita kaip bet kuri kita. |
| **Bitkoinų automatas** | Automatai, išvardyti svetainėje coinatmradar.com | ES paprastai taip, priklauso nuo operatoriaus ir sumos | Tu | Operatorius, kuris nustato limitus ir gali atsisakyti įvykdyti operaciją | Įdedi grynuosius ir po kelių minučių gauni bitkoinų. Mokesčiai paprastai didžiausi iš visų kelių. |

Daugumai žmonių, nusprendusių keisti eurus, protingas derinys būtų toks: jiems aiškus reguliuojamas kelias, naudojamas tik tam, kad bitkoinai atkeliautų į nuosavą piniginę, ir lygiarangis kelias, išbandytas su mažomis sumomis, kad nereikėtų priklausyti nuo vienų durų. Kad ir kurį kelią pasirinktum, pardavus ar išleidus bitkoinus gali atsirasti mokestinė prievolė, todėl kaupk įrašus ir pasitikrink savo šalies taisykles.

## Žingsnis po žingsnio

Pavyzdyje naudojama piniginė „Phoenix“. Bet kurioje kitoje Lightning piniginėje logika ta pati.

1. **Apmokėk mokėjimo prašymą.** Konferencijoje arba pas prekybininką bakstelėk „Send“ (siųsti) ir nuskenuok QR kodą. Patikrink rodomą sumą ir mokestį, tada patvirtink. Prekybininkas mokėjimą paprastai pamato per 1 ar 2 sekundes.
2. **Gauk mokėjimą pagal mokėjimo prašymą.** Bakstelėk „Receive“ (gauti), jei nori, įvesk sumą ir parodyk QR kodą. Nepamiršk, kad prašymas galioja ribotą laiką, o pirmasis mokėjimas į piniginę „Phoenix“ turi viršyti kanalo mokestį (žr. 13 skyrių).
3. **Gauk mokėjimą Lightning adresu.** Jei piniginė jį siūlo, susirask jį nustatymuose arba gavimo ekrane ir išbandyk iš kitos piniginės anksčiau, nei jį paskelbsi. Piniginės „Phoenix“ adresas pagrįstas BOLT12, todėl daug piniginių į jį sumokėti dar negali. Depozitinės arba Spark pagrindu veikiančios piniginės adresas tinka beveik visiems siuntėjams, tik su 13 skyriuje aprašytais kompromisais.
4. **Išsiimk lėšas iš tarpininko ar programėlės į SAVO piniginę.** Pasirink „withdraw“ (išsiimti) arba „send“ (siųsti), įklijuok savo piniginės sugeneruotą adresą arba mokėjimo prašymą ir pradėk nuo mažos bandomosios sumos. Būtent šiuo žingsniu pasitikėjimą ekrane rodomu likučiu pakeiti patikrinimu, nes pamatai, kad bitkoinai atkeliavo į piniginę, kurios raktus turi tu. Didesnes sumas išsiimk pagrindine grandine į santaupų piniginę (žr. 14 ir 17 skyrius).
5. **Telefone laikyk tik išlaidoms skirtus pinigus.** Lightning piniginę vertink kaip kišenėje nešiojamą piniginę. Kai joje susikaupia daugiau, nei nešiotumeisi grynaisiais, perteklių perkelk į pagrindinę grandinę.
6. **Tvarkyk apskaitą.** Eksportuok arba užsirašyk pirkimus ir pardavimus su datomis ir sumomis, nes jų prireiks mokesčių deklaracijai.

## Klaidos, kurių verta vengti

- **Laikyti santaupas telefono Lightning piniginėje.** Ji laikoma įrenginyje, kurį gali pamesti ar sudaužyti ir kuris visą dieną prijungtas prie interneto, todėl tinka išlaidoms skirtiems pinigams.
- **Supainioti mokėjimo prašymą su pagrindinės grandinės adresu.** BOLT11 mokėjimo prašymas prasideda „lnbc“ ir galioja ribotą laiką, o BOLT12 naudoja kitus formatus. Pagrindinės grandinės adresas prasideda „bc1“, „1“ arba „3“ ir galioja neribotai. Kai išsiimi lėšas iš paslaugos, pasirink atitinkamą tinklą.
- **Mokėti dideles sumas per Lightning.** Kanalų talpa ribota, todėl dideli mokėjimai dažniau nepavyksta. Lightning skirtas kasdienėms sumoms, o visa kita atliekama pagrindinėje grandinėje.
- **Palikti bitkoinus pas tarpininką.** Pirkimas baigtas tada, kai bitkoinai yra tavo piniginėje, o ne tada, kai programėlė rodo likutį (žr. 13 skyrių).
- **Neskaičiuoti visos kainos.** Lygink galutinį gaunamų satošių kiekį, o ne skelbiamą mokestį, nes valiutos kurse dažnai slypi marža.
- **Pamiršti mokesčius valstybei.** Mokėjimas bitkoinais gali būti laikomas jų pardavimu, o taisyklės įvairiose šalyse skiriasi.

## Norintiems daugiau

- **PROOF konferencijoje:** „CBDC, KYC ir kova dėl monetarinio privatumo“, pranešimą skaito Linas K., ir „Kodėl centralizuoti pinigai neveikia: kaip Bitcoin tapo alternatyva“, pranešimą skaito Piktas.
- **Rask, kur išleisti:** „BTC Map“ (btcmap.org).
- **Pirmiau minėtų piniginių ir mainų platformų pamokos:** „Plan B Academy“ (planb.academy).
- **Nuodugniau apie Lightning:** „Mastering the Lightning Network“, internete skaitoma nemokamai (github.com/lnbook/lnbook).
- **Kitas skyrius:** privatumas Bitcoin tinkle.

## Šaltiniai

- [Spark trust model](https://docs.spark.money/learn/trust-model), Spark dokumentacija, tikrinta 2026 m. spalio 22 d.
- [Important Update: Full Verification Coming to Pocket](https://pocketbitcoin.com/blog/posts/full-verification-coming-to-pocket), „Pocket Bitcoin“, 2025 m. spalio 16 d.
- [Security deposit](https://bisq.wiki/Security_deposit), „Bisq Wiki“, žiūrėta 2026 m. rugsėjį.
- [What is multisig escrow and how it works](https://hodlhodl.com/blog/en/escrow-explained), „Hodl Hodl“, žiūrėta 2026 m. rugsėjį.
- [Trade escrow](https://learn.robosats.org/docs/escrow/), „Learn RoboSats“, žiūrėta 2026 m. rugsėjį.
- [Bringin: wallet, euro account and fees](https://bringin.app/), „Bringin“, žiūrėta 2026 m. rugsėjį.
- [Baltic Brew](https://btcmap.org/merchant/24824) ir [Zolak Micro Art Residence](https://btcmap.org/merchant/26604), „BTC Map“ įrašai apie Vilniaus vietas, žiūrėta 2026 m. rugsėjo 20 d.
- [KYC and AML: purchase limits](https://www.coinsbee.com/en/kyc-aml/), „CoinsBee“, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Apmokėk Lightning mokėjimo prašymą konferencijoje arba pas prekybininką (5 min.)
- [ ] Susikurk Lightning adresą ir išbandyk jį iš kitos piniginės (5 min.)
- [ ] Svetainėje btcmap.org surask 3 vietas netoli savęs (5 min.)
- [ ] Visą likutį iš tarpininko ar biržos išsiimk į savo piniginę (1 val.)
- [ ] Perskaityk, kaip veikia lygiarangiai mainai, kol jų dar neprireikė (1 val.)
