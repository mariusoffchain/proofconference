#!/usr/bin/env python3
"""Source archive of the English and Lithuanian PROOF editions of A Guide to Autonomy: the corresponding source of the
pages under /book/, offered on every page footer and on the legal page (book/source/<ARCHIVE_NAME>).

The archive holds an explicit list of files, never a folder walk: the 46 Markdown sources (23 English, 23 Lithuanian),
the generator, the interface, the registries, the selected build inputs, this packager, the release exporter, the
licences and notices (guide-ui/legal/) and a rebuild README. It never holds the private repository as a whole, .git,
QA reports, audits, briefs, logs, photographs, videos or the conference pages.

A minimal bootstrap makes the archive rebuildable without the original checkout: placeholder host pages (index.html,
en/index.html, book/index.html), an empty book/sw.js and a sitemap.xml listing the book addresses, plus placeholders for
the host files the generator only checks or hashes (favicon.svg, replays.js, book/book.js, book/book.css). The bootstrap
is generated from constants and from the page list, never read from the site, and the archive never contains a
generated page: its bytes depend only on the source files, so the pages can show its SHA-256 without a cycle.

Deterministic: sorted names under 1 folder, fixed timestamps and permissions, no compression (byte-identical across
zlib versions), no absolute name. SHA256SUMS.txt inside lists every other file.

build_integration.py writes the archive as one of its planned files. To write it elsewhere, from book-drafts:

    python3 guide-ui/source_archive.py --out /path/to/new.zip     refuses to overwrite an existing file
    python3 guide-ui/source_archive.py --list                     names, sizes and SHA-256, writes nothing
"""

import argparse
import hashlib
import io
import sys
import zipfile
from pathlib import Path

GUIDE_UI = Path(__file__).resolve().parent              # book-drafts/guide-ui
DRAFTS = GUIDE_UI.parent                                # book-drafts
LEGAL = GUIDE_UI / 'legal'

# Date of this source release: the modification date of the notices and the legal page, and the archive name. A new
# release with different bytes takes a new date, so a name already published never changes content.
ARCHIVE_DATE = '2026-10-23'
# Archives already published under book/source/: never reused for different bytes.
PUBLISHED_ARCHIVES = ('proof-guide-source-2026-10-22.zip',)
# The licence and publication review (release-review-20261022): historical, not moved by a later release.
REVIEW_DATE = '2026-10-22'
ARCHIVE_NAME = 'proof-guide-source-%s.zip' % ARCHIVE_DATE
ARCHIVE_REL = 'book/source/' + ARCHIVE_NAME            # relative to the site folder
ARCHIVE_URL = '/' + ARCHIVE_REL
SOURCE_URL_PREFIX = '/book/source/'                     # online only: the service worker neither precaches nor stores it
PREFIX = 'proof-guide-source-%s/' % ARCHIVE_DATE
FIXED_TIME = tuple(int(x) for x in ARCHIVE_DATE.split('-')) + (0, 0, 0)

# The 23 sources of each language (same names in lt/). build_integration.py checks this list against import_book.py.
BOOK_SOURCES = (
    '00-introduction.md', '10-part1-privacy.md', '11-messages.md', '12-passwords.md', '13-browser.md', '14-email.md',
    '15-network.md', '20-part2-autonomy.md', '21-keys.md', '22-nostr.md', '23-big-tech.md', '24-phone.md',
    '25-self-hosting.md', '26-ai.md', '30-part3-work.md', '31-savings.md', '32-first-wallet.md', '33-seed.md',
    '34-lightning-and-euros.md', '35-bitcoin-privacy.md', '36-hardware-wallet.md', '37-node.md', '90-glossary.md',
)

# Every other input of the build, relative to book-drafts. build.py imports site/build_site.py; both read lt/ui.json,
# links.json and site/content.json.
BUILD_FILES = (
    'build.py', 'sw.template.js', 'links.json', 'lt/ui.json', 'site/build_site.py', 'site/content.json',
    'guide-ui/build_integration.py', 'guide-ui/source_archive.py', 'guide-ui/release.py',
    'guide-ui/dist/app.js', 'guide-ui/dist/config.js', 'guide-ui/dist/styles.css',
    'guide-ui/dist/assets/fonts/jetbrainsmono-latin-ext.woff2', 'guide-ui/dist/assets/fonts/jetbrainsmono-latin.woff2',
    'guide-ui/dist/assets/fonts/righteous-latin-ext.woff2', 'guide-ui/dist/assets/fonts/righteous-latin.woff2',
    'guide-ui/scripts/action-registry.json', 'guide-ui/scripts/action-registry-lt.json',
    'guide-ui/scripts/legacy-action-map.json', 'guide-ui/scripts/import_book.py', 'guide-ui/scripts/lt_sources.py',
    'guide-ui/scripts/requirements.txt', 'guide-ui/site/guide_locales.py', 'guide-ui/site/integration.css',
)

# Licences and notices. The official texts are copies; their SHA-256 is pinned when it was verified against the
# official source (release-review-20261022/official-notices). LICENSE-CONTENT is checked by its content.
LEGAL_FILES = {
    'LICENSE': '0d96a4ff68ad6d4b6f1f30f713b18d5184912ba8dd389f86aa7710db079abcb0',             # GNU AGPL v3
    'LICENSE-CONTENT': None,                                                                     # CC BY-SA 4.0
    'OFL-JetBrainsMono.txt': 'b2fe5e8987594e9ffd1d2ca52a2f5d73eb8335243893c5d6254b5ad69269591d',
    'OFL-Righteous.txt': '1c5bc055869d5e9151ec7774082727db720ec4293c65be67f91a4bdcaeb02998',
    'Markdown-3.9-LICENSE.md': '7ba4eb6d10b32b2d11dce13821340351cdbbb30ba8ccc67841db2ffd86e79aca',  # build tool only
    'NOTICE.txt': None,
    'SOURCE-README.md': None,
}
CONTENT_LICENCE_MARKERS = ('Attribution-ShareAlike 4.0 International', 'Section 8')

# Copies at the top of the archive, for a reader who opens it.
TOP_COPIES = {'README.md': 'SOURCE-README.md', 'LICENSE': 'LICENSE', 'LICENSE-CONTENT': 'LICENSE-CONTENT',
              'NOTICE.txt': 'NOTICE.txt'}

# Never in the archive, whatever a future list says.
FORBIDDEN_PARTS = ('.git', 'qa', 'release-review-20261022', 'integration-report.json', 'import-report.json',
                   '.DS_Store', '__pycache__')

SITE_URL = 'https://proofconference.com'
_PLACEHOLDER_PAGE = ('<!doctype html>\n<html lang="%s">\n<head>\n<meta charset="utf-8">\n<title>Placeholder</title>\n'
                     '</head>\n<body>\n<p>Placeholder of the host site page %s, created by the source archive so that '
                     'the guide can be built. It is not part of the guide; the real host page replaces it.</p>\n'
                     '</body>\n</html>\n')
_PLACEHOLDER_ASSET = ('/* Placeholder of the host site file %s, created by the source archive. The guide build only '
                      'checks that it exists or hashes it; it is not part of the guide. */\n')


class ArchiveError(Exception):
    pass


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def source_paths():
    """Every file taken from book-drafts, relative to it, sorted."""
    return sorted(set(BOOK_SOURCES) | {'lt/' + n for n in BOOK_SOURCES} | set(BUILD_FILES)
                  | {'guide-ui/legal/' + n for n in LEGAL_FILES})


def safe_source(drafts, rel):
    """Read only regular files within the selected source tree, never symlink targets."""
    root = Path(drafts).resolve()
    parts = Path(rel).parts
    if Path(rel).is_absolute() or '..' in parts:
        raise ArchiveError('Unsafe source path: %s' % rel)
    path = root
    for part in parts:
        path = path / part
        if path.is_symlink():
            raise ArchiveError('Symbolic links are not source inputs: %s' % rel)
    if not path.is_file() or root not in path.resolve().parents:
        raise ArchiveError('Source file missing or outside source tree: %s' % rel)
    return path


def check_legal(drafts=DRAFTS):
    """The licence files exist, the pinned ones are the verified official texts. Returns {name: bytes}."""
    out, problems = {}, []
    for name, want in sorted(LEGAL_FILES.items()):
        f = safe_source(drafts, 'guide-ui/legal/' + name)
        if not f.is_file():
            problems.append('%s is missing' % f.relative_to(drafts).as_posix())
            continue
        data = f.read_bytes()
        if want and sha256(data) != want:
            problems.append('%s is not the verified official text (SHA-256 %s)' % (name, sha256(data)))
        out[name] = data
    if 'LICENSE-CONTENT' in out:
        text = out['LICENSE-CONTENT'].decode('utf-8', 'replace')
        problems += ['LICENSE-CONTENT lacks "%s"' % m for m in CONTENT_LICENCE_MARKERS if m not in text]
    if problems:
        raise ArchiveError('guide-ui/legal/: ' + '; '.join(problems) + '.')
    return out


def bootstrap_files(book_paths, bases):
    """Minimal host tree for a first build. book_paths: page paths of each edition (relative to its base); bases:
    {'lt': '/book/', 'en': '/book/en/'}. The sitemap lists the book addresses only, without dates: the build adds the
    dates (its floor) and the alternates."""
    urls = ''.join('  <url>\n    <loc>%s</loc>\n  </url>\n' % (SITE_URL + bases[lang] + p)
                   for p in book_paths for lang in ('lt', 'en'))
    files = {
        'index.html': _PLACEHOLDER_PAGE % ('lt', '/'),
        'en/index.html': _PLACEHOLDER_PAGE % ('en', '/en/'),
        'book/index.html': _PLACEHOLDER_PAGE % ('lt', '/book/ (replaced by the first build)'),
        'book/sw.js': ("// Placeholder, replaced by the first build (book-drafts/build.py).\n"
                       "const CACHE = 'proof-book-bootstrap';\nconst CORE = [\n\n];\n"),
        'sitemap.xml': ('<?xml version="1.0" encoding="UTF-8"?>\n'
                        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n'
                        '        xmlns:xhtml="http://www.w3.org/1999/xhtml">\n' + urls + '</urlset>\n'),
        'favicon.svg': ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16"><!-- Placeholder of the host '
                        'icon. --><rect width="16" height="16" fill="#080808"/></svg>\n'),
        'replays.js': _PLACEHOLDER_ASSET % '/replays.js',
        'book/book.js': _PLACEHOLDER_ASSET % '/book/book.js',
        'book/book.css': _PLACEHOLDER_ASSET % '/book/book.css',
    }
    return {k: v.encode('utf-8') for k, v in files.items()}


def entries(book_paths, bases, drafts=DRAFTS):
    """{name inside the archive folder: bytes}, before SHA256SUMS.txt."""
    legal = check_legal(drafts)
    out = {}
    for rel in source_paths():
        f = safe_source(drafts, rel)
        if not f.is_file():
            raise ArchiveError('Source file missing: book-drafts/%s' % rel)
        out['book-drafts/' + rel] = f.read_bytes()
    for top, name in TOP_COPIES.items():
        out[top] = legal[name]
    for rel, data in bootstrap_files(book_paths, bases).items():
        if rel in out:
            raise ArchiveError('Bootstrap file %s collides with a source file.' % rel)
        out[rel] = data
    for name in out:
        parts = name.split('/')
        if name.startswith('/') or '..' in parts or '\\' in name or ':' in name:
            raise ArchiveError('Unsafe name in the archive: %s' % name)
        if set(parts) & set(FORBIDDEN_PARTS):
            raise ArchiveError('Excluded file in the archive: %s' % name)
    return out


def build(book_paths, bases, drafts=DRAFTS):
    """The archive bytes and its file list [(name, bytes, sha256)]."""
    if ARCHIVE_NAME in PUBLISHED_ARCHIVES:
        raise ArchiveError('%s is already published: set a new ARCHIVE_DATE for these sources.' % ARCHIVE_NAME)
    files = entries(book_paths, bases, drafts)
    sums = ''.join('%s  %s\n' % (sha256(files[n]), n) for n in sorted(files))
    files['SHA256SUMS.txt'] = sums.encode('utf-8')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_STORED) as z:
        for name in sorted(files):
            zi = zipfile.ZipInfo(PREFIX + name, date_time=FIXED_TIME)
            zi.compress_type = zipfile.ZIP_STORED
            zi.create_system = 3
            zi.external_attr = 0o100644 << 16
            z.writestr(zi, files[name])
    return buf.getvalue(), [(n, len(files[n]), sha256(files[n])) for n in sorted(files)]


def main(argv=None):
    p = argparse.ArgumentParser(description='Write the source archive of the PROOF EN/LT guide.')
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--out', help='new file to write (never overwritten)')
    g.add_argument('--list', action='store_true', help='print the contents, write nothing')
    args = p.parse_args(argv)
    sys.path.insert(0, str(GUIDE_UI))
    import build_integration as bi   # the page list and the bases of both editions
    try:
        data, listing = build(bi.page_paths(), bi.BASES)
    except ArchiveError as e:
        sys.exit('Source archive stopped.\n' + str(e))
    if args.list:
        for name, size, digest in listing:
            print('%s  %9d  %s' % (digest, size, PREFIX + name))
        print('%d files, archive %d bytes, SHA-256 %s' % (len(listing), len(data), sha256(data)))
        return
    out = Path(args.out).expanduser()
    if out.exists():
        sys.exit('Refusing to overwrite %s.' % out)
    out.write_bytes(data)
    print('Wrote %s: %d files, %d bytes, SHA-256 %s' % (out, len(listing), len(data), sha256(data)))


if __name__ == '__main__':
    main()
