# 5 skyrius: Tavo tinklas

## Trumpai

Kiekvienas tavo ryšys keliauja per svetimą įrangą, ar tai būtų interneto paslaugų teikėjo, ar kavinės belaidis tinklas („Wi-Fi“), ar darbovietės tinklas. HTTPS jau paslepia, ką skaitai ir rašai, tačiau tinklai dažnai vis tiek gali nustatyti, kuriose svetainėse lankaisi. VPN paslepia šį sąrašą nuo teikėjo, o IP adresą nuo svetainių, tačiau pasitikėjimą jis perkelia VPN bendrovei ir anonimiškumo nesuteikia. Tor tinklas ir maišymo tinklai (angl. mixnets) žengia toliau, bet už tai moki greičiu.

## Stebėti gali kiekvienas tinklas pakeliui

Duomenų srautas nuo tavo įrenginio iki svetainės pereina kelis tinklus, ir kiekvienas iš jų gali jį stebėti be jokių įsilaužėlių, nes taip tinklai įprastai ir veikia.

- **Interneto paslaugų teikėjas** mato kiekvieną ryšį, kurį užmezgi iš namų ar iš telefono, o daugelyje šalių įstatymai įpareigoja jį saugoti šių ryšių įrašus.
- **Viešąjį belaidį tinklą** kavinėje, viešbutyje ar oro uoste valdo tau nepažįstami žmonės, kaip ir bet kurį to paties pavadinimo tinklą, kurį sukūrė pašalinis žmogus.
- **Darbovietės ar mokyklos tinklas** dažnai stebimas, nes taip numato vidaus tvarka.
- **Kiekviena svetainė, kurioje lankaisi,** mato tavo IP adresą, t. y. skaičių, identifikuojantį tavo ryšį. Jis atskleidžia teikėją ir apytikslę buvimo vietą, o svetainėms ir reklamos užsakovams leidžia tave atpažinti per kiekvieną apsilankymą net be slapukų.

Europos Sąjungoje 2006 m. direktyva įpareigojo teikėjus srauto ir vietos nustatymo duomenis saugoti nuo 6 mėnesių iki 2 metų. Teisingumo Teismas [2014 m. balandžio 8 d. pripažino ją negaliojančia](https://curia.europa.eu/site/upload/docs/application/pdf/2014-04/cp140054en.pdf) ir pažymėjo, kad tokie duomenys „gali suteikti labai tikslios informacijos apie privatų gyvenimą“ (tų žmonių, kurių duomenys saugomi). Keliose valstybėse narėse nacionalinės duomenų saugojimo taisyklės tebegalioja.

## Spynelė slepia puslapius, bet ne tai, kur jungiesi

**HTTPS**, t. y. spynelės piktograma naršyklėje, šifruoja ryšį tarp tavęs ir svetainės, ir šiandien jį naudoja beveik visos svetainės. Tarpiniai tinklai nebemato nei skaitomų puslapių, nei to, ką rašai, nei slaptažodžių. Jie vis dar mato IP adresus, prie kurių jungiesi, ryšių laiką ir perduodamų duomenų kiekį, o dažnai ir domeno vardą (svetainės pavadinimą, o ne konkretų puslapį). Jei ECH (angl. Encrypted Client Hello) technologija palaikoma, ji kartu su šifruotu DNS gali paslėpti ir šį vardą, nors IP adresai ir duomenų srauto pobūdis vis tiek gali atskleisti, kur jungiesi.

**DNS** (domenų vardų sistema) yra interneto telefonų knyga. Kad pasiektų proofconference.com, įrenginys pirmiausia turi paklausti DNS serverio, koks IP adresas slypi už šio vardo. Numatytasis serveris priklauso interneto paslaugų teikėjui, o klausimas dažnai keliauja nešifruotas, todėl dar prieš įkeliant puslapį teikėjas jau turi sąrašą visų vardų, kurių ieškojai.

**Šifruotas DNS** šiuos klausimus šifruotu kanalu siunčia į tavo pasirinktą serverį. Geri nemokami variantai yra „Quad9“ (Šveicarijos ne pelno organizacija, kuri dar ir blokuoja žinomas kenkėjiškas svetaines), „Mullvad DNS“ (paskyros nereikia, galima įsijungti reklamos blokavimą) ir „NextDNS“ (bendrovė, paslauga labai lanksčiai konfigūruojama, nemokama iki mėnesio limito). Tai nedidelis ir naudingas žingsnis, nors tinklas vis tiek mato IP adresus, prie kurių jungiesi.

## Ką VPN daro ir ko nedaro

**VPN** (virtualusis privatusis tinklas) sukuria šifruotą tunelį nuo tavo įrenginio iki VPN bendrovės valdomo serverio, ir juo keliauja visas duomenų srautas, taip pat ir DNS užklausos. Interneto paslaugų teikėjas ar kavinės belaidis tinklas mato tik tai, kad naudojiesi VPN, o svetainės mato VPN serverio adresą.

Dabar VPN bendrovė mato tai, ką anksčiau matė teikėjas, taigi VPN perkelia pasitikėjimą iš bendrovės, kurios nesirinkai, į tą, kurią pasirinkai. Anonimiškumo jis irgi nesuteikia, nes slapukai ir atpažinimas pagal naršyklės skaitmeninį atspaudą (angl. fingerprinting, žr. 3 skyrių) veikia toliau, o „Google“ ar „Facebook“ žino, kas esi, vos tik prisijungi.

**Tor** tinkle vienintelės bendrovės, kuria tenka pasitikėti, nebelieka, nes duomenų srautas siunčiamas per 3 retransliatorius (angl. relays), kuriuos valdo nepriklausomi savanoriai. Pirmasis žino, kas esi, bet nežino, kur jungiesi, paskutinis, atvirkščiai, žino tik tai, kur jungiesi, ir nė vienas retransliatorius nemato abiejų galų. **Maišymo tinklas** taip pat naudoja kelis šuolius, tavo duomenų paketus sumaišo su kitų naudotojų paketais, juos pavėlina ir prideda netikro, „priedangos“, srauto. Taip siekiama, kad net viso tinklo stebėtojui būtų daug sunkiau susieti tai, kas įeina, su tuo, kas išeina. Maišymo tinklas lėtesnis už Tor tinklą ir praktikoje mažiau išbandytas.

## Pažadui nekaupti veiklos įrašų reikia įrodymų

Kai naudojiesi VPN, tai, ar liks konfidencialu, kur jungiesi, priklauso nuo 1 bendrovės, kuri galėtų registruoti tavo ryšius, būti įpareigota tai daryti arba nukentėti nuo įsilaužimo. Veiklos įrašų nekaupimo politika (angl. no-logs policy) yra pažadas, o jį paremia 2 rūšių įrodymai. Pirmieji yra auditai, pavyzdžiui, [veiklos įrašų nekaupimo auditas, kurį bendrovė „Securitum“ nuo 2022 m. kasmet atlieka paslaugoje „Proton VPN“](https://protonvpn.com/blog/no-logs-audit), arba [saugumo auditas, kurį „IVPN“ užsakymu kasmet atlieka bendrovė „Cure53“](https://www.ivpn.net/blog/annual-security-audit-scheduled-2026). Antrieji yra atvejai, kai įsikiša teisėsauga ar teismai. 2023 m. balandžio 18 d. Švedijos policija [su kratos orderiu atvyko į „Mullvad“ biurą Geteborge](https://mullvad.net/en/blog/2023/4/20/mullvad-vpn-was-subject-to-a-search-warrant-customer-data-not-compromised) ir, pasak bendrovės, išvyko be klientų duomenų, nes jų nebuvo. Ir vieni, ir kiti įrodymai tėra momentinės nuotraukos, ir nė vieni nerodo, ką serveris registruoja šiandien.

**Kelių šuolių režimas** (angl. multi-hop), kurį siūlo keli VPN, sujungia 2 serverius į grandinę, kad serveris, į kurį įsilaužta, žinotų mažiau, tačiau kai abu priklauso tai pačiai bendrovei, pasitikėjimas niekur nepersikelia. Pasitikėjimui decentralizuoti reikia nepriklausomų operatorių, tokių kaip savanoriai, valdantys 3 Tor retransliatorius, arba nepriklausomi „NymVPN“ serverių operatoriai. Vis dėlto decentralizuota nereiškia patikrinta, nes niekas neaudituoja kiekvieno retransliatoriaus ar operatoriaus, o apsauga remiasi maža tikimybe, kad jie veiks išvien. Programinės įrangos leidėju tenka pasitikėti ir toliau, o už visa tai moki greičiu.

## Kaip pasirinkti tinklo apsaugą

Visų toliau išvardytų variantų programėlės yra atvirojo kodo, o kiekviena iš 4 VPN bendrovių paskelbė bent 1 nepriklausomą saugumo auditą. Skiriasi tai, kuo tenka pasitikėti, greitis ir mokėjimo būdai. Kainos ir mokėjimo būdai patikrinti oficialiose svetainėse 2026 m. rugsėjį.

| Įrankis | Kas jį valdo | Kas mato tavo duomenų srautą | Mokėjimas | Kompromisai |
|---|---|---|---|---|
| **Mullvad VPN** | Viena bendrovė, Švedija | Bendrovė „Mullvad“ mato tavo IP adresą ir tai, kur jungiesi. Jos įrodymai yra keli auditai ir 2023 m. policijos krata, per kurią nieko nepaimta. | Fiksuota 5 eurų per mėnesį kaina. Kortelė, „PayPal“, banko pavedimas, paštu siunčiami grynieji pinigai, bitkoinai (taip pat ir per Lightning tinklą), Monero | El. pašto nereikia, paskyra yra atsitiktinis skaičius. Veikia greitai, audituota. Nemokamo plano nėra. |
| **IVPN** | Viena bendrovė, Gibraltaras | Bendrovė „IVPN“ mato tavo IP adresą ir tai, kur jungiesi. Jos įrodymai yra 2019 m. veiklos įrašų nekaupimo auditas, o vėliau kasmetiniai saugumo auditai. | Mokama. Kortelė, „PayPal“, grynieji pinigai, bitkoinai (taip pat ir per Lightning tinklą), Monero | El. pašto nereikia. Audituojama kasmet, apie savo ribas kalba labai atvirai. Serverių tinklas mažesnis. |
| **Proton VPN** | Viena bendrovė, Šveicarija | Bendrovė „Proton“ mato tavo IP adresą ir tai, kur jungiesi. Jos įrodymas yra kasmetinis veiklos įrašų nekaupimo auditas, kurį nuo 2022 m. atlieka bendrovė „Securitum“. | Nemokamas planas be duomenų limito 1 įrenginyje, mokami planai. Kortelė, „PayPal“, banko pavedimas, grynieji pinigai, bitkoinai (tik iš jau turimos paskyros) | Audituota. Nemokamas planas sąžiningas, bet lėtesnis, o šalių jame nedaug. Paskyrai reikia el. pašto adreso. |
| **NymVPN** | „Nym“, Šveicarija. Serverius valdo nepriklausomi operatoriai | Įėjimo operatorius mato tavo IP adresą, o išėjimo operatorius tai, kur jungiesi. Programėlę leidžia bendrovė „Nym“. Operatoriai neaudituojami. | Mokama. Kortelė, paštu siunčiami grynieji pinigai, bitkoinai (taip pat ir per Lightning tinklą), Monero ir kitos kriptovaliutos | El. pašto nereikia, paskyra yra 24 žodžių frazė. Audituota 2024 m. Yra greitas 2 šuolių režimas ir daug lėtesnis 5 šuolių maišymo tinklo režimas. Jaunesnis produktas, kurio istorija trumpesnė. PROOF pranešėjas Alexis Roussel yra „Nym“ veiklos vadovas (COO). |
| **Tor Browser / Orbot** | Ne pelno organizacija ir tūkstančiai savanorių valdomų retransliatorių | Įėjimo retransliatorius mato tavo IP adresą, o išėjimo retransliatorius tai, kur jungiesi. Nė vienas retransliatorius nemato abiejų dalykų. Retransliatoriai neaudituojami. | Nemokama | Stipriausia IP adreso apsauga naršant. Veikia lėtai, o kai kurios svetainės Tor tinklą blokuoja arba rodo begalines patikros užduotis. Programėlė „Orbot“ per Tor tinklą siunčia telefono programėlių duomenų srautą. |

Jei tau reikia VPN, rinkis šio sąrašo operatorių, kurio kompromisai tau tinka. Gali rinktis ir patikimo teikėjo nemokamą planą, jei jo pakanka tavo poreikiams. **Naršyklę „Tor Browser“** pasilik tam naršymui, kurį nori atskirti nuo įprasto ryšio ir paskyrų, tačiau anonimiškumo ji negarantuoja.

Su „nemokamo VPN“ programėlėmis verta elgtis atsargiai, nes serverių išlaikymas kainuoja, o nemokančių naudotojų duomenų srautas dažnai pats tampa preke, iš kurios uždirbama per reklamą, sekimą ar duomenų perpardavimą. Taip pat atsargiai verta vertinti ir „geriausių VPN“ reitingų svetaines. Dauguma jų gauna komisinį atlygį už kiekvieną parduotą prenumeratą, o kai kurios priklauso toms pačioms įmonių grupėms kaip ir jų vertinami VPN. 2021 m. kovą bendrovė „Kape Technologies“ [už 149,1 mln. dolerių nusipirko bendrovę „Webselenese“, apžvalgų svetainių „vpnMentor“ ir „Wizcase“ leidėją](https://en.globes.co.il/en/article-kape-acquires-israeli-co-webselenese-for-149m-1001363243), o svetainė „vpnMentor“ [pati nurodo](https://www.vpnmentor.com/about-us/), kad bendrovei „Kape“ priklauso ir VPN paslaugos „ExpressVPN“, „CyberGhost“ bei „Private Internet Access“.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta paslauga „Mullvad“, o su kitomis logika ta pati.

1. **Įdiek programėlę** iš oficialios teikėjo svetainės arba iš oficialios programėlių parduotuvės, bet niekada per nuorodą reklamoje.
2. **Susikurk paskyrą.** Paslauga „Mullvad“ duoda paskyros numerį ir daugiau nieko neprašo. Išsaugok jį slaptažodžių tvarkyklėje, o tada tau patogiu mokėjimo būdu nusipirk naudojimosi laiko.
3. **Prisijunk.** Kad greitis būtų didžiausias, pasirink serverį savo arba kaimyninėje šalyje. Tolima šalis praverčia tik tada, kai reikia, kad atrodytų, jog esi ten.
4. **Įjunk avarinį išjungiklį (angl. kill switch).** Šis nustatymas užblokuoja visą duomenų srautą, jei tunelis nutrūksta, kad niekas neiškeliautų už tunelio ribų. Programėlėje „Mullvad“ jis veikia visada, o kompiuteriuose papildomas „Lockdown mode“ (užrakinimo režimas) blokuoja internetą ir tada, kai atsijungi tyčia. Kitose programėlėse nustatymuose ieškok „kill switch“. „Android“ sistemos VPN nustatymuose taip pat yra „Always-on VPN“ (visada įjungtas VPN) ir „Block connections without VPN“ (blokuoti ryšius be VPN).
5. **Prisijunk automatiškai.** Nustatymuose pasirink, kad programėlė pasileistų įjungus įrenginį ir jungtųsi automatiškai. Kai kuriose programėlėse, pavyzdžiui, „IVPN“ ir „Proton VPN“, namų belaidį tinklą galima pažymėti kaip patikimą, o visuose kituose tinkluose jungtis automatiškai.
6. **Nustatyk šifruotą DNS toms akimirkoms, kai VPN išjungtas.** „Android“ sistemos tinklo nustatymuose susirask „Private DNS“ (privatus DNS) ir įrašyk pasirinktos paslaugos serverio vardą, pavyzdžiui, dns.quad9.net. „iPhone“ telefonams ir kompiuteriams pasirinkta paslauga duoda profilį arba programėlę, kurią reikia įdiegti. Naršyklės privatumo nustatymuose įjunk „saugų DNS“ (angl. secure DNS).
7. **Patikrink, ar nėra nutekėjimų.** Kai VPN įjungtas, atverk mullvad.net/check arba dnsleaktest.com. Rodomas IP adresas turi priklausyti VPN. Rodomi DNS serveriai priklauso arba VPN, arba, jei tame įrenginyje ar naršyklėje atliktas 6 žingsnis, tavo pasirinktai šifruoto DNS paslaugai (pavyzdžiui, „Quad9“), kurios užklausos tada keliauja tunelio viduje. Abu rezultatai geri. Nutekėjimas yra tada, kai pasirodo tavo interneto paslaugų teikėjo pavadinimas. Būtent šiuo žingsniu pasitikėjimą pakeiti patikrinimu, bent jau dėl to, kas iškeliauja iš tavo įrenginio, nors joks toks testas neparodo, ką registruoja paties VPN serveriai.

## Klaidos, kurių verta vengti

- **Tikėti, kad VPN suteikia anonimiškumą.** Jis paslepia IP adresą nuo svetainių, o duomenų srautą nuo teikėjo, tačiau slapukai, skaitmeninis atspaudas ir prisijungimai prie paskyrų tave vis tiek identifikuoja.
- **Rinktis VPN todėl, kad jis nemokamas arba kad taip patarė reitingų svetainė.** Ieškok atvirojo kodo programėlių, nepriklausomų auditų, aiškaus savininko ir paprasto mokamo verslo modelio.
- **Palikti avarinį išjungiklį išjungtą.** Tuneliai nutrūksta, ypač kai telefonas persijungia tarp belaidžio tinklo ir mobiliųjų duomenų, o be avarinio išjungiklio duomenų srautas tyliai grįžta į įprastą kelią.
- **Naršyklėje „Tor Browser“ jungtis prie asmeninių paskyrų.** Kai prisijungi, svetainė žino, kas esi, ir papildomi šuoliai nuo jos tavęs nebeslepia.
- **Manyti, kad spynelė reiškia, jog svetainė sąžininga.** HTTPS apsaugo ryšį, o spynelę gali turėti ir sukčiavimo apsimetant (angl. phishing) svetainė.
- **Pamiršti, kad taisyklės galioja ir toliau.** Europos Sąjungoje VPN yra teisėtas privatumo įrankis, o tai, kas neteisėta be jo, neteisėta ir su juo. Kai kurios ne ES šalys VPN naudojimą riboja, todėl prieš kelionę pasidomėk vietos taisyklėmis.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kaip „kareivis-pilietis“ gali padėti decentralizuoti pasaulį: Rusijos invazijos į Ukrainą pamokos“, pranešimą skaito Alexis Roussel. Pranešimas apie tai, kodėl daugelio nepriklausomų žmonių valdomi tinklai atsilaiko geriau nei tie, kuriuos valdo vienas.
- **Palygink VPN be apmokėtų reitingų:** „Privacy Guides“, „VPN Services“ ir „DNS Resolvers“ (privacyguides.org).
- **Suprask, kas yra Tor, ir atsisiųsk jį:** „Tor Project“ (torproject.org). „iPhone“ telefonams oficialios naršyklės „Tor Browser“ nėra, todėl jiems „Tor Project“ [rekomenduoja naršyklę „Onion Browser“](https://support.torproject.org/tor-browser/getting-started/installing/#ios), kurios apsauga silpnesnė nei kompiuteryje.
- **Kaip pasirinkti tavo situacijai tinkamą VPN:** „Surveillance Self-Defense“ (ssd.eff.org).
- **Kitas skyrius:** prasideda 2 dalis, o pirmasis jos skyrius yra „Raktai vietoj paskyrų“.

## Šaltiniai

- [Firefox DNS over HTTPS, including ECH](https://support.mozilla.org/en-US/kb/firefox-dns-over-https), „Mozilla Support“, tikrinta 2026 m. spalio 22 d.
- [Press release No 54/14: The Court of Justice declares the Data Retention Directive to be invalid](https://curia.europa.eu/site/upload/docs/application/pdf/2014-04/cp140054en.pdf), Europos Sąjungos Teisingumo Teismas, 2014 m. balandžio 8 d.
- [Kape acquires Israeli co Webselenese for $149m](https://en.globes.co.il/en/article-kape-acquires-israeli-co-webselenese-for-149m-1001363243), „Globes“, 2021 m. kovo 8 d.
- [About us (ownership disclosure)](https://www.vpnmentor.com/about-us/), „vpnMentor“, žiūrėta 2026 m. rugsėjį.
- [Proton VPN passes 5th annual external audit of no-logs policy](https://protonvpn.com/blog/no-logs-audit), „Proton VPN“, atnaujinta 2026 m. birželio 16 d.
- [Mullvad VPN was subject to a search warrant. Customer data not compromised](https://mullvad.net/en/blog/2023/4/20/mullvad-vpn-was-subject-to-a-search-warrant-customer-data-not-compromised), „Mullvad VPN“, 2023 m. balandžio 20 d.
- [Annual security audit scheduled for 2026](https://www.ivpn.net/blog/annual-security-audit-scheduled-2026), „IVPN“, 2026 m. birželio 19 d.
- [Nym response to Cure53 security audit](https://nym.com/trust-center/Cure53-security-audit-2024), „Nym“, 2024 m. liepos mėn.
- [Lightning payments](https://mullvad.net/en/blog/2025/8/5/lightning-payments), „Mullvad VPN“, 2025 m. rugpjūčio 5 d.
- [Installing Tor Browser (iOS section)](https://support.torproject.org/tor-browser/getting-started/installing/#ios), „Tor Project“, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Įjunk šifruotą DNS telefone ir naršyklėje (5 min.)
- [ ] Pasirink ir įdiek patikimo operatoriaus VPN (1 val.)
- [ ] Įjunk avarinį išjungiklį ir automatinį prisijungimą, tada patikrink, ar nėra nutekėjimų (5 min.)
- [ ] Įdiek naršyklę „Tor Browser“ ir vieną kartą ją išbandyk (5 min.)
- [ ] Pašalink VPN programėles, kurių operatoriumi ar privatumo praktika negali pasitikėti (5 min.)
