#!/usr/bin/env python3
"""Import the English PROOF sources of A Guide to Autonomy into this local edition.

Reads an explicit allowlist of 23 Markdown files from the PROOF book drafts
(18 chapters, the introduction, 3 part openings and the glossary), removes a
short and recorded list of promotional fragments, renders the rest with
Python-Markdown and writes dist/content.js and import-report.json. The source
folder is only read. Every output stays inside this project folder.

The sources are the English Markdown files of book-drafts, the parent folder of
this project (book-drafts/guide-ui). load_book() does the whole import without
writing anything; build_integration.py uses it for the pages of the PROOF site.

From the project folder:

    python3 scripts/import_book.py
    python3 scripts/import_book.py --source-dir /path/to/book-drafts
    python3 scripts/import_book.py --out-dir build-check --report build-check/import-report.json
    python3 scripts/import_book.py --legacy-file build-check/legacy-actions.json
    python3 scripts/import_book.py --update-registry

Checklist actions get their IDs from scripts/action-registry.json, matched on
their text, never on their position. When a checklist changes, the import
stops and explains what to do, unless --update-registry is given.

The Lithuanian sources (book-drafts/lt/, same file names) are imported the
same way with load_book(..., lang='lt'): titles, filter and allowlist from
scripts/lt_sources.py, IDs from scripts/action-registry-lt.json (the same 90
IDs as English, so a tick counts in both editions). That registry is never
updated automatically: an unknown Lithuanian action stops the import.

    python3 scripts/import_book.py --lang lt      check the Lithuanian import, write nothing
"""

import argparse
import hashlib
import html
import json
import re
import sys
import unicodedata
from pathlib import Path

try:
    import markdown
except ImportError:
    sys.exit('Python-Markdown is missing: python3 -m pip install -r scripts/requirements.txt')

GENERATOR = 'scripts/import_book.py'
PROJECT = Path(__file__).resolve().parent.parent
# This project lives in book-drafts/guide-ui: the English sources are in the parent folder.
DEFAULT_SOURCE = PROJECT.parent
REGISTRY = PROJECT / 'scripts' / 'action-registry.json'

sys.path.insert(0, str(PROJECT / 'scripts'))
import lt_sources  # noqa: E402  Lithuanian allowlist, titles, filter

REGISTRY_LT = PROJECT / 'scripts' / lt_sources.REGISTRY_NAME

# sane_lists is also used by the original PROOF build. It keeps the start
# number of ordered lists, so the part openings list chapters 6 to 11 and 12 to
# 18 with their real numbers. The 3 chapters of the earlier preview render the
# same with or without it.
EXTENSIONS = ['tables', 'toc', 'fenced_code', 'sane_lists']

CHAPTERS = [
    # source file, number, id (route and storage), part, title after "Chapter N: "
    ('11-messages.md', 1, 'messages', 1, 'Your messages'),
    ('12-passwords.md', 2, 'passwords', 1, 'Your passwords and your accounts'),
    ('13-browser.md', 3, 'browser', 1, 'Your browser and your searches'),
    ('14-email.md', 4, 'email', 1, 'Your email and your aliases'),
    ('15-network.md', 5, 'network', 1, 'Your network'),
    ('21-keys.md', 6, 'keys', 2, 'Keys instead of accounts'),
    ('22-nostr.md', 7, 'nostr', 2, 'Nostr: an open network without a company in charge'),
    ('23-big-tech.md', 8, 'big-tech', 2, 'Replacing Big Tech services, one at a time'),
    ('24-phone.md', 9, 'phone', 2, 'Taking back control of your phone'),
    ('25-self-hosting.md', 10, 'self-hosting', 2, 'Hosting your own services'),
    ('26-ai.md', 11, 'ai', 2, 'AI without giving yourself away'),
    ('31-savings.md', 12, 'savings', 3, 'Where to keep the fruit of your work'),
    ('32-first-wallet.md', 13, 'first-wallet', 3, 'Your first wallet and your first sats'),
    ('33-seed.md', 14, 'seed', 3, 'Backing up your seed phrase'),
    ('34-lightning-and-euros.md', 15, 'lightning-and-euros', 3, 'Lightning and euros in everyday life'),
    ('35-bitcoin-privacy.md', 16, 'bitcoin-privacy', 3, 'Privacy in Bitcoin'),
    ('36-hardware-wallet.md', 17, 'hardware-wallet', 3, 'Hardware wallets'),
    ('37-node.md', 18, 'node', 3, 'Running your own node'),
]

PAGES = [
    # source file, id (route), kind, part, expected H1, title shown
    ('00-introduction.md', 'introduction', 'introduction', None, 'Introduction', 'Introduction'),
    ('10-part1-privacy.md', 'part-1', 'part', 1, 'Part 1: Proof of Privacy', 'Proof of Privacy'),
    ('20-part2-autonomy.md', 'part-2', 'part', 2, 'Part 2: Proof of Autonomy', 'Proof of Autonomy'),
    ('30-part3-work.md', 'part-3', 'part', 3, 'Part 3: Proof of Work', 'Proof of Work'),
    ('90-glossary.md', 'glossary', 'glossary', None, 'Glossary', 'Glossary'),
]

ACTIONS_PER_CHAPTER = 5

# Every "Go further" list opens with 1 line promoting a conference talk.
AT_PROOF_PREFIX = '- **At PROOF:**'

# Sentences or clauses that promote the sponsor or a talk. Each must be found
# exactly once in its file. Straight and typographic quotes are both accepted.
FRAGMENTS = [
    {
        'rule': 'intro-sponsor-and-speakers',
        'file': '00-introduction.md',
        'text': ' The conference has a single sponsor, Bringin, and whenever it appears in these pages it is named as the sponsor and shown among other options. The same goes for any tool connected to a speaker.',
        'reason': 'Sponsor and speaker notice. The first sentence of the paragraph, on tools never paid to be listed, is kept.',
    },
    {
        'rule': 'first-wallet-sponsor',
        'file': '32-first-wallet.md',
        'text': ' Bringin sponsors this conference.',
        'reason': 'Sponsor notice in the Bringin row. The row, its comparison and its limits are kept.',
    },
    {
        'rule': 'lightning-sponsor',
        'file': '34-lightning-and-euros.md',
        'text': '; Bringin sponsors this conference',
        'reason': 'Sponsor notice inside the parentheses of the Bringin route. The comparison and its sources are kept.',
    },
    {
        'rule': 'part3-money-talk',
        'file': '30-part3-work.md',
        'text': ', which Piktas takes further at PROOF in "Why Centralized Money Fails: How Bitcoin Became an Alternative"',
        'reason': 'Talk promotion clause. The economic explanation and its full stop are kept.',
    },
    {
        'rule': 'part3-cbdc-talk',
        'file': '30-part3-work.md',
        'text': ' Linas K. covers the subject at PROOF in "CBDCs, KYC, and the Fight for Monetary Privacy".',
        'reason': 'Talk promotion sentence. The sourced CBDC context before it is kept.',
    },
]

# Mentions left in the text on purpose, listed in the report for review.
MENTION = re.compile(r'PROOF|Bringin|[Cc]onference|[Ss]peaker')

TAG = re.compile(r'<[^>]+>')
EFFORT = re.compile(r'\s*\(([^()<>]+)\)\s*$')  # same rule as app.js
CHECK_MD = re.compile(r'^- \[ \] ', re.M)
CHECK_LI = re.compile(r'<li>\[ \] (.*?)</li>')
H1_HTML = re.compile(r'<h1 id="[^"]*">.*?</h1>\n?')
QUOTES = str.maketrans({'‘': "'", '’': "'", '“': '"', '”': '"', '„': '"'})
STOPWORDS = {'a', 'an', 'the', 'and', 'or', 'of', 'to', 'on', 'in', 'at', 'for', 'with', 'from',
             'by', 'it', 'its', 'is', 'that', 'this', 'your', 'you', 'any', 'every', 'then'}


class ImportFailure(Exception):
    pass


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def plain(fragment):
    """Text of an HTML fragment, entities decoded, spaces collapsed."""
    return ' '.join(html.unescape(TAG.sub('', fragment)).split())


def normalize(text):
    """Identity of an action: what a reader reads, without markup or typography."""
    text = unicodedata.normalize('NFKC', plain(text)).translate(QUOTES)
    return ' '.join(text.casefold().split())


def split_effort(fragment):
    m = EFFORT.search(fragment)
    return (fragment[:m.start()], m.group(1).strip()) if m else (fragment, '')


def quote_tolerant(text):
    out = []
    for ch in text:
        if ch == "'":
            out.append("['’]")
        elif ch == '"':
            out.append('["“”]')
        else:
            out.append(re.escape(ch))
    return ''.join(out)


def confined(path, source_dir, what):
    p = Path(path).expanduser()
    p = (p if p.is_absolute() else PROJECT / p).resolve()
    try:
        p.relative_to(PROJECT)
    except ValueError:
        raise ImportFailure('%s must stay inside the project folder %s: %s' % (what, PROJECT, p))
    try:
        p.relative_to(source_dir)
    except ValueError:
        return p
    # The project folder is a subfolder of the sources (book-drafts/guide-ui): an output inside it
    # can never overwrite one of the Markdown sources, which sit at the top of the source folder.
    if source_dir in PROJECT.parents:
        return p
    raise ImportFailure('%s must not be inside the source folder: %s' % (what, p))


def filter_source(name, text, is_chapter, fragments=None, at_proof_prefix=None, mention=None):
    """Apply the exclusion rules. Returns the kept text, the exclusions and the retained mentions.
    The rules default to the English ones; load_book() passes the Lithuanian ones for lang='lt'."""
    fragments = FRAGMENTS if fragments is None else fragments
    at_proof_prefix = at_proof_prefix or AT_PROOF_PREFIX
    mention = mention or MENTION
    exclusions = []
    for rule in (r for r in fragments if r['file'] == name):
        found = list(re.finditer(quote_tolerant(rule['text']), text))
        if len(found) != 1:
            raise ImportFailure('%s: rule %s expected 1 match, found %d. Check the source before importing.'
                                % (name, rule['rule'], len(found)))
        m = found[0]
        exclusions.append({
            'rule': rule['rule'], 'file': name, 'line': text.count('\n', 0, m.start()) + 1,
            'removed': m.group(0), 'reason': rule['reason'],
        })
        text = text[:m.start()] + text[m.end():]

    kept = []
    for no, line in enumerate(text.split('\n'), 1):
        if line.startswith(at_proof_prefix):
            exclusions.append({
                'rule': 'go-further-at-proof', 'file': name, 'line': no, 'removed': line,
                'reason': 'Conference talk listed in "Go further". The other resources of the list are kept.',
            })
        else:
            kept.append((no, line))
    at_proof = sum(1 for e in exclusions if e['rule'] == 'go-further-at-proof')
    if at_proof != (1 if is_chapter else 0):
        raise ImportFailure('%s: expected %d "At PROOF" line, found %d.' % (name, 1 if is_chapter else 0, at_proof))

    mentions = []
    for no, line in kept:
        for m in mention.finditer(line):
            start = max(0, m.start() - 70)
            mentions.append({'file': name, 'line': no, 'term': m.group(0),
                             'excerpt': line[start:m.end() + 70].strip()})
    exclusions.sort(key=lambda e: (e['line'], e['rule']))
    return '\n'.join(line for _, line in kept), exclusions, mentions


def render(name, text, expected_h1):
    first = text.lstrip('\n').split('\n', 1)[0]
    if first != '# ' + expected_h1:
        raise ImportFailure('%s: expected the title "# %s", found "%s".' % (name, expected_h1, first))
    md = markdown.Markdown(extensions=EXTENSIONS)
    body = md.convert(text)
    m = H1_HTML.match(body)
    if not m:
        raise ImportFailure('%s: the rendered page does not start with its title.' % name)
    body = body[m.end():]
    if '<h1' in body:
        raise ImportFailure('%s: only 1 top-level title is expected.' % name)
    tokens = md.toc_tokens
    if len(tokens) != 1 or tokens[0]['level'] != 1:
        raise ImportFailure('%s: unexpected heading structure.' % name)
    return body, tokens[0]['children']


def heading_ids(tokens):
    out = []
    for t in tokens:
        out.append(t['id'])
        out.extend(heading_ids(t['children']))
    return out


def checklist(name, text, body, expected, checklist_id='your-checklist', efforts=None):
    md_count = len(CHECK_MD.findall(text))
    items = CHECK_LI.findall(body)
    if md_count != expected or len(items) != expected:
        raise ImportFailure('%s: expected %d checklist actions, found %d in the source and %d rendered.'
                            % (name, expected, md_count, len(items)))
    if items:
        head = body.find('<h2 id="%s">' % checklist_id)
        if head == -1 or body.find('<li>[ ] ') < head:
            raise ImportFailure('%s: checklist actions found outside the checklist section (#%s).' % (name, checklist_id))
    out = []
    for item in items:
        text_html, effort = split_effort(item)
        if efforts is not None and effort not in efforts:
            raise ImportFailure('%s: effort tag "(%s)" of "%s" is not one of %s.'
                                % (name, effort, plain(text_html), ', '.join('(%s)' % e for e in efforts)))
        out.append({'html': item, 'text': plain(text_html), 'effort': effort})
    return out


def mint_id(chapter, text, taken):
    words = [w for w in re.findall(r'[a-z0-9]+', normalize(text)) if w not in STOPWORDS][:4]
    base = '-'.join([chapter] + (words or ['action']))
    new, k = base, 2
    while new in taken:
        new, k = '%s-%d' % (base, k), k + 1
    return new


def load_registry(path=None):
    path = Path(path) if path else REGISTRY
    data = json.loads(path.read_text(encoding='utf-8'))
    entries = data.get('actions', [])
    seen_ids, seen_keys = set(), set()
    for e in entries:
        if e['id'] in seen_ids:
            raise ImportFailure('Registry: ID %s is listed twice.' % e['id'])
        seen_ids.add(e['id'])
        key = (e['chapter'], normalize(e['text']))
        if key in seen_keys:
            raise ImportFailure('Registry: 2 entries of %s have the same text: %s' % (e['chapter'], e['text']))
        seen_keys.add(key)
        known_texts = {normalize(t) for t in [e['text']] + e.get('previous_texts', [])}
        if 'legacy_html' in e and normalize(split_effort(e['legacy_html'])[0]) not in known_texts:
            raise ImportFailure('Registry: the text of %s no longer matches its legacy HTML or explicit previous texts.' % e['id'])
        # Lithuanian registry: the label of the former page must stay the current text or an explicit previous text.
        if 'legacy_text' in e and normalize(e['legacy_text']) not in known_texts:
            raise ImportFailure('Registry %s: the text of %s no longer matches its former label "%s" or explicit previous texts.'
                                % (path.name, e['id'], e['legacy_text']))
    return data, entries


def assign_ids(chapter_actions, entries, update, registry_name=None):
    """Match each action to a registry entry of its chapter, by normalized text."""
    taken = {e['id'] for e in entries}
    added, retired, problems = [], [], []
    for cid, actions in chapter_actions:
        pool = {normalize(e['text']): e for e in entries if e['chapter'] == cid}
        keys = [normalize(a['text']) for a in actions]
        if len(set(keys)) != len(keys):
            raise ImportFailure('%s: 2 checklist actions have the same text.' % cid)
        matched = set()
        for a, key in zip(actions, keys):
            e = pool.get(key)
            if e is not None and not e.get('retired'):
                a['id'], a['origin'] = e['id'], e['origin']
                matched.add(e['id'])
            elif e is not None and update:
                e.pop('retired', None)
                a['id'], a['origin'] = e['id'], e['origin']
                matched.add(e['id'])
                added.append({'id': e['id'], 'chapter': cid, 'text': a['text'], 'reactivated': True})
            elif update:
                new = {'id': mint_id(cid, a['text'], taken), 'chapter': cid, 'text': a['text'],
                       'origin': 'added-by-importer'}
                taken.add(new['id'])
                entries.append(new)
                a['id'], a['origin'] = new['id'], new['origin']
                matched.add(new['id'])
                added.append({'id': new['id'], 'chapter': cid, 'text': a['text']})
            else:
                problems.append('%s: no registry entry for "%s"%s.'
                                % (cid, a['text'], ' (its entry is retired)' if e is not None else ''))
        for e in entries:
            if e['chapter'] == cid and not e.get('retired') and e['id'] not in matched:
                if update:
                    e['retired'] = True
                    retired.append({'id': e['id'], 'chapter': cid, 'text': e['text']})
                else:
                    problems.append('%s: registry entry %s is not in the checklist any more: "%s".'
                                    % (cid, e['id'], e['text']))
    if problems and registry_name:
        # Lithuanian: never minted nor retired here, an unknown label always stops (fail closed).
        raise ImportFailure('The checklists no longer match %s:\n  - ' % registry_name
                            + '\n  - '.join(problems)
                            + '\nIf a translated action was only reworded, put its new wording in "text" and move the '
                              'former one to "previous_texts" of the entry with the same ID as its English action. '
                              'Never map by position.')
    if problems:
        raise ImportFailure('The checklists no longer match scripts/action-registry.json:\n  - '
                            + '\n  - '.join(problems)
                            + '\nIf an action was only reworded, update its "text" in the registry to keep its ID '
                              'and the ticks saved under it. If it is really new or removed, run again with '
                              '--update-registry: new actions get new IDs, removed ones are marked retired.')
    return added, retired


def write_registry(data, entries):
    head = {k: v for k, v in data.items() if k != 'actions'}
    lines = ['{']
    for k, v in head.items():
        lines.append('  %s: %s,' % (json.dumps(k), json.dumps(v, ensure_ascii=False)))
    lines.append('  "actions": [')
    lines.append(',\n'.join('    ' + json.dumps(e, ensure_ascii=False) for e in entries))
    lines.append('  ]')
    lines.append('}')
    with open(REGISTRY, 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(lines) + '\n')


def check_legacy(path, entries, chapter_actions):
    legacy = json.loads(Path(path).read_text(encoding='utf-8'))
    by_id = {e['id']: e for e in entries}
    produced = {a['id']: a for _, actions in chapter_actions for a in actions}
    results = []
    for item in legacy:
        e = by_id.get(item['id'])
        if e is None or e['chapter'] != item['chapter']:
            raise ImportFailure('Legacy ID %s is missing from the registry.' % item['id'])
        known_texts = {normalize(t) for t in [e['text']] + e.get('previous_texts', [])}
        if normalize(split_effort(item['html'])[0]) not in known_texts:
            raise ImportFailure('Legacy ID %s: the registry text and explicit previous texts differ from the legacy action.' % item['id'])
        a = produced.get(item['id'])
        if a is None:
            raise ImportFailure('Legacy ID %s is not given to any action of this import.' % item['id'])
        results.append({'id': item['id'], 'chapter': item['chapter'], 'html_identical': a['html'] == item['html']})
    return {'file': str(Path(path).resolve()), 'entries': len(legacy), 'all_preserved': True, 'actions': results}


def locale_rules(lang):
    """Allowlist, titles, filter and registry of one language."""
    if lang == 'en':
        return {'lang': 'en', 'subdir': '', 'chapters': CHAPTERS, 'pages': PAGES, 'chapter_h1': 'Chapter %d: %s',
                'fragments': FRAGMENTS, 'at_proof': AT_PROOF_PREFIX, 'mention': MENTION,
                'checklist_id': 'your-checklist', 'efforts': None, 'registry': REGISTRY}
    if lang == 'lt':
        L = lt_sources
        return {'lang': 'lt', 'subdir': L.SOURCE_SUBDIR, 'chapters': L.CHAPTERS, 'pages': L.PAGES,
                'chapter_h1': L.CHAPTER_H1, 'fragments': L.FRAGMENTS, 'at_proof': L.AT_PROOF_PREFIX,
                'mention': L.MENTION, 'checklist_id': L.CHECKLIST_ID, 'efforts': L.EFFORTS, 'registry': REGISTRY_LT}
    raise ImportFailure('Unknown language: %s' % lang)


def load_book(source_dir, update_registry=False, legacy_file=None, lang='en'):
    """Read, filter, render and check the 23 sources of one language. Writes nothing.

    source_dir is book-drafts: the English files are at its top, the Lithuanian
    ones in its lt/ folder. Chapters and pages keep their filtered Markdown
    under 'markdown' and their actions with their rendered HTML, for
    build_integration.py. The English registry is updated in memory only when
    update_registry is set; run() saves it. The Lithuanian registry never is."""
    rules = locale_rules(lang)
    if lang != 'en' and update_registry:
        raise ImportFailure('The %s registry is never updated automatically: map a new or reworded action by hand in '
                            'scripts/%s, with the same ID as its English action.' % (lang, rules['registry'].name))
    source_dir = Path(source_dir).expanduser().resolve()
    if not source_dir.is_dir():
        raise ImportFailure('Source folder not found: %s' % source_dir)
    files_dir = source_dir / rules['subdir'] if rules['subdir'] else source_dir
    if not files_dir.is_dir():
        raise ImportFailure('Source folder not found: %s' % files_dir)

    data, entries = load_registry(rules['registry'])
    sources, exclusions, mentions, headings = [], [], [], {}
    chapters, pages, chapter_actions = [], [], []

    def read(name):
        path = files_dir / name
        if not path.is_file():
            raise ImportFailure('Source file not found: %s' % path)
        raw = path.read_bytes()
        return raw, raw.decode('utf-8-sig').replace('\r\n', '\n')

    def filtered(name, text, is_chapter):
        return filter_source(name, text, is_chapter, rules['fragments'], rules['at_proof'], rules['mention'])

    for name, number, cid, part, title in rules['chapters']:
        raw, text = read(name)
        h1 = rules['chapter_h1'] % (number, title)
        kept, excl, ment = filtered(name, text, True)
        body, toc = render(name, kept, h1)
        actions = checklist(name, kept, body, ACTIONS_PER_CHAPTER, rules['checklist_id'], rules['efforts'])
        sources.append({'file': (rules['subdir'] + '/' if rules['subdir'] else '') + name, 'kind': 'chapter', 'id': cid,
                        'h1': h1, 'bytes': len(raw), 'sha256': sha256(raw)})
        exclusions += excl
        mentions += ment
        headings['chapter:' + cid] = heading_ids(toc)
        chapter_actions.append((cid, actions))
        chapters.append({'number': number, 'id': cid, 'title': title, 'part': part, 'available': True,
                         'source': name, 'html': body, 'headings': toc, 'actions': actions, 'markdown': kept})

    for name, pid, kind, part, h1, title in rules['pages']:
        raw, text = read(name)
        kept, excl, ment = filtered(name, text, False)
        body, toc = render(name, kept, h1)
        checklist(name, kept, body, 0, rules['checklist_id'])
        sources.append({'file': (rules['subdir'] + '/' if rules['subdir'] else '') + name, 'kind': kind, 'id': pid,
                        'h1': h1, 'bytes': len(raw), 'sha256': sha256(raw)})
        exclusions += excl
        mentions += ment
        headings['page:' + pid] = heading_ids(toc)
        pages.append({'id': pid, 'kind': kind, 'title': title, 'part': part, 'source': name,
                      'html': body, 'headings': toc, 'markdown': kept})

    rules_found = {e['rule'] for e in exclusions}
    missing = [r['rule'] for r in rules['fragments'] if r['rule'] not in rules_found]
    if missing:
        raise ImportFailure('Exclusion rules not applied: %s' % ', '.join(missing))

    added, retired = assign_ids(chapter_actions, entries, update_registry,
                                None if lang == 'en' else 'scripts/' + rules['registry'].name)
    ids = [a['id'] for _, actions in chapter_actions for a in actions]
    if len(set(ids)) != len(ids):
        raise ImportFailure('2 actions received the same ID.')
    legacy = check_legacy(legacy_file, entries, chapter_actions) if legacy_file else None

    return {'lang': lang, 'source_dir': source_dir, 'data': data, 'entries': entries, 'sources': sources,
            'exclusions': exclusions, 'mentions': mentions, 'headings': headings,
            'chapters': chapters, 'pages': pages, 'chapter_actions': chapter_actions,
            'ids': ids, 'added': added, 'retired': retired, 'legacy': legacy,
            'fragments': rules['fragments'], 'registry_file': rules['registry']}


def run(args):
    source_dir = Path(args.source_dir).expanduser().resolve()
    if not source_dir.is_dir():
        raise ImportFailure('Source folder not found: %s' % source_dir)
    if args.lang != 'en':
        # The local edition (dist/) stays English: a Lithuanian import is a check, nothing is written.
        book = load_book(source_dir, args.update_registry, None, args.lang)
        n_excl = sum(1 for e in book['exclusions'] if e['rule'] == 'go-further-at-proof')
        print('[%s] %d chapters, %d other pages, %d actions, %d excluded lines, %d excluded fragments, %d retained mentions'
              % (args.lang, len(book['chapters']), len(book['pages']), len(book['ids']), n_excl,
                 len(book['exclusions']) - n_excl, len(book['mentions'])))
        print('[%s] Every action matched %s by its text. Nothing was written.' % (args.lang, book['registry_file'].name))
        return
    out_dir = confined(args.out_dir, source_dir, 'Output folder')
    report_path = confined(args.report, source_dir, 'Report')

    book = load_book(source_dir, args.update_registry, args.legacy_file)
    data, entries = book['data'], book['entries']
    sources, exclusions, mentions, headings = book['sources'], book['exclusions'], book['mentions'], book['headings']
    chapter_actions, ids = book['chapter_actions'], book['ids']
    added, retired, legacy = book['added'], book['retired'], book['legacy']

    # content.js keeps its original shape: no Markdown, actions without their HTML.
    chapters = [dict({k: v for k, v in ch.items() if k != 'markdown'},
                     actions=[{'id': a['id'], 'text': a['text'], 'effort': a['effort']} for a in ch['actions']])
                for ch in book['chapters']]
    pages = [{k: v for k, v in p.items() if k != 'markdown'} for p in book['pages']]

    js = ('/* Generated by %s from the English PROOF sources. Do not edit by hand:\n'
          '   change the sources or scripts/action-registry.json, then run the importer again. */\n'
          'window.GUIDE_CONTENT = %s;\n'
          'window.GUIDE_PAGES = %s;\n') % (GENERATOR, json.dumps(chapters, ensure_ascii=True),
                                           json.dumps(pages, ensure_ascii=True))
    js_bytes = js.encode('utf-8')

    if args.update_registry and (added or retired):
        write_registry(data, entries)
    registry_bytes = REGISTRY.read_bytes()

    report = {
        'generator': GENERATOR,
        'python_markdown': markdown.__version__,
        'extensions': EXTENSIONS,
        'source_dir': str(source_dir),
        'content_js': {'bytes': len(js_bytes), 'sha256': sha256(js_bytes)},
        'counts': {
            'chapters': len(chapters),
            'supplemental_pages': len(pages),
            'source_files': len(sources),
            'actions': len(ids),
            'actions_per_chapter': {cid: len(a) for cid, a in chapter_actions},
            'readmarks': len(chapters),
            'legacy_ids_in_registry': sum(1 for e in entries if e.get('origin') == 'legacy-preview' and not e.get('retired')),
            'excluded_lines': sum(1 for e in exclusions if e['rule'] == 'go-further-at-proof'),
            'excluded_fragments': sum(1 for e in exclusions if e['rule'] != 'go-further-at-proof'),
            'retained_mentions': len(mentions),
        },
        'sources': sources,
        'exclusions': exclusions,
        'retained_mentions': mentions,
        'actions': [dict(chapter=cid, position=i + 1, id=a['id'], text=a['text'], effort=a['effort'],
                         origin=a['origin']) for cid, actions in chapter_actions for i, a in enumerate(actions)],
        'headings': headings,
        'registry': {'file': 'scripts/action-registry.json', 'sha256': sha256(registry_bytes),
                     'updated': bool(args.update_registry and (added or retired)),
                     'added': added, 'retired': retired},
        'legacy_check': legacy,
    }

    shell_path = out_dir / 'index.html'
    shell_before = shell_path.read_text(encoding='utf-8') if shell_path.is_file() else None
    shell_after = shell_before
    if shell_after is not None:
        for asset in ['content.js', 'config.js', 'app.js', 'styles.css']:
            asset_bytes = js_bytes if asset == 'content.js' else (out_dir / asset).read_bytes()
            version = sha256(asset_bytes)[:12]
            # Match only the existing local resource attribute, preserving its quotes.
            pattern = r'((?:src|href)=")' + re.escape(asset) + r'(?:\?[^"\s]*)?(")'
            shell_after, count = re.subn(pattern, lambda m: m[1] + asset + '?v=' + version + m[2], shell_after)
            if count != 1:
                raise ImportFailure('Expected 1 local resource reference for %s in %s.' % (asset, shell_path))

    out_dir.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_dir / 'content.js', 'wb') as f:
        f.write(js_bytes)
    with open(report_path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    if shell_after is not None and shell_after != shell_before:
        with open(shell_path, 'w', encoding='utf-8', newline='\n') as f:
            f.write(shell_after)

    c = report['counts']
    print('Wrote %s (%d bytes, sha256 %s)' % (out_dir / 'content.js', len(js_bytes), report['content_js']['sha256']))
    print('Wrote %s' % report_path)
    print('%d chapters, %d other pages, %d actions, %d excluded lines, %d excluded fragments, %d retained mentions'
          % (c['chapters'], c['supplemental_pages'], c['actions'], c['excluded_lines'],
             c['excluded_fragments'], c['retained_mentions']))
    if legacy:
        print('Legacy IDs preserved: %d of %d' % (len(legacy['actions']), legacy['entries']))
    if report['registry']['updated']:
        print('Registry updated: %d added, %d retired' % (len(added), len(retired)))
    if not markdown.__version__.startswith('3.9'):
        print('Note: Python-Markdown %s, the documented version is 3.9. The HTML may differ.' % markdown.__version__)


def main():
    p = argparse.ArgumentParser(description='Import the PROOF English sources into dist/content.js.')
    p.add_argument('--source-dir', default=str(DEFAULT_SOURCE),
                   help='folder of the PROOF Markdown sources, only read (default: %(default)s)')
    p.add_argument('--out-dir', default='dist',
                   help='folder for content.js, inside this project (default: %(default)s)')
    p.add_argument('--report', default='import-report.json',
                   help='path of the import report, inside this project (default: %(default)s)')
    p.add_argument('--legacy-file',
                   help='optional JSON list of earlier action IDs and HTML to check against the result')
    p.add_argument('--update-registry', action='store_true',
                   help='give new IDs to new actions and retire removed ones in scripts/action-registry.json')
    p.add_argument('--lang', choices=['en', 'lt'], default='en',
                   help='lt: check the Lithuanian sources (lt/) against scripts/action-registry-lt.json, write nothing')
    args = p.parse_args()
    try:
        run(args)
    except ImportFailure as e:
        sys.exit('Import stopped, nothing was written.\n' + str(e))


if __name__ == '__main__':
    main()
