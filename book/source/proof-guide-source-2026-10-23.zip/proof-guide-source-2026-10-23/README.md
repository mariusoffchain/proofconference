# A Guide to Autonomy, PROOF edition (EN/LT): source archive

This archive is the corresponding source of the English (`/book/en/`) and Lithuanian (`/book/`) pages of *A Guide to Autonomy* on proofconference.com, edition of 2026-10-22. It is offered as a file; there is no public repository for this edition.

Licences: book text and editorial wording under CC BY-SA 4.0 (`LICENSE-CONTENT`), code under AGPL-3.0-or-later (`LICENSE`), fonts under SIL OFL 1.1. Credits, modifications, third-party resources and the limits of these licences (names, logos, conference media) are in `NOTICE.txt`. Neither licence covers the rest of proofconference.com.

## Contents

| Path | Role |
|---|---|
| `book-drafts/NN-slug.md`, `book-drafts/lt/NN-slug.md` | The 46 Markdown sources (23 per language) |
| `book-drafts/build.py`, `book-drafts/site/build_site.py` | Default command; `build.py` calls the generator. Both are imported by it |
| `book-drafts/guide-ui/build_integration.py` | Generator: pages, interface files, legal page, service worker, sitemap entries, this archive |
| `book-drafts/guide-ui/scripts/` | Importer, Lithuanian filter, action registries, former checklist ID map, `requirements.txt` |
| `book-drafts/guide-ui/dist/`, `book-drafts/guide-ui/site/` | Browser script, styles, configuration, fonts, interface strings of both languages |
| `book-drafts/sw.template.js`, `links.json`, `lt/ui.json`, `site/content.json` | Service worker template, tool links, Lithuanian strings of the former renderer, talk recordings |
| `book-drafts/guide-ui/legal/` | Licences, notices, this README |
| `book-drafts/guide-ui/source_archive.py` | Writes this archive (explicit file list, deterministic) |
| `book-drafts/guide-ui/release.py` | Exports the generated guide files to a new folder, with a hashed manifest |
| `index.html`, `en/index.html`, `book/index.html`, `book/sw.js`, `sitemap.xml`, `favicon.svg`, `replays.js`, `book/book.js`, `book/book.css` | Bootstrap: placeholders of host site files the generator checks or reads. They are not part of the guide |
| `SHA256SUMS.txt` | SHA-256 of every other file |

## Rebuild

Python 3 and Python-Markdown 3.9. No Node, no network after the installation. The folder that contains `book-drafts` is the site folder: the build writes there.

```sh
unzip proof-guide-source-2026-10-22.zip
cd proof-guide-source-2026-10-22
shasum -a 256 -c SHA256SUMS.txt                  # or: sha256sum -c SHA256SUMS.txt
python3 -m venv ../proof-guide-venv              # outside the site folder
../proof-guide-venv/bin/python -m pip install -r book-drafts/guide-ui/scripts/requirements.txt
cd book-drafts
../../proof-guide-venv/bin/python build.py --dry-run   # render and check, write nothing
../../proof-guide-venv/bin/python build.py             # write the guide into the site folder
../../proof-guide-venv/bin/python build.py --dry-run   # expect: Would write 0 files
cmp ../book/source/proof-guide-source-2026-10-22.zip ../../proof-guide-source-2026-10-22.zip
```

The build writes the 26 pages of each edition and its legal page (`legal/`), `book/guide-assets/` (interface, fonts, licence texts), `book/source/` (this archive, rebuilt byte for byte), `book/sw.js`, `sitemap.xml` and a private report `book-drafts/guide-ui/integration-report.json`. It never deletes a file and stops if any other file of the site folder changes.

The pages, the interface files, the licence texts, `book/sw.js` and the archive are expected to be byte-identical to the published ones. `sitemap.xml` is a host file: here it lists only the book addresses; on the host it also keeps the host entries. The placeholder host pages are not replaced by the build, except `book/index.html`, which is the Lithuanian cover.

To export only the generated guide files, with their hashes, to a new folder (never overwrites, never deletes):

```sh
../../proof-guide-venv/bin/python guide-ui/release.py --dest ../../proof-guide-export
```

## Modifying

Edit the Markdown sources or the code, rebuild, and keep `NOTICE.txt` with your own modification notice and date. Changing a checklist action needs its registry entry (see the docstring of `guide-ui/scripts/import_book.py`). If you distribute or serve a modified version, offer its corresponding source, for example with `guide-ui/source_archive.py --out`, and follow both licences.
