# 13 skyrius: Tavo pirmoji piniginė ir pirmieji satošiai

## Trumpai

Biržoje palikti bitkoinai yra įmonės pažadas, o bitkoinus piniginėje, kurios raktus laikai tu, ir kontroliuoji tu. Piniginė yra nemokama programėlė, kuriai paruošti pakanka maždaug 10 minučių, o mokytis pakanka sumos, artimos pietų kainai. Įdiek piniginę, užsirašyk atkūrimo žodžius, gauk pirmą mokėjimą, dalį jo nusiųsk atgal, o tada palyginimui išbandyk antrą, kitos komandos sukurtą piniginę.

## Likutis biržoje yra skolos raštelis

Kai nusiperki bitkoinų biržoje ir ten juos palieki, tau priklauso tik eilutė įmonės duomenų bazėje, kurioje parašyta, kad įmonė tau jų skolinga. Kol įmonė sąžininga, moki, saugi ir jai leidžiama tave aptarnauti, skirtumo nuo tikrų bitkoinų nematyti.

Birža „Mt. Gox“, kadaise didžiausia pasaulyje bitkoinų birža, 2014 m. vasarį kreipėsi dėl bankroto ir pranešė, kad [trūksta apie 850 000 bitkoinų](https://www.wired.com/2014/03/bitcoin-exchange/). Jos administratorius pirmąsias išmokas kreditoriams pervedė 2024 m. liepą, o 2025 m. spalį [galutinį terminą nukėlė į 2026 m. spalio 31 d.](https://www.mtgox.com/img/pdf/20251027_1cc36334-e8b2-4fe4-8135-97d9a149e4f7_announcement_en.pdf), kai nuo žlugimo bus praėję daugiau kaip 12 metų.

Birža „FTX“, viena didžiausių tuo metu, dėl bankroto kreipėsi 2022 m. lapkritį, praėjus kelioms dienoms po to, kai buvo sustabdytas lėšų išėmimas. Jos įkūrėjas 2023 m. lapkritį pripažintas kaltu dėl sukčiavimo, o 2024 m. kovą [nuteistas kalėti 25 metus](https://www.justice.gov/archives/opa/pr/samuel-bankman-fried-sentenced-25-years-his-orchestration-multiple-fraudulent-schemes). Tarp tokio masto įvykių pasitaiko ir kasdieniškesnių: įšaldomos paskyros, stabdomas lėšų išėmimas, į platformas įsilaužiama. Bitcoin naudotojai visa tai apibendrina posakiu „Not your keys, not your coins“ (ne tavo raktai, ne tavo monetos).

## Piniginėje laikomi raktai, o ne monetos

Kiekvienas bitkoinas egzistuoja tik kaip įrašas blokų grandinėje, viešajame registre, kurį sinchronizuoja tūkstančiai kompiuterių. Piniginėje laikomi **raktai**, t. y. slapti skaičiai, kuriais tinklui įrodai, kad turi teisę perkelti tam tikrą įrašą. Norint išleisti bitkoinus reikia raktu pasirašyti žinutę, todėl monetas valdo tas, kas turi raktą, ir tam nereikia nei vardo, nei paskyros, nei leidimo.

Taigi programėlė yra ir langas, ir rašiklis. Ji parodo, ką valdo tavo raktai, ir pasirašo, kai nusprendi mokėti. Daugelis piniginių raktų atsarginę kopiją pateikia kaip 12 arba 24 žodžius. Yra ir kitų formatų, o atkurti galima tik suderinama programine įranga (žr. 14 skyrių). Lightning piniginėms gali prireikti ir papildomų atkūrimo duomenų, kurie priklauso nuo konkrečios piniginės.

Viso bitkoino irgi nereikia. 1 bitkoinas dalijamas į 100 mln. vienetų, vadinamų **satošiais** (angl. satoshis, trumpiau **sats**), ir su 20 000 satošių piniginė veikia lygiai taip pat kaip su 2 bitkoinais, todėl mokytis pakanka mažų sumų.

## 2 pasirinkimai, su kuriais susidursi

**Pagrindinėje grandinėje ar per Lightning.** Pagrindinės grandinės (angl. on-chain) transakcijos įrašomos tiesiai į blokų grandinę. Jos trunka nuo kelių minučių iki kelių valandų, o jų mokestis priklauso nuo paklausos, todėl jos tinka didesnėms sumoms ir santaupoms. Lightning yra Bitcoin pagrindu veikiantis mokėjimų tinklas, praktiškai momentinis ir labai pigus, todėl tinka mažoms kasdienėms sumoms (žr. 15 skyrių).

**Depozitinė ar savarankiško saugojimo piniginė.** Depozitinė piniginė (angl. custodial) veikia kaip maža birža, nes raktus laiko įmonė, o tau rodo likutį. Savarankiško saugojimo piniginė raktus laiko tavo telefone.

Su depozitine pinigine pradėti lengviausia, nes nereikia nei daryti atsarginės kopijos, nei ko nors suprasti, ir ji priimtina sumai, kurią prarasti neskaudėtų, panašiai kaip smulkias monetas kišenėje. Tačiau ES šis pasirinkimas siaurėja, nes depozitinių piniginių teikėjams dabar reikia licencijos ir jie privalo nustatyti naudotojų tapatybę (žr. 15 skyrių). Savarankiškas saugojimas iš tavęs reikalauja šiek tiek daugiau, visų pirma rimtos atsarginės kopijos. Užtat jokia įmonė tavo likučio nei įšaldys, nei praras, nors biržos ir tarpininkai (angl. brokers) vis tiek gali atsisakyti tave aptarnauti.

## Laikyti raktus dar ne viskas

Naudojantis depozitine pinigine patikima trečioji šalis akivaizdi, nes raktus laiko įmonė ir ji gali tavo likutį įšaldyti arba prarasti. Kai raktus laikai tu, šios šalies nebelieka, bet lieka 3 mažiau pastebimos.

Pirmoji yra serveris, kurio klausia piniginė. Piniginė telefone pati blokų grandinės netikrina, o siunčia užklausas serveriui, dažniausiai piniginės kūrėjų. Šis sužino tavo adresus ir IP adresą ir galėtų parodyti neteisingą likutį, nors išleisti tavo monetų negali. Antroji yra platinimo kanalas, nes nuo „Apple“ ar „Google“ parduotuvės ir nuo kūrėjo pasirašymo rakto priklauso, koks kodas veiks tavo telefone. Trečioji, Lightning tinkle, yra paslaugų teikėjas. Piniginė „Phoenix“ kanalus atidaro tik su bendrovės „ACINQ“ mazgu, kuris paprastai mato, kur keliauja tavo mokėjimai, ir galėtų atsisakyti juos persiųsti, o Spark pagrindu sukurtos piniginės priklauso nuo [nedidelės operatorių grupės](https://docs.spark.money/spark/trust-model). Abiem atvejais išlieka galimybė išeiti į blokų grandinę, tik ji kainuoja.

Kiekvieną iš šių šalių galima iš dalies patikrinti. Atvirąjį kodą galima perskaityti, projektas [„WalletScrutiny“](https://walletscrutiny.com/methodology/) tikrina, ar parduotuvėje esančią programėlę galima surinkti iš to kodo (tai vadinama atkartojamu programos surinkimu, angl. reproducible build), o kelios piniginės leidžia prisijungti prie savo mazgo (žr. 18 skyrių).

## Kaip pasirinkti piniginę

Visos toliau išvardytos piniginės nemokamos, ir verta išbandyti 2 skirtingų komandų pinigines, kad dėl vienos programėlės ar vienos paslaugos bėdų niekada neliktum be galimybės mokėti.

Pirmoje eilutėje esanti piniginė [„Bitkit“](https://bitkit.to/) yra šios knygos redakcijos pasirinkimas pirmajai piniginei. Bendrovės „Synonym“ išleista programėlė, skirta „iPhone“ ir „Android“ telefonams, viename ekrane rodo 2 likučius: santaupas pagrindinėje grandinėje ir išlaidoms skirtas lėšas Lightning tinkle, o abu saugo vienas 12 žodžių sąrašas. Per Lightning gauti mokėjimus gali nuo pirmos minutės, nes atėjus pirmajam mokėjimui „Synonym“ paslaugų teikėjas „Blocktank“ atidaro kanalą ir išskaičiuoja savo mokestį, [2026 m. rugsėjo viduryje aprašytu atveju apie 1 800 satošių](https://github.com/synonymdev/bitkit-android/issues/1265). Dėl šio kanalo piniginė „Bitkit“ priklauso nuo teikėjo „Blocktank“, o jos Lightning ryšys [nesiūlomas JAV ir Kanados gyventojams](https://help.bitkit.to/hc/help-center/articles/1702656162-how-do-i-manage-my-spending-balance).

2 paskutinėse eilutėse yra Ark pagrindu sukurtos piniginės. Ark yra būdas greitai ir pigiai mokėti bitkoinais už pagrindinės grandinės ribų (angl. off-chain), kai daug naudotojų per Ark serverį dalijasi tomis pačiomis pagrindinės grandinės transakcijomis. Tu laikai iš anksto pasirašytas transakcijas, su kuriomis, jei serveris dingtų, gali savarankiškai išeiti į blokų grandinę. Ark dar jaunas, nes pagrindiniame Bitcoin tinkle jis pradėjo veikti [2025 m. spalį su „Arkade“](https://arklabs.xyz/insights/press-start-arkade-goes-live) ir [2026 m. birželį su bendrovės „Second“ sukurtu „Bark“](https://second.tech/blog/introducing-noah-and-arke/), o bendrovės „Second“ serveryje likutis [nustoja galioti po 28 dienų, jei piniginė jo neatnaujina](https://second.tech/docs/learn/intro). Lentelė atspindi 2026 m. rugsėjo mėn. padėtį, todėl prieš diegiant verta pasitikrinti kiekvieno projekto svetainėje.

| Piniginė | Kas laiko raktus | Nuo ko ji vis dar priklauso | Tinklai | Atvirasis kodas | Kompromisas be pagražinimų |
|---|---|---|---|---|---|
| **[Bitkit](https://bitkit.to/)** | Tu | Numatytasis Lightning kanalų teikėjas yra bendrovės „Synonym“ paslauga „Blocktank“. Blokų grandinės duomenis teikia „Synonym“ Electrum serveris, kurį galima pakeisti savu. | Pagrindinė grandinė ir Lightning, 2 likučiai vienoje programėlėje | Taip | Lightning mazgas telefone ir santaupų likutis pagrindinėje grandinėje, o abiem pakanka 1 atsarginės kopijos. Iš pirmojo Lightning mokėjimo sumokama už kanalą (2026 m. rugsėjo viduryje apie 1 800 satošių, suma priklauso nuo kasėjų mokesčio), bendra Lightning kanalų talpa neviršija maždaug 999 dolerių, o JAV ir Kanados gyventojams Lightning nesiūlomas. |
| **Phoenix** | Tu | Kiekvienas Lightning mokėjimas eina per bendrovės „ACINQ“ mazgą. Blokų grandinės duomenis teikia Electrum serveriai, kuriuos galima pakeisti savu. | Lightning (į pagrindinę grandinę ir iš jos patenkama per keitimus, angl. swaps) | Taip | Tikras Lightning mazgas telefone, paprasta naudotis. Dėl kanalų priklauso nuo vienos bendrovės („ACINQ“). Pirmojo kanalo atidarymas [kainuoja 1 000 satošių, 1 % sumos ir kasėjų mokestį](https://phoenix.acinq.co/faq), todėl labai mažas pirmasis mokėjimas atmetamas. |
| **Breez** („Glow“, anksčiau „Misty Breez“) | Tu | Priklauso nuo Spark operatorių, kurie kartu pasirašo kiekvieną pervedimą, ir nuo „Breez“ programinės įrangos. | Lightning per Spark tinklą | Taip | 2026 m. rugpjūtį piniginė „Misty Breez“ [neteko Lightning ir pagrindinės grandinės mokėjimų](https://breez.technology/misty/). Dabar „Breez“ siūlo tą patį mėnesį išleistą piniginę „Glow“. Kanalų tvarkyti nereikia, tačiau piniginė labai nauja, o Spark remiasi nedidele operatorių grupe. |
| **BlueWallet** | Tu | Likučius rodo ir transakcijas į tinklą siunčia „BlueWallet“ Electrum serveriai, kuriuos nustatymuose galima pakeisti savu. | Pagrindinė grandinė | Taip | Aiški ir tinka mokytis, kaip veikia pagrindinė grandinė. Jos serveriuose veikusi Lightning paslauga uždaryta 2023 m. |
| **Blockstream app** (anksčiau „Green“) | Tu | Numatytieji yra „Blockstream“ serveriai, bet galima naudoti savo Electrum serverį. Lightning mokėjimams reikia Liquid federacijos ir keitimo paslaugos. | Pagrindinė grandinė, Liquid, Lightning per keitimus | Taip | Daug galimybių, veikia su aparatinėmis piniginėmis. Pradedantiesiems meniu daugoka, o Lightning mokėjimai per keitimus įvykdomi Liquid tinkle. |
| **Zeus** | Tu | Numatytasis kanalų teikėjas yra pačios piniginės „Zeus“ paslauga „Olympus“. Blokų grandinės duomenis teikia kiti Bitcoin mazgai arba tavo mazgas. | Lightning ir pagrindinė grandinė | Taip | Tikras Lightning mazgas telefone arba nuotolinis tavo mazgo valdymo pultas (žr. 18 skyrių). Galinga, bet mokytis reikia daugiau. 2026 m. rugpjūtį per ataką prieš „Zeus“ serverius [buvo uždaryti daugelio naudotojų kanalai](https://zeusln.com/blog/post-mortem-security-update-august-5th-2026/), tačiau klientų lėšų neprarasta. |
| **Wallet of Satoshi** | ES raktus laikai tu, nes depozitinis režimas čia [nepasiekiamas nuo 2026 m. sausio](https://www.therage.co/wallet-of-satoshi-eu-mica/). Kitur raktus laiko bendrovė. | Depozitinio likučio atveju priklausai nuo bendrovės. Savarankiško saugojimo režimu priklausai nuo Spark operatorių ir bendrovės serverių. | Lightning | Ne | Paprasčiausia iš visų. Savarankiško saugojimo režimas veikia Spark tinkle, naujoje sistemoje, kuri remiasi nedidele operatorių grupe. Tinka tik kišenpinigiams. |
| **Bringin** | Tu | Dėl pasirenkamos sąskaitos eurais priklausai nuo bendrovės „Bringin“, kuri, kaip ir bet kuri mokėjimo bendrovė, gali ją užblokuoti. Bitkoinų piniginė yra savarankiško saugojimo, todėl šių lėšų „Bringin“ nelaiko. | Lightning ir pagrindinė grandinė | Svetainėje nenurodyta | Piniginė susieta su pasirenkama sąskaita eurais, kuriai reikia patvirtinti tapatybę (žr. 15 skyrių). „Bringin“ yra šios konferencijos rėmėja. |
| **[Arkade wallet](https://arkade.money/)** | Tu | Priklauso nuo „Ark Labs“ valdomo „Arkade“ serverio, kuris kartu pasirašo kiekvieną Ark mokėjimą. Išeiti į blokų grandinę galima ir be jo. | Ark ir pagrindinė grandinė | Taip | Žiniatinklio programėlė, įdiegiama iš naršyklės, be programėlių parduotuvės. Vieša beta versija veikia nuo 2025 m. spalio, o pristatydama ją bendrovė „Ark Labs“ rašė, kad santaupoms ji dar neparengta. |
| **[Noah](https://beta.noahwallet.io/)** | Tu | Priklauso nuo bendrovės „Second“ valdomo Ark serverio, kuris kartu pasirašo mokėjimus ir sujungia piniginę su Lightning tinklu. Išeiti į blokų grandinę galima ir be jo. | Ark, Lightning ir pagrindinė grandinė | Taip | Sukūrė piniginės „Blixt“ komanda. Beta versija skirta „Android“, o „iPhone“ telefonams ji platinama per „TestFlight“. Kūrėjai prašo įnešti tik tiek, kiek gali sau leisti prarasti. |

Daugumai žmonių protingas derinys būtų toks: savarankiško saugojimo Lightning piniginė mažoms sumoms ir pagrindinės grandinės piniginė baziniam sluoksniui suprasti. Tai gali būti viena programėlė, pavyzdžiui, „Bitkit“, arba 2 atskiros programėlės, kai pagrindinei grandinei pasirenkama „BlueWallet“ arba „Blockstream app“. Piniginės, kurios pačios tvarko savo kanalus („Bitkit“, „Phoenix“, „Zeus“), pirmą dieną kainuoja daugiau, bet priklauso nuo mažiau išorinių paslaugų, o keitimais ar Spark tinklu paremtų piniginių atveju yra atvirkščiai. Išbandyk 2 ir pasilik tą, kuri tau aiški.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta piniginė „Bitkit“. Kitose piniginėse logika ta pati.

1. **Įdiek ją** iš oficialios programėlių parduotuvės. Prieš diegiant patikrink kūrėjo pavadinimą („Bitkit“ kūrėjas yra „Synonym Software“) ir į parduotuvę eik per nuorodą iš oficialios projekto svetainės bitkit.to, o ne per parduotuvės paiešką. Šis patikrinimas, papildytas žvilgsniu į programėlės puslapį svetainėje walletscrutiny.com, ir yra tas žingsnis, kuriuo pasitikėjimą pakeiti patikrinimu, kiek tai telefone įmanoma.
2. **Sukurk naują piniginę.** Programėlė neprašo nei el. pašto, nei vardo, nei paskyros, ir tai normalu.
3. **Užsirašyk atkūrimo žodžius, kol dar nieko negavai.** Atsarginės kopijos nustatymuose rask 12 žodžių, ranka nusirašyk juos ant popieriaus ir perskaityk 14 skyrių, kol dar neįnešei daugiau nei kišenpinigių.
4. **Gauk pirmą mokėjimą, didesnį už kanalo mokestį.** Bakstelėk „Receive“ (gauti), pasirink, kad mokėjimas ateitų į išlaidoms skirtą likutį, parodyk QR kodą ir neuždaryk programėlės, kol mokėjimas pasirodys. Tuo metu „Blocktank“ atidaro tavo kanalą ir iš sumos išskaičiuoja savo mokestį: [2026 m. rugsėjo 15 d. aprašytu atveju](https://github.com/synonymdev/bitkit-android/issues/1265) jis siekė 1 835 satošius, o kai kasėjų mokesčiai kyla, būna didesnis. Iš to paties pranešimo, rugsėjo 20 d. vis dar neuždaryto, matyti, kad gavus siūlomą mažiausią 2 000 satošių sumą gali likti toks mažas likutis, kad jo nepavyks išleisti. Paprašyk realistiškos sumos, pavyzdžiui, 20 000 satošių, ir, kol dar nesutikai, perskaityk programėlės rodomą mokestį. Jei nori išbandyti vos su keliais šimtais satošių, rinkis piniginę be kanalų („Wallet of Satoshi“ arba „Glow“) ir susitaikyk su jos kompromisu.
5. **Nusiųsk nedidelę sumą atgal.** Nuskenuok kito žmogaus QR kodą, patikrink sumą ir patvirtink. Paprastai mokėjimas ateina per 1 ar 2 sekundes.
6. **Patikrink mokestį** mokėjimo informacijoje, kad žinotum, koks mokestis yra įprastas.
7. **Išbandyk antrą piniginę**, persiųsk satošių iš vienos į kitą ir palygink.

## Klaidos, kurių verta vengti

- **Laikyti santaupas biržoje.** Birža praverčia tol, kol perki. Po to išsiimk bitkoinus į piniginę, kurią kontroliuoji.
- **Daryti atkūrimo žodžių ekrano nuotrauką.** Nuotraukos dažnai sinchronizuojamos su debesija, ir jas gali perskaityti kitos programėlės. Naudok popierių ir rašiklį (žr. 14 skyrių).
- **Įdiegti netikrą piniginę.** Programėlių parduotuvėse pasitaiko kopijų, sukurtų vogti. Patikrink kūrėjo pavadinimą ir pradėk nuo oficialios projekto svetainės.
- **Siųsti į ne tą tinklą.** Lightning mokėjimo prašymas (angl. invoice), pagrindinės grandinės adresas ir Liquid adresas yra 3 skirtingi dalykai. Gera piniginė netinkamo adreso nepriima, o jei kas nors atrodo keistai, sustok ir pasiklausk.
- **Pradėti nuo didelės sumos.** Pradedančiųjų klaidos nutinka pirmosiomis savaitėmis, todėl daryk jas su maža suma.
- **Pasitikėti tais, kurie internete siūlosi „padėti“ sutvarkyti piniginę.** Atkūrimo žodžių nereikia nei piniginės kūrėjams, nei biržai, nei jokiai institucijai.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl nuo tavo raktų priklauso tavo interneto sauga“, pranešimą skaito Satoshine. Raktai piniginėje remiasi ta pačia idėja kaip ir 6 skyriaus raktai.
- **Piniginių pamokos žingsnis po žingsnio:** „Plan B Academy“ (planb.academy).
- **Patikrink, ar piniginė tikrai atvirojo kodo:** „WalletScrutiny“ (walletscrutiny.com).
- **Paprasti vadovai pradedantiesiems:** „Bitcoiner.Guide“ (bitcoiner.guide).
- **Kitas skyrius:** kaip pasidaryti atkūrimo frazės atsarginę kopiją.

## Šaltiniai

- [The Inside Story of Mt. Gox, Bitcoin's $460 Million Disaster](https://www.wired.com/2014/03/bitcoin-exchange/), „Wired“, 2014 m. kovo 3 d.
- [Notice Concerning Change of Repayments Deadline](https://www.mtgox.com/img/pdf/20251027_1cc36334-e8b2-4fe4-8135-97d9a149e4f7_announcement_en.pdf), „MtGox Co., Ltd.“ reabilitacijos administratorius, 2025 m. spalio 27 d.
- [Samuel Bankman-Fried Sentenced to 25 Years for His Orchestration of Multiple Fraudulent Schemes](https://www.justice.gov/archives/opa/pr/samuel-bankman-fried-sentenced-25-years-his-orchestration-multiple-fraudulent-schemes), JAV teisingumo departamentas, 2024 m. kovo 28 d.
- [Methodology](https://walletscrutiny.com/methodology/), „WalletScrutiny“, žiūrėta 2026 m. rugsėjį.
- [Spark trust model](https://docs.spark.money/spark/trust-model), Spark dokumentacija, žiūrėta 2026 m. rugsėjį.
- [Phoenix FAQ: fees, restoring a wallet](https://phoenix.acinq.co/faq), „ACINQ“, žiūrėta 2026 m. rugsėjį.
- [How do I manage my spending balance?](https://help.bitkit.to/hc/help-center/articles/1702656162-how-do-i-manage-my-spending-balance) („Blocktank“, 999 dolerių riba, JAV ir Kanada), „Bitkit“ pagalbos centras, „Synonym“, žiūrėta 2026 m. rugsėjį.
- [CJIT at suggested minimum yields unspendable channel](https://github.com/synonymdev/bitkit-android/issues/1265) („Blocktank“ mokestis už pirmąjį mokėjimą buvo 1 835 satošiai), „Bitkit“ klaidų registras platformoje „GitHub“, 2026 m. rugsėjo 15 d.
- [Press Start: Arkade Goes Live](https://arklabs.xyz/insights/press-start-arkade-goes-live), „Ark Labs“, 2025 m. spalio 20 d.
- [Introducing Noah and Arké: Two new Bark-based wallets](https://second.tech/blog/introducing-noah-and-arke/), „Second“, 2026 m. birželio 10 d.
- [Intro to the Ark protocol](https://second.tech/docs/learn/intro), „Second“ dokumentacija, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Įdiek savarankiško saugojimo piniginę iš oficialaus šaltinio, bet pirmiausia patikrink kūrėjo pavadinimą ir jos puslapį svetainėje walletscrutiny.com (5 min.)
- [ ] Atkūrimo žodžius užsirašyk ant popieriaus, kol dar nieko negavai (5 min.)
- [ ] Gauk pirmą mokėjimą, didesnį už pradinį kanalo mokestį, ir dalį nusiųsk atgal (5 min.)
- [ ] Įdiek antrą, kitos komandos sukurtą piniginę ir palygink (1 val.)
- [ ] Viską, ką palikai biržoje, perkelk į piniginę, kurią kontroliuoji (1 val.)
