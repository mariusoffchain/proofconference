# 3 skyrius: Tavo naršyklė ir paieška

## Trumpai

Naršyklė ir paieškos sistema mato daugiau tavo gyvenimo nei bet kuri kita programinė įranga, o tas, kurios yra tavo įrenginyje, už tave parinko verslo sandoris. Pereik prie sekimą blokuojančios naršyklės, pridėk vieną gerą turinio blokatorių ir pasirink paieškos sistemą, kuri nekuria tavo profilio. Užtruksi mažiau nei valandą, o skirtumą pamatysi iškart: reklamos bus mažiau, puslapiai atsivers greičiau.

## Numatytoji parinktis, už kurią sumokėjo kažkas kitas

Naršyklėje skaitai naujienas, ieškai ligų simptomų ir lygini paskolas, o dauguma atveriamų puslapių dar įkelia nematomą kodą, priklausantį dešimtims kitų bendrovių, pavyzdžiui, reklamos tinklams ir analitikos paslaugoms. Šie **sekikliai** (naršyklė „Firefox“ juos vadina stebėjimo elementais) fiksuoja, ką skaitai, ir papildo metų metus kuriamą profilį. Paieškos užklausos atskleidžia dar daugiau, nes paieškos sistemos klausi to, ko neklaustum nei gydytojo, nei partnerio.

Vis dėlto numatytąsias parinktis įrenginyje pasirinkai ne tu. Per JAV antimonopolinę bylą prieš bendrovę „Google“ paviešinta skaidrė parodė, kad bendrovė [2021 m. sumokėjo 26,3 mlrd. JAV dolerių](https://www.cnbc.com/2023/10/27/google-paid-26-billion-in-2021-to-become-a-default-search-engine.html) už tai, kad būtų numatytoji paieškos sistema: daugiausia tikriausiai gavo „Apple“, o tarp kitų gavėjų buvo naršyklių kūrėjai, pavyzdžiui, „Mozilla“. 2025 m. rugsėjį JAV federalinis teisėjas [nutraukė išimtines sutartis, bet leido „Google“ toliau mokėti už vietą](https://www.npr.org/2025/09/02/nx-s1-5478625/google-chrome-doj-antitrust-ruling), todėl numatytoji parinktis tavo įrenginyje, 2026 m. rugsėjo mėn. duomenimis, dažniausiai tebėra mokėjimo rezultatas.

Privatusis naršymas, arba inkognito režimas, šios problemos neišsprendžia, nes jis tik neleidžia tavo įrenginiui išsaugoti naršymo istorijos ir slapukų. Svetainės, sekikliai, interneto paslaugų teikėjas ir darbdavio tinklas mato tą patį, ką ir anksčiau.

## 3 būdai, kuriais sekikliai tave atpažįsta

Sekikliai remiasi 3 pagrindinėmis technikomis.

- **Trečiųjų šalių slapukai.** Slapukas yra mažas failas, kurį svetainė išsaugo tavo naršyklėje. Kai ta pati reklamos bendrovė veikia tūkstančiuose svetainių, jos slapukas keliauja paskui tave iš vienos svetainės į kitą. Naršyklės „Safari“, „Firefox“ ir „Brave“ tokius slapukus automatiškai blokuoja arba izoliuoja. Populiariausia naršyklė „Chrome“ juos vis dar leidžia, o 2025 m. balandį bendrovė „Google“, daug metų skelbusi, kad jų atsisakys, [patvirtino, kad šios tvarkos nekeis](https://privacysandbox.google.com/blog/privacy-sandbox-next-steps).
- **Atpažinimas pagal skaitmeninį atspaudą (angl. fingerprinting).** Naršyklė atskleidžia daug smulkmenų, pavyzdžiui, ekrano dydį, kalbą, laiko juostą, įdiegtus šriftus ir grafikos įrangą. Kiekviena atskirai yra įprasta, bet jų derinys dažnai būna unikalus. Įrenginyje nieko neišsaugoma, todėl ištrynus slapukus niekas nepasikeičia.
- **Tavo paskyros.** Jei neatsijungi nuo „Google“ ar „Facebook“ paskyros, kiekvieną puslapį, kuriame yra jų kodo, galima susieti su tikruoju tavo vardu.

Gynyba remiasi ta pačia logika.

- **Blokuoti.** Turinio blokatorius žinomų sekiklių išvis neįkelia.
- **Izoliuoti.** Naršyklė kiekvienai svetainei skiria atskirą slapukų saugyklą, todėl vienoje svetainėje įrašyto slapuko kita svetainė perskaityti negali.
- **Atrodyti kaip visi.** Kai kurios naršyklės siekia, kad visi jų naudotojai atrodytų vienodai ir skaitmeninis atspaudas nurodytų minią, o ne vieną žmogų.

Atpažinti tave leidžia ir IP adresas, o apie jį kalbama 5 skyriuje.

## Kas laiduoja už spynelę

Spynelės piktograma žada, kad pakeliui niekas negali perskaityti puslapio (konfidencialumas) ir kad svetainė tikrai yra ta, kuri nurodyta adrese (autentiškumas). Antrąjį pažadą užtikrina **sertifikatų išdavimo įstaiga** (angl. certificate authority), t. y. organizacija, pasirašanti svetainės sertifikatą, o naršyklėje arba sistemoje iš anksto įrašytas sąrašas įstaigų, kurias ji pripažįsta. Bet kuri iš jų gali laiduoti už bet kurią svetainę, todėl jos yra klasikinis žiniatinklio patikimų trečiųjų šalių pavyzdys. 2011 m. į Nyderlandų įstaigą „DigiNotar“ įsibrovęs asmuo [išdavė 531 netikrą sertifikatą](https://www.enisa.europa.eu/sites/default/files/all_files/Operation_Black_Tulip_v2.pdf), o google.com skirtu sertifikatu, kol [naršyklės nepašalino „DigiNotar“ iš savo sąrašų](https://blog.mozilla.org/security/2011/09/02/diginotar-removal-follow-up/), buvo perimtas maždaug 300 000 naudotojų ryšys, ir beveik visi jie buvo Irane.

Po šios nesėkmės atsirado **sertifikatų skaidrumas** (angl. certificate transparency). Dabar sertifikatai turi būti įrašyti į viešus žurnalus, kuriuose gali ieškoti bet kas, todėl svetainės savininkas gali pastebėti netikrą sertifikatą, o [naršyklė „Firefox“ kompiuteriuose nuo 135 versijos, išleistos 2025 m. vasarį, nepriima į žurnalus neįrašytų sertifikatų](https://groups.google.com/a/mozilla.org/g/dev-security-policy/c/OagRKpVirsA/m/Q4c89XG-EAAJ), kaip jau anksčiau darė naršyklės „Chrome“ ir „Safari“.

Kita trečioji šalis yra naršyklės kūrėjas, nes jis parenka tą sąrašą, numatytąją paieškos sistemą ir plėtinių parduotuvę, o jo naujinių kanalu gali būti pakeista programa, kuria naudojiesi. Atvirasis kodas ir atkartojamas programos surinkimas (angl. reproducible builds) leidžia pašaliniams patikrinti, ką jis platina.

## Kaip pasirinkti naršyklę

Tobulos naršyklės nėra, todėl žiūrėk, kas ją kuria, ką ji blokuoja be papildomo nustatymo ir ko tenka atsisakyti.

| Naršyklė | Kas ją kuria | Kuo tenka pasitikėti | Privalumai | Kompromisai |
|---|---|---|---|---|
| **Firefox** | „Mozilla“, priklausanti pelno nesiekiančiam fondui | Organizacija „Mozilla“, kuri teikia naujinius, tvarko savo sertifikatų išdavimo įstaigų sąrašą ir priedų parduotuvę. Kodas viešas. | Nuosavas variklis, nepriklausomas nuo „Google“ kuriamo „Chromium“. Stipri apsauga pasirinkus lygį „Griežta“. Kompiuteriuose ir sistemoje „Android“ veikia visavertis plėtinys „uBlock Origin“. | Iš pradžių reikia pakeisti kelis nustatymus. Automatiškai siunčia naudojimo duomenis. Didžiąją dalį „Mozilla“ pajamų duoda paieškos sutartis su „Google“. Telefone „iPhone“ plėtinių įdiegti negalima. |
| **Brave** | „Brave Software“, pelno siekianti JAV bendrovė | Bendrove „Brave Software“, kuri teikia naujinius, ir bendrove „Google“, kuri kuria pagrindą sudarantį „Chromium“ kodą ir valdo plėtinių parduotuvę. Kodas viešas. | Reklamą ir sekiklius blokuoja be jokio nustatymo, taip pat ir telefone „iPhone“. Veikia beveik visose svetainėse. Yra versijos kompiuteriui ir telefonui. | Reklamuoja savo produktus, tarp jų kriptovaliutų piniginę, reklamą už atlygį ir mokamą VPN. Juos galima išjungti. Sukurta „Google“ variklio „Chromium“ pagrindu. |
| **Mullvad Browser** | Kuria organizacija „Tor Project“ kartu su Švedijos VPN bendrove „Mullvad“ | Organizacija „Tor Project“ ir bendrove „Mullvad“, kurios teikia naujinius. Kodas viešas, o programos surinkimas atkartojamas, todėl pašaliniai gali jį patikrinti. | Stipri apsauga nuo atpažinimo pagal skaitmeninį atspaudą: sukurta taip, kad visi naudotojai atrodytų vienodai. Nesiunčia jokių naudojimo duomenų. Nemokama, VPN nebūtinas. | Veikia tik kompiuteryje. Uždaryta viską pamiršta. Kai kurios svetainės neveikia. |
| **LibreWolf** | Savanorių bendruomenė | Keliais savanoriais, nuo kurių priklauso programos surinkimas ir tai, kaip greitai ją pasiekia „Firefox“ saugumo pataisos. Kodas viešas. | Tai naršyklė „Firefox“ su jau pritaikytais griežtais nustatymais, be naudojimo duomenų siuntimo ir su įdiegtu „uBlock Origin“. | Veikia tik kompiuteryje. Komanda maža. Kai kuriose sistemose naujiniais rūpiniesi tu. |
| **Tor Browser** | „Tor Project“, ne pelno organizacija | Organizacija „Tor Project“, kuri teikia naujinius (programos surinkimas atkartojamas). Nė vienas retransliatorius (angl. relay) nemato kartu ir tavęs, ir svetainės. | Slepia IP adresą, nes ryšys eina per 3 retransliatorius. Stipriausias anonimiškumas šioje lentelėje. | Veikia lėtai. Daug svetainių rodo papildomus patikrinimus arba ją blokuoja. Neskirta kasdienėms paskyroms, prie kurių prisijungi. |

Blokavimo etalonas yra **„uBlock Origin“**: šis plėtinys nemokamas, atvirojo kodo ir nedaro mokamų išimčių reklamos užsakovams. Visos jo funkcijos veikia naršyklėje „Firefox“ kompiuteriuose ir sistemoje „Android“. Naršyklėje „Chrome“ jis nebeveikia, nes bendrovė „Google“ [2025 m. liepą išjungė senesnį plėtinių formatą](https://developer.chrome.com/docs/extensions/develop/migrate/mv2-deprecation-timeline), o 2026 m. rugpjūčio 31 d. pašalino paskutinius tokio tipo plėtinius iš parduotuvės „Chrome Web Store“. Liko ribotesnė versija „uBlock Origin Lite“, o naršyklė „Brave“ turi įtaisytą savo blokatorių.

Telefonas „iPhone“ yra atskiras atvejis, nes [naršyklėje „Firefox“, skirtoje sistemai „iOS“, plėtinių įdiegti negalima](https://support.mozilla.org/en-US/kb/add-ons-firefox-ios), taigi „uBlock Origin“ ten nėra. Galima rinktis įtaisytą naršyklės „Brave“ blokatorių, paprastesnį reklamos blokatorių, kuris [siūlomas naršyklėje „Firefox“, skirtoje sistemai „iOS“](https://support.mozilla.org/en-US/kb/block-ads-firefox-ios) (automatiškai jis išjungtas ir naudotojams pateikiamas palaipsniui), arba naršyklę „Safari“ su plėtiniu „uBlock Origin Lite“, kurį galima įdiegti nuo 2025 m. rugpjūčio.

Daugiau plėtinių nediek, kad ir kaip norėtųsi, nes kiekvienas plėtinys gali skaityti tavo lankomus puslapius, o dėl neįprasto jų rinkinio skaitmeninis atspaudas tampa unikalesnis.

Daugumai žmonių protingas derinys būtų toks: **naršyklė „Firefox“ arba „Brave“ kasdienai** ir **„Mullvad Browser“ arba „Tor Browser“** toms paieškoms, kurias nori laikyti atskirai nuo savo paskyrų.

## Kaip pasirinkti paieškos sistemą

Paieškos sistemą pakeisi maždaug per minutę, todėl tai vienas lengviausių šios knygos žingsnių. Pagal pačių paieškos sistemų privatumo politiką nė viena toliau pateikta sistema nekuria tavo reklamos profilio, tačiau jos skiriasi tuo, iš kur gauna rezultatus ir iš ko uždirba.

| Paieškos sistema | Iš kur gaunami rezultatai | Iš ko uždirba | Verta žinoti |
|---|---|---|---|
| **DuckDuckGo** | Daugiausia iš „Bing“ ir iš savo šaltinių | Iš reklamos, parenkamos pagal įvestus žodžius, o ne pagal profilį | JAV bendrovė. Pereiti lengviausia. |
| **Brave Search** | Iš savo nepriklausomo indekso | Iš reklamos | Ta pati bendrovė, kuri kuria naršyklę „Brave“. |
| **Startpage** | Iš „Google“, tik užklausos siunčiamos neatskleidžiant tavo tapatybės | Iš neindividualizuotos reklamos | Nyderlandų bendrovė. Nuo 2019 m. didžioji jos dalis priklauso JAV reklamos grupei „System1“. |
| **Kagi** | Iš savo indekso ir kelių kitų šaltinių | Iš mokamos prenumeratos, reklamos nėra | JAV bendrovė. Reikia paskyros. Finansuoja tik naudotojai. |
| **SearXNG** | Vienu metu sujungia daugelio paieškos sistemų rezultatus | Iš nieko. Tai nemokama atvirojo kodo programinė įranga | Paleisk nuosavame serveryje arba naudokis viešu serveriu (sąrašas yra searx.space). Tada pasitiki tuo, kas tą serverį valdo. |

Vieną jų išbandyk 2 savaites ir tik tada vertink. Vietinių lietuviškų paieškų rezultatai įvairiose sistemose gali skirtis, ir niekas netrukdo retkarčiais pasitaikančiai sudėtingai užklausai pasitelkti antrą paieškos sistemą.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta naršyklė „Firefox“ kompiuteryje, nes jos versijų yra visoms sistemoms ir ji nepriklauso nuo „Google“ variklio. Kitose naršyklėse logika ta pati, o nustatymų pavadinimai įvairiose versijose gali šiek tiek skirtis.

1. **Įdiek naršyklę** iš mozilla.org arba iš oficialios savo sistemos parduotuvės.
2. **Sustiprink apsaugą.** Pasirink „Nuostatos“, „Privatumas ir saugumas“ ir prie „Išplėsta apsauga nuo stebėjimo“ pažymėk „Griežta“.
3. **Reikalauk šifruoto ryšio.** Tame pačiame puslapyje pažymėk „Įjungti tik HTTPS veikseną visuose languose“. Būtent šis žingsnis pasitikėjimą pakeičia patikrinimu, nes tada naršyklė kaskart jungdamasi tikrina sertifikatą ir nebepasikliauja tarpiniais tinklais.
4. **Nebesiųsk naudojimo duomenų.** Vis dar tame pačiame puslapyje, skiltyje apie „Firefox“ duomenų rinkimą, nuimk varneles nuo langelių.
5. **Pakeisk paieškos sistemą.** Pasirink „Nuostatos“, „Paieška“ ir prie „Numatytoji ieškyklė“ („Firefox“ taip vadina paieškos sistemą) išsirink naują. Jei jos sąraše nėra, atverk paieškos sistemos svetainę ir pridėk ją iš adreso juostos.
6. **Įdiek „uBlock Origin“** iš oficialios priedų svetainės (addons.mozilla.org) ir palik numatytuosius nustatymus, nes jie geri.
7. **Perkelk adresyną (angl. bookmarks).** Meniu „Adresynas“ esančiu importo įrankiu nukopijuok išsaugotas nuorodas iš senosios naršyklės. Išsaugotų slaptažodžių neimportuok, nes jų vieta yra slaptažodžių tvarkyklėje (žr. 2 skyrių).
8. **Nustatyk ją numatytąja, taip pat ir telefone.** Kompiuteryje naująją naršyklę nustatyk numatytąja, tada tuos pačius pasirinkimus pakartok telefone. Sistemoje „Android“ naršyklė „Firefox“ taip pat priima „uBlock Origin“. Telefone „iPhone“ nepriima, todėl rinkis vieną iš pirmiau aprašytų „iPhone“ variantų.

## Klaidos, kurių verta vengti

- **Tikėti, kad įjungus inkognito režimą tavęs niekas nemato.** Jis paslepia naršymą nuo žmonių, su kuriais dalijiesi įrenginiu, ir daugiau nuo nieko.
- **Įdiegti 10 privatumo plėtinių.** Kiekvienas gali skaityti tavo puslapius, o visi kartu išskiria tave iš minios, todėl užtenka vieno gero turinio blokatoriaus.
- **Visą dieną pagrindinėje naršyklėje neatsijungti nuo „Google“ ar „Facebook“.** Jei šias paskyras laikai antroje naršyklėje, jų slapukai nebeseka kasdienio naršymo, todėl ryšys tarp tavo vardo ir to, ką skaitai, susilpnėja. Jis neišnyksta, nes lankomos svetainės vis tiek mato tavo IP adresą ir skaitmeninį atspaudą.
- **Iš įpročio spustelėti „Priimti visus“.** Ieškok „Atmesti visus“. Plėtinys „uBlock Origin“ gali paslėpti ir daugumą slapukų juostų, jei jo nustatymuose įjungsi filtrų sąrašus, skirtus pranešimams apie slapukus (angl. „Cookie notices“).
- **Visus nustatymus iškart sukti iki maksimumo.** Jei pusė svetainių nebeveiks, tikėtina, kad per savaitę grįši prie senosios naršyklės, todėl nustatymus griežtink pamažu ir pasilik tokį lygį, kuris tau priimtinas.
- **Nepaisyti naujinių.** Iš visų programų naršyklė labiausiai atvira internetui, todėl paleisk ją iš naujo, kai ji to paprašo.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kaip „kareivis-pilietis“ gali padėti decentralizuoti pasaulį: Rusijos invazijos į Ukrainą pamokos“, pranešimą skaito Alexis Roussel. Kodėl atvirojo kodo įrankiai, kurių nevaldo kuri nors viena bendrovė, svarbūs toli už tavo ekrano ribų.
- **Išbandyk savo naršyklę:** organizacijos „Electronic Frontier Foundation“ įrankis „Cover Your Tracks“ (coveryourtracks.eff.org) parodo, kiek unikalus tavo skaitmeninis atspaudas.
- **Išsamiai palygink:** „Privacy Guides“, „Desktop Browsers“ (naršyklės kompiuteriui) ir „Search Engines“ (paieškos sistemos) (privacyguides.org).
- **Kitas skyrius:** tavo el. paštas ir pseudonimai.

## Šaltiniai

- [Operation Black Tulip: certificate authorities lose authority](https://www.enisa.europa.eu/sites/default/files/all_files/Operation_Black_Tulip_v2.pdf), ENISA (Europos Sąjungos kibernetinio saugumo agentūra), 2011 m. gruodžio mėn.
- [DigiNotar removal follow up](https://blog.mozilla.org/security/2011/09/02/diginotar-removal-follow-up/), „Mozilla Security Blog“, 2011 m. rugsėjo 2 d.
- [Certificate Transparency is now enforced in Firefox on desktop platforms starting with version 135](https://groups.google.com/a/mozilla.org/g/dev-security-policy/c/OagRKpVirsA/m/Q4c89XG-EAAJ), „Mozilla“ adresatų sąrašas „dev-security-policy“, 2025 m. vasario 4 d.
- [Google paid $26 billion in 2021 to become a default search engine](https://www.cnbc.com/2023/10/27/google-paid-26-billion-in-2021-to-become-a-default-search-engine.html), CNBC, 2023 m. spalio 27 d.
- [In a major antitrust ruling, a judge lets Google keep Chrome but levies other penalties](https://www.npr.org/2025/09/02/nx-s1-5478625/google-chrome-doj-antitrust-ruling), NPR, 2025 m. rugsėjo 2 d.
- [Next steps for Privacy Sandbox and tracking protections in Chrome](https://privacysandbox.google.com/blog/privacy-sandbox-next-steps), „Google“, 2025 m. balandžio 22 d.
- [Manifest V2 support timeline](https://developer.chrome.com/docs/extensions/develop/migrate/mv2-deprecation-timeline), „Chrome for Developers“ („Google“), atnaujinta 2026 m. rugsėjį.
- [Add-ons in Firefox for iOS](https://support.mozilla.org/en-US/kb/add-ons-firefox-ios), „Mozilla Support“, žiūrėta 2026 m. rugsėjį.
- [Block ads in Firefox for iOS](https://support.mozilla.org/en-US/kb/block-ads-firefox-ios), „Mozilla Support“, tikrinta 2026 m. spalio 22 d.

## Tavo veiksmų sąrašas

- [ ] Pakeisk numatytąją paieškos sistemą kompiuteryje ir telefone (5 min.)
- [ ] Įdiek sekimą blokuojančią naršyklę ir nustatyk ją numatytąja (1 val.)
- [ ] Kur palaikomas, pridėk plėtinį „uBlock Origin“ arba naudokis naršyklės blokatoriumi ir pašalink nenaudojamus plėtinius (5 min.)
- [ ] Perkelk „Google“ ir „Facebook“ sesijas į antrą naršyklę (5 min.)
- [ ] Išbandyk savo naršyklę svetainėje coveryourtracks.eff.org (5 min.)
