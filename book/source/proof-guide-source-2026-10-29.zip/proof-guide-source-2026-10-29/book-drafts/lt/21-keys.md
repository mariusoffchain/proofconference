# 6 skyrius: Raktai vietoj paskyrų

## Trumpai

Paskyra yra leidimas, kurį tau suteikia įmonė ir kurį ji gali atšaukti. Raktas yra paslaptis, kurią turi tik tu, o veikia jis dėl matematikos, nesvarbu, pritaria tam kuri nors įmonė ar ne. Raktais jau naudojiesi kasdien, tik jų nematai, nes jie slypi susirašinėjimo programėlėje ir prieigos raktuose (angl. passkeys). Už šią laisvę moki tuo, kad rakto už tave niekas neatkurs, todėl šiame skyriuje daugiausia kalbama apie tai, kaip raktus saugiai laikyti.

## Paskyra yra leidimas, kurį galima atšaukti

Paskyra yra eilutė svetimoje duomenų bazėje, o ką ta eilutė leidžia, sprendžia įmonė. Ji gali paskyrą užblokuoti per klaidą, automatiniu sprendimu, pasikeitus taisyklėms arba todėl, kad paslauga uždaroma ar pasitraukia iš tavo šalies. Taip žmonės netenka per daugelį metų sukauptų el. laiškų ir nuotraukų, o dažnai net nėra gyvo žmogaus, su kuriuo galėtų apie tai pasikalbėti.

Be to, paskyra saugi tik tiek, kiek saugi ta duomenų bazė. 2022 m. lapkritį Airijos duomenų apsaugos komisija [skyrė bendrovei „Meta“ 265 mln. eurų baudą](https://www.dataprotection.ie/en/news-media/press-releases/data-protection-commission-announces-decision-in-facebook-data-scraping-inquiry) po to, kai internete buvo paskelbti daugiau kaip 500 mln. „Facebook“ naudotojų asmens duomenys, tarp jų ir telefono numeriai.

Mygtukas „Pamiršau slaptažodį“ yra antras įėjimas, atviras kiekvienam, kas valdo tavo el. pašto adresą arba telefono numerį. 2020 m. kovą Europolas [pranešė, kad Ispanijoje sulaikyta 12 žmonių](https://www.europol.europa.eu/media-press/newsroom/news/sim-highjackers-how-criminals-are-stealing-millions-highjacking-phone-numbers). Jie įtariami pavogę daugiau kaip 3 mln. eurų: gaudavo aukų SIM kortelių dublikatus ir vietoj tų žmonių priimdavo bankų siunčiamus patvirtinimo kodus.

Paskyros patogios ir daugumai paslaugų visiškai tinka. Tačiau kai kalbama apie svarbiausius dalykus (tapatybę, privačius pokalbius, pinigus), verta paklausti, ar jie galėtų veikti neprašant niekieno leidimo. Su raktais tai didžia dalimi įmanoma.

## Paslaptis, įrodanti, kas esi

**Raktų pora** yra 2 labai dideli skaičiai, kartu sukurti tavo įrenginyje. **Privatusis raktas** yra paslaptis, kuri lieka pas tave, o **viešasis raktas** iš jo apskaičiuojamas ir jį galima rodyti bet kam. Iš privačiojo rakto gauti viešąjį lengva, o atvirkščiai praktiškai neįmanoma.

Raktų pora atlieka 2 darbus:

- **Priima paslaptis.** Įsivaizduok pašto dėžutę su plyšiu. Kiekvienas, kas žino adresą (tavo viešąjį raktą), gali įmesti laišką, o atidaryti dėžutę gali tik tas, kas turi jos raktą (tavo privatųjį raktą).
- **Pasirašo.** Privačiuoju raktu sukuriamas parašas, kurį viešuoju raktu gali patikrinti bet kas ir kurio be privačiojo rakto praktiškai neįmanoma suklastoti.

Tapatybei patvirtinti centrinio serverio nereikia, nes tikrinimas yra skaičiavimas, kurį gali atlikti bet kas.

Su raktais jau susiduri, tik to nežinai. Šifruojanti susirašinėjimo programėlė (žr. 1 skyrių) raktų porą sukūrė tavo telefone. Prieigos raktas (žr. 2 skyrių) yra raktų pora, kurios svetainė saugo tik viešąją pusę, o Nostr tapatybė (žr. 7 skyrių) irgi yra raktų pora. Daugelis Bitcoin piniginių (žr. 3 dalį) raktus išveda iš atsarginės kopijos, užrašytos 12 arba 24 žodžiais, o kitos naudoja kitokius formatus (žr. 14 skyrių). Smalsiems dar pora pavyzdžių: SSH raktais administratoriai prisijungia prie serverių, o PGP raktais šifruojami el. laiškai ir pasirašoma programinė įranga.

## Už kitų žmonių raktus vis tiek kas nors laiduoja

Raktas leidžia apsieiti be trečiosios šalies, kai kalbama apie 1 savybę, kontrolę, nes už tave niekas negali nei pasirašyti, nei iššifruoti. Autentiškumo klausimas lieka atviras, kai tik prireikia kito žmogaus rakto, nes pačiame viešajame rakte nepasakyta, kieno jis. Šią informaciją reikia iš kur nors gauti, o įprasti atsakymai yra 4: įmonės tvarkomas katalogas, kaip daugumoje susirašinėjimo programėlių (žr. 1 skyrių); sertifikatų išdavimo įstaiga, kuria remdamasi naršyklė atpažįsta svetainę; pasitikėjimo tinklas (angl. web of trust), kuriame žmonės pasirašo vieni kitų raktus, kaip daro PGP naudotojai; arba rakto atspaudas (angl. fingerprint), kurį kitu kanalu palygini tu.

Tik paskutiniam atsakymui nereikia patikimos trečiosios šalies. 2011 m. į Nyderlandų sertifikatų išdavimo įstaigą „DigiNotar“ buvo įsilaužta, [išduotas netikras google.com sertifikatas](https://blog.mozilla.org/security/2011/08/29/fraudulent-google-com-certificate/), ir naršyklės išbraukė „DigiNotar“ iš patikimų įstaigų sąrašų. Dabar viešuose [sertifikatų skaidrumo (angl. Certificate Transparency)](https://certificate.transparency.dev/) žurnaluose kiekvienas gali pamatyti, kokie sertifikatai išduoti kuriam nors domenui.

Tą patį kompromisą rodo ir prieigos raktai, tik čia kalbama apie saugojimą. Kai juos sinchronizuoja bendrovė „Apple“ arba „Google“, jie [šifruojami ištisiniu būdu](https://support.apple.com/en-us/102195), tačiau iš naujo įrenginio juos pasieksi tik per paskyrą toje bendrovėje, taigi prieinamumas vėl priklauso nuo jos. Prieigos raktas, laikomas aparatiniame saugos rakte, nepriklauso nuo nieko, ir jo neįmanoma nukopijuoti.

## Kaip pasirinkti, kur laikyti raktus

Raktas neturi mygtuko „Pamiršau slaptažodį“. Jokia įmonė negali atimti iš tavęs prieigos prie jo, bet jokia įmonė negali ir įleisti tavęs atgal. Pamestas raktas dingsta visam laikui, o kas jį nusikopijuoja, gali veikti tavo vardu. Atsakomybė iš įmonės pereina tau, todėl kiekvienam raktui reikia vietos, atitinkančios jo vertę.

| Kur | Kam tinka | Silpnoji vieta | Nuo ko vis dar priklausai |
|---|---|---|---|
| **Popierius, užrašyta ranka, 2 vietose** | Atkūrimo kodams, Nostr raktui, nedidelių sumų atkūrimo frazei | Gaisras, vanduo ir kiekvienas, kas jį ras | Nuo nieko, išskyrus tuos, kas gali patekti į tas 2 vietas |
| **Slaptažodžių tvarkyklė** (žr. 2 skyrių) | Mažos vertės raktams ir įprastų svetainių atkūrimo kodams | Ji veikia prie interneto prijungtuose įrenginiuose. Bitcoin atkūrimo frazei čia ne vieta, o savo pačios atkūrimo kodų tvarkyklė saugoti negali | Nuo teikėjo, kuris sinchronizuoja duomenis ir atnaujina programėles. Saugykla šifruojama ištisiniu būdu, o atvirojo kodo tvarkykles galima audituoti |
| **Aparatinis įrenginys** | Prisijungimams skirtas saugos raktas („YubiKey“, „Nitrokey“, „Token2“ ir kiti), bitkoinams skirta aparatinė piniginė arba pasirašymo įrenginys (žr. 17 skyrių) | Kainuoja pinigų, gali sugesti arba pasimesti. Atsarginės kopijos vis tiek reikia: tai arba antras saugos raktas, arba atkūrimo frazė popieriuje ar pliene | Nuo lusto ir jo programinės aparatinės įrangos (angl. firmware) gamintojo. Rakto „YubiKey“ programinė įranga uždara, o „Nitrokey“ yra atvirojo kodo |
| **Plieninė atsarginė kopija** | Atkūrimo frazėms, kurios turi atlaikyti ugnį ir vandenį (žr. 14 skyrių) | Brangesnė, o perskaityti ją gali kiekvienas, kas ją ras | Nuo nieko, išskyrus tuos, kas gali pasiekti slėptuvę |
| **Padalijimas arba kelių parašų schema** (angl. multisig) | Didelei vertei: keli raktai laikomi keliose vietose, todėl vienas praradimas ar viena vagystė dar nėra lemtingi | Sudėtinga. Suklydus nustatant galima netekti prieigos. Pirmiausia išmok, kaip tai veikia | Nė nuo vienos atskiros šalies. Priklausai nuo raktus koordinuojančios programinės įrangos ir nuo raktus laikančių žmonių ar vietų |

Daugumai žmonių protingas derinys būtų toks: **slaptažodžių tvarkyklė mažos vertės raktams**, **popierius 2 vietose atkūrimo kodams, kurie saugo visa kita**, **2 saugos raktai pagrindinėms paskyroms**, o kai atsiranda tikrų santaupų, aparatinė piniginė su plienine atsargine kopija. Tavo atveju gali labiau tikti kitoks derinys.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkti raktai, kuriuos dauguma skaitytojų jau turi, o ta pati logika tinka kiekvienam raktui, kurį susikursi vėliau.

1. **Sudaryk sąrašą.** Popieriuje surašyk raktų ir atkūrimo kodų pavadinimus, o ne pačias paslaptis: slaptažodžių tvarkyklės pagrindinį slaptažodį ir atkūrimo rinkinį (angl. recovery kit), pagrindinių paskyrų dviejų veiksnių autentifikavimo atkūrimo kodus, susirašinėjimo programėlės PIN kodą, kompiuterio disko šifravimo atkūrimo raktą, o vėliau ir Nostr raktą bei atkūrimo frazę. Prieigos raktų užrašyti neįmanoma, todėl pasižymėk, kur kiekvienas laikomas (kuriame telefone, tvarkyklėje ar saugos rakte) ir koks yra antrasis būdas patekti į tą paskyrą.
2. **Kiekvienam parink vietą** pagal pirmiau pateiktą lentelę ir užrašyk ją šalia pavadinimo.
3. **Atsargines kopijas užrašyk ranka.** Jokių nuotraukų, ekrano nuotraukų, užrašų debesijoje ar biuro spausdintuvų. Rašyk aiškiai ir kiekvieną ženklą patikrink 2 kartus.
4. **Laikyk jas 2 vietose**, pavyzdžiui, savo namuose ir pas giminaitį, kuriuo pasitiki, arba banko seife, jei tau tinka banko darbo laikas ir taisyklės. Per vieną gaisrą ar vieną vagystę neturėtų dingti abi kopijos.
5. **Nusipirk 2 saugos raktus, o ne 1.** Saugos rakto nukopijuoti neįmanoma, todėl antrasis raktas yra ne pirmojo kopija, o atskiras, nepriklausomas būdas prisijungti. Abu užregistruok pagrindinėse paskyrose (el. pašto, slaptažodžių tvarkyklės, debesų saugyklos): saugumo nustatymuose ieškok skilties „saugos raktas“ arba „prieigos raktas“ (angl. „security key“, „passkey“). Pirmąjį nešiokis su savimi, antrąjį laikyk kartu su popierinėmis atsarginėmis kopijomis ir pasilik tų paskyrų atkūrimo kodus.
6. **Išbandyk atkūrimą.** Prisijunk prie kurios nors paskyros atkūrimo kodu, tada sugeneruok naujus kodus. Senieji kodai nustoja veikti, todėl naujuosius įrašyk į abi popierines kopijas, o senus lapus sunaikink. Vieną kartą prisijunk ir antruoju saugos raktu, nes neišbandyta atsarginė kopija gali nesuveikti tą dieną, kai jos prireiks. Būtent šis žingsnis pasitikėjimą atsargine kopija ir įmonės atkūrimo procesu pakeičia tuo, ką patikrinai tu.
7. **Pasakyk žmogui, kuriuo pasitiki**, kur kas laikoma ir ką daryti, bet pačių paslapčių neatskleisk. Pakanka užklijuoto laiško su nurodymais. Kai tavęs nebebus, jokia įmonė nepadės šeimai atkurti rakto.
8. **Kartą per metus peržiūrėk sąrašą.**

## Klaidos, kurių verta vengti

- **Fotografuoti raktą ar atkūrimo frazę.** Nuotraukos kopijuojamos į debesijos paslaugas, jas gali perskaityti kitos programėlės, todėl būtent taip paslaptis dažnai išslysta iš rankų.
- **Įvesti privatųjį raktą svetainėje arba duoti jį „pagalbos tarnybai“.** Jokia sąžininga paslauga jo neprašo, o toks prašymas yra sukčiavimo ženklas.
- **Laikyti vienintelę kopiją telefone.** Telefonai kasdien pametami, pavagiami ir sudaužomi.
- **Laikyti atsarginę kopiją šalia įrenginio.** Tada vagis ar gaisras pasiima abu iš karto.
- **Paslėpti kopiją taip gerai, kad niekas nerastų.** Tada jos nerasi nei tu po 5 metų, nei tavo šeima, kai tavęs nebebus.
- **Per anksti pasirinkti sudėtingą schemą.** Padalyta atsarginė kopija, kurios iki galo nesupranti, pavojingesnė už 2 popieriaus lapus 2 saugiose vietose.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl nuo tavo raktų priklauso tavo interneto sauga“, šį skyrių papildantį pranešimą skaito Satoshine.
- **Suprask viešojo rakto šifravimą:** „Surveillance Self-Defense“, „A Deep Dive on End-to-End Encryption“, parengė organizacija „Electronic Frontier Foundation“ (ssd.eff.org).
- **Palygink saugos raktus ir slaptažodžių tvarkykles:** „Privacy Guides“ (privacyguides.org).
- **Sužinok daugiau apie prieigos raktus:** „FIDO Alliance“ (fidoalliance.org).
- **Kitas skyrius:** Nostr: atviras tinklas, kurio nevaldo jokia įmonė.

## Šaltiniai

- [Data Protection Commission announces decision in Facebook „Data Scraping“ Inquiry](https://www.dataprotection.ie/en/news-media/press-releases/data-protection-commission-announces-decision-in-facebook-data-scraping-inquiry), Airijos duomenų apsaugos komisija, 2022 m. lapkričio 28 d.
- [Meta hit with ~$275M GDPR penalty for Facebook data-scraping breach](https://techcrunch.com/2022/11/28/facebook-gdpr-penalty/), „TechCrunch“, 2022 m. lapkričio 28 d.
- [The SIM highjackers: how criminals are stealing millions by highjacking phone numbers](https://www.europol.europa.eu/media-press/newsroom/news/sim-highjackers-how-criminals-are-stealing-millions-highjacking-phone-numbers), Europolas, 2020 m. kovas.
- [Fraudulent *.google.com certificate](https://blog.mozilla.org/security/2011/08/29/fraudulent-google-com-certificate/), „Mozilla Security Blog“, 2011 m. rugpjūčio 29 d.
- [Certificate Transparency](https://certificate.transparency.dev/), projekto svetainė, žiūrėta 2026 m. rugsėjį.
- [About the security of passkeys](https://support.apple.com/en-us/102195), „Apple Support“, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Surašyk visus raktus ir atkūrimo kodus, kuriuos jau turi (1 val.)
- [ ] Trūkstamas atsargines kopijas užrašyk ranka ir laikyk 2 vietose (1 val.)
- [ ] Išbandyk atkūrimą su tikru atkūrimo kodu (5 min.)
- [ ] Pasakyk žmogui, kuriuo pasitiki, kur laikomos atsarginės kopijos (5 min.)
- [ ] Nusipirk 2 saugos raktus ir pridėk juos prie pagrindinių paskyrų (savaitgalis)
