#!/usr/bin/env python3
"""Export the generated files of the English and Lithuanian PROOF guide to a new folder: a deploy overlay, never the
working tree.

    python3 guide-ui/release.py --dest PATH [--site-dir PATH]

1. Runs build_integration.py in dry-run mode: the export stops unless every planned output in the site folder is
   identical to a fresh render of the sources (rebuild first with python3 build.py).
2. Copies exactly those planned outputs, and nothing else, to PATH/site/ with the same relative paths: the 54 pages
   (52 book pages and 2 legal pages), book/guide-assets/ (interface, fonts, licence texts), the source archive
   book/source/*.zip, book/sw.js and sitemap.xml.
3. Writes PATH/RELEASE-MANIFEST.json: relative path, group, size and SHA-256 of every exported file, the host files the
   pages need but this overlay does not contain, and what is never exported. No absolute path.

PATH must not exist or must be an empty folder, outside the site folder. Nothing is ever overwritten or deleted, in
PATH or in the site. The private report (guide-ui/integration-report.json), book-drafts, QA reports, audits, .git and
the conference pages are never exported: none of them is a planned output, and a forbidden name stops the export.

Upload the content of PATH/site/ over the root of the host site. sitemap.xml is a host file whose book entries the build
maintains: use it only when the site folder held the host's real sitemap (a tree rebuilt from the source archive holds
only the book entries). The overlay never removes a host file.
"""

import argparse
import hashlib
import json
import sys
from pathlib import Path

GUIDE_UI = Path(__file__).resolve().parent
sys.path.insert(0, str(GUIDE_UI))
import build_integration as bi   # noqa: E402  planned outputs and the dry-run check
import source_archive            # noqa: E402

HOST_FILES = ('index.html', 'en/index.html', 'favicon.svg')     # linked or precached by the pages, owned by the host
HOST_MERGE = ('sitemap.xml',)
FORBIDDEN = ('.git', 'book-drafts', 'qa', 'release-review-20261022', 'integration-report.json', 'import-report.json',
             '.DS_Store', '__pycache__')
NOT_EXPORTED = ['book-drafts/ (private sources; the public source is book/source/%s)' % source_archive.ARCHIVE_NAME,
                'book-drafts/guide-ui/integration-report.json (private build report)',
                'QA reports, audits, briefs, logs, .git',
                'conference pages, photographs, videos and other host files']


class ReleaseError(Exception):
    pass


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def group_of(rel):
    if rel == source_archive.ARCHIVE_REL:
        return 'source_archive'
    if rel.startswith('book/guide-assets/legal/'):
        return 'legal_text'
    if rel.startswith('book/guide-assets/'):
        return 'interface_asset'
    if rel == 'book/sw.js':
        return 'service_worker'
    if rel in HOST_MERGE:
        return 'host_merge'
    if rel.endswith('/index.html'):
        return 'legal_page' if rel.endswith('/' + bi.LEGAL_PATH + 'index.html') else 'page'
    raise ReleaseError('Unclassified planned output: %s' % rel)


def inside(child, parent):
    return child == parent or parent in child.parents


def export(site, dest):
    raw_dest = dest.expanduser().absolute()
    if raw_dest.is_symlink():
        raise ReleaseError('Destination must not be a symbolic link.')
    site, dest = site.resolve(), raw_dest.resolve()
    if inside(dest, site) or inside(site, dest) or inside(dest, bi.DRAFTS.resolve()):
        raise ReleaseError('The destination must be outside the site folder and book-drafts: %s' % dest)
    if dest.exists() and (not dest.is_dir() or any(dest.iterdir())):
        raise ReleaseError('The destination exists and is not an empty folder: %s' % dest)
    if not dest.parent.is_dir():
        raise ReleaseError('The parent folder of the destination does not exist: %s' % dest.parent)

    report = bi.run(argparse.Namespace(site_dir=str(site), dry_run=True, report=str(bi.REPORT)))
    if report['written']:
        raise ReleaseError('The site is not up to date with the sources (%d files differ, e.g. %s). Run python3 build.py '
                           'first.' % (len(report['written']), report['written'][0]))

    planned = sorted(bi.planned_writes())
    missing_host = [h for h in HOST_FILES if not (site / h).is_file()]
    if missing_host:
        raise ReleaseError('Host files the pages need are missing from the site folder: %s' % ', '.join(missing_host))
    files = []
    for rel in planned:
        parts = rel.split('/')
        if rel.startswith('/') or '..' in parts or set(parts) & set(FORBIDDEN):
            raise ReleaseError('Refusing to export %s' % rel)
        path = site
        for part in parts:
            path = path / part
            if path.is_symlink():
                raise ReleaseError('Refusing symbolic link in output: %s' % rel)
        data = path.read_bytes()
        files.append((rel, group_of(rel), data))

    dest.mkdir(exist_ok=True)
    out = dest / 'site'
    out.mkdir()
    for rel, _, data in files:
        target = out.joinpath(*rel.split('/'))
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, 'xb') as f:
            f.write(data)
        if sha256(target.read_bytes()) != sha256(data):
            raise ReleaseError('Copy differs after writing: %s' % rel)

    archive = next(d for r, _, d in files if r == source_archive.ARCHIVE_REL)
    manifest = {
        'edition': 'A Guide to Autonomy, PROOF edition, English and Lithuanian',
        'date': source_archive.ARCHIVE_DATE,
        'kind': 'overlay: upload the content of site/ over the root of the host site; never removes a host file',
        'counts': {g: sum(1 for _, gg, _ in files if gg == g) for g in sorted({g for _, g, _ in files})},
        'source_archive': {'path': source_archive.ARCHIVE_REL, 'bytes': len(archive), 'sha256': sha256(archive)},
        'host_files_required': list(HOST_FILES),
        'host_merge': {'sitemap.xml': 'book entries maintained by the build, host entries kept from the site folder; '
                                      'use only if the site folder held the real host sitemap'},
        'not_exported': NOT_EXPORTED,
        'python_markdown': report['python_markdown'],
        'files': [{'path': rel, 'group': g, 'bytes': len(data), 'sha256': sha256(data)} for rel, g, data in files],
    }
    with open(dest / 'RELEASE-MANIFEST.json', 'x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    return manifest


def main(argv=None):
    p = argparse.ArgumentParser(description='Export the generated PROOF EN/LT guide files to a new folder.')
    p.add_argument('--dest', required=True, help='new or empty folder, outside the site folder')
    p.add_argument('--site-dir', default=str(bi.DRAFTS.parent), help='PROOF site folder (default: %(default)s)')
    args = p.parse_args(argv)
    try:
        m = export(Path(args.site_dir).expanduser(), Path(args.dest))
    except (ReleaseError, bi.IntegrationError, bi.ib.ImportFailure) as e:
        sys.exit('Export stopped.\n' + str(e))
    print('Exported %d files to %s/site (%s); manifest RELEASE-MANIFEST.json'
          % (len(m['files']), Path(args.dest).expanduser().resolve(),
             ', '.join('%d %s' % (n, g) for g, n in m['counts'].items())))


if __name__ == '__main__':
    main()
