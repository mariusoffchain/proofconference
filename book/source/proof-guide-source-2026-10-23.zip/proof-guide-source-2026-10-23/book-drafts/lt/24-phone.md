# 9 skyrius: Kaip susigrąžinti telefono kontrolę

## Trumpai

Telefonas apie tave žino daugiau nei bet kuris kitas tavo daiktas. Nereikalingai perduodamų duomenų kiekį gali sumažinti per 1 vakarą, turimame telefone ir nieko nediegiant: pakanka sutvarkyti leidimus, reklamos identifikatorių, buvimo vietos nustatymus, ekrano užraktą, SIM kortelės PIN kodą ir naujinius. Tai 1 lygis, ir daugumai žmonių jo užtenka. 2 lygis skirtas smalsesniems: tai alternatyvios programėlių parduotuvės ir be „Google“ veikiančios „Android“ sistemos.

## Jutiklis, kuris atsiskaito daugeliui įmonių

Telefonas yra išsamiausias tavo turimas jutiklis. Jis žino, kur miegi ir kur dirbi, jame laikomi kontaktai, nuotraukos, mokėjimai ir dažnai sveikatos duomenys, o jo mikrofonas ir kamera visur keliauja kartu su tavimi.

Žibintuvėlio programėlei nereikia tavo kontaktų, o žaidimui nereikia tikslios buvimo vietos, tačiau daugelis programėlių vis tiek to prašo, nes duomenis galima parduoti. Be to, daugelyje nemokamų programėlių įdėtas reklamos kodas, siunčiantis duomenis toms pačioms kelioms bendrovėms. 2025 m. sausį įsilaužta į buvimo vietos duomenų prekeivio (angl. data broker) „Gravy Analytics“ sistemas, o [pavogtuose failuose](https://www.theregister.com/2025/02/06/gravy_analytics_data_breach_suit/) buvo dešimčių milijonų telefonų koordinatės, surinktos per tokias populiarias programėles kaip „Tinder“, „Candy Crush“ ir „MyFitnessPal“. Dalis šių telefonų buvo Europoje.

Kad šiuos duomenis būtų galima sujungti, telefonas turi **reklamos identifikatorių** (angl. advertising ID). Šį numerį mato kiekviena programėlė, todėl tavo veiksmus vienoje programėlėje galima susieti su veiksmais kitoje. 2021 m. balandį organizacija „noyb“ [pateikė skundą Prancūzijoje](https://noyb.eu/en/buy-phone-get-tracker-unauthorized-tracking-code-illegally-installed-android-phones) ir jame teigė, kad „Android“ sistema šį identifikatorių sukuria neprašydama sutikimo.

Galiausiai beveik kiekvieną telefoną, nuo sistemos iki programėlių parduotuvės ir numatytųjų paslaugų, valdo 2 bendrovės: „Google“ ir „Apple“.

## 4 svertai tavo rankose

Beveik visas šis skyrius remiasi 4 idėjomis.

- **Leidimai.** Programėlė negali pasiekti buvimo vietos, kameros, mikrofono, kontaktų ar nuotraukų, jei sistema to neleidžia. Leidimą suteiki tu ir bet kada gali jį atšaukti, todėl tai stipriausias tavo svertas.
- **Reklamos identifikatorius.** Tai nustatymas. Jį galima nustatyti iš naujo, o dabartiniuose telefonuose ir ištrinti arba apskritai uždrausti sekimą.
- **Programėlių parduotuvė kaip vartų sargas.** Parduotuvė sprendžia, kurios programėlės tau apskritai prieinamos, reikalauja paskyros ir žino viską, ką įdiegi. „Android“ sistemoje programėles galima diegti ir iš kitų šaltinių, tačiau tam taikomos sąlygos keičiasi (žr. 2 lygį). „iPhone“ telefone tai ribojama kur kas labiau, net Europos Sąjungoje.
- **Sistema ir paslaugos.** Pati „Android“ sistema yra atvirojo kodo. Tai, ką dauguma žmonių vadina „Android“, yra ši sistema kartu su „Google“ programėlėmis ir paslaugomis, kurioms suteiktos plačios privilegijos. Šias 2 dalis galima atskirti, ir būtent tai daro alternatyvios sistemos. Sistemos „iOS“ nuo „Apple“ atskirti negalima, tačiau didelę dalį to, ką ji siunčia į „iCloud“, galima išjungti arba užšifruoti.

## 1 lygis: sustiprink turimo telefono apsaugą

1 lygis tinka bet kuriam telefonui, ar tai būtų „Android“, ar „iPhone“, ir pradėti galima šiandien. Jam naudojami nustatymai, kuriuos „Google“ ir „Apple“ jau siūlo pačios, ir jokios naujos programėlės diegti nereikia. Leidimų apribojimai gali paveikti programėlių funkcijas, todėl pakeitimus išbandyk ir grąžink tik tuos leidimus, kurių tikrai reikia. Šie nustatymai apima pirmuosius 2 svertus, t. y. leidimus ir reklamos identifikatorių, taip pat ekrano užraktą, SIM kortelę ir naujinius.

Visam sąrašui skirk 1 vakarą. Ilgiausiai trunka leidimų peržiūra, nes reikia po kartą peržiūrėti kiekvieną programėlę, o kiti žingsniai užima po kelias minutes. Nė vienas pakeitimas nėra negrįžtamas: jei programėlė nustos veikti, nes leidimo jai tikrai reikėjo, ji paprašys dar kartą, ir tada galėsi jį suteikti.

1 lygis turi ribą, kurią verta žinoti. „Google“ arba „Apple“ niekur nedingsta: lieka jų parduotuvė, paskyra ir paslaugos, o programėlės, kurias pasilieki, vis tiek mato viską, ką joms leidi matyti. Daugumai žmonių čia sustoti visai protinga. Žingsniai aprašyti iškart po šio skirsnio, o po jų eina 2 lygis tiems, kurie nori žengti toliau.

## Žingsnis po žingsnio

Tai 1 lygio žingsniai, atliekami turimame telefone. Meniu pavadinimai priklauso nuo gamintojo ir versijos, todėl, jei kurio nors nerandi, pasinaudok nustatymų paieškos laukeliu.

1. **Pašalink tai, kuo nesinaudoji.** Peržiūrėk programėles ir pašalink kiekvieną, kurios neatvėrei jau kelis mėnesius. Pašalinus programėlę jos veikla telefone nutrūksta, tačiau duomenys, kuriuos jau turi jos teikėjas, neištrinami.
2. **Peržiūrėk leidimus.** „Android“ telefone atverk „Settings“, „Privacy“, „Permission manager“ (nustatymai, privatumas, leidimų tvarkytuvė). „iPhone“ telefone atverk „Settings“, „Privacy & Security“ (nustatymai, privatumas ir saugumas). Peržiūrėk skiltis „Location“, „Microphone“, „Camera“, „Contacts“ ir „Photos“ (buvimo vieta, mikrofonas, kamera, kontaktai ir nuotraukos) ir prie kiekvienos programėlės paklausk savęs, ar jai to tikrai reikia. Jei abejoji, neleisk: jei leidimas programėlei svarbus, ji paprašys dar kartą. Būtent šiuo žingsniu pasitikėjimą tuo, ką programėlė sako apie save, pakeiti patikrinimu: pamatai, ką ji gali pasiekti.
3. **Apribok buvimo vietos duomenis.** Vietoj „Always“ (visada) pasirink „While using the app“ (tik naudojant programėlę) ir išjunk tikslią buvimo vietą visoms programėlėms, išskyrus žemėlapius ir navigaciją. Orų programėlei pakanka žinoti miestą.
4. **Pašalink reklamos identifikatorių.** „Android“ telefone privatumo arba „Google“ nustatymuose atverk „Ads“ (reklama) ir pasirink „Delete advertising ID“ (ištrinti reklamos identifikatorių). „iPhone“ telefone atverk „Settings“, „Privacy & Security“, „Tracking“ (sekimas) ir išjunk „Allow Apps to Request to Track“ (leisti programėlėms prašyti leidimo sekti).
5. **Sustiprink užraktą.** Naudok bent 6 skaitmenų PIN kodą arba slaptafrazę. Jei nori, patogumo dėlei pasilik atrakinimą piršto atspaudu ar veidu, tačiau tikrasis raktas yra PIN kodas. Paslėpk pranešimų turinį užrakinimo ekrane.
6. **Nustatyk SIM kortelės PIN kodą.** Jis yra SIM kortelės arba mobiliojo tinklo nustatymuose. Tada pavogta SIM kortelė, įdėta į kitą telefoną, be šio PIN kodo negaus nei tavo skambučių, nei SMS kodų. Pirmiausia sužinok numatytąjį operatoriaus PIN kodą ir tai, kaip kortelė atblokuojama PUK kodu, nes po 3 klaidingų PIN kodo bandymų kortelė užblokuojama. Ši priemonė apsaugo fizinę SIM kortelę, tačiau neapsaugo nuo SIM kortelės perėmimo, kurį patvirtina pats operatorius.
7. **Įjunk automatinius naujinius** ir sistemai, ir programėlėms. Dauguma atakų naudojasi jau ištaisytomis spragomis.
8. **„iPhone“ telefone užšifruok „iCloud“.** Atverk „Settings“, savo vardą, „iCloud“, „Advanced Data Protection“ (išplėstinė duomenų apsauga). Atsarginėms kopijoms, nuotraukoms ir užrašams bus taikomas ištisinis šifravimas. Turi nurodyti atkūrimo kontaktą arba susikurti atkūrimo raktą, nes bendrovė „Apple“ nebegalės padėti atgauti prieigos. 2026 m. rugsėjo mėn. duomenimis, ši funkcija veikia Europos Sąjungoje, bet ne Jungtinėje Karalystėje, kur [„Apple“ ją atšaukė 2025 m. vasarį](https://support.apple.com/en-us/122234). Jei tau iš tikrųjų gresia tikslinės atakos (žurnalistika, aktyvizmas, vieša veikla), skiltyje „Privacy & Security“ dar peržiūrėk užrakinimo režimą („Lockdown Mode“).

## 2 lygis: pakeisk parduotuvę arba sistemą

2 lygyje imamasi paskutinių 2 svertų: programėlių parduotuvės ir sistemos atskyrimo nuo „Google“ paslaugų. Jį sudaro 2 vienas nuo kito nepriklausantys etapai. „Android“ telefone šalia „Google Play“ arba vietoj jos gali pridėti kitą programėlių šaltinį: tai užtrunka apie 1 valandą, ir šį pakeitimą galima atšaukti. Taip pat gali visą sistemą pakeisti „Android“ versija, veikiančia be „Google“: tam prireiks savaitgalio, telefono duomenys bus ištrinti, o tinka tik tam tikri modeliai. „iPhone“ telefone sistemos pakeisti negalima, o alternatyvios parduotuvės tebėra ribojamos kur kas labiau, todėl praktiškai 1 lygis su funkcija „Advanced Data Protection“ čia ir yra riba.

Už tai moki patogumu, o kartais ir programėle, kuri atsisako veikti. Tolesniuose 3 poskyriuose aiškinama, kuo pasitiki, kai išsuki iš oficialaus kelio, kaip pasirinkti sistemą ir programėlių šaltinį ir kas gali nustoti veikti, pradedant banko programėlėmis. Abiejų lentelių faktai atspindi 2026 m. rugsėjo mėn. padėtį ir greitai keičiasi.

### Kiekvieną įdiegiamą naujinį kas nors pasirašo

Telefone autentiškumas priklauso nuo parašų. Sistema pasileidžia tik tada, kai yra pasirašyta raktu, kurį pripažįsta aparatinė įranga (šį mechanizmą „Android“ vadina [patikrintu paleidimu, angl. verified boot](https://source.android.com/docs/security/features/verifiedboot)), o programėlės naujinys įdiegiamas tik tada, kai jo kūrėjo parašas sutampa su telefone jau esančios versijos parašu. Taigi trečiosios šalys, kuriomis tenka pasitikėti, yra sistemos kūrėjas, galintis išsiųsti naujinį į kiekvieną telefoną, ir programėlių parduotuvė, kuri sprendžia, ką į katalogą įtraukti ir ką iš jo pašalinti, ir žino, kas įdiegta iš kiekvienos paskyros.

Atsisakius oficialios parduotuvės šis pasitikėjimas nedingsta, o tik perkeliamas kitur. Katalogas „F-Droid“ kiekvieną programėlę surenka iš viešo programos kodo ir daugumą jų pasirašo savo raktu, todėl pasitiki ne kiekvienu kūrėju atskirai, o katalogu „F-Droid“. Daliai katalogo taikomas [atkartojamas programos surinkimas (angl. reproducible builds)](https://f-droid.org/docs/Reproducible_Builds/): bet kas gali surinkti programėlę iš naujo ir gauti lygiai tokį patį failą, o tada programėlė išlaiko savo kūrėjo parašą. Iš svetainės atsisiųsto failo netikrina niekas, todėl visa rizika slypi adrese ir pirmajame įdiegime, o pradedantiesiems oficiali parduotuvė dažnai yra saugesnė nei neatsargus atsisiuntimas.

### Kaip pasirinkti sistemą ir programėlių šaltinį

Pirmoje lentelėje lyginamos sistemos, pradedant ta, kurią jau turi po 1 lygio, o antroje lyginami „Android“ programėlių šaltiniai. Abiejų paskutiniame stulpelyje nurodyta, kas pasirašo tai, ką įdiegi.

| Sistema | Kur veikia | Privalumas | Kompromisas | Kas pasirašo naujinius |
|---|---|---|---|---|
| **Gamintojo Android arba iOS su sustiprinta apsauga** | Dabartiniame tavo telefone | Įprasti nustatymai, apribojimus galima atšaukti | „Google“ arba „Apple“ niekur nedingsta | „Apple“ arba „Google“ ir telefono gamintojas. Patikrintas paleidimas įjungtas |
| **GrapheneOS** | Suderinamuose „Google Pixel“ telefonuose, įtrauktuose į [prižiūrimą palaikomų įrenginių sąrašą](https://grapheneos.org/faq). Prieš perkant patikrink, kiek dar truks saugumo naujinių palaikymas, nes seniausiam palaikomam modeliui gali būti likę nedaug laiko. Apie partnerystę su „Motorola“ [paskelbta 2026 m. kovą](https://9to5google.com/2026/03/01/motorola-confirms-grapheneos-partnership-for-a-future-smartphone-porting-features/), ji skirta būsimiems modeliams, o kol kas nepalaikomas nė vienas dabartinis „Motorola“ telefonas | Stipriausia apsauga. „Google Play“ pasirenkama ir veikia kaip įprasta programėlė be ypatingų privilegijų | Kol kas tenka pirkti „Pixel“ telefoną. Kai kurios programėlės atsisako veikti | Projektas „GrapheneOS“. Paleidyklė (angl. bootloader) vėl užrakinama, o projekto [programėle „Auditor“](https://attestation.app/about) sistemą galima patikrinti iš antro telefono |
| **CalyxOS** | „Pixel“ telefonuose, kai kuriuose „Fairphone“ ir „Motorola“ modeliuose, telefone „SHIFTphone 8“ | Lengvesnė pradžia, naudoja „microG“ (atvirojo kodo „Google“ paslaugų pakaitalą) | Saugumo naujiniai nutrūko 2025 m. rugpjūtį, ir projektas tada patarė naudotojams sistemos atsisakyti. Naujos versijos [vėl leidžiamos nuo 2026 m. liepos 1 d.](https://calyxos.org/news/2026/07/01/calyxos-official-release-is-back/) Prieš pasirenkant šią sistemą svetainėje calyxos.org patikrink, kaip dažnai jos išleidžiamos | Ne pelno organizacija „Calyx Institute“ iš JAV. Paleidyklė vėl užrakinama, todėl patikrintas paleidimas lieka įjungtas |
| **LineageOS** | Šimtuose modelių, taip pat senesniuose | Seniems telefonams suteikia antrą gyvenimą | Saugumas priklauso nuo įrenginio ir jį prižiūrinčio savanorio. Numatytojoje versijoje „Google“ paslaugų nėra | Projektas ir tavo modelį prižiūrintis savanoris. Paleidyklė [paprastai lieka atrakinta](https://wiki.lineageos.org/faq), todėl patikrintas paleidimas išjungtas |
| **/e/OS (Murena)** | Daugelyje modelių, parduodama ir jau įdiegta telefonuose | Nusipirkus tokį telefoną nieko diegti nereikia. Kuria Europos bendrovė | Saugumo naujiniai gali pasirodyti vėliau nei kitose sistemose | Bendrovė „Murena“ ir fondas „e Foundation“. Paleidyklę vėl užrakinti galima tik kai kuriuose modeliuose |

| Programėlių šaltinis | Kas tai | Kompromisas | Kuo tenka pasitikėti |
|---|---|---|---|
| **F-Droid** | Vien atvirojo kodo programėlių katalogas, paskyros nereikia | Naujiniai gali vėluoti. Pasirinkimas mažesnis | Katalogu „F-Droid“, kuris pats surenka ir pasirašo daugumą programėlių. Kai surinkimas atkartojamas, išlieka kūrėjo parašas |
| **Aurora Store** | Atvirojo kodo „Google Play“ klientas, kuriuo galima naudotis be savo „Google“ paskyros | Anoniminiu režimu prieinamos tik nemokamos programėlės. „Google“ jam nepritaria, jo veikimas gali sutrikti | „Google“ serveriais ir kiekvieno kūrėjo parašu, kaip ir parduotuvėje „Google Play“, taip pat bendromis „Aurora Store“ paskyromis |
| **Obtainium** | Naujinius parsiunčia tiesiai iš kūrėjo versijų puslapio | Kuo pasitikėti, sprendi tu. Tarpinės peržiūros nėra | Kiekvienu kūrėju ir puslapiu, kurį pridėjai. „Android“ tikrina tik tai, ar naujinių parašas sutampa su pirmuoju |
| **Accrescent** | Parduotuvė, kuriai svarbiausia saugumas | Katalogas labai mažas | Kiekvienu kūrėju, kuris savo programėles pasirašo pats. [Pasirašyti metaduomenys](https://accrescent.app/features) nuo pirmojo įdiegimo susieja programėlę su teisingu raktu |

Programėlių diegimo ne iš „Google Play“ taisyklės keičiasi. Pagal [kūrėjų tapatybės patvirtinimo programą](https://android-developers.googleblog.com/2026/06/android-developer-verification.html) „Google“ reikalauja, kad sertifikuotuose „Android“ telefonuose diegiamų programėlių kūrėjas būtų užregistravęs tapatybę bendrovėje „Google“. Programa pradedama taikyti 2026 m. rugsėjo 30 d. Brazilijoje, Indonezijoje, Singapūre ir Tailande, o 2027 m. „Google“ planuoja ją išplėsti visame pasaulyje, todėl Europoje kol kas niekas nesikeičia. Neužsiregistravusių kūrėjų programėles turėtų likti įmanoma įdiegti pasirinkus vadinamąją išplėstinę eigą (angl. advanced flow) su papildomais patvirtinimo žingsniais. Projektas „F-Droid“ [šią programą laiko grėsme](https://f-droid.org/2025/09/29/google-developer-registration-decree.html) savo katalogui. Alternatyvios sistemos, pavyzdžiui, „GrapheneOS“, sertifikuotiems įrenginiams nepriskiriamos ir šios programos netaiko.

Daugumai žmonių protingas kelias būtų toks: dabar atlikti 1 lygio žingsnius, pridėti „F-Droid“, jei naudojiesi „Android“, o apie kitą sistemą pagalvoti tada, kai kitą kartą keisi telefoną.

### Banko programėlės ir kiti dalykai, kurie gali nustoti veikti

Tai reikia aiškiai suprasti dar prieš keičiant sistemą. Kai kurios programėlės tikrina, ar telefonas sertifikuotas „Google“, ir jei ne, atsisako veikti. Dažniausiai tai banko ir mokėjimo programėlės, kai kurios valstybės institucijų bei tapatybės programėlės ir keli žaidimai. Bekontakčiai mokėjimai per „Google Wallet“ alternatyviose sistemose neveikia.

Daug banko programėlių vis dėlto veikia, ypač sistemoje „GrapheneOS“, kai „Google Play“ įdiegta kaip įprasta programėlė. Tačiau niekas negali pažadėti, kad veiks būtent tavo banko programėlė, o padėtį gali pakeisti bet kuris naujinys.

Žmonės šią problemą sprendžia keliais būdais:

- Prieš keisdami sistemą bendruomenės sudarytuose suderinamumo sąrašuose patikrina, ar ten yra jų bankas.
- Vietoj programėlės naudojasi banko svetaine ir fizine kortele.
- Namie laiko antrą telefoną su gamintojo sistema, prijungtą prie belaidžio tinklo („Wi-Fi“), ir naudoja jį tik banko ir oficialioms programėlėms. Tai turi būti modelis, kuris vis dar gauna saugumo naujinius, nes senas telefonas, kuriam jie nebeleidžiami, yra prasta vieta banko programėlei.
- Pasirenka banką, kurio programėlė veikia.

## Klaidos, kurių verta vengti

- **Diegiant suteikti visus leidimus.** Būtent tada dėmesio skiri mažiausiai. Iš pradžių neleisk, o jei kas nors neveiks, leidimą suteiksi vėliau.
- **Pasikliauti vien piršto atspaudu ar veidu.** Biometriniai duomenys patogūs, tačiau kas nors gali pakelti telefoną tau prie veido. Abiejose sistemose biometrinį atrakinimą galima išjungti iki kito PIN kodo įvedimo. „iPhone“ telefone kelias sekundes palaikyk nuspaustą šoninį mygtuką ir vieną iš garsumo mygtukų. „Android“ telefone išjungimo meniu pasirink „Lockdown“ (užrakinimas).
- **Diegti alternatyvią sistemą vieninteliame telefone kelionės išvakarėse.** Pirmiausia išbandyk ją su banko ir bilietų programėlėmis, geriausia antrame įrenginyje.
- **Laikyti telefoną, kuris nebegauna saugumo naujinių.** Dar prieš perkant patikrink, kiek laiko gamintojas prižiūri modelį. Kai priežiūra baigiasi, žinomos spragos lieka atviros, kad ir kokie būtų nustatymai, ir tas pats galioja antram telefonui, laikomam namie dėl banko programėlių.
- **Siųstis programėlių failus iš atsitiktinių svetainių.** Jei programėles diegi ne iš „Google Play“, rinkis žinomus šaltinius, pavyzdžiui, „F-Droid“, paties kūrėjo svetainę ar vieną iš pirmiau aprašytų parduotuvių.
- **Manyti, kad nauja sistema pataisys įpročius.** Sustiprintos apsaugos telefonas, pilnas tave sekančių programėlių ir prijungtas prie tų pačių paskyrų, siunčia didelę dalį tų pačių duomenų kaip anksčiau.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kaip „kareivis-pilietis“ gali padėti decentralizuoti pasaulį: Rusijos invazijos į Ukrainą pamokos“, pranešimą skaito Alexis Roussel. Kodėl visą visuomenę palaužti sunkiau, kai atvirojo kodo technologijas valdo paprasti žmonės.
- **Palygink sistemas ir parduotuves:** „Privacy Guides“, skiltys apie „Android“ ir mobiliuosius telefonus (privacyguides.org).
- **Vadovai ir „iPhone“, ir „Android“ naudotojams:** „Surveillance Self-Defense“, parengė organizacija „Electronic Frontier Foundation“ (ssd.eff.org).
- **Projektų svetainės:** grapheneos.org, calyxos.org, lineageos.org, e.foundation, f-droid.org.
- **Kitas skyrius:** kaip paleisti paslaugas nuosavame serveryje.

## Šaltiniai

- [Supported devices and support lifetimes](https://grapheneos.org/faq), „GrapheneOS FAQ“, tikrinta 2026 m. spalio 22 d.
- [Coordinates of millions of smartphones feared stolen, sparking yet another lawsuit against data broker](https://www.theregister.com/2025/02/06/gravy_analytics_data_breach_suit/), „The Register“, 2025 m. vasario 6 d.
- [Buy a phone, get a tracker: unauthorized tracking code illegally installed on Android phones](https://noyb.eu/en/buy-phone-get-tracker-unauthorized-tracking-code-illegally-installed-android-phones), „noyb“, 2021 m. balandžio 7 d.
- [Android developer verification: Building a safer ecosystem together](https://android-developers.googleblog.com/2026/06/android-developer-verification.html), „Android Developers Blog“, 2026 m. birželio 18 d.
- [F-Droid and Google's developer registration decree](https://f-droid.org/2025/09/29/google-developer-registration-decree.html), „F-Droid“, 2025 m. rugsėjo 29 d.
- [Verified Boot](https://source.android.com/docs/security/features/verifiedboot), „Android Open Source Project“, žiūrėta 2026 m. rugsėjį.
- [Reproducible builds](https://f-droid.org/docs/Reproducible_Builds/), „F-Droid“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [Frequently asked questions](https://wiki.lineageos.org/faq), „LineageOS Wiki“, žiūrėta 2026 m. rugsėjį.
- [Accrescent features](https://accrescent.app/features), „Accrescent“, žiūrėta 2026 m. rugsėjį.
- [CalyxOS is back: download release 7.2.2.0 with full maintenance support](https://calyxos.org/news/2026/07/01/calyxos-official-release-is-back/), „CalyxOS“, 2026 m. liepos 1 d.
- [Apple can no longer offer Advanced Data Protection in the United Kingdom to new users](https://support.apple.com/en-us/122234), „Apple Support“, 2025 m.

## Tavo veiksmų sąrašas

- [ ] Pašalink programėles, kuriomis nebesinaudoji (5 min.)
- [ ] Peržiūrėk buvimo vietos, mikrofono, kameros ir kontaktų leidimus (1 val.)
- [ ] Ištrink reklamos identifikatorių arba išjunk sekimą (5 min.)
- [ ] Nustatyk 6 ar daugiau skaitmenų PIN kodą ir SIM kortelės PIN kodą (5 min.)
- [ ] „iPhone“ telefone įjunk „Advanced Data Protection“. „Android“ telefone įdiek „F-Droid“ ir išbandyk 1 programėlę (1 val.)
