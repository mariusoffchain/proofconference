// Placeholder, replaced by the first build (book-drafts/build.py).
const CACHE = 'proof-book-bootstrap';
const CORE = [

];
