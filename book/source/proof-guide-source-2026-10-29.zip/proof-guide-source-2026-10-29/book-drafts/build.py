"""Builds the online PROOF book (static HTML) from the Markdown chapters in this folder.

Usage:  python3 build.py [--dry-run]   (needs Python-Markdown 3.9: guide-ui/scripts/requirements.txt)
Input:  book-drafts/NN-slug.md         (NN decides the order; first digit = part: 1 privacy, 2 autonomy, 3 bitcoin)
Input:  book-drafts/lt/NN-slug.md      the Lithuanian sources, same file names
Output: the English and Lithuanian editions in the guide UI, written by guide-ui/build_integration.py (see
        guide-ui/INTEGRATION.md): ../book/en/**/index.html and ../book/**/index.html (each with its legal page,
        legal/), ../book/guide-assets/ (interface, fonts, licence texts), the source archive ../book/source/*.zip,
        ../book/sw.js and the book entries of ../sitemap.xml. book.css and book.js are read, never written.

The functions below (load, render_page, render_cover, build_edition...) are the former renderer, kept for reference
(build_integration.py uses summary(), autolink() and the replays data). Its former main() deleted ../book/en/ before
writing: it is not run any more.

In the PROOF workspace this folder is a separate private Git repository. Only selected files of it are published, in
the source archive (list in guide-ui/source_archive.py, rebuild steps in guide-ui/legal/SOURCE-README.md); the
generated outputs belong to the site. Building does not publish.
"""
import re, html, hashlib, pathlib, shutil
import markdown

HERE = pathlib.Path(__file__).parent
ROOT = HERE.parent
# Two editions from the same generator. English lives in /book/en/, Lithuanian (the language of the QR code) in /book/.
# The Lithuanian sources are in lt/ with the same file names; its interface strings are in lt/ui.json.
LANG = 'en'; SRC = HERE; OUT = ROOT / 'book' / 'en'; BASE = '/book/en/'; OTHER = None

PARTS = {'1': ('priv', 'Part 1', 'Proof of Privacy'), '2': ('auto', 'Part 2', 'Proof of Autonomy'), '3': ('mono', 'Part 3', 'Proof of Work')}
CL_HEADING = 'Your checklist'
OPENER_SLUGS = {'10': 'privacy', '20': 'autonomy', '30': 'work'}
EFFORT = {'5 min': '1', '1 hour': '2', 'weekend': '3'}
TALK_WORDS = 'privacy|autonomy|work'

UI_EN = dict(
    book_title='Your privacy guide', site='PROOF &lt;conference&gt;',
    desc='The PROOF conference book: a practical manual to take back your privacy, your autonomy and your money.',
    note='The practical manual of PROOF: why it matters, how it works, what to set up, step by step. Several tools for every need, none of them paid to be here. No account, no cookies, no tracking.',
    dash_label='Your progress', dash_read='chapters read', dash_done='actions done', dash_open='Open the checklist',
    contents='Contents', read_count='chapters read', start='Start reading', resume='Continue reading', checklist='Your checklist', checklist_nav='checklist', contents_nav='contents', replays_nav='replays', glossary='Glossary',
    prev='Previous', next='Next', back='Back to contents', read='read the chapter',
    cl_h1='Your checklist', cl_kicker='Recap',
    cl_intro='Every action from every chapter, in one place. Tick off what you have done: your progress is saved only in this browser, and nothing is sent anywhere.',
    progress='Progress', f_all='All', efforts={'1': '5 min', '2': '1 hour', '3': 'Weekend'}, reset='Reset', confirm='Click again to erase everything',
    alldone='All done. Sovereignty taken back.',
    after_label='&lt;after&gt; What\'s next', after_h2='After the<br>conference',
    after_p1='The talk recordings are published on this page and on the <a href="/en/#replays" style="color:inherit">conference site</a>.',
    after_p2='This book stays free and will keep growing.',
    comm_label='Community', comm_h2='Stay in<br>touch',
    comm_p='Questions, corrections, a tool we should add? Write to <a href="mailto:contact@proofconference.com" style="color:inherit">contact@proofconference.com</a> or join the <a href="https://www.facebook.com/groups/309991789709782/" target="_blank" rel="noopener noreferrer" style="color:inherit">Facebook group</a>.',
    sponsor='Sole sponsor',
    code_label='Conference code', code_label15='Sole sponsor · conference code', code_key='PROOF',
    code_txt='Bringin, the sponsor of the conference, gives PROOF attendees a code to enter in its app when opening an account: 50% off its fees for 3 months.',
    code_note='Bringin is one option among others in chapters 13 and 15. The book takes no commission.',
    code_note15='Bringin is listed above among the other routes, and the same limits apply: the euro side is a regulated account with identity verification.',
    code_copy='Copy', code_copied='Copied', code_anchor='<h2>Step by step</h2>',
    footer_c='no cookies · no tracking · no bullshit', f_terms='terms', f_priv='privacy', f_contact='contact',
    h2_pre='Your', h2_post='guide', start_label='Start reading', hero_label='&lt;book&gt; · PROOF &lt;conference&gt;',
    skip='Skip to content', lang_other='Lietuviška versija', lang_other_code='lt',
)

UI = UI_EN

# Talks of the conference: same list as the replays of the home pages (site/content.json), rendered by the same function.
# Each talk lists the book pages ("chapters", slugs) where it appears; the cover shows them all below the contents.
import sys as _sys
_sys.path.insert(0, str(HERE / 'site'))
from build_site import replay_item, T as _T, REPLAYS_TAG
REPLAYS = __import__('json').loads((HERE / 'site' / 'content.json').read_text(encoding='utf-8'))['replays']
TALK_ANCHORS = {'en': ['<h2>Go further</h2>', '<h2>Sources</h2>'], 'lt': ['<h2>Norintiems daugiau</h2>', '<h2>Šaltiniai</h2>']}
REPLAYS_JS = REPLAYS_TAG + '\n'

md = markdown.Markdown(extensions=['tables', 'sane_lists'])

# Version the script and the stylesheet in their URL: a page and the assets it was built for always travel together,
# so a browser can never run an old cached script against a new page (GitHub Pages caches files for 10 minutes).
ASSET_V = hashlib.sha1((ROOT / 'book' / 'book.js').read_bytes() + (ROOT / 'book' / 'book.css').read_bytes()).hexdigest()[:8]


def esc(s): return html.escape(s, quote=True)


def configure(lang):
    """Point the module-level settings at one edition."""
    global LANG, SRC, OUT, BASE, OTHER, UI, PARTS, EFFORT, CL_HEADING, TALK_WORDS
    import json
    LANG = lang
    if lang == 'en':
        SRC, OUT, BASE, UI = HERE, ROOT / 'book' / 'en', '/book/en/', UI_EN
        PARTS = {'1': ('priv', 'Part 1', 'Proof of Privacy'), '2': ('auto', 'Part 2', 'Proof of Autonomy'), '3': ('mono', 'Part 3', 'Proof of Work')}
        EFFORT = {'5 min': '1', '1 hour': '2', 'weekend': '3'}
        CL_HEADING, TALK_WORDS = 'Your checklist', 'privacy|autonomy|work'
        OTHER = ('/book/', 'LT') if lt_ready() else None
    else:
        SRC, OUT, BASE = HERE / 'lt', ROOT / 'book', '/book/'
        UI = json.loads((HERE / 'lt' / 'ui.json').read_text())
        PARTS = {'1': ('priv', '1 dalis', 'Privatumo įrodymas'), '2': ('auto', '2 dalis', 'Autonomijos įrodymas'), '3': ('mono', '3 dalis', 'Darbo įrodymas')}
        EFFORT = {'5 min.': '1', '1 val.': '2', 'savaitgalis': '3'}
        CL_HEADING, TALK_WORDS = 'Tavo veiksmų sąrašas', UI['talk_words']
        OTHER = ('/book/en/', 'EN')


def lt_ready():
    """The Lithuanian edition is built only when every chapter has been translated."""
    want = {f.name for f in HERE.glob('[0-9][0-9]-*.md')}
    have = {f.name for f in (HERE / 'lt').glob('[0-9][0-9]-*.md')}
    return bool(want) and want <= have and (HERE / 'lt' / 'ui.json').exists()


# Official websites of the tools named in the book (book-drafts/links.json). Used to link tool names inside tables.
import json as _json
_links_file = HERE / 'links.json'
TOOL_LINKS = _json.loads(_links_file.read_text()) if _links_file.exists() else {}
_TOOL_RE = (re.compile(r'(?<![\w-])(' + '|'.join(re.escape(k) for k in sorted(TOOL_LINKS, key=len, reverse=True)) + r')(?![\w-])')
            if TOOL_LINKS else None)
_DOMAIN_RE = re.compile(r'(?<![\w@/.-])((?:[a-z0-9-]+\.)+[a-z]{2,}(?:/[\w\-./%#?=&]*[\w/])?)')


def autolink(h):
    """Turn bare domains (anywhere) and known tool names (inside table cells) into links. Never touches text already in a link."""
    out, in_a, in_td, seen = [], 0, 0, set()
    for tok in re.split(r'(<[^>]+>)', h):
        if tok.startswith('<'):
            low = tok.lower()
            if low.startswith('<a'): in_a += 1
            elif low.startswith('</a'): in_a = max(0, in_a - 1)
            elif low.startswith('<tr'): seen = set()            # link each tool once per table ROW, not once per cell
            elif low.startswith('<td'): in_td += 1
            elif low.startswith('</td'): in_td = max(0, in_td - 1)
            out.append(tok); continue
        if in_a or not tok.strip():
            out.append(tok); continue
        slots = []
        def keep(html_piece):
            slots.append(html_piece); return f'\x00{len(slots) - 1}\x00'
        tok = _DOMAIN_RE.sub(lambda m: keep(f'<a href="https://{m.group(1)}">{m.group(1)}</a>'), tok)
        if in_td and _TOOL_RE:
            def tool(m):
                name = m.group(1)
                after = m.string[m.end():m.end() + 8].lower()
                if name in seen or after.startswith(' server'):   # "Electrum server" is not the Electrum wallet
                    return name
                seen.add(name)
                return keep(f'<a href="{TOOL_LINKS[name]}">{name}</a>')
            tok = _TOOL_RE.sub(tool, tok)
        out.append(re.sub(r'\x00(\d+)\x00', lambda m: slots[int(m.group(1))], tok))
    return ''.join(out)


def load():
    pages = []
    for f in sorted(SRC.glob('[0-9][0-9]-*.md')):
        nn = f.name[:2]
        text = f.read_text().strip()
        if re.search('[–—]', text):
            raise SystemExit(f'Long dash found in {f.name}')
        m = re.match(r'#\s+(.+)', text)
        full = m.group(1).strip()
        body = text[m.end():].strip()
        kicker, _, title = full.partition(': ')
        if not title: kicker, title = '', full
        slug = OPENER_SLUGS.get(nn) or f.stem[3:]
        part = PARTS.get(nn[0])
        kind = 'opener' if nn in OPENER_SLUGS else ('chapter' if part else 'extra')
        # checklist section
        items = []
        cm = re.search(r'\n##\s+' + re.escape(CL_HEADING) + r'\s*\n(.*?)(?=\n##\s|\Z)', body, re.S)
        if cm:
            for i, line in enumerate(re.findall(r'-\s*\[ \]\s*(.+)', cm.group(1)), 1):
                em = re.search(r'\((' + '|'.join(re.escape(k) for k in EFFORT) + r')\)\s*$', line)
                effort = EFFORT[em.group(1)] if em else '2'
                label = line[:em.start()].strip() if em else line.strip()
                label = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', label).replace('**', '')  # checklist labels are plain text
                items.append(dict(id=f'{slug}-{i}', label=label, effort=effort))
            body = body[:cm.start()] + body[cm.end():]
        md.reset()
        h = md.convert(body)
        h = re.sub(r'<table>', '<div class="bk-table"><table>', h).replace('</table>', '</table></div>')
        h = autolink(h)
        h = re.sub(r'<a href="(https?://[^"]+)"', r'<a href="\1" target="_blank" rel="noopener noreferrer"', h)
        pages.append(dict(nn=nn, slug=slug, kicker=kicker, title=title, full=full, part=part, kind=kind, html=h, items=items,
                          url=f'{BASE}{slug}/', desc=summary(body), src=f.name))
    return pages


def summary(text, limit=160):
    """Meta description of a page: the start of its first paragraphs (the "In brief" section of a chapter), whole sentences
    while they fit in `limit` characters; a sentence that does not fit is cut at a word, so the text is never too short."""
    paras = [p for p in re.split(r'\n\s*\n', text) if p.strip() and not p.lstrip().startswith('#')][:2]
    if len(paras) > 1 and re.match(r'\s*(\*\*|[-|*]|\d+\.)', paras[1]):  # a glossary term or a list is not prose
        paras = paras[:1]
    para = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', ' '.join(paras)).replace('**', '').replace('`', '')
    para = ' '.join(para.split())
    # a sentence ends before a capital (or an opening quote): "2025 m. balandį" and "e.g. a" do not split
    out = ''
    for sentence in re.split(r'(?<=[.!?])\s+(?=[A-ZĄČĘĖĮŠŲŪŽ„“"])', para):
        if len(out) + 1 + len(sentence) <= limit:
            out = f'{out} {sentence}'.strip()
            if len(out) >= 120: break
            continue
        if len(out) < 110:
            room = limit - 2 - len(out)
            out = f"{out} {sentence[:room].rsplit(' ', 1)[0].rstrip(',;:')}…".strip()
        break
    return out


NAVP = ''  # nav progress element, filled in main() once the chapters are loaded
SITE = 'https://proofconference.com'
BOOK_INDEXABLE_SINCE = '2026-10-07'  # noindex removed (commit c0393dd): no book page in the sitemap is dated earlier


def head(title, extra='', nav_progress=True, path='', desc=None, og_type='article'):
    desc = esc(desc or UI['desc'])
    url = f'{SITE}{BASE}{path}'
    image = f'{SITE}/thumbnail-proof-{LANG}.jpg'
    return f'''<!DOCTYPE html>
<html lang="{LANG}">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="canonical" href="{url}">
{hreflang(path)}<meta property="og:type" content="{og_type}">
<meta property="og:site_name" content="PROOF &lt;conference&gt;">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{image}">
<meta property="og:locale" content="{'lt_LT' if LANG == 'lt' else 'en_US'}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{desc}">
<meta name="twitter:image" content="{image}">
<link rel="preload" href="/fonts/righteous-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/fonts/jetbrainsmono-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/fonts/fonts.css">
<link rel="stylesheet" href="/style.css">
<link rel="stylesheet" href="/book/book.css?v={ASSET_V}">
<script defer src="/external-links.js"></script>
{extra}</head>
<body>
<a class="skip-link" href="#main">{UI['skip']}</a>

<!-- NAV -->
<nav class="{'bk-cover-nav' if not nav_progress else 'bk-inner-nav'}">
  <a href="{'/' if LANG == 'lt' else '/en/'}" class="nav-logo-text bk-logo-proof" style="text-decoration:none" title="PROOF &lt;conference&gt;">PROOF</a>
  <a href="{BASE}" class="nav-logo-text bk-logo-book" style="text-decoration:none" title="{UI['book_title']}">BOOK</a>
  <ul class="nav-links">
    <li><a href="{BASE}#contents">&lt;{UI['contents_nav']}&gt;</a></li>
    <li><a href="{BASE}#replays">&lt;{UI['replays_nav']}&gt;</a></li>
    <li><a href="{BASE}checklist/">&lt;{UI['checklist_nav']}&gt;</a></li>
    <li><a href="{BASE}glossary/">&lt;{UI['glossary'].lower()}&gt;</a></li>
  </ul>
  {NAVP if nav_progress else '<span class="bk-navps"></span>'}
  {lang_button(path)}
  <button class="bk-menu-btn" id="bk-menu-btn" aria-expanded="false" aria-controls="bk-menu" aria-label="Menu"><span></span><span></span><span></span></button>
</nav>
<!-- Phone menu: the nav keeps the logo (back to the conference site), the 2 gauges and this button -->
<div class="bk-menu" id="bk-menu" hidden>
  <a href="{BASE}#contents">&lt;{UI['contents_nav']}&gt;</a>
  <a href="{BASE}#replays">&lt;{UI['replays_nav']}&gt;</a>
  <a href="{BASE}checklist/">&lt;{UI['checklist_nav']}&gt;</a>
  <a href="{BASE}glossary/">&lt;{UI['glossary'].lower()}&gt;</a>
  {lang_link(path)}
  <a href="{'/' if LANG == 'lt' else '/en/'}" class="bk-menu-lang">PROOF &lt;conference&gt;</a>
</div>
'''


def hreflang(path):
    if not OTHER: return ''
    lt, en = ('/book/', '/book/en/')
    return (f'<link rel="alternate" hreflang="lt" href="{SITE}{lt}{path}">\n'
            f'<link rel="alternate" hreflang="en" href="{SITE}{en}{path}">\n'
            f'<link rel="alternate" hreflang="x-default" href="{SITE}{en}{path}">\n')  # same choice as the site's home page


def lang_link(path):
    if not OTHER: return ''
    names = {'EN': 'English', 'LT': 'Lietuvių'}
    return f'<a href="{OTHER[0]}{path}" class="bk-menu-lang">{OTHER[1]} · {names[OTHER[1]]}</a>'


def lang_button(path):
    if not OTHER: return ''
    cls = 'lang-btn lt' if LANG == 'lt' else 'lang-btn'
    # A real link: works without JavaScript, announced as a link, labelled in the target language
    return f'<a class="{cls}" id="lang-btn" href="{OTHER[0]}{path}" hreflang="{UI["lang_other_code"]}" lang="{UI["lang_other_code"]}" aria-label="{UI["lang_other"]}">{OTHER[1]}</a>'


def foot():
    return f'''
<!-- FOOTER -->
<footer>
  <span>PROOF &lt;conference&gt; Vilnius 2026</span>
  <span id="footer-center">{UI['footer_c']}</span>
  <span><a href="mailto:contact@proofconference.com">{UI['f_contact']}</a></span>
</footer>

<script src="/book/book.js?v={ASSET_V}" defer></script>
</body>
</html>
'''


def cl_items(items, with_link=None):
    out = []
    for it in items:
        more = f'<a class="bk-cl-more" href="{with_link}">{UI["read"]}</a>' if with_link else ''
        out.append(f'''      <li class="bk-cl-item" data-id="{it['id']}" data-effort="{it['effort']}">
        <label class="bk-check"><input type="checkbox" id="{it['id']}" aria-label="{esc(it['label'])}"><span class="bk-box"></span></label>
        <label class="bk-cl-title" for="{it['id']}">{html.escape(it['label'], quote=False)}</label>
        <span class="bk-effort">{UI['efforts'][it['effort']]}</span>{more}
      </li>''')
    return '\n'.join(out)


def pager(seq, i):
    prev_p = seq[i - 1] if i > 0 else None
    next_p = seq[i + 1] if i + 1 < len(seq) else None
    a = ['<div class="bk-pager">']  # not a <nav>: the site styles every nav as the fixed top bar
    a.append(f'<a class="bk-prev" href="{prev_p["url"]}"><span>{UI["prev"]}</span>{prev_p["title"]}</a>' if prev_p else '<span></span>')
    a.append(f'<a class="bk-next" href="{next_p["url"]}"><span>{UI["next"]}</span>{next_p["title"]}</a>' if next_p else '<span></span>')
    a.append('</div>')
    return '\n'.join(a)


def ticket(light, label, note):
    """Bringin's conference code as a small ticket: light on the white cover column, dark in chapter 15."""
    cls = 'bk-code bk-ticket light' if light else 'bk-code bk-ticket'
    return f'''<aside class="{cls}" id="bk-code">
  <p class="bk-label">{label}</p>
  <div class="bk-ticket-mid">
    <span class="bk-code-key">{UI['code_key']}</span>
    <button type="button" class="bk-code-copy" onclick="navigator.clipboard&&navigator.clipboard.writeText('{UI['code_key']}');this.textContent='{UI['code_copied']}';var l=document.getElementById('bk-code-live');if(l)l.textContent='{UI['code_copied']}'">{UI['code_copy']}</button>
    <span class="sr-only" aria-live="polite" id="bk-code-live"></span>
  </div>
  <p class="bk-code-txt">{UI['code_txt']}</p>
  <p class="bk-code-note">{note}</p>
</aside>'''


def talk_block(slug):
    """The talks attached to a book page, as a block placed before "Go further" (or "Sources", or at the end)."""
    talks = [it for it in REPLAYS['items'] if slug in it.get('chapters', [])]
    if not talks: return ''
    items = '\n'.join(replay_item(it, REPLAYS, LANG, indent='  ') for it in talks)
    return (f'<aside class="bk-talk" aria-label="{esc(_T(REPLAYS["chapter_label"], LANG))}">\n'
            f'<p class="bk-label">{_T(REPLAYS["chapter_label"], LANG)}</p>\n<ul class="rp-list">\n{items}\n</ul>\n</aside>\n')


def render_page(p, seq, i, i_in_seq=True):
    cls = p['part'][0] if p['part'] else 'plain'
    kicker = p['kicker'] or ''
    if p['kind'] == 'chapter': kicker = f"{p['part'][2]} · {kicker}"
    body = p['html']
    if p['slug'] == 'glossary':
        # One colour per theme: privacy green, autonomy violet, money and Bitcoin orange (same classes as the parts)
        themes = ['priv', 'auto', 'mono', 'mono']
        chunks = body.split('<h2>')
        body = chunks[0] + ''.join(
            f'<section class="bk-gloss {themes[min(n, len(themes) - 1)]}"><h2>{chunk}</section>' for n, chunk in enumerate(chunks[1:]))
    if p['slug'] == 'lightning-and-euros':
        body = body.replace(UI['code_anchor'], ticket(False, UI['code_label15'], UI['code_note15']) + '\n' + UI['code_anchor'], 1)
    talk = talk_block(p['slug'])
    if talk:
        anchor = next((a for a in TALK_ANCHORS[LANG] if a in body), None)
        body = body.replace(anchor, talk + anchor, 1) if anchor else body + '\n' + talk
    box = ''
    if p['items']:
        box = f'''
    <section class="bk-cl-box">
      <h2>{UI['checklist']}</h2>
      <ul class="bk-cl">
{cl_items(p['items'])}
      </ul>
      <p class="bk-cl-all"><a href="{BASE}checklist/">{UI['cl_h1']}: {UI['f_all'].lower()} →</a></p>
    </section>'''
    return head(f"{p['title']} · {UI['site']}", extra=REPLAYS_JS if talk else '', path=f"{p['slug']}/", desc=p['desc']) + f'''
<div class="bk-read {cls}" aria-hidden="true"><i id="bk-read"></i></div>
<main id="main" class="bk-page {cls} page-top" data-slug="{p['slug'] if i_in_seq else ''}">
  <header class="bk-head">
    <p class="bk-label">{kicker}</p>
    <h1>{p['title']}</h1>
  </header>
  <article class="bk-article">
{body}
  </article>{box}
  {pager(seq, i)}
  <p class="bk-back"><a href="{BASE}#contents">{UI['back']}</a></p>
</main>
''' + foot()


def render_cover(pages, seq):
    toc = []
    intro = [p for p in pages if p['nn'][0] == '0']
    for p in intro:
        toc.append(f'<ol class="bk-toc"><li><a href="{p["url"]}" data-slug="{p["slug"]}"><span>00</span>{p["title"]}</a></li></ol>')
    n = 0
    for key, (cls, plabel, pname) in PARTS.items():
        opener = next((p for p in pages if p['kind'] == 'opener' and p['nn'][0] == key), None)
        chapters = [p for p in pages if p['kind'] == 'chapter' and p['nn'][0] == key]
        toc.append(f'<div class="bk-toc-part {cls}"><p class="bk-label">{plabel}</p>')
        toc.append(f'<h3><a href="{opener["url"] if opener else "#"}">{pname}</a></h3><ol class="bk-toc">')
        if opener:
            toc.append(f'<li><a href="{opener["url"]}" data-slug="{opener["slug"]}"><span>··</span>{opener["html"].split("<h2>")[1].split("</h2>")[0] if "<h2>" in opener["html"] else pname}</a></li>')
        for p in chapters:
            n += 1
            toc.append(f'<li><a href="{p["url"]}" data-slug="{p["slug"]}" data-count="1"><span>{n:02d}</span>{p["title"]}</a></li>')
        toc.append('</ol></div>')
    toc.append(f'<div class="bk-toc-part plain"><p class="bk-label">{UI["cl_kicker"]}</p><ol class="bk-toc">')
    toc.append(f'<li><a href="{BASE}checklist/"><span>✓</span>{UI["cl_h1"]}</a></li>')
    toc.append(f'<li><a href="{BASE}glossary/"><span>Az</span>{UI["glossary"]}</a></li></ol></div>')
    h2 = f'{UI["h2_pre"]}<br><span class="bk-tw" id="bk-tw" data-words="{TALK_WORDS}" aria-hidden="true">{TALK_WORDS.split("|")[0]}</span><span class="sr-only">{TALK_WORDS.split("|")[0]}</span><br>{UI["h2_post"]}'
    import json
    cmap = {p['slug']: p['part'][0] for p in pages if p['part'] and p['items']}
    totals = {cls: sum(len(p['items']) for p in pages if p['part'] and p['part'][0] == cls) for cls, _, _ in PARTS.values()}
    total = sum(totals.values())
    readable = [p['slug'] for p in seq if p['kind'] == 'chapter']  # intro and part essays get a tick in the contents, but are not counted
    part_rows = '\n'.join(
        f'      <li class="{cls}" data-part="{cls}"><span class="bk-dash-p">{pname}</span>'
        f'<span class="bk-bar" aria-hidden="true"><i></i></span><span class="bk-dash-c">0 / {totals[cls]}</span></li>'
        for cls, _, pname in PARTS.values())
    # The cover has no gauges in the nav: its hero is the dashboard (same white/black split as the conference home page)
    def toc_name(p):
        return p['html'].split('<h2>')[1].split('</h2>')[0] if p['kind'] == 'opener' and '<h2>' in p['html'] else p['title']
    by_slug = {p['slug']: p for p in pages}
    rep_items = '\n'.join(
        replay_item(it, REPLAYS, LANG, book_link=next(((by_slug[c]['url'], toc_name(by_slug[c])) for c in it.get('chapters', []) if c in by_slug), None))
        for it in REPLAYS['items'])
    return head(f"{UI['book_title']} · {UI['site']}", extra=REPLAYS_JS, nav_progress=False, og_type='website') + f'''
<!-- COVER - blanc gauche (titre) / noir droite (tableau de bord) -->
<main id="main">
<section class="hero bk-hero">
  <div class="hero-left">
    <div class="hero-left-noise"></div>
    <p class="sec-label bk-hero-label">{UI['hero_label']}</p>
    <h1 class="bk-hero-title">{h2}</h1>
    <p class="bk-hero-note">{UI['note']}</p>
  </div>
  <div class="hero-right bk-dash" id="bk-dash" data-map="{esc(json.dumps(cmap))}" data-totals="{esc(json.dumps(totals))}" data-slugs="{esc(json.dumps(readable))}">
    <p class="sec-label">{UI['dash_label']}</p>
    <div class="bk-dash-stats">
      <div class="bk-dash-stat" id="bk-dash-read">
        <span class="bk-dash-n"><b>0</b> / {len(readable)}</span>
        <span class="bk-dash-l">{UI['dash_read']}</span>
        <span class="bk-bar" aria-hidden="true"><i class="white"></i></span>
      </div>
      <div class="bk-dash-stat" id="bk-dash-done">
        <span class="bk-dash-n"><b>0</b> / {total}</span>
        <span class="bk-dash-l">{UI['dash_done']}</span>
        <span class="bk-bar" aria-hidden="true"><i class="priv"></i><i class="auto"></i><i class="mono"></i></span>
      </div>
    </div>
    <ul class="bk-dash-parts">
{part_rows}
    </ul>
    <div class="bk-dash-cta">
      <a href="{seq[0]['url']}" class="hero-btn" id="bk-start" data-resume="{UI['resume']}">{UI['start']}</a>
      <a href="{BASE}checklist/" class="bk-dash-link">{UI['dash_open']}</a>
    </div>
  </div>
</section>

<!-- CONTENTS -->
<section class="bk-toc-wrap" id="contents">
  <p class="bk-sub bk-sub-row"><span>{UI['contents']}</span><span id="bk-readcount" data-total="{len(readable)}" data-label="{UI['read_count']}">0 / {len(readable)} {UI['read_count']}</span></p>
  {chr(10).join(toc)}
</section>

<!-- REPLAYS (site/content.json) -->
<section class="replays-section bk-replays" id="replays">
  <div class="replays-inner">
    <p class="sec-label">{_T(REPLAYS['label'], LANG)}</p>
    <h2>{_T(REPLAYS['h2'], LANG)}</h2>
    <p class="replays-p">{_T(REPLAYS['book_p'], LANG)}</p>
    <ul class="rp-list">
{rep_items}
    </ul>
  </div>
</section>

<!-- AFTER THE CONFERENCE -->
<section class="about-split bk-after" id="next">
  <div class="about-left">
    <p class="sec-label">{UI['after_label']}</p>
    <h2>{UI['after_h2']}</h2>
    <p>{UI['after_p1']}</p>
    <p>{UI['after_p2']}</p>
  </div>
  <div class="about-right">
    <p class="sec-label" style="color:var(--black)">{UI['comm_label']}</p>
    <h2>{UI['comm_h2']}</h2>
    <p>{UI['comm_p']}</p>
    <p class="sec-label" style="color:var(--black);margin-top:40px">{UI['sponsor']}</p>
    <a href="https://bringin.app/" target="_blank" rel="noopener noreferrer"><img src="/bringin-logo.svg" alt="Bringin" style="width:200px;display:block"></a>
    {ticket(True, UI['code_label'], UI['code_note'])}
  </div>
</section>
</main>
''' + foot()


def render_checklist(pages):
    total = sum(len(p['items']) for p in pages)
    groups = []
    for key, (cls, plabel, pname) in PARTS.items():
        chapters = [p for p in pages if p['nn'][0] == key and p['items']]
        if not chapters: continue
        n = sum(len(p['items']) for p in chapters)
        g = [f'<div class="bk-cl-group {cls}" data-block="{cls}">',
             f'<div class="bk-cl-head"><span class="bk-cl-name">{pname}</span><span class="bk-count">0 / {n}</span></div>']
        for p in chapters:
            g.append(f'<p class="bk-cl-chapter"><a href="{p["url"]}">{p["title"]}</a></p>\n<ul class="bk-cl">\n{cl_items(p["items"], p["url"])}\n</ul>')
        g.append('</div>')
        groups.append('\n'.join(g))
    return head(f"{UI['cl_h1']} · {UI['site']}", path='checklist/', desc=summary(UI['cl_intro'])) + f'''
<main id="main" class="bk-page plain page-top">
  <header class="bk-head">
    <p class="bk-label">{UI['cl_kicker']}</p>
    <h1>{UI['cl_h1']}</h1>
  </header>
  <div class="bk-article"><p>{UI['cl_intro']}</p></div>
  <div class="bk-tools-bar">
    <div class="bk-progress">
      <span>{UI['progress']} <strong id="bk-done">0 / {total}</strong></span>
      <div class="bk-bar" aria-hidden="true"><i class="priv"></i><i class="auto"></i><i class="mono"></i></div>
    </div>
    <div class="bk-filters">
      <button class="bk-filter" data-filter="all" aria-pressed="true">{UI['f_all']}</button>
      <button class="bk-filter" data-filter="1" aria-pressed="false">{UI['efforts']['1']}</button>
      <button class="bk-filter" data-filter="2" aria-pressed="false">{UI['efforts']['2']}</button>
      <button class="bk-filter" data-filter="3" aria-pressed="false">{UI['efforts']['3']}</button>
    </div>
    <button class="bk-reset" id="bk-reset" data-confirm="{esc(UI['confirm'])}">{UI['reset']}</button>
  </div>
  {chr(10).join(groups)}
  <p class="bk-alldone" id="bk-alldone" hidden>{UI['alldone']}</p>
  <p class="bk-back"><a href="{BASE}#contents">{UI['back']}</a></p>
</main>
''' + foot()


def build_edition(lang):
    """Generate one edition. Returns (urls, pages)."""
    global NAVP
    import json
    configure(lang)
    pages = load()
    cmap = {p['slug']: p['part'][0] for p in pages if p['part'] and p['items']}
    total = sum(len(p['items']) for p in pages)
    readable = [p['slug'] for p in pages if p['kind'] == 'chapter']  # gauges count the numbered chapters only
    book_icon = ('<svg class="bk-navp-l" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" '
                 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H2z"/>'
                 '<path d="M22 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8z"/></svg>')
    NAVP = (f'<div class="bk-navps">'
            f'<a href="{BASE}#contents" class="bk-navp bk-navr" id="bk-navr" data-slugs="{esc(json.dumps(readable))}" title="{UI["read_count"]}">'
            f'{book_icon}<span class="sr-only">{UI["read_count"]}: </span><span class="bk-navp-n">0 / {len(readable)}</span>'
            f'<span class="bk-bar" aria-hidden="true"><i></i></span></a>'
            f'<a href="{BASE}checklist/" class="bk-navp" id="bk-navp" data-total="{total}" data-map="{esc(json.dumps(cmap))}" '
            f'title="{UI["cl_h1"]}"><span class="bk-navp-l" aria-hidden="true">✓</span><span class="sr-only">{UI["cl_h1"]}: </span><span class="bk-navp-n">0 / {total}</span>'
            f'<span class="bk-bar" aria-hidden="true"><i class="priv"></i><i class="auto"></i><i class="mono"></i></span></a></div>')
    seq = [p for p in pages if p['slug'] != 'glossary']
    slugs = [p['slug'] for p in pages] + ['checklist']
    if lang == 'en':
        # /book/en/ belongs to guide-ui/build_integration.py now: never delete it nor write the former pages over it
        raise SystemExit('The English edition is built by guide-ui/build_integration.py (python3 build.py).')
    else:
        # /book/ also holds en/, book.css, book.js and sw.js: only replace the Lithuanian chapter folders
        for slug in slugs:
            if (OUT / slug).exists(): shutil.rmtree(OUT / slug)
    urls = [BASE]
    (OUT / 'index.html').write_text(render_cover(pages, seq))
    for p in pages:
        d = OUT / p['slug']; d.mkdir()
        i = seq.index(p) if p in seq else None
        (d / 'index.html').write_text(render_page(p, seq if i is not None else [p], i if i is not None else 0, i is not None))
        urls.append(p['url'])
    (OUT / 'checklist').mkdir()
    (OUT / 'checklist' / 'index.html').write_text(render_checklist(pages))
    urls.append(f'{BASE}checklist/')
    words = sum(len(re.sub(r'<[^>]+>', ' ', p['html']).split()) for p in pages)
    print(f'[{lang}] {len(pages)} pages, {sum(len(p["items"]) for p in pages)} checklist items, ~{words} words')
    return urls, pages


def main():
    """English edition in the guide UI: targeted writes only, the Lithuanian edition is left as it is."""
    _sys.path.insert(0, str(HERE / 'guide-ui'))
    import build_integration
    build_integration.main(_sys.argv[1:])


def legacy_main():
    """Former default, NOT run: it rebuilt both editions with this renderer and deleted ../book/en/ first.
    build_edition('en') now stops before deleting anything."""
    urls, pages = build_edition('en')
    if lt_ready():
        lt_urls, lt_pages = build_edition('lt')
        urls += lt_urls; pages += lt_pages
    else:
        # Until the Lithuanian edition exists, /book/ (the address of the QR code) sends readers to the English book
        (ROOT / 'book' / 'index.html').write_text('''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<meta http-equiv="refresh" content="0; url=/book/en/">
<title>PROOF book</title>
<link rel="stylesheet" href="/style.css">
</head>
<body style="display:grid;place-items:center;min-height:100vh">
<p><a href="/book/en/" style="color:#fff">PROOF book →</a></p>
</body>
</html>
''')
        print('[lt] not built: translation incomplete, /book/ redirects to /book/en/')

    core = [f'/book/book.css?v={ASSET_V}', f'/book/book.js?v={ASSET_V}', '/style.css', '/fonts/fonts.css',
            '/fonts/righteous-latin.woff2', '/fonts/righteous-latin-ext.woff2',
            '/fonts/jetbrainsmono-latin.woff2', '/fonts/jetbrainsmono-latin-ext.woff2',
            '/favicon.svg', '/bringin-logo.svg', REPLAYS_TAG.split('"')[1]] + sorted(set(urls + ['/book/']))
    # hash of every generated page, so a change in the <head> alone also renews the offline copies
    built = sorted((ROOT / 'book').rglob('index.html'))
    digest = hashlib.sha1((''.join(f.read_text() for f in built) + ASSET_V).encode()).hexdigest()[:8]
    sw = (HERE / 'sw.template.js').read_text().replace('__VERSION__', digest).replace('__CORE__', ',\n  '.join(f"'{u}'" for u in core))
    (ROOT / 'book' / 'sw.js').write_text(sw)
    if lt_ready():
        write_sitemap(pages)


def last_change(repo, files):
    """Date of the last commit touching these files, or today when one of them has uncommitted changes."""
    import datetime, subprocess
    files = [str(f) for f in files if pathlib.Path(repo, f).exists()]
    dirty = subprocess.run(['git', '-C', str(repo), 'status', '--porcelain', '--', *files], capture_output=True, text=True).stdout.strip()
    date = subprocess.run(['git', '-C', str(repo), 'log', '-1', '--format=%cs', '--', *files], capture_output=True, text=True).stdout.strip()
    return datetime.date.today().isoformat() if dirty or not date else date


def write_sitemap(pages):
    """../sitemap.xml: the 2 home pages and every page of the book, each with its other language and the date of its
    last real change (from git, so rebuilding without editing does not move the dates)."""
    def entry(lt, en, date):
        alt = (f'    <xhtml:link rel="alternate" hreflang="lt" href="{SITE}{lt}"/>\n'
               f'    <xhtml:link rel="alternate" hreflang="en" href="{SITE}{en}"/>\n'
               f'    <xhtml:link rel="alternate" hreflang="x-default" href="{SITE}{en}"/>\n')
        return ''.join(f'  <url>\n    <loc>{SITE}{u}</loc>\n    <lastmod>{date}</lastmod>\n{alt}  </url>\n' for u in (lt, en))
    sources = sorted({p['src'] for p in pages})
    every = sources + [f'lt/{s}' for s in sources] + ['lt/ui.json', 'build.py']
    out = ['<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n'
           '        xmlns:xhtml="http://www.w3.org/1999/xhtml">\n',
           entry('/', '/en/', last_change(ROOT, ['index.html', 'en/index.html'])),
           entry('/book/', '/book/en/', last_change(HERE, every))]
    for p in [p for p in pages if p['url'].startswith('/book/en/')]:
        # Every page changed on BOOK_INDEXABLE_SINCE (noindex removed in this file), even when its text did not
        date = max(last_change(HERE, [p['src'], f"lt/{p['src']}"]), BOOK_INDEXABLE_SINCE)
        out.append(entry(f"/book/{p['slug']}/", p['url'], date))
    out.append(entry('/book/checklist/', '/book/en/checklist/', last_change(HERE, every)))
    out.append('</urlset>\n')
    (ROOT / 'sitemap.xml').write_text(''.join(out))
    print(f'sitemap: {sum(o.count("<loc>") for o in out)} addresses')


if __name__ == '__main__':
    main()
