# 2 dalis: Autonomijos įrodymas

## Kodėl autonomija svarbi

### Skaitmeninį gyvenimą tu tik nuomojiesi

El. pašto adresas priklauso el. pašto paslaugos teikėjui, nuotraukos guli kurios nors bendrovės serveriuose, o kontaktai, sekėjai ir 10 metų pokalbių gyvena platformose. Tu turi tik paskyrą, t. y. leidimą visu tuo naudotis, o leidimą galima atšaukti.

Taip nutinka visai kasdieniškomis aplinkybėmis. 2022 m. rugpjūtį dienraštis „The New York Times“ [papasakojo apie tėvą iš San Fransisko](https://www.nytimes.com/2022/08/21/technology/google-surveillance-toddler-photo.html), kuris gydytojui nufotografavo sergantį mažylį. Automatinė sistema šias nuotraukas pažymėjo kaip įtartinas, bendrovė „Google“ išjungė jo paskyrą, ir jis neteko el. pašto, kontaktų, nuotraukų ir telefono numerio. Policija įtarimus jam panaikino, tačiau bendrovė paskyros vis tiek negrąžino.

Kitos netektys tylesnės. Platforma pakeičia taisykles, kaina padvigubėja, pasikeičia algoritmas, ir per daugelį metų suburta auditorija nebemato tavo įrašų. Paslauga uždaroma, kaip [2013 m. liepos 1 d. nutiko paslaugai „Google Reader“](https://googlereader.blogspot.com/2013/03/powering-down-google-reader.html), o [2019 m. balandžio 2 d. privatiems naudotojams skirtai „Google+“ versijai](https://workspace.google.com/blog/product-announcements/what-you-need-to-know-about-the-sunset-of-consumer-google-plus-on-april-second?hl=en), ir kartu dingsta viskas, kas ja rėmėsi. Piktų kėslų tam nereikia, nes kai nuomojiesi, sprendžia kažkas kitas, o tu prisitaikai.

### Kodėl svarbios „Google“ ir kitų technologijų milžinių („Big Tech“) alternatyvos

Šiandien saujelė bendrovių stovi tarp tavęs ir beveik visko, ką darai, nuo paieškos, pašto ir žemėlapių iki telefono operacinės sistemos, parduotuvės, iš kurios atsisiunti programėles, mokėjimų ir socialinių tinklų. Dauguma jų savo darbą atlieka labai gerai, o bėda slypi kitur, koncentracijoje.

Bendrovė, ant kurios pečių tiek daug laikosi, tampa vieninteliu gedimo tašku (angl. single point of failure). 2024 m. liepos 19 d. dėl saugumo bendrovės „CrowdStrike“ naujinio su klaida, bendrovės „Microsoft“ duomenimis, [nustojo veikti apie 8,5 mln. kompiuterių su „Windows“ sistema](https://blogs.microsoft.com/blog/2024/07/20/helping-our-customers-through-the-crowdstrike-outage/), ir tą pačią dieną sutriko oro linijų, bankų ir ligoninių darbas. Ta pati bendrovė tampa ir vieninteliu cenzūros tašku, nes jos pačios priimtas arba jai primestas sprendimas gali milijonams žmonių atimti programėlę ar nutildyti kieno nors balsą. Ji tampa ir vieninteliu sekimo tašku, nes 1 duomenų bazė žino, ko ieškai, kur eini, kam rašai ir ką perki.

Naudotis alternatyvomis nereiškia rytoj pat visko atsisakyti. Alternatyvos gyvuoja tik tol, kol kas nors jomis naudojasi, jas finansuoja ir praneša apie klaidas, todėl kaskart, kai kurią nors pasirenki, padedi jai išlikti visų labui ir palieki sau kelią pasitraukti.

### Kai įstatymas gali įpareigoti tavo paslaugas skenuoti

Pagal reglamentą, kurį Europos Komisija [pasiūlė 2022 m. gegužės 11 d.](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex:52022PC0209) ir kuris vadinamas „Chat Control“ (pokalbių kontrolė), institucijos galėtų įpareigoti susirašinėjimo paslaugos teikėją privačiame susirašinėjime aptikti seksualinės prievartos prieš vaikus medžiagą. 1 skyriuje aprašytoms šifruojančioms susirašinėjimo programėlėms tai praktiškai reikštų, kad žinutės analizuojamos tavo įrenginyje dar prieš jas užšifruojant. 2025 m. lapkričio 26 d. Europos Sąjungos Taryba [patvirtino savo poziciją](https://eucrim.eu/news/csa-regulation-council-position-reached/), kuri neapima privalomų nurodymų aptikti tokią medžiagą. [Derybos su Europos Parlamentu](https://www.europarl.europa.eu/legislative-train/theme-promoting-our-european-way-of-life/file-combating-child-sexual-abuse-online) prasidėjo 2025 m. gruodį. 2026 m. spalio mėn. duomenimis, galutinio teksto vis dar nėra. 6-asis derybų raundas 2026 m. rugsėjo 29 d. [baigėsi be susitarimo](https://www.patrick-breyer.de/en/chat-control-2-0-trilogue-update-no-mass-scanning-deal-for-now-european-parliament-stands-firm-against-search-plans/) dėl aptikimo privačiose žinutėse, o kitas raundas numatomas iki 2026 m. pabaigos.

Kaip juda tokie teisėkūros klausimai, rodo laikinoji taisyklė, leidžianti teikėjams skenuoti savanoriškai. Europos Parlamentas [2026 m. kovo 26 d. atsisakė ją pratęsti](https://eucrim.eu/news/interim-rules-on-voluntary-csam-detection-reinstated-until-2028/), ir po balandžio 3 d. ji nustojo galioti. 2026 m. liepą Europos Parlamentas [pritarė siauresnei jos versijai](https://www.europarl.europa.eu/news/en/press-room/20260706IPR46318/combating-child-sexual-abuse-support-for-a-more-limited-eprivacy-derogation), o Europos Sąjungos Taryba [ją galutinai patvirtino](https://www.consilium.europa.eu/en/press/press-releases/2026/07/23/fighting-child-sexual-abuse-online-interim-measure-protecting-children-now-reinstated/). Šis tekstas, Reglamentas (ES) 2026/1881, galioja iki 2028 m. balandžio 3 d. ir neapima ištisiniu būdu šifruojamo susirašinėjimo.

Vaikų apsauga yra teisėtas tikslas, o ginčijamasi dėl metodo. Toks įpareigojimas skiriamas bendrovei, kuri jį įvykdo, užginčija arba pasitraukia iš rinkos. Protokolas, kurį palaiko daug nepriklausomų operatorių, ir atvirojo kodo programinė įranga, kurią gali paleisti ar pakeisti kita ir kurios atšaką (angl. fork) gali sukurti, neturi vienintelio langelio, prie kurio tokį įpareigojimą būtų galima įteikti. Jie palieka tau veikiančią alternatyvą, jei paslauga, nuo kurios priklausai, būtų priversta keisti savo veikimą.

### Suverenitetas yra praktiškas žodis

Suverenitetas skamba kaip didelis politinis žodis. Čia jis reiškia gebėjimą pasakyti „ne“ ir galimybę išeiti, o praktiškai remiasi 3 dalykais.

**Raktai tavo rankose.** Tavo tapatybė ir prieiga priklauso nuo paslapties, kurią žinai tik tu, o ne nuo paskyros, kurią bendrovė gali uždaryti.

**Tavo duomenis galima perkelti.** Jie saugomi atvirais formatais, kuriuos gali eksportuoti ir atverti kitur, todėl pakeisti paslaugą nepatogu, bet tai ne katastrofa.

**Tavo įrankiai, kiek tai įmanoma, yra atvirojo kodo.** Kai kodas viešas, bet kas gali jį nukopijuoti ir tęsti darbą, todėl atimti jį iš tavęs daug sunkiau, net jei autoriai projektą meta arba juos kas nors nuperka. Kai įrankio kodas atviras ne visas, šioje knygoje tai nurodoma.

Už šių 3 dalykų slypi klausimas, lydintis visą knygą: kas yra patikima trečioji šalis ir ar gali patikrinti, ką ji daro. Paskyra šį pasitikėjimą sutelkia vienoje bendrovėje, o raktai, atviri formatai ir viešas kodas trečiąją šalį arba pašalina, arba leidžia ją patikrinti ir pakeisti, tik už tai paprastai tenka paaukoti dalį patogumo.

Konferencijos tema „Atgauk savo suverenitetą“ apibūdina būtent tokią poziciją, o su užsidarymu ar nepasitikėjimu ji turi mažai ką bendra. Tai padėtis žmogaus, kuris lieka savo noru ir rytoj galėtų išeiti.

### Ką gali padaryti

Niekas per savaitgalį nepakeičia 10 metų įpročių, ir to daryti nereikia. Autonomija kuriama po 1 paslaugą, pradedant nuo tos, nuo kurios priklausyti labiausiai neramu, arba nuo tos, kurią pakeisti lengviausia.

Nebūtina ir visko daryti iki galo. Jei „Google“ paskyrą pasilieki tiems 2 dalykams, kuriems jos tikrai reikia, o paštas, nuotraukos ir kontaktai laikomi kitur, padėtis jau visai kitokia, nei laikant viską vienoje vietoje.

6 šios dalies skyriai veda nuo idėjos prie praktikos:

6. **Raktai vietoj paskyrų:** kaip paslaptis, kurią žinai tik tu, gali pakeisti prisijungimą, kurį valdo bendrovė.
7. **Nostr: atviras tinklas, kurio nevaldo jokia įmonė:** tapatybė ir auditorija, nepriklausančios nuo jokios vienos platformos.
8. **Kaip po vieną pakeisti technologijų milžinių paslaugas:** paieška, žemėlapiai, debesija, dokumentai, nuotraukos, ir kiekvienai paslaugai po kelis variantus.
9. **Kaip susigrąžinti telefono kontrolę:** įrenginys, kuris apie tave žino daugiausia, ir tai, ką jame gali pakeisti.
10. **Kaip paleisti paslaugas nuosavame serveryje:** norintiems žengti toliau, nuosavas nedidelis serveris namuose.
11. **Kaip naudotis DI ir neišsiduoti:** ką dirbtinio intelekto (DI) asistentai apie tave sužino ir kaip tokį asistentą paleisti savo įrenginyje.

6 ir 7 skyriai sudaro porą. Kiti vienas nuo kito nepriklauso, todėl gali pradėti nuo to, kuris šiandien labiausiai tinka tavo gyvenimui.

## Šaltiniai

- [A Dad Took Photos of His Naked Toddler for the Doctor. Google Flagged Him as a Criminal.](https://www.nytimes.com/2022/08/21/technology/google-surveillance-toddler-photo.html), „The New York Times“, 2022 m. rugpjūčio 21 d.
- [Powering Down Google Reader](https://googlereader.blogspot.com/2013/03/powering-down-google-reader.html), „Official Google Reader Blog“, 2013 m. kovo mėn.
- [What you need to know about the sunset of consumer Google+ on April 2](https://workspace.google.com/blog/product-announcements/what-you-need-to-know-about-the-sunset-of-consumer-google-plus-on-april-second?hl=en), „Google Workspace Blog“, 2019 m., tikrinta 2026 m. spalio 22 d.
- [Helping our customers through the CrowdStrike outage](https://blogs.microsoft.com/blog/2024/07/20/helping-our-customers-through-the-crowdstrike-outage/), „Official Microsoft Blog“, 2024 m. liepos 20 d.
- [Proposal for a regulation laying down rules to prevent and combat child sexual abuse, COM(2022) 209](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex:52022PC0209), Europos Komisija, 2022 m. gegužės 11 d.
- [CSAM Regulation: Council position reached](https://eucrim.eu/news/csa-regulation-council-position-reached/), „eucrim“, 2025 m. gruodžio 22 d., tikrinta 2026 m. spalio 29 d.
- [Legislative train: combating child sexual abuse online](https://www.europarl.europa.eu/legislative-train/theme-promoting-our-european-way-of-life/file-combating-child-sexual-abuse-online), Europos Parlamentas, atnaujinta 2026 m. rugsėjo 20 d., tikrinta 2026 m. spalio 29 d.
- [Chat Control 2.0 trilogue update: no mass scanning deal for now](https://www.patrick-breyer.de/en/chat-control-2-0-trilogue-update-no-mass-scanning-deal-for-now-european-parliament-stands-firm-against-search-plans/), Patrick Breyer, 2026 m. rugsėjo 30 d., tikrinta 2026 m. spalio 29 d.
- [Interim rules on voluntary CSAM detection reinstated until 2028](https://eucrim.eu/news/interim-rules-on-voluntary-csam-detection-reinstated-until-2028/), „eucrim“, 2026 m., tikrinta 2026 m. spalio 29 d.
- [Combating child sexual abuse online: support for more limited ePrivacy derogation](https://www.europarl.europa.eu/news/en/press-room/20260706IPR46318/combating-child-sexual-abuse-support-for-a-more-limited-eprivacy-derogation), Europos Parlamentas, 2026 m. liepos 9 d.
- [Fighting child sexual abuse online: interim measure protecting children now reinstated](https://www.consilium.europa.eu/en/press/press-releases/2026/07/23/fighting-child-sexual-abuse-online-interim-measure-protecting-children-now-reinstated/), Europos Sąjungos Taryba, 2026 m. liepos 23 d.
