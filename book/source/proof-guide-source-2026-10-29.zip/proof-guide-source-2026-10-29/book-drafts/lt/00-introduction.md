# Įvadas

## Kodėl ši knyga

Šią knygą tikriausiai skaitai todėl, kad 2026 m. rugsėjo 27 d. dalyvavai Vilniuje vykusioje konferencijoje PROOF, arba todėl, kad kas nors su tavimi pasidalijo nuoroda.

Konferencija trunka vieną popietę. Išklausai gerų pranešimų, su dauguma minčių sutinki, pasižadi sau šį tą pakeisti, o pirmadienio rytą vėl prasideda įprastas gyvenimas. O įpročiai išlieka metų metus: kuria susirašinėjimo programėle naudojiesi, kaip elgiesi su slaptažodžiais, kur laikai santaupas. Nuo jų kur kas labiau nei nuo bet kurio pranešimo priklauso, kiek tavo gyvenimas atviras svetimoms akims ir kiek turi laisvės.

Ši knyga sujungia tą popietę su įpročiais. Nuo scenos nuskambėjusias idėjas ji paverčia dalykais, kuriuos gali susitvarkyti savo telefone ir kompiuteryje: žingsniai aiškūs, o techninių žinių nereikia. Skyrių perskaitysi maždaug per 10 minučių. Veiksmams prireiks daugiau laiko, ir knygoje nurodyta, kiek. Kiekviename skyriuje yra 5 minučių veiksmų. Daugumoje skyrių rasi ir maždaug 1 valandos veiksmų, kuriuos gali išdėstyti per kelis vakarus, o keliuose yra ir projektas savaitgaliui.

Keisti viso gyvenimo čia niekas neprašo. Pakeiti vieną įprotį, o kai tam ateina metas, dar vieną.

## 3 įrodymai

3 knygos dalys pavadintos pagal 3 konferencijos temas.

**Privatumo įrodymas** pasakoja, kaip apsaugoti žinutes, slaptažodžius, naršyklę, el. paštą ir tinklo ryšį. Ši dalis pirmoji, nes ja remiasi kitos 2.

**Autonomijos įrodymas** pasakoja, kaip mažiau priklausyti nuo prieigos valdytojų (angl. gatekeepers), tų kelių didelių įmonių, kurios gali uždaryti paskyrą, per naktį pakeisti taisykles ar prarasti tavo duomenis. Šios dalies skyriuose kalbama apie raktus vietoj paskyrų, apie Nostr, apie tai, kaip po vieną pakeisti technologijų milžinių („Big Tech“) paslaugas ir kaip kelias paslaugas paleisti nuosavame serveryje.

**Darbo įrodymas** skirtas darbo vaisiams, pajamoms ir santaupoms apsaugoti. Pinigai ilgainiui paprastai nuvertėja, kartais greitai: Eurostato duomenimis, 2022 m. spalį metinė infliacija pasiekė [10,6 % euro zonoje ir 22,1 % Lietuvoje](https://ec.europa.eu/eurostat/documents/2995521/15265521/2-17112022-AP-EN.pdf/b6953137-786e-ed9c-5ee2-6812c0f8f07f). Be to, didžiąją dalį tavo turto laiko, stebi, o kartais ir įšaldo kas nors kitas. Palyginsi vietas, kuriose galima laikyti vertę (banko sąskaitos, akcijos, auksas, Bitcoin ir, pažengusiems, Monero), o tada išmoksi naudotis Bitcoin, vienu iš šio sąrašo įrankių, kurį gali laikyti ir patikrinti be niekieno pagalbos, jei tik raktai yra tavo rankose.

Visose 3 dalyse klausiama, kas turi raktus, nes praktiškai tas ir valdo.

## Kaip naudotis knyga

Skyriai vienas nuo kito nepriklauso, todėl gali skaityti juos bet kokia tvarka ir praleisti tai, ką jau darai. Kiekviena dalis pradedama trumpa esė, o visi skyriai sudaryti vienodai: skyriaus santrauka, kas šiandien negerai, sprendimo idėja, kuo tenka pasitikėti ir ką gali patikrinti, įrankių pasirinkimas, nurodymai žingsnis po žingsnio, klaidos, kurių verta vengti, medžiaga norintiems daugiau ir minimų faktų šaltiniai.

Kiekvienas skyrius baigiasi 5 veiksmų sąrašu, o visi šie veiksmai patenka į bendrą sąrašą knygos pabaigoje, kur viską matai viename puslapyje. Prie kiekvieno veiksmo nurodyta, kiek pastangų jis pareikalaus: **(5 min.)**, **(1 val.)** arba **(savaitgalis)**, todėl 5 minučių veiksmus gali atlikti jau šiandien, o savaitgalio projektus atidėti vėlesniam laikui.

Knyga sukurta taip, kad vieną kartą įkelta veiktų ir be interneto. Paskyros kurti nereikia, o puslapiai neįkelia nei trečiųjų šalių scenarijų, nei sekiklių. Kaip ir bet kurioje svetainėje, serveris, kuriame laikomi puslapiai, juos įkeliant vis tiek mato tavo IP adresą. Pažanga saugoma tik tavo naršyklėje, todėl išvalius naršyklės duomenis ar perėjus prie kito įrenginio ji pradedama skaičiuoti nuo nulio, nes to, ką pažymėjai, kopijos neturi niekas kitas.

## Keli žodžiai apie įrankius

Kiekvienam poreikiui knygoje siūlomi keli įrankiai ir niekada tik vienas, o nė vieno kūrėjai nemokėjo už tai, kad čia patektų. Konferencija turi vienintelį rėmėją, bendrovę „Bringin“, ir kaskart, kai ji minima šiuose puslapiuose, nurodoma, kad tai rėmėja, o ji pati pateikiama tarp kitų variantų. Tas pats galioja kiekvienam įrankiui, susijusiam su kuriuo nors pranešėju.

Įrankiai keičiasi. Programėlės nuperkamos, apleidžiamos arba pamažu bloginamos: 2003 m. pasirodžiusi ir 2011 m. bendrovės „Microsoft“ nupirkta programa „Skype“ [2025 m. gegužės 5 d. uždaryta](https://support.microsoft.com/en-us/skype/skype-is-retiring-in-may-2025-what-you-need-to-know), o jos naudotojai nukreipti į programą „Teams“. Rekomendacija, teisinga 2026 m. rugsėjį ir spalį, kai šie puslapiai buvo tikrinami, po 3 metų gali būti klaidinga. Principai keičiasi lėčiau, ir 3 iš jų lemia kiekvieną šios knygos pasirinkimą:

- **Atvirasis kodas.** Kodas viešas, todėl tai, ką teigia įmonė, gali patikrinti joje nedirbantys žmonės.
- **Jokio vienintelio gedimo taško (angl. single point of failure).** Rinkis įrankius, kurie nepriklauso nuo vienos įmonės, vieno serverio ar vienos šalies.
- **Raktai tavo rankose.** Jei kas nors kitas gali tavęs neįleisti, vadinasi, tai iš tikrųjų ne tavo.

Šiuos principus sieja ir per visus skyrius eina 1 klausimas: „Kas yra patikima trečioji šalis ir ar gali tai patikrinti?“ Į jį neatsako nei šifravimas, nei atvirasis kodas, nei gerbiamas prekės ženklas, nes sistema decentralizuota tik tiek, kiek decentralizuotas pasitikėjimas, kuriuo ji remiasi, ir nesvarbu, kuo pasitikima: įmonės katalogu, serveriu, programėlių parduotuve ar įrangos gamintoju. Tvarkingai dirbanti trečioji šalis dažnai yra geras pasirinkimas, ypač pradžioje, o skyriuose parodoma, kuo tenka pasitikėti, kad spręsti galėtum tu.

Bitcoin bendruomenė turi posakį: „Nepasitikėk, tikrink“ (angl. „Don't trust, verify“). Jis tinka ir šiai knygai. Prie kiekvieno fakto su data yra nuoroda į šaltinį, todėl tai, ką čia skaitai, palygink su kitais šaltiniais, viską išbandyk mažais žingsniais, o jei rasi klaidą, pranešk apie ją PROOF komandai.

## Šaltiniai

- [Annual inflation up to 10.6% in the euro area (October 2022)](https://ec.europa.eu/eurostat/documents/2995521/15265521/2-17112022-AP-EN.pdf/b6953137-786e-ed9c-5ee2-6812c0f8f07f), Eurostatas, 2022 m. lapkričio 17 d.
- [Skype is retiring in May 2025: what you need to know](https://support.microsoft.com/en-us/skype/skype-is-retiring-in-may-2025-what-you-need-to-know), „Microsoft Support“, 2025 m.
