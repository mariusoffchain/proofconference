# 14 skyrius: Kaip pasidaryti atkūrimo frazės atsarginę kopiją

## Trumpai

Atkūrimo žodžiai yra piniginės raktų atsarginė kopija, o telefonas tėra įrankis jais naudotis. Daugelis piniginių naudoja 12 arba 24 žodžius, kai kurios kitokį formatą. Kas perskaito šiuos žodžius, gali pasiimti bitkoinus, o jei prarasi ir telefoną, ir žodžius, bitkoinų nebeatgausi. Užsirašyk žodžius ranka, laikyk 2 kopijas 2 vietose, kurias kontroliuoji, niekada nedaryk skaitmeninės kopijos, o kol suma dar maža, išbandyk atsarginę kopiją tavo piniginei tinkamu būdu (6 žingsnis).

## Nei pagalbos tarnybos, nei atkūrimo mygtuko

Jei prarandi prieigą prie banko sąskaitos, tai tik nepatogumas, nes įrodai, kas esi, ir kažkas prieigą atkuria. Pasirinkus savarankišką saugojimą to „kažko“ nebelieka. Nėra nei pagalbos tarnybos, nei mygtuko „pamiršau žodžius“, nei teismo, kuris galėtų įpareigoti tinklą grąžinti bitkoinus. Būtent todėl bitkoinus labai sunku iš tolo įšaldyti ar areštuoti, tačiau dėl to paties visa atsakomybė tenka tik tau.

Gyvenime pasitaiko 2 bėdos, ir jos tempia į priešingas puses. Pirmoji yra **praradimas**, kai telefonas įkrinta į ežerą, lapelis išmetamas kraustantis arba vienintelė kopija sudega per gaisrą. Antroji yra **vagystė**, kai žodžiai buvo išsaugoti nuotraukoje, el. laiško juodraštyje, debesijos užrašuose ar slaptažodžių tvarkyklėje ir kažkas juos rado. 2025 m. kovą JAV federaliniai tyrėjai [apie 150 mln. dolerių vagystę](https://krebsonsecurity.com/2025/03/feds-link-150m-cyberheist-to-2022-lastpass-hacks/), įvykdytą 2024 m. sausį, susiejo su slaptais duomenimis, laikytais slaptažodžių tvarkyklėje „LastPass“, į kurią buvo įsilaužta 2022 m. Taip pavogti bitkoinai per kelias minutes pervedami kitur, o susigrąžinti jų neįmanoma, todėl gera atsarginė kopija turi saugoti ir nuo praradimo, ir nuo vagystės.

## Vienas atsitiktinis skaičius, užrašytas žodžiais

Kai susikuri piniginę, programėlė sugeneruoja vieną labai didelį atsitiktinį skaičių, ir iš jo išvedama visa kita: visi raktai ir visi adresai, į kuriuos šioje piniginėje kada nors gausi bitkoinų. Pagal paplitusį standartą [BIP39](https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki) šis skaičius dažniausiai užrašomas 12 arba 24 žodžiais, paimtais iš nekintamo 2 048 paprastų angliškų žodžių sąrašo, nes žodžius žmonės nurašo patikimiau nei ilgas skaitmenų eilutes. Į paskutinį žodį įtraukta kontrolinė suma (angl. checksum), pagal kurią aptinkama dauguma nurašymo klaidų.

Iš šio skaičiaus išvestiems raktams žodžiai po kiekvieno mokėjimo nesikeičia. Tačiau atkuriant vis tiek reikia suderinamo atsarginės kopijos formato, tinkamo adreso tipo arba išvedimo kelio (angl. derivation path) ir slaptafrazės, jei ją naudojai. „Trezor“ įrenginiai palaiko ir SLIP39 atsargines kopijas, dažniausiai iš 20 žodžių, o programos „Electrum“ savosios atkūrimo frazės sudaromos pagal kitokią schemą nei BIP39. Nemanyk, kad bet kuri piniginė priims bet kokius žodžius.

Kartu su atkūrimo instrukcijomis užsirašyk piniginės pavadinimą ir atsarginės kopijos formatą. Vien atkūrimo frazė neatkuria nei žymių, nei atskirai importuotų raktų, nei visų piniginės nustatymų, todėl jų atsargines kopijas pasidaryk taip, kaip nurodyta piniginės dokumentacijoje.

Išimtis yra Lightning. Kanaluose esančios lėšos priklauso nuo piniginės, kuri tuos kanalus atidarė, o kai kurioms Lightning piniginėms be žodžių reikia dar ir papildomo atsarginės kopijos failo. Jei taip yra, programėlė apie tai aiškiai praneša, ir pirmiausia reikia vadovautis jos nurodymais.

## Nėra kuo pasitikėti, nėra kam paskambinti

Naudojant atvirojo formato atkūrimo frazės atsarginę kopiją pagrindinės grandinės (angl. on-chain) piniginę galima atkurti pasitelkus suderinamą programinę įrangą ir blokų grandinės duomenis, be pirminės įmonės ir be paskyros. Vis dėlto tenka pasikliauti atkūrimo programine įranga ir įrenginiu, o jei neturi savo mazgo, ir serveriu. Ne kiekvienai piniginei pakanka vien žodžių, ypač Lightning ir kelių parašų piniginėms. Ir atsarginės kopijos prieinamumu, ir konfidencialumu turi pasirūpinti tu.

Kiekvienas patogumas, kuris šią naštą palengvina, sugrąžina trečiąją šalį. Internetu užsisakius plieninę plokštelę tavo vardas, pavardė ir adresas atsiduria gamintojo klientų duomenų bazėje, o būtent tokia duomenų bazė 2020 m. nutekėjo iš bendrovės „Ledger“ (žr. „Klaidos, kurių verta vengti“). Shamiro atsarginės kopijos (angl. Shamir backup) dalys ir kelių parašų schema (angl. multisig) riziką paskirsto, tačiau kiekvienas žmogus, kuriam patikėta dalis ar raktas, gali juos pamesti arba susimokyti su kitais, o pasitikėti tenka ir programine įranga, kuri paslaptį padalija ir vėl sudeda. Dar toliau žengia kiekviena paslauga, siūlanti atkūrimo frazę atkurti už tave. Kad galėtų grąžinti atsarginę kopiją patikrinusi tavo tapatybę, įmonė turi laikyti ją ne tavo namuose, o ten į įmonę gali būti įsilaužta, ji gali būti priversta kopiją atiduoti arba gali užsidaryti. Tokia paslauga gali tikti tam, kas labiausiai bijo praradimo, tik reikia suprasti, kad tada patikimos trečiosios šalys vėl grįžta.

Patikrinti reiškia įsitikinti, kad atsarginė kopija veikia taikant tavo piniginei tinkamą atkūrimo procedūrą (6 žingsnis).

## Kaip pasirinkti, kur laikyti frazę

Tinkama laikmena priklauso nuo sumos ir nuo to, kas gresia tavo namams: vanduo, ugnis, vagys ar smalsūs svečiai. Taikant bet kurį iš toliau išvardytų būdų žodžiai nepatenka į internetą, o pačius būdus galima derinti.

| Būdas | Kaina | Kuo tenka pasitikėti | Privalumas | Silpnoji vieta |
|---|---|---|---|---|
| **Popierius**, pieštukas arba nenuplaunamas rašalas | Beveik nieko nekainuoja | Niekuo, išskyrus žmones, galinčius patekti ten, kur jis laikomas | Pasidarai iškart, nereikia jokių įrankių | Bijo vandens ir ugnies, blunka, lengva per klaidą išmesti |
| **Laminuotas popierius** | Keli eurai | Niekuo, jei laminavimo aparatas tavo. Kopijavimo salonas jau būtų trečioji šalis. | Atsparus vandeniui ir dėvėjimuisi | Vis tiek dega. Laminuok savo aparatu, o ne kopijavimo salone. |
| **Plieno gaminys**: „Cryptosteel“, „Seedor“ ir kiti | Dešimtys eurų, iki maždaug 100 eurų | Gamintoju ir parduotuve, kurie sužino tavo vardą, pavardę ir adresą, bet niekada nesužino žodžių | Atsparus ugniai, vandeniui ir laikui | Kaina. Be to, tai matomas daiktas, kuris kiekvienam jį radusiam žmogui sako „bitkoinai“. |
| **Savadarbė plieninė kopija**: raidės, įkaltos į plienines poveržles, suvertas ant varžto | Keli eurai už metalo detales ir dar raidžių spaudų rinkinys | Niekuo. Ūkinių prekių parduotuvė nenutuokia, kam tos poveržlės skirtos. | Toks pat atsparumas, nekrenta į akis, nereikia pasitikėti jokiu prekių ženklu | Valanda darbo, o raides kalti reikia atidžiai |
| **Slaptafrazė** (pasirenkamas „25-asis žodis“) | Nemokama | Niekuo kitu, jei ji užrašyta ir laikoma atskirai nuo žodžių | Jei slaptafrazė ilga ir atsitiktinė, vagiui vien žodžių nebepakanka | Trumpa ar lengvai atspėjama slaptafrazė beveik nieko neduoda. Tai dar viena paslaptis, kurios atsarginę kopiją reikia pasidaryti ir kurią reikia perduoti įpėdiniams. Pamiršus slaptafrazę bitkoinai prarandami. |

Dar yra 2 pažengusiems skirti būdai, tinkantys didesnėms sumoms:

- **Padalijimas tarp kelių vietų.** Standartinės schemos, tokios kaip kai kurių aparatinių piniginių palaikoma Shamiro atsarginė kopija ([SLIP39](https://github.com/satoshilabs/slips/blob/master/slip-0039.md)), paslaptį padalija į dalis, pavyzdžiui, taip, kad atkurti pakaktų bet kurių 2 iš 3. SLIP39 naudoja atskirą žodžių sąrašą ir su BIP39 nesuderinamas, todėl tokią kopiją atkurs tik jį palaikančios piniginės. Nekurk savos schemos ir nekarpyk žodžių sąrašo pusiau (kodėl, paaiškinta kitame skirsnyje).
- **Kelių parašų schema.** Tai piniginė, kuriai reikia kelių nepriklausomų raktų, pavyzdžiui, 2 iš 3, laikomų skirtingose vietose, todėl viena vagystė ar vienas praradimas nėra lemtingi. Laikyk pakankamai pasirašymo raktų atsarginių kopijų ir visą piniginės konfigūraciją arba deskriptorių (angl. output descriptor) su kiekvieno bendrai pasirašančio dalyvio išplėstiniu viešuoju raktu (angl. extended public key, xpub). Vien pakankamo atkūrimo frazių skaičiaus gali neužtekti. Pats deskriptorius lėšų išleisti neleidžia, tačiau atskleidžia piniginės informaciją, todėl saugok jį nuo pašalinių akių. Įrenginiai, su kuriais tai patogu padaryti, pristatomi 17 skyriuje.

Daugumai žmonių protinga pradžia būtų tokia: pirmą dieną popierius, vėliau, kai sumos jau būtų skaudu netekti, plieninė kopija, o slaptafrazės nenaudoti tol, kol iki galo jos nesupranti. Visa kita gali pagrįstai skirtis, kaip rodo kitas skirsnis.

## Vieno teisingo sprendimo nėra

Vieno teisingo sprendimo nėra, nes skiriasi sumos, namai, šeimos ir grėsmės, todėl 2 apdairūs žmonės gali pagrįstai pasirinkti skirtingai. 3 pagrindinius būdus galima derinti.

| Būdas | Ką laimi | Kaina |
|---|---|---|
| **Keli nepriklausomi raktai** arba kelios aparatinės piniginės skirtingiems tikslams, pavyzdžiui, išlaidoms ir santaupoms | Vagystė ar klaida paliečia 1 piniginę, o ne viską | Daugiau atsarginių kopijų, kurias reikia laikyti, žymėti ir tikrinti |
| **Vienas raktas, kurio atsarginė kopija padalyta į dalis**: dalys laikomos skirtingose vietose, o kiekvienos dalies kopija yra 2 vietose | Praradus 1 vietą pinigai neprarandami, o radus 1 dalį paslaptis neatskleidžiama | Reikia daugiau vietų ir žmonių, o atkurti galima tik suderinama programine įranga |
| **Vienas raktas ir slaptafrazė** (pasirenkamas papildomas žodis ar sakinys) | Vien žodžiais piniginės nebeatversi | Dar viena paslaptis, kurios atsarginę kopiją reikia pasidaryti ir kurią reikia perduoti įpėdiniams |

Shamiro paslapties dalijimas ir kelių parašų schema yra skirtingi dalykai. Tinkamoje slenkstinėje paslapties dalijimo schemoje mažiau dalių, nei reikalaujama, paslapties neatskleidžia. Kelių parašų schemoje naudojami nepriklausomi raktai: kai reikia daugiau nei 1 rakto, 1 raktas lėšų išleisti neleidžia, tačiau gali atskleisti piniginės informaciją. Išsaugok ne tik raktus, bet ir visą kelių parašų piniginės konfigūraciją. Jei žodžių sąrašą sukarpai savaip, kiekvienas radėjas gauna dalį paslapties, o 2020 m. birželį John Cantrell išsinuomotomis vaizdo plokštėmis [4 trūkstamus 12 žodžių frazės žodžius rado maždaug per 30 valandų](https://bitcoinwords.github.io/how-i-checked-over-1-trillion-mnemonics).

Žodžius turintis užpuolikas gali labai greitai bandyti ir slaptafrazes, todėl trumpa ar lengvai atspėjama slaptafrazė saugumo beveik neprideda. Ji turi būti ilga ir atsitiktinė. Kiekviena skirtinga slaptafrazė atveria kitą piniginę, todėl taip galima susikurti atskirų arba paslėptų piniginių. Pačios slaptafrazės atsarginę kopiją irgi reikia pasidaryti ir laikyti atskirai nuo žodžių ten, kur ją ras įpėdiniai.

Praktinis kriterijus toks: rinkis paprasčiausią sprendimą, kurį ir po 10 metų tebesuprasi ir pagal kurį sugebėsi atkurti piniginę.

## Žingsnis po žingsnio

Pavyzdyje naudojamas popierius ir rašiklis. Su plienu logika ta pati.

1. **Pasirink tinkamą metą.** Kai šalia nieko nėra, prie stalo, kai už nugaros nėra kameros, ne kavinėje ir ne traukinyje.
2. **Užsirašyk žodžius ranka**, sunumeruotus, iš eilės, aiškiomis didžiosiomis raidėmis. Pažymėk piniginės pavadinimą ir datą, bet ne sumą.
3. **Patikrink juos 2 kartus.** Dar kartą perskaityk, ką užrašei, ir žodis po žodžio sulygink su ekranu. Dauguma piniginių paskui paprašo kelis iš jų patvirtinti.
4. **Niekada nedaryk skaitmeninės versijos.** Žodžių nerink klaviatūra, nefotografuok, nespausdink, nediktuok, nesiųsk el. paštu ir nelaikyk nei debesijoje, nei slaptažodžių tvarkyklėje. Jei naudoji pasirašymo įrenginį, jo atsarginės kopijos nevesk į įprastas programines pinigines. Laikykis oficialios to įrenginio atsarginės kopijos tikrinimo ir atkūrimo procedūros ir nevesk žodžių į prie interneto prijungtą įrenginį vien tam, kad juos išbandytum.
5. **Pasidaryk 2 kopijas** ir laikyk jas 2 vietose, kurias kontroliuoji, pavyzdžiui, savo namuose ir artimo giminaičio namuose, kiekvieną užklijuotame voke. Antroji vieta yra kompromisas, nes jei slaptafrazės nėra, bitkoinus valdo tas, kas atplėšia voką. Rinkis žmogų, kuriam patikėtum tokią pat sumą grynaisiais, o sumai išaugus apsvarstyk vieną iš pirmiau aprašytų būdų. Jei naudoji dalis ar slaptafrazę, 2 kopijų taisyklė galioja kiekvienai iš jų, o slaptafrazė niekada nelaikoma kartu su žodžiais.
6. **Išbandyk atsarginę kopiją tinkamoje aplinkoje.** Jei turi pagrindinės grandinės **programinę piniginę**, kurioje laikai visai mažą sumą, atkurk ją suderinama programine įranga kitame savo kontroliuojamame įrenginyje, palygink adresus ir likutį, tada bandomąją kopiją pašalink. Per visą bandymą pirminę programėlę palik vietoje: taip apsisaugai nuo nurašymo klaidos, bet ne nuo kenkėjiškos programos antrajame įrenginyje. Jei turi **aparatinę piniginę**, naudokis gamintojo atsarginės kopijos tikrinimo funkcija arba atkurk piniginę suderinamame aparatiniame įrenginyje pagal oficialią procedūrą. Niekada neimportuok aparatinės piniginės atkūrimo frazės į telefoną ar kompiuterį vien dėl šio bandymo. Duomenų ištrynimo ir atkūrimo pratimas skirtas tik visai mažam bandomajam likučiui, kol dar nepervedei santaupų (žr. 17 skyrių).
7. **Su Lightning pinigine elkis kitaip.** Jei ištrinsi programėlę, kurioje yra atidarytų kanalų, o atkurti nepavyks, gali netekti lėšų. Pavyzdžiui, piniginė „Phoenix“ [įspėja nenaudoti 2 programėlių su ta pačia atkūrimo fraze](https://phoenix.acinq.co/faq). Pirmiausia perskaityk savo piniginės atkūrimo instrukcijas. Tikrasis bandymas paprastai įvyksta keičiant telefoną: likutis turi būti mažas, senasis telefonas išjungtas, o senoji programėlė paliekama tol, kol likutis pasirodo naujajame telefone.
8. **Pasirūpink paveldėjimu.** Pridėk užklijuotą laišką, kuriame paprastais žodžiais paaiškinta, kas tai yra, kad tai turi vertę, kad žodžių niekada negalima vesti jokioje svetainėje, kuo galima pasitikėti prireikus pagalbos, iš kiek dalių susideda tavo sprendimas (žodžiai, dalys, slaptafrazė) ir kur kiekviena laikoma.

## Klaidos, kurių verta vengti

- **Laikyti skaitmeninę kopiją.** Nuotraukas, užrašus, el. laiškų juodraščius ir debesų saugyklas gali pasiekti kenkėjiškos programos ir įsilaužėliai. Ištrynus failą nebeatšauksi to, kad žodžiai jau galėjo būti pamatyti, o visos sinchronizuotos kopijos nebūtinai išnyks. Jei žodžiai galėjo nutekėti, vadovaukis gamintojo nurodymais: susikurk naują piniginę ir saugiai perkelk į ją lėšas. Niekada nepradėk nuo vienintelės veikiančios piniginės ištrynimo.
- **Laikyti vienintelę kopiją.** Jai prarasti pakanka gaisro, potvynio ar kraustymosi, todėl ir laikai 2 kopijas 2 vietose.
- **Pasakoti, kiek turi.** 2020 m. gruodį po įsilaužimo į bendrovės „Ledger“ parduotuvės duomenų bazę įsilaužėlių forume paskelbti [maždaug 272 000 jos klientų](https://www.ledger.com/message-ledgers-ceo-data-leak) vardai, pavardės, pašto adresai ir telefono numeriai, o paskui šie klientai tapo sukčiavimo apsimetant (angl. phishing) kampanijų taikiniu. Apie Bitcoin kalbėk kiek nori, tik ne apie savo likutį.
- **Vesti žodžius svetainėje arba duoti juos „pagalbos tarnybai“.** Jų niekada neprašys nei piniginės kūrėjai, nei birža, nei valdžios institucija, todėl tas, kas prašo, bando apvogti.
- **Susikurti schemą, kurios po 5 metų nebeprisiminsi.** Knygoje paslėpti, į 4 dalis padalyti ir improvizuotu kodu užšifruoti žodžiai ne vienam žmogui užvėrė kelią prie nuosavų bitkoinų. Schema turi būti paprasta, aprašyta ir išbandyta.
- **Niekada nebandyti arba bandyti ištrinant programėlę.** Neišbandytoje atsarginėje kopijoje gali būti neteisingas žodis, o jei pirmiausia ištrinsi programėlę, tai sužinosi tik tada, kai vienintelės veikiančios kopijos jau nebebus. Naudok tavo piniginei tinkamą programinės ar aparatinės piniginės procedūrą (6 žingsnis).

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl nuo tavo raktų priklauso tavo interneto sauga“, pranešimą skaito Satoshine. Atkūrimo frazė yra akivaizdžiausias tik tau priklausančio rakto pavyzdys.
- **Ugnimi, rūgštimi ir presu išbandytos plieninės atsarginės kopijos:** programuotojo Jameson Lopp parengtos metalinių laikmenų apžvalgos (jlopp.github.io/metal-bitcoin-storage-reviews).
- **Atsarginių kopijų ir atkūrimo pamokos:** „Plan B Academy“ (planb.academy).
- **Pats standartas ir jo žodžių sąrašas:** BIP39, vienas iš Bitcoin tobulinimo pasiūlymų (github.com/bitcoin/bips).
- **Kuri piniginė kurią atkūrimo frazę gali atkurti:** „Wallets Recovery“ (walletsrecovery.org).
- **Kitas skyrius:** Lightning ir eurai kasdienybėje.

## Šaltiniai

- [Understanding Trezor backups, 12, 20 or 24 words](https://trezor.io/learn/security-privacy/personal-security-standards/understanding-trezor-wallet-backups-12-20-or-24-words), „Trezor“, tikrinta 2026 m. spalio 22 d.
- [Seed version system](https://electrum.readthedocs.io/en/latest/seedphrase.html), „Electrum“ dokumentacija, tikrinta 2026 m. spalio 22 d.
- [How to use a wallet backup](https://trezor.io/guides/backups-recovery/general-standards/how-to-use-a-wallet-backup), „Trezor“, tikrinta 2026 m. spalio 22 d.
- [Move crypto to a wallet with a new backup](https://trezor.io/guides/backups-recovery/general-standards/move-crypto-to-a-wallet-with-a-new-wallet-backup), „Trezor“, tikrinta 2026 m. spalio 22 d.
- [Multisig backup warning and descriptor export](https://github.com/sparrowwallet/sparrow/blob/master/src/main/java/com/sparrowwallet/sparrow/wallet/MultisigBackupDialog.java), „Sparrow“ programos kodas, tikrinta 2026 m. spalio 22 d.
- [Feds Link $150M Cyberheist to 2022 LastPass Hacks](https://krebsonsecurity.com/2025/03/feds-link-150m-cyberheist-to-2022-lastpass-hacks/), „Krebs on Security“, 2025 m. kovo 6 d.
- [Message from Ledger's CEO on the data leak](https://www.ledger.com/message-ledgers-ceo-data-leak), „Ledger“, 2020 m. gruodžio 21 d.
- [BIP39: Mnemonic code for generating deterministic keys](https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki), „Bitcoin Improvement Proposals“, 2013 m.
- [SLIP39: Shamir's Secret-Sharing for Mnemonic Codes](https://github.com/satoshilabs/slips/blob/master/slip-0039.md), „SatoshiLabs“, žiūrėta 2026 m. rugsėjį.
- [How I checked over 1 trillion mnemonics in 30 hours to win a bitcoin](https://bitcoinwords.github.io/how-i-checked-over-1-trillion-mnemonics), John Cantrell, pakartotinai paskelbė „WORDS Bitcoin Journal“, 2020 m. birželio 18 d.
- [Phoenix FAQ: restoring a wallet, limitations](https://phoenix.acinq.co/faq), „ACINQ“, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Užsirašyk žodžius ranka ir patikrink juos 2 kartus (5 min.)
- [ ] Pašalink skaitmenines atkūrimo frazės kopijas, o jei ji galėjo nutekėti, saugiai perkelk lėšas į naują piniginę, nes ištrynimas nutekėjimo neatšaukia (1 val.)
- [ ] Pasidaryk antrą kopiją ir padėk ją antroje vietoje (1 val.)
- [ ] Programinę piniginę su visai maža suma išbandyk kitame įrenginyje ir neištrink pirminės, o aparatinės piniginės atsarginę kopiją tikrink tik gamintojo nurodyta procedūra pačiame įrenginyje (1 val.)
- [ ] Parašyk šeimai laišką, įdėk jį į užklijuotą voką ir pasidaryk plieninę kopiją (savaitgalis)
