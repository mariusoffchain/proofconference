/* Placeholder of the host site file /book/book.js, created by the source archive. The guide build only checks that it exists or hashes it; it is not part of the guide. */
