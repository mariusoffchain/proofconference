# 1 skyrius: Tavo žinutės

## Trumpai

Pokalbiai yra vieni intymiausių duomenų, kuriuos sukuri. Perkelk juos į susirašinėjimo programėlę, kuri automatiškai šifruoja žinutes ištisiniu būdu, yra atvirojo kodo ir renka kuo mažiau metaduomenų. Gerų programėlių yra keletas, ir nė viena nėra pranašesnė visais atžvilgiais. Išsirink vieną, pirmiausia perkelk 5 artimiausius kontaktus, o senąją programėlę pasilik bendrauti su visais kitais.

## Užšifruota dar nereiškia privatu

Daugelis kasdien naudojamų susirašinėjimo programėlių priklauso reklamos bendrovėms. Bendrovei „Meta“ priklausančios programėlės „WhatsApp“ ir „Messenger“ žinučių turinį tikrai šifruoja, tačiau vis tiek fiksuoja, su kuo bendrauji, kada, kaip dažnai, iš kurio įrenginio ir iš kurios vietos, ir sieja tai su viskuo, ką ši įmonių grupė apie tave jau žino.

Kitos programėlės automatiškai išvis nešifruoja. Programėlėje „Telegram“ įprasti pokalbiai ir visi grupių pokalbiai saugomi tokiu pavidalu, kad bendrovė gali juos perskaityti. SMS žinutės apsaugotos dar menkiau, nes jas gali perskaityti operatorius, o telefono tinklu jos keliauja nešifruotos. Po to, kai „Salt Typhoon“ vadinama grupuotė įsilaužė į kelių JAV telekomunikacijų operatorių tinklus, šios šalies kibernetinio saugumo agentūra CISA [2024 m. gruodį patarė](https://www.cisa.gov/resources-tools/resources/mobile-communications-best-practice-guidance) žmonėms, į kuriuos taikomasi ypač dažnai, naudotis tik tokiomis susirašinėjimo priemonėmis, kuriose taikomas ištisinis šifravimas, ir prisijungimo kodams gauti nebepasikliauti SMS žinutėmis.

Dar lieka atsarginės kopijos. Pokalbis gali būti šifruojamas perduodant ir vis tiek atsidurti debesijos atsarginėje kopijoje, kurią galima perskaityti, ir nesvarbu, ar tai tavo, ar pašnekovo kopija.

Pasekmės visai konkrečios: nutekėję pokalbiai, sukčių perimtos paskyros, iš kurių jie paskui rašo tavo šeimai, ir žinutės, kurios teisėsaugos ar teismo reikalavimu perduodamos po daugelio metų, kai jau nebeprisimeni, kad jas rašei.

## Užklijuotas vokas, kurio paštininkas negali atplėšti

Kai taikomas **ištisinis šifravimas**, žinutė užrakinama tavo telefone, o atrakinti ją galima tik telefone to žmogaus, kuriam rašai. Tarpininkaujanti bendrovė perduoda užklijuotą voką, kurio atplėšti negali. Jei į jos sistemas kas nors įsilaužia arba ji gauna teisėsaugos ar teismo reikalavimą, žinučių turinio atiduoti negali, nes jo neturi. Nuo to, kaip sukurta programėlė, priklauso, ar bendrovė vis tiek turi metaduomenų, pavyzdžiui, IP adresą, kontaktų sąrašą ar paskutinio prisijungimo datą.

Europoje šis vokas yra ir politinis klausimas. Pagal reglamentą, kurį Europos Komisija [pasiūlė 2022 m. gegužės 11 d.](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex:52022PC0209) ir kurį kritikai vadina „Chat Control“ (pokalbių kontrolė), institucijos galėtų įpareigoti susirašinėjimo paslaugų teikėjus skenuoti privatų susirašinėjimą. 2026 m. spalio mėn. duomenimis, dėl jo [vis dar derasi](https://www.europarl.europa.eu/legislative-train/theme-promoting-our-european-way-of-life/file-combating-child-sexual-abuse-online) Europos Parlamentas ir Europos Sąjungos Taryba. 6-asis derybų raundas 2026 m. rugsėjo 29 d. [baigėsi be susitarimo dėl privačių žinučių skenavimo](https://data.consilium.europa.eu/doc/document/WK-15082-2026-INIT/en/pdf), o kitas raundas numatomas iki 2026 m. pabaigos. Tuo metu Reglamentas (ES) 2026/1881, laikinoji taisyklė, leidžianti teikėjams skenuoti savanoriškai, [2026 m. liepą vėl patvirtintas](https://www.consilium.europa.eu/en/press/press-releases/2026/07/23/fighting-child-sexual-abuse-online-interim-measure-protecting-children-now-reinstated/) ir galioja iki 2028 m. balandžio 3 d. Europos Parlamento prašymu jis [neapima ištisiniu būdu šifruojamo susirašinėjimo](https://www.europarl.europa.eu/news/en/press-room/20260706IPR46318/combating-child-sexual-abuse-support-for-a-more-limited-eprivacy-derogation).

Šifravimas būtinas, tačiau svarbūs dar 3 dalykai:

- **Atvirasis kodas.** Programos kodas viešas, todėl nepriklausomi ekspertai gali patikrinti, ar programėlė daro tai, ką žada, ir nereikia aklai tikėti bendrovės žodžiu.
- **Metaduomenys.** Atsargiausios susirašinėjimo programėlės kuriamos taip, kad apie tave žinotų labai mažai: jos gali neturėti nei tavo kontaktų sąrašo, nei duomenų apie grupes, kurioms priklausai, o kartais net jokio identifikatoriaus.
- **Kas ją valdo.** Ne pelno organizacijai ar bendruomenei nereikia maitinti reklamos verslo, o tinkle be centrinės bendrovės nėra vienintelių durų, į kurias pakaktų pasibelsti.

## Konfidencialu dar nereiškia autentiška

Šifravimas atsako į 1 klausimą: ar žinutę gali perskaityti kas nors kitas. Lieka dar vienas: ar kitame gale tikrai yra tas žmogus, apie kurį galvoji. Pirmąją savybę kriptografai vadina konfidencialumu, o antrąją autentiškumu. SMS žinutė ar el. laiškas neužtikrina nė vienos. Per telefono skambutį pažįstamas balsas gali padėti atpažinti žmogų, bet skambutis dėl to netampa konfidencialus, o tapatybės balsas neįrodo, nes [jį galima klonuoti](https://consumer.ftc.gov/articles/scammers-use-fake-emergencies-steal-your-money). Saugus kanalas turi užtikrinti abi.

Autentiškumas priklauso nuo to, kaip programėlė gavo kito žmogaus raktą. Programėlėse „Signal“, „WhatsApp“, „iMessage“ ir daugumoje kitų šifruojančių susirašinėjimo programėlių šis raktas gaunamas iš bendrovės tvarkomo katalogo, todėl bendrovė, kad ir kaip gerai ji šifruotų, tampa patikima trečiąja šalimi, t. y. tarpininke, kuria tenka pasitikėti. Jei į katalogą būtų įsilaužta arba bendrovė būtų priversta pateikti netikrą raktą, vokas liktų užklijuotas, tik skirtas jau ne tam skaitytojui. Apsisaugoti galima: tam skirti [saugumo numeriai programėlėje „Signal“](https://support.signal.org/hc/en-us/articles/360007060632-What-is-a-safety-number-and-why-do-I-see-that-it-changed) (reikia palyginti 60 skaitmenų), [rakto skaidrumas programėlėje „WhatsApp“](https://engineering.fb.com/2023/04/13/security/whatsapp-key-transparency/) ir [kontaktų raktų patvirtinimas (angl. Contact Key Verification) programėlėje „iMessage“](https://security.apple.com/blog/imessage-contact-key-verification/), tačiau šios priemonės pasirenkamos ir naudojamos retai.

Kitos programėlės katalogo atsisako ir šį pasitikėjimą decentralizuoja. Programėlėje „Olvid“ prieš pirmąją žinutę [būtina apsikeisti 2 kodais po 4 skaitmenis](https://olvid.io/faq/olvid-secure-channels/), o programėlėse „SimpleX“ ir „Briar“ pokalbis prasideda nuo nuorodos arba QR kodo, kurį perduodi tu, o ne bendrovė. Tada saugumas priklauso nuo 2 bendraujančių žmonių, o kaina yra patogumas, nes programėlė kontaktų už tave nesuras.

## Kaip pasirinkti susirašinėjimo programėlę

Pirmiausia sąžiningai įvertink tai, kuo tikriausiai naudojiesi šiandien. Nė viena iš šių programėlių nėra bevertė, tačiau kiekviena turi aiškią silpnąją vietą. Lentelėje pateikta 2026 m. rugsėjo mėn. padėtis.

| Programėlė | Savininkas | Ar šifruojama ištisiniu būdu? | Ką ji vis tiek renka ar atskleidžia | Įvertinimas |
|---|---|---|---|---|
| [**WhatsApp**](https://www.whatsapp.com/) | „Meta“ | Taip, automatiškai (Signal protokolas) | Daug metaduomenų: tavo kontaktai, kam rašai, kada, iš kurio įrenginio. Kodas uždaras. Debesijos atsarginės kopijos ištisiniu būdu šifruojamos tik tada, kai šią funkciją įjungi. | Turinys apsaugotas, o metaduomenys atitenka reklamos grupei. |
| [**Facebook Messenger**](https://www.messenger.com/) | „Meta“ | Taip, nuo 2023 m. gruodžio mėn. asmeniniai pokalbiai ir skambučiai šifruojami automatiškai. Pokalbiams su įmonėmis ir skilčiai „Marketplace“ tai negalioja. | Tie patys metaduomenys, susieti su tavo „Facebook“ tapatybe. Kodas uždaras. | Geriau nei anksčiau, bet tai vis tiek „Meta“ produktas. |
| [**Asmeninės „Instagram“ žinutės**](https://www.instagram.com/) | „Meta“ | Ne. Šifruoti pokalbiai, kuriuos buvo galima įjungti pasirinktinai, pašalinti 2026 m. gegužės 8 d. | Bendrovė „Meta“ gali perskaityti kiekvienos žinutės turinį ir mato metaduomenis. | Netinka niekam, kas privatu. |
| [**Telegram**](https://telegram.org/) | „Telegram“, privati bendrovė | Tik slaptuosiuose pokalbiuose (angl. secret chats), kuriuos reikia pradėti atskirai ir kurie galimi tik tarp 2 žmonių. Įprastiems pokalbiams, visoms grupėms ir kanalams ištisinis šifravimas netaikomas. | Įprastos žinutės saugomos „Telegram“ serveriuose, ir bendrovė gali jas perskaityti. Serverio kodas uždaras. | Labiau socialinis tinklas nei privati susirašinėjimo programėlė. |
| **SMS** | Tavo mobiliojo ryšio operatorius | Ne | Turinį ir metaduomenis gali perskaityti operatoriai. Žinutes galima perimti arba nukreipti kitur, jei sukčius perima SIM kortelę (angl. SIM swap), t. y. perkelia tavo numerį į savo SIM kortelę. | Nenaudok niekam, kas jautru, o jei gali rinktis, ir prisijungimo kodams gauti. |
| [**iMessage (Apple Messages)**](https://support.apple.com/messages) | „Apple“ | Taip, tarp „Apple“ įrenginių (mėlyni burbulai) | Veikia tik „Apple“ įrenginiuose. Kodas uždaras. „iCloud“ atsargines kopijas bendrovė „Apple“ gali perskaityti, nebent įjungi funkciją „Advanced Data Protection“ (išplėstinė duomenų apsauga). | Tinka „Apple“ pasaulyje, bet niekur kitur. |
| [**Google Messages (RCS)**](https://www.android.com/google-messages/) | „Google“ kartu su mobiliojo ryšio operatoriais | Taip, automatiškai tarp „Google Messages“ naudotojų. Su „iPhone“ telefonais šifravimas pradėtas diegti 2026 m. gegužę, kol kas beta versijoje, ir priklauso nuo tavo operatoriaus. | Susieta su telefono numeriu. Metaduomenys vis tiek renkami. Kodas uždaras. Kai RCS neveikia, siunčiama paprasta SMS žinutė. | Geriau nei SMS. Patikrink, ar matai spynelės piktogramą. |

O štai geresni variantai. Vieno teisingo atsakymo nėra, ir tai gerai, nes pasaulis, kuriame visi priklauso nuo vienos programėlės, yra trapus. Visose 7 privatūs pokalbiai automatiškai šifruojami ištisiniu būdu, o pačių programėlių kodas atviras.

| Programėlė | Ar reikia telefono numerio | Kas valdo tinklą | Kas laiduoja už raktus | Kam labiausiai tinka |
|---|---|---|---|---|
| [**Signal**](https://signal.org/) | Taip (jį galima paslėpti nuo kitų) | Vienas pelno nesiekiantis fondas | „Signal“ tvarkomas katalogas. Jei nori, gali palyginti 60 skaitmenų saugumo numerį. | Programėlei „WhatsApp“ pakeisti bendraujant su šeima ir draugais. Pereiti lengviausia. |
| [**SimpleX Chat**](https://simplex.chat/) | Nereikia jokio identifikatoriaus | Retransliatoriai (angl. relays), kuriuos gali paleisti bet kas | Niekas. Nuorodą arba QR kodą perduodi tu, o jei nori, gali dar palyginti saugumo kodą. | Stipri metaduomenų apsauga. Nėra nei paskyros, nei naudotojo vardo, nei identifikatoriaus, kurį būtų galima su kuo nors susieti. |
| [**Session**](https://getsession.org/) | Ne | Decentralizuotas bendruomenės valdomų mazgų tinklas | Katalogo nėra, nes „Session ID“ ir yra viešasis raktas. Šį ID turi gauti kanalu, kuriuo pasitiki. | Anoniminės paskyros, žinutės keliauja per kelis mazgus. Veikia lėčiau, funkcijų mažiau. Dabartinis protokolas neužtikrina išankstinio slaptumo (angl. forward secrecy): kada nors pavogtu raktu būtų galima atrakinti ir senesnes žinutes. 2025 m. gruodį paskelbtas protokolo atnaujinimas [2026 m. rugpjūtį buvo sustabdytas](https://getsession.org/session-development-update-pro-beta-protocol-v2). |
| [**Threema**](https://threema.com/) | Ne | Viena Šveicarijos bendrovė, kurią [nuo 2026 m. sausio valdo](https://www.privacyguides.org/news/2026/01/16/another-private-equity-firm-acquires-threema/) Vokietijos investicinė bendrovė „Comitis Capital“. Programėlė mokama | „Threema“ tvarkomas katalogas. Gyvai nuskenavus kontakto QR kodą jam suteikiamas aukščiausias pasitikėjimo lygis. | Tiems, kas nenori nurodyti telefono numerio ir ieško išbaigto mokamo produkto. |
| [**Olvid**](https://olvid.io/) | Ne, nereikia nei el. pašto, nei kitų asmens duomenų | Viena Prancūzijos bendrovė, serveriai veikia „Amazon Web Services“ infrastruktūroje | Niekas. Prieš pirmąją žinutę 2 žmonės apsikeičia 2 kodais po 4 skaitmenis, ir šis žingsnis privalomas. | Europietiška programėlė, kurios saugumą sertifikavo Prancūzijos kibernetinio saugumo agentūra ANSSI. Žinutės ir gaunami skambučiai nemokami. Norint skambinti ir naudotis keliais įrenginiais reikia prenumeratos (apie 5 eurus per mėnesį). |
| [**Element (Matrix)**](https://element.io/) | Ne | Federacinis tinklas: daug serverių arba nuosavas serveris | Tavo serverio katalogas. Patvirtinimas pasirenkamas: palyginami jaustukai arba nuskenuojamas QR kodas. | Bendruomenėms, komandoms ir tiems, kas nori turėti nuosavą serverį. Pokalbyje dalyvaujantys serveriai mato metaduomenis (kas kuriame kambaryje ir kada), todėl svarbu, kurį serverį pasirinksi. |
| [**Briar**](https://briarproject.org/) | Ne | Niekas: ryšys tiesiogiai tarp įrenginių | Niekas. Kontaktai pridedami gyvai nuskenavus QR kodą arba apsikeitus nuorodomis. | Ekstremalioms situacijoms. Veikia per Tor tinklą ir net per „Bluetooth“ ar belaidį tinklą („Wi-Fi“) be interneto. Yra programėlė „Android“ sistemai ir beta versijos programa kompiuteriui („Windows“, „macOS“, „Linux“). Programėlės „iPhone“ telefonams nėra. |

Daugumai žmonių protingas derinys būtų toks: **programėlė „Signal“ kasdieniam bendravimui** ir **susirašinėjimo programėlė be telefono numerio** (pavyzdžiui, „SimpleX“ ar „Olvid“) tiems kontaktams, kurių nenori sieti su savo tapatybe.

Jei dalis artimųjų ir pažįstamų lieka programėlėje „WhatsApp“, padėk jiems bent įjungti šifruotas atsargines kopijas („Settings“, „Chats“, „Chat backup“, „End-to-end encrypted backup“, t. y. nustatymai, pokalbiai, pokalbių atsarginė kopija, ištisiniu būdu šifruota atsarginė kopija). Kaip tai padaryti, aiškinama „WhatsApp“ pagalbos centro straipsnyje [„About end-to-end encrypted backup“](https://faq.whatsapp.com/490592613091019) (apie ištisiniu būdu šifruotas atsargines kopijas).

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta programėlė „Signal“, nes ji dažniausiai būna pirmasis žingsnis, o kitose programėlėse logika ta pati. Meniu pavadinimai tokie, kokie buvo 2026 m. rugsėjį.

1. **Įdiek programėlę** iš oficialios programėlių parduotuvės arba iš projekto svetainės ir užsiregistruok.
2. **Užrakink paskyrą.** Pasirink „Nustatymai“, „Paskyra“, susikurk PIN kodą ir įjunk nustatymą „Registracijos užraktas“, kad iš naujo registruojant tavo numerį būtų prašoma šio PIN kodo. PIN kodą išsaugok slaptažodžių tvarkyklėje (žr. 2 skyrių).
3. **Paslėpk telefono numerį.** Susikurk naudotojo vardą, tada pasirink „Nustatymai“, „Privatumas“, „Telefono numeris“ ir prie „Kas gali matyti mano tel. numerį“ pažymėk „Niekas“. Nuo šiol vietoj numerio gali duoti naudotojo vardą. Atskiras nustatymas „Kas gali mane rasti pagal numerį“ lemia, ar žmogus, jau turintis tavo numerį, ras tave programėlėje „Signal“. Jei nori, ir čia pasirink „Niekas“, tik žinok, kad tada draugams reikės tavo naudotojo vardo.
4. **Įjunk automatiškai išnykstančias žinutes.** Pasirink „Nustatymai“, „Privatumas“, „Išnykstančios žinutės“ ir nustatyk numatytąjį laikmatį, pavyzdžiui, 4 savaites. Taip telefone lieka mažiau susirašinėjimo istorijos. Ekrano nuotraukų, eksportuotų pokalbių ar kopijų, kurias pasidarė gavėjas, tai nepanaikina.
5. **Užrakink programėlę**: „Nustatymai“, „Privatumas“, „Ekrano užraktas“.
6. **Įjunk atsargines kopijas.** Jei telefoną pamesi ar jis suges, be atsarginės kopijos prarasi ir pokalbių istoriją. Nustatymuose atverk atsarginių kopijų skiltį ir įjunk „Signal“ [ištisiniu būdu šifruojamą atsarginę kopiją](https://support.signal.org/hc/en-us/articles/9708267671322-Signal-Secure-Backup). Tekstinėms žinutėms ir pastarųjų 45 dienų medijos failams ji nemokama. Tada „Signal“ parodys 64 simbolių atkūrimo raktą. Užsirašyk jį popieriuje arba išsaugok slaptažodžių tvarkyklėje, nes „Signal“ jo atkurti negali, o be jo atsarginės kopijos atkurti nepavyks.
7. **Patvirtink svarbiausius kontaktus.** Atverk pokalbį, bakstelėk vardą, tada „Rodyti saugumo numerį“ ir palygink jį susitikus gyvai arba kitu kanalu, kuriuo jau pasitiki, pavyzdžiui, telefonu, jei jau žinai, kad numeris, kuriuo skambini, tikrai priklauso tam žmogui. Vien pažįstamo balso nepakanka. Būtent šis žingsnis užtikrina autentiškumą, ir po jo nebepriklausai nuo „Signal“ katalogo, todėl vieną kartą atlik jį su tais keliais žmonėmis, kurie tau svarbiausi.
8. **Perkelk savo žmones**, tik neskelbk revoliucijos. Iš naujosios programėlės parašyk 5 artimiausiems kontaktams, ten pat sukurk šeimos grupę, o senoji programėlė tegul pamažu pasimiršta.

## Klaidos, kurių verta vengti

- **Manyti, kad „užšifruota“ reiškia „privatu“.** Šifravimas apsaugo turinį, bet neslepia, su kuo bendrauji, nebent susirašinėjimo programėlė sukurta būtent tam.
- **Pamiršti patį telefoną.** Kiekvienas, kam į rankas pateks atrakintas tavo telefonas, gali perskaityti viską, todėl stiprus ekrano užraktas yra ir susirašinėjimo programėlės saugumo dalis.
- **Palikti įjungtas nešifruotas debesijos atsargines kopijas.** Nešifruotoje atsarginėje kopijoje lieka perskaitomi pokalbiai, kurie perduodant buvo šifruojami. Patikrink nustatymus ir nepamiršk, kad svarbi ir pašnekovo atsarginė kopija.
- **Laukti, kol persikels visi.** Dalis artimųjų ir pažįstamų liks ten, kur yra, o 2 programėlės vienu metu yra visiškai priimtinas rezultatas.
- **Painioti privatumą su anonimiškumu.** Su telefono numeriu susieta susirašinėjimo programėlė apsaugo tai, ką sakai, bet ne tai, kas esi. Jei reikia, kad tavęs niekas neatpažintų, rinkis programėlę be telefono numerio.
- **Pasitikėti programėle labiau nei žmogumi.** Ekrano nuotrauką gali padaryti bet kas, o silpniausia pokalbio vieta dažnai būna kitas jo galas.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl nuo tavo raktų priklauso tavo interneto sauga“, pranešimą skaito Satoshine. Tavo žinutes saugantys raktai remiasi ta pačia idėja kaip ir raktai, saugantys bitkoinus.
- **Išsamiai palygink susirašinėjimo programėles:** „Privacy Guides“, „Real-Time Communication“ (privacyguides.org).
- **Suprask, kas gresia būtent tau:** „Surveillance Self-Defense“, parengė organizacija „Electronic Frontier Foundation“ (ssd.eff.org).
- **Kitas skyrius:** tavo slaptažodžiai ir paskyros.

## Šaltiniai

- [Set and manage disappearing messages](https://support.signal.org/hc/en-us/articles/360007320771-Set-and-manage-disappearing-messages), „Signal Support“, tikrinta 2026 m. spalio 22 d.
- [Scammers use fake emergencies to steal your money](https://consumer.ftc.gov/articles/scammers-use-fake-emergencies-steal-your-money), JAV Federalinė prekybos komisija (FTC), tikrinta 2026 m. spalio 22 d.
- [Proposal for a regulation laying down rules to prevent and combat child sexual abuse, COM(2022) 209](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex:52022PC0209), Europos Komisija, 2022 m. gegužės 11 d.
- [Legislative train: combating child sexual abuse online](https://www.europarl.europa.eu/legislative-train/theme-promoting-our-european-way-of-life/file-combating-child-sexual-abuse-online), Europos Parlamentas, atnaujinta 2026 m. rugsėjo 20 d., tikrinta 2026 m. spalio 29 d.
- [Outcome of the 6th trilogue on 29 September 2026 and way forward (WK 15082/2026)](https://data.consilium.europa.eu/doc/document/WK-15082-2026-INIT/en/pdf), Europos Sąjungos Taryba, 2026 m. rugsėjo 30 d.
- [Combating child sexual abuse online: support for more limited ePrivacy derogation](https://www.europarl.europa.eu/news/en/press-room/20260706IPR46318/combating-child-sexual-abuse-support-for-a-more-limited-eprivacy-derogation), Europos Parlamentas, 2026 m. liepos 9 d.
- [Fighting child sexual abuse online: interim measure protecting children now reinstated](https://www.consilium.europa.eu/en/press/press-releases/2026/07/23/fighting-child-sexual-abuse-online-interim-measure-protecting-children-now-reinstated/), Europos Sąjungos Taryba, 2026 m. liepos 23 d.
- [Mobile Communications Best Practice Guidance](https://www.cisa.gov/resources-tools/resources/mobile-communications-best-practice-guidance), CISA, 2024 m. gruodžio 18 d.
- [What is a safety number and why do I see that it changed?](https://support.signal.org/hc/en-us/articles/360007060632-What-is-a-safety-number-and-why-do-I-see-that-it-changed), „Signal Support“, žiūrėta 2026 m. rugsėjį.
- [Deploying key transparency at WhatsApp](https://engineering.fb.com/2023/04/13/security/whatsapp-key-transparency/), „Engineering at Meta“, 2023 m. balandžio 13 d.
- [Advancing iMessage security: iMessage Contact Key Verification](https://security.apple.com/blog/imessage-contact-key-verification/), „Apple Security Research“, 2023 m.
- [Olvid secure channels](https://olvid.io/faq/olvid-secure-channels/), „Olvid“, žiūrėta 2026 m. rugsėjį.
- [What are Signal Secure Backups?](https://support.signal.org/hc/en-us/articles/9708267671322-Signal-Secure-Backup), „Signal Support“, tikrinta 2026 m. spalio 29 d.
- [Session Development Update: Pro Beta and Protocol v2](https://getsession.org/session-development-update-pro-beta-protocol-v2), „Session“, 2026 m. rugpjūčio 2 d., tikrinta 2026 m. spalio 29 d.
- [Another private equity firm acquires Threema](https://www.privacyguides.org/news/2026/01/16/another-private-equity-firm-acquires-threema/), „Privacy Guides“, 2026 m. sausį, tikrinta 2026 m. spalio 29 d.

## Tavo veiksmų sąrašas

- [ ] Įdiek privačią susirašinėjimo programėlę, apsaugok ją PIN kodu, paslėpk telefono numerį ir įjunk išnykstančias žinutes (5 min.)
- [ ] Perkelk 5 artimiausius kontaktus ir šeimos grupę (1 val.)
- [ ] Patvirtink 3 svarbiausių kontaktų saugumo numerius (5 min.)
- [ ] Įdiek antrą susirašinėjimo programėlę, kuriai nereikia telefono numerio (5 min.)
- [ ] Programėlėse, kurias pasilieki, įjunk šifruotas atsargines kopijas (5 min.)
