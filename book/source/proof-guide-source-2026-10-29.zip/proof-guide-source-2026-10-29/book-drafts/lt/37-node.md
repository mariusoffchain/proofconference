# 18 skyrius: Kaip paleisti savo mazgą

## Trumpai

Kol neturi savo mazgo, piniginė apie tavo pinigus klausia svetimo serverio. Mazgas yra nuosava Bitcoin taisyklių ir registro kopija, kuri kiekvieną bloką ir kiekvieną transakciją patikrina savarankiškai, todėl nuo svetimo atsakymo nebepriklausai. Jis saugo tavo privatumą ir stiprina tinklą. Mazgui reikia mažo nuolat įjungto kompiuterio, 2 TB SSD disko, tavo savaitgalio ir dar kelių dienų sinchronizavimui, kai kompiuteris dirba be tavęs. Mazgas nėra kasėjas ir nieko neuždirba.

## Piniginė apie tavo pinigus klausia nepažįstamojo

Kai atveri piniginės programėlę, jai reikia sužinoti likutį. Registro ji neturi, todėl klausia serverio, kas vyko tavo adresuose. Tas serveris priklauso piniginės kūrėjui arba nežinomam savanoriui.

Iš to išplaukia 2 dalykai. Pirma, serveris gali sužinoti, kurie adresai yra tavo (visi iki vieno), o kartu ir IP adresą. 16 skyriuje aprašytos atskiros piniginės ir nauji adresai vėl sugrupuojami kažkieno veiklos įrašuose. Antra, atsakymu tenka tikėti, nes jei serveris klysta, neveikia ar yra nesąžiningas, piniginė rodo tai, kas jai buvo pasakyta.

Mažoms sumoms tai protingas kompromisas, ir dauguma žmonių pradeda būtent taip. Vis dėlto tai keista tvarka sistemoje, sukurtoje taip, kad niekuo nereikėtų pasitikėti. Kai turi savo mazgą, klausimas lieka namų tinkle.

## Kompiuteris, kuris kiekvieną taisyklę tikrina savarankiškai

**Mazgas** yra kompiuteris, kuriame veikia Bitcoin programinė įranga, dažniausiai „Bitcoin Core“ (yra ir kitų realizacijų, pavyzdžiui, „Bitcoin Knots“). Jis atsisiunčia visą registrą nuo pirmojo bloko, sukurto 2009 m., ir kiekvieną transakciją patikrina pagal taisykles, o tai reiškia, kad jokia moneta neišleista dukart, jokia moneta nesukurta iš nieko ir monetų niekada nėra daugiau kaip 21 mln. Tą patį jis kartoja su kiekvienu nauju bloku, maždaug kas 10 minučių, ir būtent tai reiškia posakis „Nepasitikėk, tikrink“ (angl. „don't trust, verify“).

Mazgas priima tik tai, kas atitinka taisykles, pagal kurias jis veikia. Kai taip daro tūkstančiai žmonių, kitokių taisyklių norinti įmonė, kasėjas ar vyriausybė pirmiausia turėtų juos įtikinti įdiegti kitą programinę įrangą.

Mazgas nėra kasėjas. Jis naudoja mažai elektros, nieko neuždirba ir privačiųjų raktų laikyti neprivalo. Čia aprašytoje vien tikrinimui skirtoje sąrankoje raktai lieka atskiroje piniginėje arba pasirašymo įrenginyje. „Bitcoin Core“ gali veikti ir kaip piniginė. Jei šia funkcija naudojiesi, pasidaryk ir tos piniginės atsarginę kopiją.

Jam reikia mažo nuolat įjungto kompiuterio, įprasto namų interneto ryšio ir 2 TB SSD disko. 2026 m. rugsėjo mėn. duomenimis, registras užima [apie 770 GB](https://www.blockchain.com/explorer/charts/blocks-size) ir [kas mėnesį padidėja 5-10 GB](https://bitcoincore.org/en/download/), o Electrum serverio indeksui reikia dar nuo kelių dešimčių iki daugiau kaip 100 GB, tad 1 TB diskas būtų beveik pilnas.

## Kuo vis dar tenka pasitikėti turint mazgą

Visą knygą lydintis klausimas, kas yra patikima trečioji šalis ir ar gali ją patikrinti, čia baigiasi. Kai kalbama apie tavo pinigų būklę, turint mazgą atsakymas yra „niekas“. Mazgas netiki nei piniginės kūrėjo serveriu, nei mazgais, prie kurių jungiasi, nes kiekvieną jų atsiųstą bloką patikrina pagal taisykles ir atmeta, jei jis negalioja, kad ir kas jį būtų atsiuntęs. Įgyji autentiškumą (matomas likutis yra tikras) ir kontroliuoji, kokias taisykles priimi.

Lieka 2 dalykai. Pirmasis yra programinė įranga, nes mazgas vykdo įdiegtos programos taisykles, o suklastota kopija vykdytų kažkieno kito taisykles. „Bitcoin Core“ projektas į tai atsako atkartojamu programos surinkimu (angl. reproducible builds), kai keli kūrėjai kiekvieną versiją sukompiliuoja nepriklausomai, gauna identiškus failus ir [paskelbia savo parašus](https://github.com/bitcoin-core/guix.sigs). Patikrinus kelis iš jų nebereikia pasikliauti vieno žmogaus sąžiningumu. Mazgo platforma į šį sąrašą įtraukia ir savo kūrėją, kuriuo tenka pasitikėti dėl sistemos, programėlių parduotuvės ir naujinių. Antrasis yra tavo kompiuterio aparatinė įranga ir operacinė sistema, kurių iki galo audituoti negali.

Visa tai kainuoja diską, savaitgalį ir šiek tiek priežiūros, o mažoms sumoms viešas serveris tebėra protingas pasirinkimas.

## Kaip pasirinkti kelią

Kad ir kurį kelią pasirinktum, veiks ta pati Bitcoin programinė įranga, o skiriasi keliai tuo, kiek darbo padaroma už tave.

Kasdieniame kompiuteryje lengvesnis variantas yra **apkarpytasis mazgas** (angl. pruned node). Jis patikrina viską, bet saugo tik naujausius blokus, todėl nustačius mažą apkarpymo ribą jam gali pakakti maždaug 10 GB ir dar vietos augimui bei kitiems failams. Visą istoriją jis vis tiek atsisiunčia ir patikrina, todėl apkarpymas nesumažina duomenų kiekio, kurį reikia atsisiųsti pradžioje. Tačiau daugumai piniginėms skirtų serverio programų reikia viso registro, todėl atskirame, tik tam skirtame mazge jis laikomas visas.

| Kelias | Kas tai | Privalumai | Kompromisai | Kuo vis dar pasitiki |
|---|---|---|---|---|
| **Bitcoin Core kasdieniame kompiuteryje** | Etaloninė atvirojo kodo programinė įranga iš svetainės bitcoincore.org | Nemokama, paprasčiausia pradžia, turi savo piniginę, mažame diske gali veikti apkarpytuoju režimu | Veikia ne visą laiką. Be apkarpytojo režimo užima didžiąją 1 TB disko dalį | „Bitcoin Core“ kūrėjais, nebent patikrini kelių surinkėjų parašus, ir savo kasdieniu kompiuteriu |
| **Umbrel** | Namų serverio sistema su programėlių parduotuve. Veikia tavo kompiuteryje arba bendrovės parduodamame įrenginyje | Dailiausia sąsaja, programėlės įdiegiamos vienu spustelėjimu | Kuria viena bendrovė. Asmeniniam naudojimui nemokama, tačiau licencija nėra atvirojo kodo (komerciškai pakartotinai naudoti negalima) | Dar ir bendrove „Umbrel“ dėl sistemos, jos programėlių parduotuvės ir naujinių. Kodą galima perskaityti |
| **Start9 (StartOS)** | Atvirojo kodo serverio sistema. Veikia tavo kompiuteryje arba bendrovės parduodamame serveryje | Daug dėmesio skiriama privatumui ir paslaugų laikymui nuosavame serveryje, gera dokumentacija | Kuria viena bendrovė. Iš pradžių reikia išmokti šiek tiek daugiau | Dar ir bendrove „Start9“ dėl sistemos, jos programėlių prekyvietės ir naujinių. Prie sistemos atvaizdo (angl. image) pridedama kontrolinė suma ir parašas |
| **RaspiBlitz** | Atvirojo kodo bendruomenės projektas, skirtas kompiuteriui „Raspberry Pi“ | Nėra jokios įmonės, stiprūs Lightning įrankiai | Techniškesnis, dalį darbų reikia atlikti komandų eilutėje | Projektą prižiūrinčiais savanoriais. Surinkimo scenarijai vieši, o atvaizdas pasirašytas pagrindinio kūrėjo PGP parašu |
| **MyNode** | Mazgo sistema mažiems kompiuteriams, turinti nemokamą bendruomenės versiją ir mokamą išplėstinę versiją | Paprasta žiniatinklio sąsaja, daug Bitcoin programėlių | Kuria maža bendrovė, dalis funkcijų prieinama tik mokamoje versijoje | Dar ir bendrove „MyNode“ dėl sistemos, jos pateikiamų programėlių ir naujinių |
| **Savarankiškas kelias** | „Linux“ sistema „Debian“ arba „Ubuntu“, tada „Bitcoin Core“, tada Electrum serveris („electrs“ arba „Fulcrum“), viską diegiant pagal vadovą | Supranti kiekvieną dalį. Niekas nepaslėpta, viskas atvirojo kodo | Lėta, dirbama tik komandų eilutėje. Tiems, kam patinka mokytis | Tik programine įranga, kurios parašus tikrini tu, pasirinkto vadovo autoriais ir savo aparatine įranga |

Sistemos „Umbrel“ ir „Start9“ kartu yra ir bendrosios paskirties namų serveriai, o tai siejasi su 10 skyriumi, nes toje pačioje dėžutėje gali laikyti ir savo failus bei nuotraukas.

Daugumai žmonių protingas derinys būtų toks: iš pradžių išbandyti „Bitcoin Core“ savo kompiuteryje apkarpytuoju režimu ir pamatyti, kas yra mazgas, o paskui pereiti prie atskiro mažo kompiuterio su ta platforma, kurios kompromisai tau priimtini.

## Keli žodžiai apie Lightning mazgus

Tos pačios platformos leidžia 1 spustelėjimu įdiegti Lightning mazgą („LND“ arba „Core Lightning“). Laikyk tai vėlesniu projektu. Lightning mazgas kanaluose laiko tikras lėšas, ir tai vyksta kompiuteryje, kuris visada prijungtas prie interneto. Kanalams reikia atskirų atsarginių kopijų, nuolatinio dėmesio ir supratimo, kas nutiks sugedus diskui, o neteisingai atkūrus seną atsarginę kopiją galima net prarasti kanale esančias lėšas. Vien Bitcoin mazgas gali sugesti be jokių nuostolių, nes tereikia sinchronizuoti iš naujo, o apie Lightning mazgą to pasakyti negalima. Mokykis su mažomis sumomis ir tik tada, kai visa kita šiame skyriuje taps įprasta.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta platforma su programėlių parduotuve, tokia kaip „Umbrel“ arba „StartOS“. Platformose „RaspiBlitz“ ir „MyNode“ eiga ta pati. Tavo darbas telpa į savaitgalį, o paskui kompiuteris dar kelias dienas turi padirbėti vienas.

1. **Pasirink aparatinę įrangą.** Naudotas minikompiuteris arba naujesnis „Raspberry Pi“ su 8 GB atminties, žinomo gamintojo 2 TB SSD diskas ir tinklo kabelis iki maršrutizatoriaus.
2. **Įdiek platformą** pagal oficialų jos vadovą iš atvaizdo, atsisiųsto iš oficialios svetainės, ir nustatyk stiprų unikalų slaptažodį (žr. 2 skyrių). Jei projektas skelbia to atvaizdo kontrolinę sumą arba parašą, kaip daro [„Start9“](https://docs.start9.com/start-os/0.4.0.x/installing-startos.html) ir [„RaspiBlitz“](https://docs.raspiblitz.org/docs/faq), patikrink juos dar prieš įrašant atvaizdą į diską. Būtent šiuo žingsniu pasitikėjimą atsisiųstu failu pakeiti patikra.
3. **Įdiek Bitcoin programėlę ir leisk jai sinchronizuotis.** Tai trunka kelias dienas, o lėtoje aparatinėje įrangoje, pavyzdžiui, kompiuteryje „Raspberry Pi“, iki savaitės. Kai įmanoma, palik mazgą veikti. Jei reikia sustabdyti, tvarkingai išjunk mazgą per sąsają ir leisk sinchronizavimui vėliau tęstis. Maitinimo neatjunk.
4. **Įdiek Electrum serverio programėlę** („electrs“ arba „Fulcrum“). Ji sukuria indeksą, kad piniginės galėtų klausti tavo mazgo, ir tam prireikia dar kelių valandų, o kartais visos paros.
5. **Prijunk piniginę.** Programoje „Sparrow“, „BlueWallet“ arba „Nunchuk“ atverk serverio arba tinklo nustatymus ir vietoj viešojo serverio įrašyk savo Electrum serverio adresą. Nuo šio žingsnio piniginė rodo tai, ką patikrino tavo mazgas, o ne tai, ką jai pasakė trečioji šalis. Programėlė „Zeus“ veikia kitaip, nes jungiasi prie Lightning mazgo, o tai jau vėlesnis etapas.
6. **Kai esi ne namie, prie jo junkis** per Tor tinklą arba privatų VPN (žr. 10 skyrių). Sistemos „umbrelOS“ ir „StartOS“ prieigą per Tor siūlo kaip pasirinkimą.
7. **Nuolat jį atnaujink,** o atkūrimo frazių atsargines kopijas laikyk atskirai nuo mazgo. Vien tikrinimui skirtam mazgui atkūrimo frazės nereikia, ir jis niekada neturėtų jos matyti. Jei įjungi „Bitcoin Core“ piniginę arba įdiegi Lightning, tas pinigines apsaugok ir jų atsargines kopijas pasidaryk atskirai.

## Klaidos, kurių verta vengti

- **Naudoti pigią SD kortelę ar USB atmintuką arba per mažą diską.** Mazgas į diską rašo nuolat, o SD kortelės ir USB atmintukai paprastai sugenda per kelis mėnesius ir gali sugadinti duomenis. Naudok tikrą 2 TB SSD diską, nes, 2026 m. rugsėjo mėn. duomenimis, 1 TB beveik nepalieka atsargos, o [„RaspiBolt“ vadove dabar irgi prašoma 2 TB](https://raspibolt.org/).
- **Neapsaugoti maitinimo.** Staiga dingus elektrai gali būti sugadinta duomenų bazė, ir tai kainuotų kelias sinchronizavimo dienas. Visada išjunk mazgą per sąsają ir pagalvok apie nedidelį nenutrūkstamo maitinimo šaltinį (UPS).
- **Manyti, kad mazgas laiko tavo monetas.** Vien tikrinimui skirtame mazge nėra raktų, kuriais galima išleisti lėšas. Pasirenkama „Bitcoin Core“ piniginė ir Lightning programėlė raktus laiko, todėl joms reikia atskirų atsarginių kopijų. Jei raktai laikomi atskirai, sugedusį tikrinimo mazgą galima sukurti iš naujo neprarandant lėšų.
- **Atverti mazgą internetui.** Neatidarinėk maršrutizatoriaus prievadų, kad pasiektum valdymo skydelį. Naudok Tor tinklą arba VPN.
- **Pasiduoti per pirmąjį sinchronizavimą.** Kelias dienas gali atrodyti, kad jis užstrigo, nors iš tikrųjų tikrina daugiau kaip 15 metų transakcijas, o tai padaryti reikia tik kartą.
- **Atsisiųsti programinę įrangą ne iš ten, kur reikia, arba jos nepatikrinti.** Programą „Bitcoin Core“ siųskis tik iš bitcoincore.org, o kiekvieną platformą iš oficialios jos svetainės. [„Bitcoin Core“ atsisiuntimo puslapyje](https://bitcoincore.org/en/download/) paaiškinta, kaip sutikrinti failą su paskelbtu kontrolinių sumų sąrašu ir kaip patikrinti, ar tas sąrašas pasirašytas kelių kūrėjų PGP parašais. Platformoje pasikliauji tuo, kad jos kūrėjas tai padaro su programėlėmis, kurias ji įdiegia, o savo kompiuteryje ir einant savarankišku keliu tai tavo darbas.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl centralizuoti pinigai neveikia: kaip Bitcoin tapo alternatyva“, pranešimą skaito Piktas. Mazgas yra būdas tą alternatyvą patikrinti savarankiškai. Taip pat žr. pranešėjo Alexis Roussel pranešimą apie decentralizuotas atvirojo kodo technologijas.
- **Pagrindai:** „Bitcoin Core“ atsisiuntimo puslapis (bitcoincore.org), kuriame nurodyti dabartiniai reikalavimai, aprašytas apkarpytasis režimas ir atsisiųsto failo tikrinimo tvarka.
- **Savarankiškas kelias:** vadovas „RaspiBolt“ (raspibolt.org, 4 versija, atnaujinta 2026 m. rugpjūtį) ir „MiniBolt“, panašus vadovas įprastiems kompiuteriams (minibolt.minibolt.info). 2026 m. rugsėjo mėn. duomenimis, abu vadovai prižiūrimi.
- **Kaip prijungti piniginę prie savo mazgo:** „Sparrow Wallet“ dokumentacija (sparrowwallet.com/docs).
- **Toliau:** tavo veiksmų sąrašas.

## Šaltiniai

- [Graceful shutdown, stop RPC](https://bitcoincore.org/en/doc/30.0.0/rpc/control/stop/), „Bitcoin Core“ dokumentacija, tikrinta 2026 m. spalio 22 d.
- [Blockchain size chart](https://www.blockchain.com/explorer/charts/blocks-size), „Blockchain.com“, žiūrėta 2026 m. rugsėjo 20 d. (apie 770 GB).
- [Download Bitcoin Core, with requirements and verification of the download](https://bitcoincore.org/en/download/), „Bitcoin Core“ projektas, žiūrėta 2026 m. rugsėjį.
- [Signatures of the Bitcoin Core builders (guix.sigs)](https://github.com/bitcoin-core/guix.sigs), „Bitcoin Core“ projektas platformoje „GitHub“, atnaujinama su kiekviena versija.
- [Installing StartOS, with verification of the download](https://docs.start9.com/start-os/0.4.0.x/installing-startos.html), „Start9“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [RaspiBlitz FAQ, how to verify the SD card image](https://docs.raspiblitz.org/docs/faq), „RaspiBlitz“ projektas, žiūrėta 2026 m. rugsėjį.
- [RaspiBolt, version 4](https://raspibolt.org/), bendruomenės vadovas „RaspiBolt“, atnaujinta 2026 m. rugpjūtį.
- [MiniBolt](https://minibolt.minibolt.info/), bendruomenės vadovas „MiniBolt“, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Atverk piniginės tinklo nustatymus ir pažiūrėk, kuriuo serveriu ji naudojasi šiandien (5 min.)
- [ ] Patikrink atsisiųstą „Bitcoin Core“ failą, įdiek programą apkarpytuoju režimu, kad ji neužpildytų disko, ir stebėk, kaip ji sinchronizuojasi (1 val.)
- [ ] Pasirink platformą ir aparatinę įrangą atskiram mazgui su 2 TB SSD disku (1 val.)
- [ ] Surink mazgą, paleisk sinchronizavimą (kelios dienos be priežiūros) ir pridėk Electrum serverį (savaitgalis)
- [ ] Nukreipk piniginę į savo mazgą ir pašalink viešąjį serverį (5 min.)
