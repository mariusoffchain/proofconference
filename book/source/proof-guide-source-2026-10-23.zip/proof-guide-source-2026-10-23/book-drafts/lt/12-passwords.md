# 2 skyrius: Tavo slaptažodžiai ir paskyros

## Trumpai

Keliose svetainėse kartojamas slaptažodis, greta sukčiavimo apsimetant (angl. phishing), tebėra vienas dažniausių būdų perimti paprastų žmonių paskyras. Slaptažodžių tvarkyklė kiekvienai svetainei sukuria ir įsimena vis kitą slaptažodį, o ją pačią apsaugai viena stipria slaptafraze. Tada svarbiausiose paskyrose įjungi antrąjį veiksnį, pirmiausia el. pašto, nes tas, kieno rankose tavo el. paštas, gali atkurti beveik visų kitų paskyrų slaptažodžius.

## Nutekėjęs slaptažodis atrakina daug durų

2019 m. sausį saugumo tyrėjas Troy Hunt viename įsilaužėlių forume aptiko platinamą failų rinkinį, pavadintą [„Collection #1“](https://www.troyhunt.com/the-773-million-record-collection-1-data-reach/). Jame buvo 773 mln. unikalių el. pašto adresų ir daugiau kaip 21 mln. unikalių slaptažodžių, surinktų iš tūkstančių senesnių duomenų nutekėjimų. Tokius sąrašus užpuolikai sukelia į programas, kurios kiekvieną adreso ir slaptažodžio porą išbando kitose paslaugose, pavyzdžiui, tavo el. pašte, parduotuvėse ir socialiniuose tinkluose. Ši technika vadinama **masiniu nutekėjusių prisijungimo duomenų bandymu** (angl. credential stuffing).

Asmeniškai į tave niekas nesitaiko, tiesiog durys atsidaro visur, kur dar kartą panaudojai nutekėjusį slaptažodį. Būtent taip nuo 2023 m. balandžio iki rugsėjo nukentėjo genetinių tyrimų bendrovė „23andMe“. Jungtinės Karalystės priežiūros institucija [2025 m. birželį skyrė jai 2,31 mln. svarų sterlingų baudą](https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/2025/06/23andme-fined-for-failing-to-protect-uk-users-genetic-data/) po to, kai buvo atskleisti 155 592 šios šalies gyventojų duomenys, ir pažymėjo, kad prisijungiant bendrovė nereikalavo antrojo veiksnio.

Ar tavo adresas pateko į žinomus nutekėjimus, gali pasitikrinti nemokamoje svetainėje [„Have I Been Pwned“](https://haveibeenpwned.com/), kurią tvarko Troy Hunt. Tie, kas internetu naudojasi 10 metų, paprastai randa kelis nutekėjimus. Svarbiausia paskyra yra el. paštas, nes tas, kas ją valdo, gali spustelėti „pamiršau slaptažodį“ beveik visur kitur.

## Viena slaptafrazė, o tada antrasis veiksnys

**Slaptažodžių tvarkyklė** yra šifruota saugykla, kuri kiekvienai svetainei sukuria ilgą atsitiktinį slaptažodį, jį įsimena ir už tave įrašo. Saugykla užšifruojama tavo įrenginyje dar prieš sinchronizuojant, todėl, jei paslauga sukurta gerai, teikėjas jos perskaityti negali, o tau užtenka atsiminti 1 paslaptį vietoj 100. Ta paslaptis turėtų būti **slaptafrazė** iš 6 atsitiktinių žodžių, parinktų, pavyzdžiui, metant kauliuką ir pagal iškritusius skaičius ieškant žodžių sąraše (šis metodas vadinamas „diceware“). Ją sunku atspėti, o įsiminti kur kas lengviau nei „xK9#qL2v“.

**Dviejų veiksnių autentifikavimas** (2FA) prideda dar vieną žingsnį po slaptažodžio: svetainė paprašo to, ką turi. SMS žinute atsiųstas kodas yra silpnas variantas, nes nusikaltėlis gali įkalbėti operatorių ir tavo numerį persikelti į savo SIM kortelę. Tokia ataka vadinama SIM kortelės perėmimu (angl. SIM swap). 2020 m. kovą [Europolas pranešė, kad Ispanijoje sulaikyta 12 žmonių](https://www.europol.europa.eu/media-press/newsroom/news/sim-highjackers-how-criminals-are-stealing-millions-highjacking-phone-numbers), kurie naudodami SIM kortelių dublikatus daugiau kaip 100 kartų ištuštino banko sąskaitas ir iš viso pasisavino daugiau kaip 3 mln. eurų.

Autentifikavimo programėlė yra gerokai geresnis variantas, o stipriausias yra aparatinis saugos raktas. **Prieigos raktai** (angl. passkeys) remiasi ta pačia technologija kaip šie raktai ir pakeičia patį slaptažodį.

## Net ir su nuliniu žinojimu lieka saugyklos laikytojas

Šifravimas užtikrina sinchronizuojamos saugyklos konfidencialumą, tačiau bendrovė, kuri ją laiko ir siunčia tau naujinius, lieka patikima trečiąja šalimi. Teikėjai tokią architektūrą vadina nulinio žinojimo (angl. zero knowledge) architektūra: saugyklą jie laiko, bet ją atrakinančios slaptafrazės neturi. 2022 m. gruodį bendrovė „LastPass“ [patvirtino, kad įsilaužėlis nusikopijavo klientų saugyklų atsarginę kopiją](https://blog.lastpass.com/posts/notice-of-recent-security-incident). Slaptažodžiai ir užrašai buvo užšifruoti, svetainių adresai ne, o kiekviena pavogta saugykla liko tik tiek saugi, kiek stiprus buvo jos savininko pagrindinis slaptažodis. Jungtinės Karalystės priežiūros institucija, kuri [2025 m. gruodį skyrė bendrovei 1,2 mln. svarų sterlingų baudą](https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/2025/12/password-manager-provider-fined/) dėl to, kad nukentėjo iki 1,6 mln. šios šalies naudotojų, nerado įrodymų, kad slaptažodžiai būtų buvę iššifruoti.

Kai programėlė yra atvirojo kodo, ekspertai šį teiginį gali palyginti su kodu, o papildomų įrodymų duoda paskelbti auditai, pavyzdžiui, [saugumo sertifikatas, kurį Prancūzijos kibernetinio saugumo agentūra ANSSI 2025 m. suteikė programai „KeePassXC“](https://keepassxc.org/audits/). Jei saugyklą laikai vietiniame faile arba nuosavame serveryje, saugyklos laikytojo nebelieka, bet tada atsarginės kopijos, naujiniai ir sinchronizavimas tampa tavo rūpesčiu.

Trečiųjų šalių turi ir antrieji veiksniai. Svetainė saugo tą pačią paslaptį kaip ir autentifikavimo programėlė, o jos kopiją gali turėti ir sinchronizavimo paslauga. O aparatinis raktas autentiškumą tikrina dar ir priešinga kryptimi, nes patikrina, kuri svetainė į jį kreipiasi.

## Kaip pasirinkti slaptažodžių tvarkyklę

Visi toliau pateikti variantai kur kas geresni už kartojamus slaptažodžius, o skiriasi jie tuo, kas laiko tavo šifruotą saugyklą, ar kodas viešas ir kiek darbo sutinki prisiimti.

| Tvarkyklė | Atvirasis kodas | Kur laikoma saugykla | Kuo tenka pasitikėti ir ką gali patikrinti | Kaina | Kompromisai |
|---|---|---|---|---|---|
| **[Bitwarden](https://bitwarden.com/)** | Taip | „Bitwarden“ debesijoje arba nuosavame serveryje | Bendrove „Bitwarden“, kuri laiko saugyklą ir teikia programėlių naujinius. Kodas viešas, kasmet skelbiami nepriklausomi auditai. Paleidus tvarkyklę nuosavame serveryje bendrovės nebereikia. | Nemokama, yra pasirenkamas mokamas planas | Lengviausias atvirojo kodo variantas, veikia visuose įrenginiuose. Numatytąją paslaugą valdo viena JAV bendrovė. |
| **[KeePassXC](https://keepassxc.org/)** | Taip | Faile tavo kompiuteryje | Saugyklos laikytojo nėra. Pasikliauji viešu programos kodu, kurį 2025 m. sertifikavo ANSSI, ir savo atsarginėmis kopijomis. | Nemokama | Nėra nei bendrovės, nei debesijos, nei paskyros. Sinchronizavimu ir atsarginėmis kopijomis rūpiniesi tu. Telefone naudok suderinamas programėles, pavyzdžiui, [„KeePassDX“](https://www.keepassdx.com/) („Android“) arba [„KeePassium“](https://keepassium.com/) („iPhone“). |
| **[Proton Pass](https://proton.me/pass)** | Taip | „Proton“ debesijoje (Šveicarijos bendrovė) | Bendrove „Proton“, kuri laiko saugyklą ir teikia programėlių naujinius. Programėlių kodas viešas, 2023 m. jo auditą atliko bendrovė „Cure53“. Nuosavame serveryje paleisti negalima. | Nemokama, yra pasirenkamas mokamas planas | Yra el. pašto pseudonimai. Patogu, jei jau naudojiesi „Proton“ paslaugomis, tačiau taip dar didesnė tavo gyvenimo dalis sutelkiama vienoje bendrovėje. |
| **[1Password](https://1password.com/)** | Ne, kodas uždaras | „1Password“ debesijoje (Kanados bendrovė) | Bendrove „1Password“, kuri laiko saugyklą, teikia naujinius ir valdo patį kodą. Ji skelbia auditų ataskaitas, bet ne programos kodą. | Tik mokama prenumerata | Išbaigtas produktas, patogus šeimoms, reguliariai audituojamas. Viešai kodo patikrinti negalima. |
| **Įtaisyta naršyklėje arba sistemoje** ([„Google“](https://passwords.google.com/), [„Apple“](https://support.apple.com/en-us/120758), [„Firefox“](https://www.firefox.com/en-US/features/password-manager/)) | Įvairiai | Tavo „Google“, „Apple“ arba „Mozilla“ paskyroje | Bendrove „Google“, „Apple“ arba „Mozilla“, kuri laiko saugyklą, teikia naujinius ir atkuria paskyrą. Visas kodas viešas tik naršyklės „Firefox“. | Nemokama | Jau yra įrenginyje, ir tai kur kas geriau nei nieko. Pririša prie vienos naršyklės ar ekosistemos, o saugi tik tiek, kiek saugi ta pagrindinė paskyra. |

Daugumai žmonių protingas derinys būtų toks: **tvarkyklė „Bitwarden“ arba „Proton Pass“**, jei nori sinchronizavimo be pastangų, arba **programa „KeePassXC“**, jei nenori, kad tavo saugyklą, net ir šifruotą, laikytų kokia nors bendrovė.

## Kaip pasirinkti autentifikavimo programėlę

Autentifikavimo programėlė rodo 6 skaitmenų kodą, kuris keičiasi kas 30 sekundžių. Svetainė ir telefonas turi bendrą paslaptį (tai QR kodas, kurį vieną kartą nuskenuoji) ir abu pagal ją apskaičiuoja tą patį kodą net be tinklo ryšio, todėl daugumai paskyrų tai tinkamas antrasis veiksnys. Rinkis atvirojo kodo programėlę, iš kurios kodus galima vėl išsikelti: jei paslaptys laikomos tik 1 telefone, jį pametus ar jam sugedus iškart nebepateksi niekur. Šiuos kodus dažnai gali saugoti ir slaptažodžių tvarkyklė. Tai patogu, bet tada abu veiksniai atsiduria vienoje vietoje.

| Programėlė | Platformos | Atvirasis kodas | Atsarginės kopijos ir sinchronizavimas | Kompromisai |
|---|---|---|---|---|
| **[Aegis](https://getaegis.app/)** | Tik „Android“ | Taip | Šifruota saugykla laikoma telefone. Šifruotas atsargines kopijas eksportuoji savarankiškai. | Nėra nei debesijos, nei paskyros, todėl nereikia pasitikėti jokia sinchronizavimo paslauga. Atsarginėmis kopijomis rūpiniesi tu, o versijos „iPhone“ telefonams nėra. |
| **[Ente Auth](https://ente.com/auth/)** | „Android“, „iPhone“, „Windows“, „Mac“, „Linux“, žiniatinklis | Taip | Pasirinktinai galima įjungti ištisiniu būdu šifruojamą sinchronizavimą, kuriam reikia „Ente“ paskyros. Veikia ir be interneto, ir be paskyros. | Kodus turi visuose savo įrenginiuose. Sinchronizavimas priklauso nuo vienos mažos bendrovės. |
| **[2FAS](https://2fas.com/)** | „Android“, „iPhone“ ir naršyklės plėtinys | Taip | Atsarginė kopija daroma per tavo „Google Drive“ arba „iCloud“ paskyrą. | Paprasta naudotis. Atsarginė kopija saugi tik tiek, kiek saugi ta „Google“ arba „Apple“ paskyra. |
| **[Proton Authenticator](https://proton.me/authenticator)** | „Android“, „iPhone“, „Windows“, „Mac“, „Linux“ | Taip | Veikia be paskyros. Turint „Proton“ paskyrą pasirinktinai galima įjungti ištisiniu būdu šifruojamą sinchronizavimą, be to, kodus galima eksportuoti ir importuoti pačiame įrenginyje. | Nemokama, pasirodė 2025 m. liepą, taigi jaunesnė už kitas. Jei jau naudojiesi „Proton“ paslaugomis, šiai bendrovei patiki dar vieną savo gyvenimo dalį. |

Daugumai žmonių protingas derinys būtų toks: **programėlė „Aegis“** sistemoje „Android“, jei sutinki atsarginėmis kopijomis rūpintis savarankiškai, arba **„Ente Auth“ ar „Proton Authenticator“**, jei nori turėti kodus keliuose įrenginiuose. Kad ir ką pasirinktum, vieną kartą išbandyk eksportą arba atsarginę kopiją.

## Aparatiniai saugos raktai

Aparatinis saugos raktas yra kitokio pobūdžio įrankis. Šis mažas fizinis įrenginys jungiamas į USB jungtį arba priglaudžiamas prie telefono (NFC). Jame laikomas privatusis raktas, kuris sukurtas taip, kad niekada įrenginio nepaliktų, o pats įrenginys remiasi atviraisiais standartais FIDO2 ir WebAuthn. Kai jungiesi, raktas prieš atsakydamas patikrina tikrąjį svetainės adresą, o tau lieka jį paliesti ir taip patvirtinti prisijungimą. Netikras prisijungimo puslapis iš jo nieko negauna, o programėlės kodą apgautas naudotojas vis dar gali įvesti ne tame puslapyje. Tuose pačiuose raktuose galima laikyti ir **prieigos raktus**.

Nusipirk 2 raktus ir abu užregistruok kiekvienoje paskyroje: vienas bus ant raktų ryšulio, kitas saugioje vietoje. Raktus palaiko ne visos svetainės, todėl pasilik ir autentifikavimo programėlę, o raktus pirmiausia naudok svarbiausioms paskyroms: el. paštui, slaptažodžių tvarkyklei ir pagrindinei „Apple“ arba „Google“ paskyrai.

| Raktas | Gamintojas | Jungtis | Atvirasis kodas | Kompromisai |
|---|---|---|---|---|
| **[YubiKey](https://www.yubico.com/)** | „Yubico“ (Švedija ir JAV) | USB-A arba USB-C, daugumoje modelių yra NFC | Ne, programinė aparatinė įranga (angl. firmware) uždara | Palaikomas plačiausiai, dokumentacija išsamiausia. Įrenginio programinės įrangos negalima nei patikrinti, nei atnaujinti. Prisijungti pakanka pigesnės serijos „Security Key“. |
| **[Nitrokey](https://www.nitrokey.com/)** | „Nitrokey“ (Vokietija) | USB-A arba USB-C, kai kuriuose modeliuose yra NFC | Taip, ir įrenginio programinė įranga, ir aparatinė dalis | Įrenginio programinę įrangą galima atnaujinti. Modelių mažiau, dokumentacija ne tokia išbaigta. |
| **[Token2](https://www.token2.com/)** | „Token2“ (Šveicarija) | USB-A arba USB-C, daugumoje modelių yra NFC | Iš dalies. Įrenginio programinės įrangos FIDO2 dalis vieša ir 2024 m. nepriklausomai patikrinta, visa kita uždara | Raktai pigesni. Gamintojas mažiau žinomas. |
| **[OnlyKey](https://onlykey.io/)** | „CryptoTrust“ (JAV) | Tik USB, NFC nėra | Taip, įrenginio programinė įranga | Turi savo mygtukus PIN kodui įvesti ir gali įrašyti išsaugotus slaptažodžius. Didesnis ir sudėtingesnis, nei reikia pradedantiesiems. |

Daugumai žmonių protingas derinys būtų toks: 2 bet kurio iš šių gamintojų raktai ir autentifikavimo programėlė toms svetainėms, kurios raktų nepriima.

## Žingsnis po žingsnio

Pavyzdžiu pasirinkta tvarkyklė „Bitwarden“, nes ji nemokama, atvirojo kodo ir veikia visose sistemose, o kitose tvarkyklėse logika ta pati.

1. **Susikurk slaptafrazę.** Mesk kauliuką ir ieškok žodžių [organizacijos „Electronic Frontier Foundation“ (EFF) žodžių sąraše](https://www.eff.org/dice) arba naudokis tvarkyklės slaptafrazių generatoriumi, kol turėsi 6 žodžius (EFF rekomenduoja ne mažiau kaip 6). Užsirašyk slaptafrazę ant popieriaus ir laikyk tą lapą saugioje vietoje namuose.
2. **Įdiek tvarkyklę** kompiuteryje (kaip naršyklės plėtinį) ir telefone, tada su ta slaptafraze susikurk paskyrą. Jei iš anksto nepasirūpinsi atkūrimu ir ją pamirši, gali netekti visos saugyklos. Bendrovė „Bitwarden“ negali tiesiog atkurti pagrindinio slaptažodžio, o iš anksto nustatyta avarinė prieiga (angl. emergency access) yra atskiras kelias (žr. 8 žingsnį).
3. **Pradėk nuo el. pašto.** Prisijunk prie el. pašto paskyros, pakeisk slaptažodį tvarkyklės sugeneruotu ir išsaugok jį saugykloje.
4. **Perkelk dar 4 paskyras:** pagrindinę „Apple“ arba „Google“ paskyrą, banko ar mokėjimų programėlę, pagrindinį socialinį tinklą ir parduotuvę, kurioje išsaugota tavo mokėjimo kortelė. Kitas perkelsi per ateinančias savaites, kaskart, kai kur nors prisijungsi.
5. **Įjunk 2FA su autentifikavimo programėle** tose 5 paskyrose, pirmiausia el. pašto, ir pačioje slaptažodžių tvarkyklėje. Kiekvienos paskyros saugumo nustatymuose ieškok „patvirtinimas dviem veiksmais“ arba „dviejų veiksnių autentifikavimas“ (angl. „two-step verification“, „two-factor authentication“), tada programėle nuskenuok QR kodą ir įvesk jos rodomą kodą. Jei svetainė leidžia, pašalink SMS žinutes iš patvirtinimo būdų.
6. **Užregistruok aparatinius raktus, jei juos pasirinkai.** Tuose pačiuose saugumo nustatymuose pasirink „saugos raktas“ (angl. „security key“), kartais „prieigos raktas“ (angl. „passkey“). Prijunk arba priglausk pirmąjį raktą, paliesk jį ir suteik jam pavadinimą, tada iškart pakartok tą patį su antruoju. Būtent šis žingsnis pasitikėjimą pakeičia patikrinimu, nes nuo tol kaskart prisijungiant svetainės adresą tikrina raktas, o ne tavo akys. Vieną raktą nešiokis su savimi, kitą laikyk saugioje vietoje. Jei svetainė leidžia, pirmenybę teik išbandytam atsarginiam raktui ir saugiai laikomiems atkūrimo kodams. Autentifikavimo programėlę pasilikti kaip atsarginį būdą patogu, bet jos kodus sukčiai apsimesdami vis tiek gali išvilioti, todėl lieka mažiau saugus būdas prisijungti prie paskyros. Pirmiausia išbandyk atkūrimo galimybes ir tik tada šalink kurį nors prisijungimo būdą.
7. **Išsaugok atkūrimo kodus atskirai nuo slaptafrazės.** Dauguma svetainių duoda vienkartinių kodų tai dienai, kai prarasi telefoną ar raktus. Atsispausdink juos ir laikyk kitoje vietoje nei lapą su slaptafraze, pavyzdžiui, slaptafrazę namuose, o kodus užklijuotame voke pas patikimą giminaitį, kad 1 lapą radęs žmogus negautų visko.
8. **Pasirūpink prieiga nelaimės atveju.** Kai kurios tvarkyklės turi avarinės prieigos funkciją, skirtą patikimam žmogui (tvarkyklėje „Bitwarden“ ji įeina į mokamą planą). Tinka ir rašytiniai nurodymai šeimai, kuriuose pasakyta, kur yra tie 2 lapai.

## Klaidos, kurių verta vengti

- **Laikyti slaptafrazę tik galvoje.** Atmintis gali pavesti po ligos, nelaimingo atsitikimo ar ilgų atostogų. Popierinė kopija saugioje vietoje nėra silpnoji vieta, jei tik atkūrimo kodai laikomi kitur.
- **Palikti SMS žinutes kaip atsarginį būdą.** Jei svetainė vis dar priima SMS kodą, SIM kortelės perėmimas vis dar veikia, todėl pašalink šį būdą visur, kur svetainė leidžia.
- **Turėti 1 autentifikavimo programėlę arba 1 aparatinį raktą ir neturėti jokios atsarginės kopijos.** Pamestas telefonas ar raktas turėtų kainuoti vieną popietę, o ne paskyras, todėl ir eksportuoji kodus bei registruoji 2 raktus.
- **Laikyti slaptažodžius užrašuose, skaičiuoklėse ar el. laiškuose.** Tai nėra šifruotos saugyklos, ir tai vienos pirmųjų vietų, kur ieško įsibrovėlis.
- **Įvesti kodą puslapyje, į kurį patekai iš žinutės.** Sukčiai apsimesdami gali išvilioti ir autentifikavimo programėlės kodus. Jei tvarkyklė nesiūlo įrašyti slaptažodžio, patikrink adresą, nes gali būti, kad atsidūrei netikroje svetainėje.
- **Bandyti viską pakeisti per vieną vakarą.** Pradėk nuo 5 minėtų paskyrų, o kitas perkelk per ateinančias savaites, kaskart, kai kur nors prisijungsi.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl nuo tavo raktų priklauso tavo interneto sauga“, pranešimą skaito Satoshine. Slaptafrazė, aparatinis raktas ir prieigos raktas įgyvendina tą pačią idėją, t. y. paslaptį, kurią turi tik tu.
- **Pasitikrink, kiek tavo duomenų nutekėjo:** [„Have I Been Pwned“](https://haveibeenpwned.com/).
- **Susikurk slaptafrazę kauliuku:** [organizacijos „Electronic Frontier Foundation“ žodžių sąrašai](https://www.eff.org/dice).
- **Išsamiai palygink įrankius:** „Privacy Guides“, [„Password Managers“](https://www.privacyguides.org/en/passwords/) (slaptažodžių tvarkyklės), [„Multifactor Authentication“](https://www.privacyguides.org/en/multi-factor-authentication/) (kelių veiksnių autentifikavimas) ir [„Security Keys“](https://www.privacyguides.org/en/security-keys/) (saugos raktai).
- **Kitas skyrius:** tavo naršyklė ir paieška.

## Šaltiniai

- [Implementing phishing-resistant MFA](https://www.cisa.gov/sites/default/files/2023-01/fact-sheet-implementing-phishing-resistant-mfa-508c.pdf), CISA, tikrinta 2026 m. spalio 22 d.
- [Emergency access](https://bitwarden.com/help/emergency-access/), „Bitwarden Help“, tikrinta 2026 m. spalio 22 d.
- [The 773 Million Record „Collection #1“ Data Breach](https://www.troyhunt.com/the-773-million-record-collection-1-data-reach/), Troy Hunt, 2019 m. sausio 17 d.
- [23andMe fined £2.31 million for failing to protect UK users' genetic data](https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/2025/06/23andme-fined-for-failing-to-protect-uk-users-genetic-data/), „Information Commissioner's Office“ (Jungtinė Karalystė), 2025 m. birželio 17 d.
- [The SIM highjackers: how criminals are stealing millions by highjacking phone numbers](https://www.europol.europa.eu/media-press/newsroom/news/sim-highjackers-how-criminals-are-stealing-millions-highjacking-phone-numbers), Europolas, 2020 m. kovo 13 d.
- [Notice of recent security incident](https://blog.lastpass.com/posts/notice-of-recent-security-incident), „LastPass“, 2022 m. gruodžio 22 d.
- [Password manager provider fined £1.2m by ICO for data breach](https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/2025/12/password-manager-provider-fined/), „Information Commissioner's Office“ (Jungtinė Karalystė), 2025 m. gruodžio 11 d.
- [KeePassXC security audits and certifications](https://keepassxc.org/audits/), „KeePassXC“, žiūrėta 2026 m. rugsėjį.
- [EFF Dice-Generated Passphrases](https://www.eff.org/dice), „Electronic Frontier Foundation“, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Patikrink savo el. pašto adresą svetainėje [„Have I Been Pwned“](https://haveibeenpwned.com/) (5 min.)
- [ ] Įdiek slaptažodžių tvarkyklę ir susikurk slaptafrazę iš 6 atsitiktinių žodžių (1 val.)
- [ ] El. paštui sukurk naują unikalų slaptažodį ir įjunk 2FA su autentifikavimo programėle, o jei nusipirkai 2 aparatinius raktus, užregistruok ir juos (1 val.)
- [ ] Perkelk 4 kitas svarbiausias paskyras ir, kur įmanoma, pašalink SMS kodus (1 val.)
- [ ] Popieriuje užrašytą slaptafrazę laikyk vienoje saugioje vietoje, atkūrimo kodus kitoje ir pasakyk 1 patikimam žmogui, kur jie yra (5 min.)
