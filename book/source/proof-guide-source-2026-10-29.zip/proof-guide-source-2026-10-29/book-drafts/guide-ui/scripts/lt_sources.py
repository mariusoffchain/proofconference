"""Lithuanian sources of A Guide to Autonomy: the allowlist, titles and content filter read by import_book.py.

The Lithuanian Markdown files sit in book-drafts/lt/ with the same names as the English ones. Their titles are the
fixed titles of lt/TRANSLATOR-PROMPT.md and the part names of the "Decision update" of lt/LT-TRANSLATION-GUIDE.md.
The filter removes the same 18 "At PROOF" lines and the same 5 promotional fragments as the English import, each
matched exactly once in its file: a change in the translation stops the import instead of letting a fragment through.
The action IDs come from scripts/action-registry-lt.json, matched on the Lithuanian text, never on the position.
"""

import re

SOURCE_SUBDIR = 'lt'
REGISTRY_NAME = 'action-registry-lt.json'

# "# 1 skyrius: Tavo žinutės"
CHAPTER_H1 = '%d skyrius: %s'

CHAPTERS = [
    # source file, number, id (route and storage, shared with English), part, title after "N skyrius: "
    ('11-messages.md', 1, 'messages', 1, 'Tavo žinutės'),
    ('12-passwords.md', 2, 'passwords', 1, 'Tavo slaptažodžiai ir paskyros'),
    ('13-browser.md', 3, 'browser', 1, 'Tavo naršyklė ir paieška'),
    ('14-email.md', 4, 'email', 1, 'Tavo el. paštas ir pseudonimai'),
    ('15-network.md', 5, 'network', 1, 'Tavo tinklas'),
    ('21-keys.md', 6, 'keys', 2, 'Raktai vietoj paskyrų'),
    ('22-nostr.md', 7, 'nostr', 2, 'Nostr: atviras tinklas, kurio nevaldo jokia įmonė'),
    ('23-big-tech.md', 8, 'big-tech', 2, 'Kaip po vieną pakeisti technologijų milžinių paslaugas'),
    ('24-phone.md', 9, 'phone', 2, 'Kaip susigrąžinti telefono kontrolę'),
    ('25-self-hosting.md', 10, 'self-hosting', 2, 'Kaip paleisti paslaugas nuosavame serveryje'),
    ('26-ai.md', 11, 'ai', 2, 'Kaip naudotis DI ir neišsiduoti'),
    ('31-savings.md', 12, 'savings', 3, 'Kur laikyti savo darbo vaisius'),
    ('32-first-wallet.md', 13, 'first-wallet', 3, 'Tavo pirmoji piniginė ir pirmieji satošiai'),
    ('33-seed.md', 14, 'seed', 3, 'Kaip pasidaryti atkūrimo frazės atsarginę kopiją'),
    ('34-lightning-and-euros.md', 15, 'lightning-and-euros', 3, 'Lightning ir eurai kasdienybėje'),
    ('35-bitcoin-privacy.md', 16, 'bitcoin-privacy', 3, 'Privatumas Bitcoin tinkle'),
    ('36-hardware-wallet.md', 17, 'hardware-wallet', 3, 'Aparatinės piniginės'),
    ('37-node.md', 18, 'node', 3, 'Kaip paleisti savo mazgą'),
]

PAGES = [
    # source file, id (route), kind, part, expected H1, title shown
    ('00-introduction.md', 'introduction', 'introduction', None, 'Įvadas', 'Įvadas'),
    ('10-part1-privacy.md', 'part-1', 'part', 1, '1 dalis: Privatumo įrodymas', 'Privatumo įrodymas'),
    ('20-part2-autonomy.md', 'part-2', 'part', 2, '2 dalis: Autonomijos įrodymas', 'Autonomijos įrodymas'),
    ('30-part3-work.md', 'part-3', 'part', 3, '3 dalis: Darbo įrodymas', 'Darbo įrodymas'),
    ('90-glossary.md', 'glossary', 'glossary', None, 'Žodynėlis', 'Žodynėlis'),
]

# Python-Markdown's toc ID of "## Tavo veiksmų sąrašas" (accents dropped).
CHECKLIST_ID = 'tavo-veiksmu-sarasas'

# The only effort tags of lt/LT-TRANSLATION-GUIDE.md, part E.
EFFORTS = ('5 min.', '1 val.', 'savaitgalis')

# "At PROOF:" of every "Go further" list.
AT_PROOF_PREFIX = '- **PROOF konferencijoje:**'

# Same 5 rules as the English FRAGMENTS of import_book.py, on the Lithuanian wording.
FRAGMENTS = [
    {
        'rule': 'intro-sponsor-and-speakers',
        'file': '00-introduction.md',
        'text': ' Konferencija turi vienintelį rėmėją, bendrovę „Bringin“, ir kaskart, kai ji minima šiuose puslapiuose, nurodoma, kad tai rėmėja, o ji pati pateikiama tarp kitų variantų. Tas pats galioja kiekvienam įrankiui, susijusiam su kuriuo nors pranešėju.',
        'reason': 'Sponsor and speaker notice. The first sentence of the paragraph, on tools never paid to be listed, is kept.',
    },
    {
        'rule': 'first-wallet-sponsor',
        'file': '32-first-wallet.md',
        'text': ' „Bringin“ yra šios konferencijos rėmėja.',
        'reason': 'Sponsor notice in the Bringin row. The row, its comparison and its limits are kept.',
    },
    {
        'rule': 'lightning-sponsor',
        'file': '34-lightning-and-euros.md',
        'text': '; „Bringin“ yra šios konferencijos rėmėja',
        'reason': 'Sponsor notice inside the parentheses of the Bringin route. The comparison and its sources are kept.',
    },
    {
        'rule': 'part3-money-talk',
        'file': '30-part3-work.md',
        'text': ' Šią mintį PROOF konferencijoje pranešime „Kodėl centralizuoti pinigai neveikia: kaip Bitcoin tapo alternatyva“ plėtoja Piktas.',
        'reason': 'Talk promotion sentence (a clause in English). The economic explanation before it is kept.',
    },
    {
        'rule': 'part3-cbdc-talk',
        'file': '30-part3-work.md',
        'text': ' Šią temą PROOF konferencijoje pranešime „CBDC, KYC ir kova dėl monetarinio privatumo“ nagrinėja Linas K.',
        'reason': 'Talk promotion sentence. The sourced CBDC context before it is kept.',
    },
]

# Mentions left in the text on purpose, listed in the report for review.
MENTION = re.compile(r'PROOF|Bringin|[Kk]onferencij\w*|[Pp]ranešėj\w*')

# Must never appear in a generated Lithuanian page (checked by build_integration.py, like "At PROOF:" in English).
FILTERED_MARKERS = ('PROOF konferencijoje:', 'konferencijos rėmėja')
