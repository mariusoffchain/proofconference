# 12 skyrius: Kur laikyti savo darbo vaisius

## Trumpai

Kad ir kur laikytum santaupas, visada tenka ieškoti kompromiso tarp patogumo, apsaugos nuo infliacijos, privatumo ir kontrolės. Grynieji pinigai, bankai, akcijos, auksas, Bitcoin ir Monero turi savų stiprybių ir savų silpnybių, ir kiekvieno jos kitokios. Šiame skyriuje nesakoma, ką pirkti. Jame rasi 5 klausimus, kuriuos verta užduoti apie bet kurį savo turtą, ir būdą nebepriklausyti nuo vienos institucijos. Čia nėra jokių investavimo patarimų, o viskam, kas aprašyta toliau, galioja tavo šalies mokesčių taisyklės.

## Kai viskas laikoma vienoje vietoje

Dažnai viskas laikoma vienoje sistemoje, neretai viename banke: alga, santaupos, o kartais ir to paties banko parduotas fondas ar pensijų kaupimo produktas. Tai atrodo saugu, nes taip įprasta.

Praktiškai tai reiškia, kad santaupų perkamoji galia mažėja, kai grąža po išlaidų ir mokesčių būna mažesnė už infliaciją, kad kiekvienas pinigų judėjimas užfiksuojamas tavo vardu ir kad viskas priklauso nuo kelių tarpininkų geranoriškumo ir finansinės būklės. Įšaldyta sąskaita, sunkumų patiriantis bankas, finansų maklerio įmonė, nustojusi aptarnauti tavo šalies klientus, ar nauji kapitalo judėjimo apribojimai pasitaiko retai, tačiau kai viskas laikoma vienoje vietoje, jie vienu metu smogia visam tavo turtui. 2013 m. kovą Kipras maždaug 10 dienų uždarė bankus, 2 didžiausių šalies bankų klientai [patyrė nuostolių dėl indėlių dalies, viršijančios 100 000 eurų](https://elischolar.library.yale.edu/journal-of-financial-crises/vol7/iss2/4/), o pinigų išėmimo ir pervedimų apribojimai buvo naikinami palaipsniui iki pat 2015 m.

Pasitaiko ir priešinga klaida: viską sudėti į vienos rūšies turtą, nes kažkas internete kalbėjo įtikinamai. Šiame skyriuje suverenitetas reiškia, kad nei vienoje, nei kitoje pusėje nėra vienintelio gedimo taško (angl. single point of failure).

## 5 klausimai apie bet kurį turtą

Trumpam pamiršk grąžą ir apie kiekvieną savo turtą užduok 5 klausimus.

1. **Kas jį laiko?** Tu ar kas nors, kas tau jį skolingas? Banko indėlis yra paskola bankui. Akcija laikoma per maklerio įmonių ir depozitoriumų grandinę. Monetą delne ar raktą galvoje laikai tu. Rizika, kad kita šalis žlugs arba atsisakys vykdyti įsipareigojimą, vadinama **sandorio šalies rizika**.
2. **Kas gali jį įšaldyti ar areštuoti?** Viską, ką laiko tarpininkas, galima užblokuoti vienu sprendimu.
3. **Kas jį mato?** Dauguma turto registruojama tavo vardu, ir apie jį automatiškai pranešama institucijoms.
4. **Kas gali jo sukurti daugiau?** Jei kas nors gali, tavo dalis bendrame kiekyje mažėja.
5. **Ar gali jį perkelti kitur?** Išsivežti per sieną, skubiai pasiimti arba perduoti vaikams.

Nė viena turto rūšis nesulaukia 5 gerų atsakymų, todėl svarbu jas derinti ir paskirstyti ne tik patį turtą, bet ir tai, kas jį laiko.

## Likutis, kurio negali patikrinti savarankiškai

Šie 5 klausimai yra visoje knygoje kartojamas klausimas „kas yra patikima trečioji šalis?“, pritaikytas pinigams. Ankstesniuose skyriuose klausta, kas laiduoja už raktą arba kas valdo serverį, o čia trečioji šalis yra tas, kas laiko turtą, tvarko registrą arba sprendžia, kiek to turto yra.

Prie šių klausimų prisideda dar vienas, apie patikrinimą. Banko sąskaitos likutis ar fondo vienetas yra eilutė svetimoje duomenų bazėje: ją matai per svetimą programėlę ir savarankiškai audituoti negali, todėl pasikliauji auditoriais, priežiūros institucijomis ir indėlių draudimu. Fizinį auksą galima patikrinti pagal svorį, matmenis, tankį arba prekiautojo spektrometru, jei tik kas nors tai padaro. 2020 m. birželį leidinys „Caixin“ pranešė, kad bent dalis iš 83 tonų luitų, kuriuos bendrovė „Wuhan Kingold Jewelry“ įkeitė už maždaug 16 mlrd. juanių negrąžintų paskolų, [pasirodė esą paauksuotas varis](https://www.caixinglobal.com/2020-06-29/cover-story-the-mystery-of-2-billion-of-loans-backed-by-fake-gold-101572911.html), kai skolintojai pagaliau juos ištyrė. Bitcoin sukurtas taip, kad auditą galėtų atlikti paprastas kompiuteris, nes [pilnasis mazgas](https://bitcoin.org/en/full-node) kiekvieną transakciją ir kiekvieną bloką patikrina pagal taisykles, įskaitant 21 mln. ribą (žr. 18 skyrių). Kol savo mazgo nepaleidai, piniginė klausia svetimo serverio (žr. 13 skyrių).

## Kaip pasirinkti, kur laikyti vertę

Lentelėje 5 klausimai pritaikyti pagrindinėms vietoms, kuriose galima laikyti vertę. Kompromisai joje aprašyti 2026 m. rugsėjo mėn. duomenimis, tai nėra reitingas, ir kiekviena eilutė turi rimtų silpnųjų vietų.

| Turtas | Kas jį laiko | Ar galima jį įšaldyti arba areštuoti? | Kas jį mato? | Ar galima jo sukurti daugiau? | Pagrindinės silpnosios vietos |
|---|---|---|---|---|---|
| **Grynieji pinigai** | Tu | Tik fiziškai atimant | Niekas | Taip, ir tai daroma sąmoningai | Kylant kainoms netenka perkamosios galios. Gali būti pavogti arba sudegti. Daugelyje ES šalių didelius atsiskaitymus grynaisiais riboja įstatymai, o nuo 2027 m. liepos 10 d. visoje ES mokėjimams įmonėms galios 10 000 eurų riba. |
| **Banko indėlis** | Bankas. Tu turi reikalavimo teisę, kuri ES apdrausta [iki 100 000 eurų vienam indėlininkui viename banke](https://eur-lex.europa.eu/EN/legal-content/summary/deposit-guarantee-schemes.html). | Taip, vienu sprendimu | Bankas, valstybė | Taip, ir tai daroma sąmoningai | Netenka perkamosios galios, jei grynosios palūkanos atsilieka nuo infliacijos. Visiškai stebimas. Priklauso nuo banko ir nuo tuo metu galiojančių taisyklių. |
| **Akcijos ir fondai** | Maklerio įmonė ir centrinis vertybinių popierių depozitoriumas, tavo vardu | Taip. Sistema centralizuota ir lengvai blokuojama, pavyzdžiui, dėl sankcijų arba kai maklerio įmonė pasitraukia iš tavo šalies. | Maklerio įmonė, mokesčių inspekcija | Įmonės gali išleisti naujų akcijų | Tau priklauso dalis tikrų įmonių, ir tai tikras privalumas. Tačiau kainos gali kristi ne vienus metus, rinkos kartais uždaromos, o tu niekada nieko nelaikai savo rankose. |
| **Fizinis auksas** | Tu, jei jis laikomas namuose arba tavo kontroliuojamame seife | Tik fiziškai atimant. Valstybės praeityje yra konfiskavusios auksą (žr. kitą skirsnį). | Prekiautojai privalo nustatyti pirkėjo tapatybę, kai suma viršija ribą, kuri kiekvienoje šalyje skirtinga | Tik išgaunant kasyklose, lėtai | Sunkus, jį nelengva pervežti per sieną, juo nelengva atsiskaityti, o tikrumui patikrinti reikia įrankių arba prekiautojo. Prekiautojai taiko antkainį. Auksą reikia kur nors laikyti, ir jį gali pavogti. |
| **„Popierinis“ auksas** (fondai, nepaskirstyto aukso sąskaitos, angl. unallocated accounts) | Tarpininkas | Taip | Tarpininkas, mokesčių inspekcija | Reikalavimų gali būti daugiau nei metalo | Tai aukso pažadas, o ne auksas. Patogu, tačiau trūkumai tie patys kaip akcijų. |
| **Bitcoin, savarankiškas saugojimas** | Tu, savo raktais (žr. 13 ir 14 skyrius) | Be tavo raktų negalima, nors kriptovaliutų biržos ir mokėjimo paslaugų teikėjai vis tiek gali atsisakyti tave aptarnauti | Registras viešas, bet jame matyti tik pseudonimai (žr. 16 skyrių) | Ne. Kad 21 mln. riba nebūtų viršyta, prižiūri kiekvienas mazgas | Jaunas ir smarkiai svyruojantis, todėl kaina gali stipriai kristi. Klaidos nepataisomos. Reikia mokytis. |
| **Monero, savarankiškas saugojimas** (pažengusiems) | Tu, savo raktais | Be tavo raktų negalima, su ta pačia išlyga kaip Bitcoin atveju | Sumos, siuntėjai ir gavėjai automatiškai paslėpti | Taip, lėtai. Nuo 2022 m. birželio 9 d. kasėjams atlyginti neribotą laiką išleidžiama fiksuota suma, [0,6 XMR už bloką](https://web.getmonero.org/get-started/faq/) (vadinamoji liekamoji emisija, angl. tail emission) | Daug mažiau likvidus ir priimamas daug rečiau nei Bitcoin. Europoje reguliuojamos biržos jo atsisako (žr. kitą skirsnį). Tinklas gerokai mažesnis, ir 2025 m. jo darbą sutrikdė pašalinis kasėjų telkinys (angl. mining pool, žr. toliau). Kūrimas labiau centralizuotas. Mažiau piniginių ir įrenginių. Kaina smarkiai svyruoja. |

Biržoje palikti bitkoinai ar prekiautojui patikėtas auksas priskirtini eilutėms, kuriose turtą laiko tarpininkas, o ne savarankiško saugojimo eilutėms.

Monero paskirtis panaši į Bitcoin paskirtį: tai pinigai, kuriuos gali laikyti savarankiškai, o tikroji jo stiprybė tebėra automatiškai užtikrinamas privatumas. Tačiau jo tinklas gerokai mažesnis, todėl pašalinei jėgai jį lengviau užpulti. 2025 m. rugpjūtį kasėjų telkinys „Qubic“ [pareiškė sutelkęs daugiau kaip 51 % Monero kasimo galios](https://www.coindesk.com/business/2025/08/12/qubic-claims-majority-control-of-monero-hashrate-raising-51-attack-fears), o 2025 m. rugsėjo 14 d. [18 blokų pertvarkymas (angl. reorg) panaikino 118 patvirtintų transakcijų](https://www.coindesk.com/web3/2025/09/15/monero-suffers-deepest-ever-blockchain-reorganization-invalidating-118-transactions). [Šią kampaniją išmatavę tyrėjai](https://arxiv.org/abs/2512.01437) užfiksavo gilesnius blokų grandinės pertvarkymus, bet ne ilgalaikę daugumą. „Qubic“ yra mažas projektas, kurį valdo nedidelė žmonių grupė, todėl lieka atviras klausimas, ką tam pačiam tinklui galėtų padaryti vyriausybė ar bet kuri kita geriau organizuota ir geriau finansuojama grupė. Monero kūrimas taip pat labiau centralizuotas: kūrėjų grupė mažesnė, o taisyklės keičiamos [naujiniais, kuriuos privalo įdiegti kiekvienas dalyvis](https://www.getmonero.org/2022/04/20/network-upgrade-july-2022.html).

Daugumai žmonių protinga būtų elgtis taip: tai, ko prireiks artimiausiais mėnesiais, laikyti ten, kur paprasta ir stabilu, pasirūpinti, kad viso turto nelaikytų viena institucija, ir pradedant nuo mažų sumų išmokti laikyti bent 1 turto rūšį, kuriai nereikia niekieno leidimo. Kurią ir kiek, sprendi tik tu.

## Turtui taikomos taisyklės gali pasikeisti

Atsakymai lentelėje nėra galutiniai, nes turtui taikomos taisyklės gali pasikeisti vienu sprendimu. 1933 m. balandžio 5 d. [vykdomuoju įsaku Nr. 6102](https://www.presidency.ucsb.edu/documents/executive-order-6102-forbidding-the-hoarding-gold-coin-gold-bullion-and-gold-certificates) JAV gyventojai buvo įpareigoti iki gegužės 1 d. atiduoti Federaliniam rezervui auksines monetas, aukso luitus ir aukso sertifikatus, o išimtis taikyta tik 100 dolerių vertės auksui vienam asmeniui. Už nepaklusimą grėsė bauda iki 10 000 dolerių, laisvės atėmimas iki 10 metų arba abi bausmės.

Monero yra šių dienų europietiškas pavyzdys. Birža „Kraken“ [2024 m. spalio 31 d. nutraukė prekybą juo Europos ekonominės erdvės klientams](https://support.kraken.com/articles/support-for-monero-xmr-in-europe) ir tai aiškino reguliavimo pokyčiais. 2024 m. gegužės 31 d. ES kovos su pinigų plovimu reglamentas žengia toliau, nes [jo 79 straipsnis](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng) nuo 2027 m. liepos 10 d. draudžia bankams ir kriptoturto paslaugų teikėjams tvarkyti sąskaitas, kuriomis naudojantis transakcijas galima padaryti anonimines, taip pat ir naudojant „anonimiškumą didinančias monetas“ (angl. anonymity-enhancing coins).

Draudimas skirtas reguliuojamiems tarpininkams, o reglamente nurodyta, kad savarankiško saugojimo piniginių (reglamente jos vadinamos „saviprieglobėmis piniginėmis“, angl. self-hosted wallets) teikėjams jis netaikomas. 2026 m. rugsėjo mėn. duomenimis, praktinis poveikis toks: Europoje per reguliuojamas platformas Monero darosi vis sunkiau nusipirkti ir parduoti.

Dalis Monero naudotojų tokį išstūmimą laiko jo stiprybe. Turtas, kuriuo didelės prekyvietės prekiauti negali, nepriklauso nė nuo vienos iš jų, ir juo žmonės naudojasi tiesiogiai tarpusavyje. Bitcoin turi abu bruožus: jį laiko didelės institucijos ir juo prekiaujama reguliuojamose platformose, tačiau jis taip pat keliauja tiesiogiai tarp žmonių (angl. peer-to-peer).

## Žingsnis po žingsnio

1. **Nusibraižyk žemėlapį.** Popieriaus lape surašyk, kur laikomos tavo santaupos: sąskaitos, fondai, pensija, grynieji pinigai ir visa kita. Prie kiekvienos eilutės užrašyk, kas tą turtą laiko.
2. **Užduok 5 klausimus** apie kiekvieną eilutę. Ieškai ne tobulo įvertinimo, o to, ko iki šiol nežinojai.
3. **Surask vienintelį gedimo tašką.** Vienas bankas viskam, viena maklerio įmonė ar viena šalis yra pirmas dalykas, kurį verta taisyti, o tam gali pakakti atidaryti antrą sąskaitą kitur.
4. **Turėk atsargą, kuriai nereikia niekieno leidimo.** Nedidelė grynųjų pinigų suma namuose padės kelias dienas išsiversti, jei sutriktų mokėjimai kortelėmis arba būtų įšaldyta sąskaita.
5. **Pradėk nuo mažų sumų ir išmok laikyti 1 savarankiškai saugomą turto rūšį.** Jei tai Bitcoin, viską paaiškins 13-18 skyriai. Jei tai fizinis auksas, įprastos atsargumo priemonės tokios: rinktis paplitusias, lengvai atpažįstamas monetas iš seniai veikiančio prekiautojo, palyginti kainą su tos dienos metalo kaina ir pirmiausia nuspręsti, kur monetos bus laikomos. Kai monetą pasveri ir išmatuoji savo rankomis arba vėliau bitkoinų likutį patikrini savo mazgu (žr. 18 skyrių), pasitikėjimą pakeiti patikrinimu.
6. **Tvarkyk apskaitą.** Užsirašyk pirkimo ir pardavimo datas, sumas ir kainas. Jų prireiks pildant mokesčių deklaraciją.
7. **Pagalvok, kas bus, kai tavęs nebus.** Turtas, kurį pasiekti gali tik tu ir apie kurį žinai tik tu, išnyksta kartu su tavimi. 6 skyriuje paaiškinta, kaip palikti nurodymus neatiduodant raktų.

## Klaidos, kurių verta vengti

- **Painioti reikalavimo teisę su pačiu daiktu.** Aukso fondas nėra auksas, o bitkoinai biržoje nėra bitkoinai tavo piniginėje. Ir viena, ir kita yra pažadai.
- **Viską laikyti vienoje vietoje,** nesvarbu, ar ta vieta yra bankas, ar turtas, kuriuo ką tik susižavėjai.
- **Investuoti pinigus, kurių greitai prireiks, arba skolintus pinigus** į tai, kas smarkiai svyruoja. Bitcoin, Monero, akcijos ir net auksas gali ne vieniems metams netekti didelės dalies kainos, o paskolą teks grąžinti ir kainai nukritus.
- **Klausyti patarimų, ką pirkti.** Kas žada grąžą, terminą ar paslaptį, tas ką nors parduoda. Ypač saugokis nepažįstamųjų, kurie pirmi užmezga ryšį.
- **Kalbėti apie tai, ką turi.** Diskretiškumas yra saugumo dalis ir internete, ir prie vakarienės stalo.
- **Pamiršti mokesčius valstybei.** Pardavus su pelnu paprastai tenka mokėti mokesčius, kad ir koks tai turtas ir kad ir kaip jį įsigijai.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kodėl centralizuoti pinigai neveikia: kaip Bitcoin tapo alternatyva“, pranešimą skaito Piktas, ir „CBDC, KYC ir kova dėl monetarinio privatumo“, pranešimą skaito Linas K.
- **Kaip veikia pinigų sistema, plačiajam skaitytojui:** Lyn Alden knyga „Broken Money“.
- **Kaip saugomi tavo indėliai:** Europos Komisijos puslapis apie indėlių garantijų sistemas (ec.europa.eu).
- **Monero iš pirmų lūpų:** getmonero.org. Dažnai naudojamos piniginės: „Monero GUI“, „Feather Wallet“ ir „Cake Wallet“.
- **Kitas skyrius:** tavo pirmoji piniginė ir pirmieji satošiai.

## Šaltiniai

- [What are interest rates? Nominal and real returns](https://data.ecb.europa.eu/methodology/what-are-interest-rates), Europos Centrinis Bankas, tikrinta 2026 m. spalio 22 d.
- [Deposit guarantee schemes, summary of Directive 2014/49/EU](https://eur-lex.europa.eu/EN/legal-content/summary/deposit-guarantee-schemes.html), „EUR-Lex“, žiūrėta 2026 m. rugsėjį.
- [Cyprus: National Bank Holiday, 2013](https://elischolar.library.yale.edu/journal-of-financial-crises/vol7/iss2/4/), „Yale Program on Financial Stability“, žurnalas „Journal of Financial Crises“, 2025 m.
- [Executive Order 6102, Forbidding the Hoarding of Gold Coin, Gold Bullion and Gold Certificates](https://www.presidency.ucsb.edu/documents/executive-order-6102-forbidding-the-hoarding-gold-coin-gold-bullion-and-gold-certificates), „The American Presidency Project“, 1933 m. balandžio 5 d.
- [Regulation (EU) 2024/1624, Articles 79 and 80](https://eur-lex.europa.eu/eli/reg/2024/1624/oj/eng), priimtas 2024 m. gegužės 31 d. ir paskelbtas Europos Sąjungos oficialiajame leidinyje 2024 m. birželio 19 d.
- [Support for Monero (XMR) in Europe](https://support.kraken.com/articles/support-for-monero-xmr-in-europe), „Kraken“, 2024 m. spalio mėn.
- [Cover Story: The Mystery of $2 Billion of Loans Backed by Fake Gold](https://www.caixinglobal.com/2020-06-29/cover-story-the-mystery-of-2-billion-of-loans-backed-by-fake-gold-101572911.html), „Caixin Global“, 2020 m. birželio 29 d.
- [Running a full node](https://bitcoin.org/en/full-node), „Bitcoin.org“, žiūrėta 2026 m. rugsėjį.
- [Qubic Claims Majority Control of Monero Hashrate, Raising 51% Attack Fears](https://www.coindesk.com/business/2025/08/12/qubic-claims-majority-control-of-monero-hashrate-raising-51-attack-fears), „CoinDesk“, 2025 m. rugpjūčio 12 d.
- [Monero Suffers Deepest-Ever Blockchain Reorganization, Invalidating 118 Transactions](https://www.coindesk.com/web3/2025/09/15/monero-suffers-deepest-ever-blockchain-reorganization-invalidating-118-transactions), „CoinDesk“, 2025 m. rugsėjo 15 d.
- [Inside Qubic's Selfish Mining Campaign on Monero: Evidence, Tactics, and Limits](https://arxiv.org/abs/2512.01437), Suhyeon Lee ir Hyeongyeong Kim, „arXiv“, 2025 m. gruodžio mėn., pataisyta 2026 m. rugpjūčio mėn.
- [Monero will undergo a network upgrade on 13th August, 2022](https://www.getmonero.org/2022/04/20/network-upgrade-july-2022.html), getmonero.org, 2022 m. balandžio 20 d.
- [FAQ, tail emission at block 2641623 on 9 June 2022](https://web.getmonero.org/get-started/faq/), Monero projektas, tikrinta 2026 m. spalio 22 d. Dabartiniame DUK nurodyta tikroji pradžios data, o senesniame „Moneropedia“ puslapyje vis dar pateiktas gegužės pabaigos įvertis.

## Tavo veiksmų sąrašas

- [ ] Nusibraižyk žemėlapį, kur laikomos tavo santaupos ir kas laiko kiekvieną jų dalį (1 val.)
- [ ] Atsakyk į 5 klausimus apie savo pagrindinę sąskaitą ir pagrindinę investiciją (1 val.)
- [ ] Patikrink, ar viso tavo turto nelaiko vienas bankas arba viena maklerio įmonė (5 min.)
- [ ] Atsidėk namuose nedidelę grynųjų pinigų atsargą (5 min.)
- [ ] Nuspręsk, kurią savarankiškai saugomą turto rūšį nori išmokti laikyti pirmiausia ir su kokia nedidele suma (5 min.)
