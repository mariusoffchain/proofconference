#!/usr/bin/env python3
"""PROOF site: one content file for the 2 languages of the programme, the speakers and the replays.

    python3 build_site.py extract   # read ../../index.html (LT) and ../../en/index.html (EN) into content.json (one-off)
    python3 build_site.py check     # render content.json and compare with the current pages (must print "identical")
    python3 build_site.py build     # render content.json into the 3 sections of both pages, everything else untouched

Every text field is {"lt": "...", "en": "..."} and holds the inner HTML of the element (entities and <span> kept as is).
Structure (row classes, times, card types, ids, photos, links, videos) is shared by the 2 pages.
The replays are also rendered into the book (cover and the chapters listed in each talk's "chapters"): ../build.py imports replay_item.
The rest of the pages (hero, recap, book, about, partners, footer, scripts) stays hand-edited.
"""
import json, pathlib, re, sys

HERE = pathlib.Path(__file__).parent
ROOT = HERE.parent.parent
PAGES = {'lt': ROOT / 'index.html', 'en': ROOT / 'en' / 'index.html'}
CONTENT = HERE / 'content.json'
PHOTO_PREFIX = {'lt': '', 'en': '../'}
# /replays.js travels with a version in its URL (hash of the file), so a returning visitor never runs an old cached player
import hashlib
REPLAYS_V = hashlib.sha1((ROOT / 'replays.js').read_bytes()).hexdigest()[:8]
REPLAYS_TAG = f'<script defer src="/replays.js?v={REPLAYS_V}"></script>'
REPLAYS_TAG_RE = re.compile(r'<script defer src="/replays\.js(?:\?v=[0-9a-f]+)?"></script>')   # the Lithuanian page sits at the root, the English one in /en/


def section(html, start):
    i = html.index(start)
    j = html.index('\n</section>', i) + len('\n</section>')
    return i, j, html[i:j]


def attr_id(m):
    return f' id="{m}"' if m else ''


# ---------- extract
def extract_program(html):
    i, j, s = section(html, '<section class="program-section" id="program">')
    head = re.search(r'<p class="sec-label" id="label-program">(.*?)</p>\n    <h2 id="program-h2">(.*?)</h2>\n    <p class="prog-note" id="prog-note">(.*?)</p>', s, re.S)
    rows = []
    for rm in re.finditer(r'      <div class="tl-row (\w+)">\n        <div class="tl-l"><div class="tl-time">(.*?)</div></div>\n        <div class="tl-r">\n          <div class="tl-section"(?: id="([^"]+)")?>(.*?)</div>\n(.*?)\n        </div>\n      </div>\n', s, re.S):
        cls, time, sid, sec, body = rm.groups()
        cards = []
        for cm in re.finditer(r'          <div class="tl-card">\n            <div class="tl-card-top">\n              <span class="tl-type">(.*?)</span>\n              <span class="tl-title"(?: id="([^"]+)")?>(.*?)</span>\n            </div>\n(?:            <div class="tl-speaker"(?: id="([^"]+)")?>(.*?)</div>\n)?(?:            <div class="tl-desc"(?: id="([^"]+)")?>(.*?)</div>\n)?          </div>', body, re.S):
            typ, tid, title, spid, speaker, did, desc = cm.groups()
            cards.append({'type': typ, 'title_id': tid, 'title': title, 'speaker_id': spid, 'speaker': speaker, 'desc_id': did, 'desc': desc})
        rows.append({'cls': cls, 'time': time, 'section_id': sid, 'section': sec, 'cards': cards})
    return {'label': head.group(1), 'h2': head.group(2), 'note': head.group(3), 'rows': rows}


def extract_speakers(html):
    i, j, s = section(html, '<section class="speakers-section" id="speakers">')
    head = re.search(r'<p class="sec-label rev" id="label-speakers">(.*?)</p>\n  <h2 class="rev" id="speakers-h2">(.*?)</h2>', s, re.S)
    spk = []
    for m in re.finditer(r'    <div class="spk (block-\w+)" style="([^"]+)">\n      <div class="spk-photo-wrap"><img src="([^"]+)" alt="([^"]+)" class="spk-photo" loading="lazy" decoding="async"(?: style="([^"]+)")?></div>\n      <div class="spk-handle">(.*?)</div>\n      <div class="spk-name">(.*?)</div>\n      <div class="spk-topic" id="([^"]+)">(.*?)</div>\n      <div class="spk-links">\n(.*?)      </div>\n    </div>\n', s, re.S):
        cls, style, src, alt, pstyle, handle, name, tid, topic, links = m.groups()
        ls = [{'href': a, 'label': b} for a, b in re.findall(r'<a href="([^"]+)" target="_blank" rel="noopener" class="spk-link">(.*?)</a>', links)]
        spk.append({'cls': cls, 'style': style, 'photo': src.removeprefix('../'), 'alt': alt, 'photo_style': pstyle, 'handle': handle, 'name': name, 'topic_id': tid, 'topic': topic, 'links': ls})
    return {'label': head.group(1), 'h2': head.group(2), 'speakers': spk}


def extract_replays(html):
    i, j, s = section(html, '<section class="replays-section" id="replays">')
    head = re.search(r'<p class="sec-label rev">(.*?)</p>\n    <h2 class="rev">(.*?)</h2>\n    <p class="replays-p rev">(.*?)</p>', s, re.S)
    items = []
    for m in re.finditer(r'      <li class="rp-item (\w+)"(?: data-video="([^"]*)")?>\n        <div><div class="rp-title">(.*?)</div><div class="rp-spk">(.*?)</div></div>\n        <span class="rp-badge">(.*?)</span>\n      </li>\n', s, re.S):
        cls, video, title, spk, badge = m.groups()
        items.append({'cls': cls, 'video': video, 'title': title, 'speaker': spk, 'badge': badge})
    return {'label': head.group(1), 'h2': head.group(2), 'p': head.group(3), 'items': items}


def merge(lt, en, text_keys, list_key=None, item_text_keys=(), sub=None):
    """Shared structure from EN, texts as {lt, en}."""
    out = {}
    for k, v in en.items():
        if k in text_keys:
            out[k] = {'lt': lt[k], 'en': v}
        elif k == list_key:
            out[k] = [merge(a, b, item_text_keys, *(sub or ())) for a, b in zip(lt[k], v)]
        else:
            out[k] = v
    return out


def extract():
    pages = {lang: p.read_text(encoding='utf-8') for lang, p in PAGES.items()}
    prog = {l: extract_program(h) for l, h in pages.items()} if '<section class="program-section"' in pages['en'] else None
    spk = {l: extract_speakers(h) for l, h in pages.items()}
    rep = {l: extract_replays(h) for l, h in pages.items()}
    content = {
        'program': json.loads(CONTENT.read_text(encoding='utf-8'))['program'] if prog is None else merge(prog['lt'], prog['en'], ('label', 'h2', 'note'), 'rows', ('time', 'section'), ('cards', ('type', 'title', 'speaker', 'desc'))),
        'speakers': merge(spk['lt'], spk['en'], ('label', 'h2'), 'speakers', ('topic',), ('links', ('label',))),
        'replays': json.loads(CONTENT.read_text(encoding='utf-8'))['replays'] if CONTENT.exists()
                   else merge(rep['lt'], rep['en'], ('label', 'h2', 'p'), 'items', ('title', 'speaker', 'badge')),
    }
    return content


# ---------- render
T = lambda field, lang: field[lang] if isinstance(field, dict) else field


def render_program(c, lang):
    out = ['<section class="program-section" id="program">', '  <div class="prog-header rev">',
           f'    <p class="sec-label" id="label-program">{T(c["label"], lang)}</p>', f'    <h2 id="program-h2">{T(c["h2"], lang)}</h2>',
           f'    <p class="prog-note" id="prog-note">{T(c["note"], lang)}</p>', '  </div>', '', '  <div class="tl-body rev">', '    <div class="tl-inner">', '']
    for r in c['rows']:
        out += [f'      <div class="tl-row {r["cls"]}">', f'        <div class="tl-l"><div class="tl-time">{T(r["time"], lang)}</div></div>', '        <div class="tl-r">',
                f'          <div class="tl-section"{attr_id(r["section_id"])}>{T(r["section"], lang)}</div>']
        for k in r['cards']:
            out += ['          <div class="tl-card">', '            <div class="tl-card-top">', f'              <span class="tl-type">{T(k["type"], lang)}</span>',
                    f'              <span class="tl-title"{attr_id(k["title_id"])}>{T(k["title"], lang)}</span>', '            </div>']
            if T(k['speaker'], lang) is not None:
                out.append(f'            <div class="tl-speaker"{attr_id(k["speaker_id"])}>{T(k["speaker"], lang)}</div>')
            if T(k['desc'], lang) is not None:
                out.append(f'            <div class="tl-desc"{attr_id(k["desc_id"])}>{T(k["desc"], lang)}</div>')
            out.append('          </div>')
        out += ['        </div>', '      </div>', '']
    out += ['    </div>', '  </div>', '', '</section>']
    return '\n'.join(out)


def render_speakers(c, lang):
    out = ['<section class="speakers-section" id="speakers">', f'  <p class="sec-label rev" id="label-speakers">{T(c["label"], lang)}</p>',
           f'  <h2 class="rev" id="speakers-h2">{T(c["h2"], lang)}</h2>', '  <div class="speakers-grid rev">']
    for s in c['speakers']:
        ps = f' style="{s["photo_style"]}"' if s['photo_style'] else ''
        out += [f'    <div class="spk {s["cls"]}" style="{s["style"]}">',
                f'      <div class="spk-photo-wrap"><img src="{PHOTO_PREFIX[lang]}{s["photo"]}" alt="{s["alt"]}" class="spk-photo" loading="lazy" decoding="async"{ps}></div>',
                f'      <div class="spk-handle">{s["handle"]}</div>', f'      <div class="spk-name">{s["name"]}</div>',
                f'      <div class="spk-topic" id="{s["topic_id"]}">{T(s["topic"], lang)}</div>', '      <div class="spk-links">']
        out += [f'        <a href="{l["href"]}" target="_blank" rel="noopener" class="spk-link">{T(l["label"], lang)}</a>' for l in s['links']]
        out += ['      </div>', '    </div>']
    out += ['  </div>', '</section>']
    return '\n'.join(out)


YT_RE = re.compile(r'(?:youtube\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{6,})')
MP4_RE = re.compile(r'\.mp4(?:[?#]|$)', re.I)


def replay_item(it, c, lang, indent='      ', book_link=None):
    """One talk of the replays list. Shared by the 2 home pages and the book (cover and chapters, see ../build.py).
    A video (MP4 or YouTube) gets the thumbnail on the right and a white button: /replays.js plays it in place, nothing loads
    before the click, and without JavaScript the button is a plain link to the file. Any other URL is a simple link.
    book_link = (href, chapter title) adds an "In the book" line."""
    v = it.get('video')
    text = [f'<div class="rp-title">{T(it["title"], lang)}</div>', f'<div class="rp-spk">{T(it["speaker"], lang)}</div>']
    if it.get('kicker'):
        text.insert(0, f'<div class="rp-kicker">{T(it["kicker"], lang)}</div>')
    if it.get('links'):
        links = ' · '.join(f'<a href="{l["href"]}" target="_blank" rel="noopener">{T(l["label"], lang)}</a>' for l in it['links'])
        text.append(f'<div class="rp-alt">{T(c["also"], lang)} {links}</div>')
    if book_link:
        text.append(f'<div class="rp-alt">{T(c["in_book"], lang)} <a href="{book_link[0]}">{book_link[1]}</a></div>')
    playable = v and (MP4_RE.search(v) or YT_RE.search(v))
    cls, attrs, side = f'rp-item {it["cls"]}' + (' rp-closing' if it.get('kicker') else ''), '', ''
    if playable:
        href = it.get('video_sd') or v
        cls += ' rp-has-video'
        attrs = f' data-video="{v}"'
        if it.get('video_type'): attrs += f" data-video-type='{it['video_type']}'"
        if it.get('video_sd'): attrs += f' data-video-sd="{it["video_sd"]}"'
        if it.get('video_sd_type'): attrs += f" data-video-sd-type='{it['video_sd_type']}'"
        text.append(f'<a class="rp-play" href="{href}">{T(c["watch"], lang)}</a>')
        if it.get('poster'):
            side = (f'<a class="rp-thumb" href="{href}" tabindex="-1" aria-hidden="true">'
                    f'<img src="/{it["poster"]}" alt="" width="1280" height="720" loading="lazy" decoding="async"></a>')
    elif v:
        side = f'<a class="rp-badge rp-ext" href="{v}" target="_blank" rel="noopener">{T(c["elsewhere"], lang)}</a>'
    else:
        side = f'<span class="rp-badge">{T(it["badge"], lang)}</span>'
    out = [f'{indent}<li class="{cls}"{attrs}>', f'{indent}  <div class="rp-text">{"".join(text)}</div>']
    if side: out.append(f'{indent}  {side}')
    out.append(f'{indent}</li>')
    return '\n'.join(out)


def render_replays(c, lang):
    out = ['<section class="replays-section" id="replays">', '  <div class="replays-inner">', f'    <p class="sec-label rev">{T(c["label"], lang)}</p>',
           f'    <h2 class="rev">{T(c["h2"], lang)}</h2>', f'    <p class="replays-p rev">{T(c["p"], lang)}</p>', '    <ul class="rp-list rev">']
    out += [replay_item(it, c, lang) for it in c['items']]
    out += ['    </ul>', '  </div>', '</section>']
    return '\n'.join(out)


def render_page(html, content, lang):
    html = REPLAYS_TAG_RE.sub(REPLAYS_TAG, html)
    for start, fn, key in (('<section class="program-section" id="program">', render_program, 'program'),
                           ('<section class="speakers-section" id="speakers">', render_speakers, 'speakers'),
                           ('<section class="replays-section" id="replays">', render_replays, 'replays')):
        if start not in html:   # the programme was removed from the pages after the event (2026-10-10); content.json keeps it
            continue
        i, j, _ = section(html, start)
        html = html[:i] + fn(content[key], lang) + html[j:]
    return html


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'
    if cmd == 'extract':
        CONTENT.write_text(json.dumps(extract(), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(f'wrote {CONTENT}')
        return
    content = json.loads(CONTENT.read_text(encoding='utf-8'))
    for lang, p in PAGES.items():
        html = p.read_text(encoding='utf-8')
        new = render_page(html, content, lang)
        if cmd == 'build':
            if new != html:
                p.write_text(new, encoding='utf-8'); print(f'{lang}: updated {p.relative_to(ROOT)}')
            else:
                print(f'{lang}: no change')
        else:
            print(f'{lang}: ' + ('identical' if new == html else 'DIFFERENT'))
            if new != html:
                import difflib
                for line in list(difflib.unified_diff(html.splitlines(), new.splitlines(), lineterm='', n=1))[:40]:
                    print(line)


if __name__ == '__main__':
    main()
