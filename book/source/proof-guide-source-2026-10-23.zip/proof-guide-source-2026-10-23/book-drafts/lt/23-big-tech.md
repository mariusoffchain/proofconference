# 8 skyrius: Kaip po vieną pakeisti technologijų milžinių paslaugas

## Trumpai

Bendrovių „Google“, „Apple“, „Meta“ ar „Microsoft“ paslaugų per 1 dieną neatsisakysi, ir to nereikia. Pirmiausia eksportuok duomenis, tada pakeisk 1 paslaugą, pagyvenk su ja 2 savaites ir tik tada imkis kitos. Kiekvienam poreikiui yra kelios rimtos alternatyvos, dauguma jų atvirojo kodo ir valdomos skirtingų operatorių. Su kiekviena perkelta paslauga viena įmonė apie tave žino mažiau, o užblokavus paskyrą netektum mažiau.

## Vienoje paskyroje telpa visas skaitmeninis gyvenimas

Daugumos žmonių skaitmeninis gyvenimas telpa 1 ar 2 įmonėse: paštas, kalendorius, nuotraukos, dokumentai, žemėlapiai ir vaizdo įrašai sudėti į vieną paskyrą. Tai patogu, bet kelia 2 rizikas.

Pirmoji yra profilis, nes įmonė, matanti tavo paieškas, judėjimą, pašto dėžutę ir nuotraukas, žino apie tave daugiau nei bet kuris žmogus. Antroji yra priklausomybė, nes užblokavus tą paskyrą (žr. 6 skyrių) viskas dingsta tą pačią akimirką.

2025 m. gegužę naujienų agentūra „Associated Press“ pranešė, kad Tarptautinio baudžiamojo teismo vyriausiasis prokuroras po JAV sankcijų neteko prieigos prie savo „Microsoft“ el. pašto paskyros, nors bendrovė „Microsoft“ teigia niekada nesustabdžiusi paslaugų teismui. 2025 m. spalį teismas [patvirtino, kad „Microsoft Office“ keičia į „openDesk“](https://www.theregister.com/2025/10/31/international_criminal_court_ditches_office/), atvirojo kodo programų paketą, sukurtą Vokietijos valstybei.

Įprasta reakcija yra motyvacijos protrūkis „šiandien viską ištrinu“, ir ji beveik visada baigiasi nesėkme. Vienu metu sugriūva per daug įpročių, šeimos kalendorius nustoja veikti, prieš pat terminą nepavyksta rasti dokumento, o po 2 savaičių viskas vėl ten, kur buvo. Tada daroma išvada, kad alternatyvos neveikia, nors iš tikrųjų nepavyko kas kita: bandymas vienu metu pakeisti 10 įpročių.

## Pirmiausia eksportas, tada po 1 paslaugą

Metodas remiasi 3 idėjomis.

**Pirmiausia eksportuok.** [Bendrojo duomenų apsaugos reglamento](https://eur-lex.europa.eu/eli/reg/2016/679/oj), taikomo nuo 2018 m. gegužės 25 d., 20 straipsnis suteikia teisę į tam tikrų tavo pateiktų asmens duomenų perkeliamumą, kai jie tvarkomi automatizuotomis priemonėmis remiantis sutikimu arba sutartimi. Ši teisė apima ne visus teikėjo turimus įrašus. Jai priskiriami duomenys turi būti pateikiami susistemintu, įprastai naudojamu ir kompiuterio skaitomu formatu. Didžiosios bendrovės tam turi įrankį: „Google Takeout“ (takeout.google.com), „Apple“ puslapį „Data and Privacy“ (duomenys ir privatumas, privacy.apple.com) ir galimybę atsisiųsti savo informaciją „Facebook“ bei „Instagram“ paskyros nustatymuose. Eksporto tenka laukti kelias valandas ar dienas. Kad ir kas nutiktų vėliau, savo istoriją turėsi, be to, pamatysi, kiek apie tave sukaupta, o daugeliui žmonių būtent tą akimirką motyvacija ir tampa tikra.

**Išsirink 1 paslaugą.** Yra 2 geri būdai rinktis: imti arba tą, kuri apie tave žino daugiausia (dažnai tai paštas, nuotraukos ar paieška), arba lengviausią (dažnai tai žemėlapiai, užrašai ar paieška). Jei dvejoji, imk lengviausią, nes po ankstyvos sėkmės kitas žingsnis būna paprastesnis.

**Naudok abi lygiagrečiai.** 2 savaites naudok naująjį įrankį, kol senasis dar tebėra, o duomenis perkelk ir senojoje vietoje ištrink tik tada, kai senojo įrankio nebeatidarinėji.

Paskui kartok. 4 paslaugos per metus yra labai geras tempas.

## Privatumą žadantis prekių ženklas vis tiek yra 1 įmonė

Perėjus iš bendrovės „Google“ pas teikėją, kurio šūkyje yra žodis „privatumas“, pasikeičia šeimininkas, o klausimas lieka tas pats: kas gali perskaityti tavo duomenis ir kas nutiks, jei ta įmonė žlugs, bus parduota ar pakeis sąlygas. Atsakyti padeda 3 testai.

- **Ar teikėjas gali tai perskaityti?** Kai taikomas ištisinis šifravimas, duomenys užrakinami tavo įrenginyje, o teikėjas saugo tai, ko negali atidaryti. Be jo turinį saugo tik teikėjo pažadas ir jo šalies įstatymai. Net ir su juo teikėjas mato dalį metaduomenų ir pats pateikia šifruojančią programėlę, todėl svarbu, kad programėlės būtų atvirojo kodo, o auditų rezultatai skelbiami.
- **Ar gali išeiti?** Kai duomenis galima eksportuoti standartiniu formatu, bet kurią įmonę galima pakeisti kita.
- **Ar paslaugą gali valdyti kas nors kitas?** Programinė įranga, kurią savo serveryje gali paleisti tu arba kokia nors asociacija („Nextcloud“, „CryptPad“, „Immich“, „PeerTube“), nepriklauso nuo 1 operatoriaus išlikimo, o vietiniai įrankiai („Syncthing“, „Joplin“, „Obsidian“, „LibreOffice“) duomenis laiko tavo įrenginiuose.

Gerai tvarkoma įmonė, taikanti ištisinį šifravimą, daugumai skaitytojų tebėra protingas pasirinkimas ir dažnai saugesnis už serverį, kurio niekas neprižiūri.

## Kaip pasirinkti pakaitalus

Lentelė sudaryta pagal poreikius. „Atvirojo kodo“ reiškia, kad kodas viešas ir jį galima patikrinti. „Veikia nuosavame serveryje“ reiškia, kad serverį turi valdyti tu arba žmogus, kuriuo pasitiki (žr. 10 skyrių). Visa kita paruošta naudoti.

Nė viena alternatyva nėra tiksli kopija to, ką ji pakeičia. Vienos geresnės, kitos reikalauja nedidelio kompromiso, o pastabose nurodyta, kurios. Kol neapsisprendei, tam pačiam poreikiui išbandyk 2 variantus, nes daugumą galima išbandyti nemokamai arba pigiai.

Kai kurie pavadinimai, ypač „Proton“, kartojasi keliose eilutėse. Viską imti iš vieno teikėjo patogu, bet taip atkuriama ta pati priklausomybė, iš kurios vaduojiesi, todėl pagalvok, ar nevertėtų derinti kelių operatorių.

| Poreikis | Alternatyvos | Pastabos | Kas gali perskaityti tavo duomenis |
|---|---|---|---|
| **Paieška** | Žr. 3 skyrių | Lengviausias pirmasis žingsnis, pakanka pakeisti vieną naršyklės nustatymą. | Žr. 3 skyrių. |
| **El. paštas ir kalendorius** | Apie el. paštą žr. 4 skyrių. Kalendoriai: „Proton Calendar“, „Tuta Calendar“, „Nextcloud“ | „Proton“ ir „Tuta“ kalendorių šifruoja ir skelbia savo programėlių kodą. Kiekvieną valdo viena bendrovė. „Nextcloud“ yra atvirojo kodo, ją galima paleisti nuosavame serveryje arba išsinuomoti iš pasirinkto teikėjo. | Nei „Proton“, nei „Tuta“ negali, nes [įvykius šifruoja ištisiniu būdu](https://proton.me/blog/protoncalendar-security-model). Jei naudoji „Nextcloud“, gali tas, kas valdo serverį. |
| **Žemėlapiai** | „Organic Maps“, „CoMaps“, „OsmAnd“, „Magic Earth“ | Visos naudoja „OpenStreetMap“ duomenis. „Organic Maps“, bendruomenės sukurta jos atšaka (angl. fork) „CoMaps“ ir „OsmAnd“ (išsamesnė, sudėtingesnė) yra atvirojo kodo ir nemokamai veikia be interneto, tačiau eismo informacijos realiuoju laiku nerodo. „Magic Earth“ kodas uždaras, eismo informaciją realiuoju laiku ji rodo, tačiau, 2026 m. rugsėjo mėn. duomenimis, eismo informacija ir žemėlapiai be interneto įeina į jos [mokamą planą „Premium“](https://www.magicearth.com/pricing). Nė vienoje nerasi tokių atsiliepimų apie parduotuves kaip „Google Maps“. | Be interneto paieška ir maršrutai skaičiuojami pačiame telefone, paskyros nereikia. „Magic Earth“ kodo patikrinti neįmanoma. |
| **Debesų saugykla ir sinchronizavimas** | „Nextcloud“, „Proton Drive“, „Filen“, „Syncthing“ | „Proton Drive“ ir „Filen“ šifruojamos ištisiniu būdu, jų programėlės atvirojo kodo, kiekvieną valdo viena bendrovė. Apie „Nextcloud“ žr. pirmiau. „Syncthing“ yra atvirojo kodo ir apsieina visai be debesijos, nes tavo įrenginius sinchronizuoja tiesiogiai. Geriausiai veikia tarp kompiuterių. Oficiali programėlė „Android“ sistemai [nebekuriama nuo 2024 m. gruodžio](https://forum.syncthing.net/t/discontinuing-syncthing-android/23002). Bendruomenės versija „Syncthing-Fork“ toliau platinama per „F-Droid“, o 2025 m. pasikeitė jos prižiūrėtojas, todėl pirma patikrink dabartinę jos būklę ir tik tada ja pasikliauk. Telefonams „iPhone“ yra tik trečiųjų šalių programėlių. | Nei „Proton“, nei „Filen“ negali. Tas, kas valdo „Nextcloud“ serverį, gali, nebent kliento pusėje naudoji [ištisiniu būdu šifruojamus aplankus](https://nextcloud.com/encryption/). Vien serverio pusės šifravimas failų nuo administratoriaus nepaslepia. „Syncthing“ [retransliatoriai (angl. relays) perduoda šifruotus duomenis](https://docs.syncthing.net/users/relaying.html). |
| **Dokumentai** | „CryptPad“, „LibreOffice“, „OnlyOffice“ | „CryptPad“ skirta šifruotam bendram darbui internete, yra atvirojo kodo, ja galima naudotis viešame serveryje arba paleisti nuosavame. „LibreOffice“ yra atvirojo kodo ir veikia kompiuteryje be interneto. „OnlyOffice“ yra atvirojo kodo, gerai dera su „Microsoft“ formatais ir dažnai naudojama sistemoje „Nextcloud“. | Tas, kas valdo „CryptPad“ serverį, negali (dokumentai užšifruojami naršyklėje). „LibreOffice“ failai lieka kompiuteryje. Jei naudoji „OnlyOffice“, tai priklauso nuo to, kas valdo serverį. |
| **Užrašai** | „Standard Notes“, „Joplin“, „Notesnook“, „Obsidian“ | „Standard Notes“ ir „Notesnook“ yra atvirojo kodo ir automatiškai šifruoja ištisiniu būdu. „Standard Notes“ priklauso bendrovei „Proton“. „Joplin“ yra atvirojo kodo ir sinchronizuoja per tavo pasirinktą saugyklą, tačiau ištisinis šifravimas joje [pasirenkamas](https://joplinapp.org/help/apps/sync/e2ee/), todėl įjunk jį nustatymuose prieš pirmąjį sinchronizavimą. „Obsidian“ kodas uždaras, bet užrašai yra paprastojo teksto failai tavo diske. | Nei „Standard Notes“, nei „Notesnook“ negali. „Joplin“ saugyklos teikėjas gali, kol šifravimas neįjungtas. „Obsidian“ failai lieka tavo diske. |
| **Nuotraukos** | „Ente Photos“, „Immich“ | „Ente“ šifruojama ištisiniu būdu, yra atvirojo kodo, mokama, kai nebepakanka nedidelio nemokamo plano, ir gali veikti nuosavame serveryje. „Immich“ yra atvirojo kodo, veikia tik nuosavame serveryje ir labiausiai primena „Google Photos“. | „Ente“ negali, o jos [architektūra paskelbta](https://ente.io/architecture/). Jei naudoji „Immich“, gali tas, kas valdo serverį, o paprastai tai esi tu. |
| **Vaizdo įrašai** | „NewPipe“, „FreeTube“, „Invidious“, „PeerTube“ | „NewPipe“ („Android“) ir „FreeTube“ (kompiuteris) rodo „YouTube“ vaizdo įrašus be paskyros ir be reklamos. „Invidious“ tą patį daro naršyklėje per viešus serverius, kurie dažnai sutrinka. Visos 3 yra atvirojo kodo ir gali nustoti veikti, kai „YouTube“ ką nors pakeičia. „PeerTube“ yra kitokia: tai atvirojo kodo federacinis tinklas su savais vaizdo įrašais. | „YouTube“ vis tiek mato tavo IP adresą. „Invidious“ arba „PeerTube“ serveris mato, ką ten žiūri. |
| **Vertimas** | „LibreTranslate“, naršyklėje „Firefox“ įtaisytas vertimas | „LibreTranslate“ yra atvirojo kodo ir gali veikti nuosavame serveryje. „Firefox“ puslapius verčia tavo įrenginyje. „DeepL“ verčia kokybiškiau, tačiau jos kodas uždaras ir ji gauna tavo tekstą, o tai priimtina restorano meniu, bet ne sutarčiai. | „LibreTranslate“ serveris mato tavo tekstą, nebent paleidi jį savo serveryje. „Firefox“ nieko nesiunčia. „DeepL“ gauna viską, ką įvedi. |
| **Programėlių parduotuvė „Android“ sistemai** | „F-Droid“, „Obtainium“, „Aurora Store“ | „F-Droid“ yra vien atvirojo kodo programėlių katalogas. Žr. 9 skyrių. | Čia duomenų niekas neskaito. Svarbu, kas programėles surenka ir pasirašo (žr. 9 skyrių). |

Daugumai žmonių protinga pradžia būtų tokia: **paieška, tada žemėlapiai, tada užrašai**, nes ten beveik nieko nereikia perkelti. Svarbiausi yra paštas ir nuotraukos, ir kiekvienam iš jų verta skirti ramų savaitgalį.

## Žingsnis po žingsnio

Pavyzdyje perkeliamos nuotraukos, o ta pati logika tinka kiekvienai lentelės eilutei.

1. **Eksportuok.** Senojoje paslaugoje užsisakyk visą savo archyvą ir išsaugok jį diske, kuris priklauso tau. Patikrink, ar failai atsidaro.
2. **Išsirink 1 paslaugą** iš lentelės. Perskaityk jos svetainę, patikrink, kas ją valdo, ar kodas atviras, ar teikėjas gali perskaityti tavo duomenis ir kiek ji kainuoja. Būtent šis žingsnis pasitikėjimą prekių ženklu pakeičia patikrinimu.
3. **2 savaites naudok abi lygiagrečiai.** Telefone įjunk nuotraukų atsarginį kopijavimą naujojoje paslaugoje, o senąjį palik įjungtą. Kaskart, kai nori pažiūrėti nuotrauką, atverk naująją programėlę.
4. **Perkelk duomenis.** Importuok eksportuotą archyvą į naująją paslaugą. Dauguma alternatyvų turi importavimo įrankį arba vadovą, skirtą didžiosioms platformoms.
5. **Pakeisk numatytąją paslaugą kiekviename įrenginyje**, t. y. telefone, planšetėje, kompiuteryje ir visų, kas šia paslauga naudojasi kartu su tavimi, įrenginiuose. Išjunk senąjį atsarginį kopijavimą arba sinchronizavimą.
6. **Ištrink duomenis iš senosios paslaugos**, kai įsitikinsi, kad naujojoje kopijoje nieko netrūksta ir kad turi jos atsarginę kopiją. Su nuotraukomis elkis atsargiai. Pasak [pačios „Google“ pagalbos puslapio](https://support.google.com/photos/answer/6128858/delete-or-restore-your-photos-amp-videos-android?co=GENIE.Platform%3DAndroid), programėlėje „Google Photos“ ištrynus nuotrauką, kurios atsarginė kopija padaryta, ištrinama ir telefone esanti kopija. Jei nori pasilikti telefone esančias kopijas, pirmiausia kiekviename įrenginyje išjunk atsarginį kopijavimą ir tada trink kompiuteryje, svetainėje photos.google.com, arba programėlės atsarginio kopijavimo nustatymuose pasirink „Undo backup“ (atšaukti atsarginį kopijavimą): ši funkcija pašalina debesijoje esančias kopijas, o failus įrenginyje palieka. Jei naudoji paslaugą „iCloud Photos“, pirmiausia [atsisiųsk originalus](https://support.apple.com/en-ie/102179), palauk, kol atsisiuntimas baigsis, ir patikrink failus, tada išjunk sinchronizavimą tuose įrenginiuose, kuriuose nori pasilikti kopijas, ir tik po to trink debesijoje esančius elementus. Ištrinti elementai 30 dienų lieka šiukšlinėje, kurią gali ištuštinti, kai nebeliks abejonių.
7. **Išsirink kitą paslaugą**, tik ne tą pačią savaitę.

## Klaidos, kurių verta vengti

- **Purizmas.** Pakeisti 7 paslaugas iš 10 yra didelis laimėjimas, o tai, kad pasilikai „YouTube“ ar darbo įrankį, viso kito nenubraukia.
- **Perkelti viską iš karto.** Tai pagrindinė priežastis, kodėl žmonės grįžta atgal. Perkelk 1 paslaugą, pagyvenk su ja 2 savaites, tada rinkis kitą.
- **Pamiršti žmones, su kuriais dalijiesi.** Bendri albumai, šeimos kalendorius ir bendras pirkinių sąrašas susiję su kitais žmonėmis, todėl prieš persikeliant su jais pasikalbėk arba tą dalyką kol kas palik ten, kur yra.
- **Pasitikėti žodžiu „privatumas“ reklamoje.** Patikrink faktus: ar kodas atviras, ar duomenys šifruojami taip, kad įmonė negalėtų jų perskaityti, ar šis šifravimas įjungtas automatiškai, kam priklauso įmonė ir iš ko ji uždirba.
- **Ištrinti nepatikrinus.** Atverk naująją kopiją, suskaičiuok albumus, patikrink seniausius ir naujausius failus ir tik tada ištrink originalą taip, kaip aprašyta 6 žingsnyje.
- **Vieną priklausomybę pakeisti kita.** Jei viskas persikelia į vieną naują įmonę, priklausomybė lieka ta pati, tik šeimininkas geresnis. Paskirstyk paslaugas keliems operatoriams.

## Norintiems daugiau

- **PROOF konferencijoje:** „Kaip „kareivis-pilietis“ gali padėti decentralizuoti pasaulį: Rusijos invazijos į Ukrainą pamokos“, pranešimą apie tai, kodėl atviri ir decentralizuoti įrankiai svarbūs visuomenei, skaito Alexis Roussel.
- **Išsamios nepriklausomos rekomendacijos:** „Privacy Guides“ (privacyguides.org).
- **Alternatyvos, surūšiuotos pagal paslaugą, kurią nori pakeisti:** switching.software.
- **Europoje įsikūrusios paslaugos:** european-alternatives.eu.
- **Kitas skyrius:** kaip susigrąžinti telefono kontrolę.

## Šaltiniai

- [Respect individuals' rights, including portability](https://www.edpb.europa.eu/sme/be-compliant/respect-individuals-rights_en), Europos duomenų apsaugos valdyba, tikrinta 2026 m. spalio 22 d.
- [Server-side encryption and its limits](https://docs.nextcloud.com/server/32/admin_manual/configuration_files/encryption_configuration.html), „Nextcloud“ administravimo vadovas, tikrinta 2026 m. spalio 22 d.
- [Turn off iCloud Photos](https://support.apple.com/en-ie/102179), „Apple Support“, tikrinta 2026 m. spalio 22 d.
- [International Criminal Court dumps Microsoft Office](https://www.theregister.com/2025/10/31/international_criminal_court_ditches_office/), „The Register“, 2025 m. spalio 31 d.
- [Regulation (EU) 2016/679, General Data Protection Regulation, Article 20](https://eur-lex.europa.eu/eli/reg/2016/679/oj), Europos Sąjungos oficialusis leidinys, 2016 m. balandžio 27 d.
- [Discontinuing syncthing-android](https://forum.syncthing.net/t/discontinuing-syncthing-android/23002), „Syncthing“ bendruomenės forumas, 2024 m. spalio 20 d.
- [Delete photos and videos](https://support.google.com/photos/answer/6128858/delete-or-restore-your-photos-amp-videos-android?co=GENIE.Platform%3DAndroid), „Google Photos“ pagalba, tikrinta 2026 m. spalio 22 d.
- [Magic Earth pricing](https://www.magicearth.com/pricing), „Magic Earth“, žiūrėta 2026 m. rugsėjį.
- [End-to-end encryption](https://joplinapp.org/help/apps/sync/e2ee/), „Joplin“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [The Proton Calendar security model](https://proton.me/blog/protoncalendar-security-model), „Proton“, žiūrėta 2026 m. rugsėjį.
- [Nextcloud encryption](https://nextcloud.com/encryption/), „Nextcloud“, žiūrėta 2026 m. rugsėjį.
- [Relaying](https://docs.syncthing.net/users/relaying.html), „Syncthing“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [Ente architecture](https://ente.io/architecture/), „Ente“, žiūrėta 2026 m. rugsėjį.

## Tavo veiksmų sąrašas

- [ ] Užsisakyk savo duomenų eksportą iš „Google“, „Apple“ arba „Meta“ (5 min.)
- [ ] Pakeisk 1 lengvą paslaugą: paiešką, žemėlapius arba užrašus (5 min.)
- [ ] Išsirink pirmąją svarbią paslaugą ir 2 savaites naudok ją lygiagrečiai su senąja (1 val.)
- [ ] Perkelk duomenis ir pakeisk numatytąsias paslaugas, o senąją debesijos kopiją ištrink tik tada, kai patikrinsi nepriklausomą atsarginę kopiją ir išjungsi sinchronizavimą įrenginiuose, kurių kopijas nori pasilikti (savaitgalis)
- [ ] Kalendoriuje pasižymėk, kurią paslaugą keisi po 1 mėnesio (5 min.)
