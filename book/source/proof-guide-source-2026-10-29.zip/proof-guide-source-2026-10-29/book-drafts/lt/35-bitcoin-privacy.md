# 16 skyrius: Privatumas Bitcoin tinkle

## Trumpai

Pagrindiniame sluoksnyje Bitcoin neslepia transakcijų grafo. Transakcijos lieka viešos, o tai, ar pavyks nustatyti jų savininkus, priklauso nuo išorinės informacijos ir euristikų. Tačiau adrese nėra vardo. Su tavimi jį susieja biržos atliekamas tapatybės tikrinimas arba tave pažįstantys žmonės, su kuriais atsiskaitai, o tada stebėtojas jau gali susieti piniginę su žmogumi. Keli įpročiai šį atvirumą gerokai sumažina (nauji adresai, atskiros piniginės, pažymėtos monetos, savo mazgas, Lightning kasdienėms išlaidoms), o pažengusiems skirtais įrankiais, tokiais kaip coinjoin ir payjoin, privatumo galima įgyti dar daugiau. Nė vienas iš jų nekeičia tavo teisinių ir mokestinių prievolių.

## Viešasis registras, kuris nieko nepamiršta

Banko sąskaitos išrašą matai tu ir tavo bankas, o Bitcoin registrą gali skaityti bet kas, ir iš jo niekas niekada neištrinama. Tie, kas sako, kad Bitcoin trūksta privatumo, dėl šio pagrindinio sluoksnio yra teisūs, nes transakcijų grafas lieka prieinamas analizei, net kai savininkų patikimai nustatyti nepavyksta.

Tie, kas atsako, kad adresas nėra tapatybė, irgi teisūs, bet tik iš dalies. Adrese nėra vardo, o vardas prie jo prisegamas tik per kitur atsiradusią sąsają. Tavo tapatybę patikrinusi birža žino, kur išsiėmei bitkoinus. Žmonės, su kuriais atsiskaitai, tave pažįsta, pavyzdžiui, internetinė parduotuvė žino tavo vardą ir pavardę ir mato adresą, iš kurio sumokėjai. Analitikos įmonės iš to daro verslą: renka šias sąsajas, grupuoja adresus pagal savininką ir parduoda rezultatą, todėl stebėtojas gali susieti piniginę su konkrečiu žmogumi.

Nuo tos akimirkos ankstesnę ir būsimą su tuo adresu susijusią veiklą gali sekti prekybininkas, darbdavys, buto nuomotojas ar smalsus pažįstamas.

Pavojus yra ir fizinis. 2025 m. sausį [vienas iš bendrovės „Ledger“ įkūrėjų David Balland buvo pagrobtas savo namuose Prancūzijoje](https://www.coindesk.com/policy/2025/01/24/ledger-co-founder-s-kidnapping-sheds-light-on-soaring-crypto-robberies), ir užpuolikai reikalavo išpirkos kriptovaliuta, kol policija išlaisvino jį ir jo partnerę. Programuotojas Jameson Lopp tvarko [viešą fizinių išpuolių prieš bitkoinų turėtojus sąrašą](https://github.com/jlopp/physical-bitcoin-attacks).

## Dideli judėjimai matomi, o pavieniai žmonės turi įrankių

Valstybių leidžiamų pinigų (angl. fiat money) pasaulyje didžiausi veikėjai stambias transakcijas gali paslėpti už finansinių struktūrų, tokių kaip kontroliuojančiosios bendrovės, patikos fondai ir sąskaitos keliose jurisdikcijose, o gyventojų kasdienės banko operacijos stebimos atidžiai, mokėjimas po mokėjimo. Bitcoin tinkle paprastai būna atvirkščiai. Labai didelėms sumoms privatumą užtikrinti gali būti sunkiau, nes coinjoin transakcijai reikia kitų dalyvių ir pakankamai išvesčių, iš kurių bet kuri galėtų būti tavo. Todėl kai bitkoinus perkelia valstybė ar didelė institucija, viešajame registre tai paprastai matyti. 2024 m. vasarą Vokietijos Saksonijos žemė [nuo birželio 19 d. iki liepos 12 d. pardavė apie 49 858 areštuotus bitkoinus](https://www.medienservice.sachsen.de/medien/news/1077662), o spauda, remdamasi analitikos įmonės „Arkham“ duomenimis, diena po dienos [sekė pervedimus iš pažymėtos piniginės į biržas](https://cointelegraph.com/news/german-government-354m-btc-sell-off).

O pavienis žmogus turi įrankių, kuriais gali įgyti privatumo ir apsisaugoti nuo tapatybės atskleidimo (angl. deanonymisation). Jie pristatomi likusioje šio skyriaus dalyje. Tam reikia atidumo ir šiek tiek pasimokyti, tačiau tinkamai juos taikantis žmogus praktikoje gali naudotis Bitcoin privačiai.

## 3 dėsningumai, kurie tave išduoda

Bitkoinus geriau įsivaizduoti ne kaip sąskaitos likutį, o kaip atskiras skirtingo dydžio monetas, panašiai kaip banknotus odinėje piniginėje. Kiekviena gauta moneta įrašyta viešajame registre kartu su suma ir adresu.

Daug atskleidžia 3 paprasti dėsningumai:

- **Pakartotinis adreso naudojimas.** Jei į tą patį adresą gauni 10 mokėjimų, bet kas gali pamatyti visus 10, juos susumuoti ir stebėti, kada jie pajuda.
- **Sujungtos įvestys.** Kai moki, piniginė gali sujungti kelias monetas į 1 transakciją, panašiai kaip mokant 2 banknotais. Stebėtojas padaro išvadą, kad abi monetos priklauso tam pačiam žmogui, todėl su tavo vardu susieta 1 moneta dabar išduoda ir kitą.
- **Grąža.** Jei 50 vertės moneta sumoki 30, likę 20 grįžta į naują tavo adresą. Stebėtojai dažnai gali atspėti, kuri išvestis yra grąža, ir sekti tave toliau.

Analitikai šiuos spėjimus, vadinamus euristikomis (angl. heuristics), derina tarpusavyje. Spėjimai ne visada pasitvirtina, bet profiliui sudaryti jų pakanka, o geri privatumo įpročiai palieka analitikams mažiau medžiagos.

## KYC ir ką jis reiškia

KYC reiškia „pažink savo klientą“ (angl. know your customer), t. y. tapatybės tikrinimą, kurį privalo atlikti reguliuojamos kriptovaliutų biržos. Nusiunti asmens dokumento kopiją, dažnai kartu su asmenuke ir gyvenamosios vietos patvirtinimu. Įmonei tai teisinė pareiga, o naudotis tokia paslauga yra teisėta ir įprasta.

Vis dėlto taip atsiranda ilgalaikė tavo tapatybės ir bitkoinų sąsaja, saugoma įmonės duomenų bazėje. Europos Sąjungoje [MiCA reglamentas](https://www.esma.europa.eu/esmas-activities/digital-finance-and-innovation/markets-crypto-assets-regulation-mica) kriptoturto paslaugų teikėjams taikomas nuo 2024 m. gruodžio 30 d., o pereinamasis laikotarpis baigėsi 2026 m. liepos 1 d. Be to, nuo 2026 m. sausio 1 d. [DAC8 direktyva](https://taxation-customs.ec.europa.eu/taxation/tax-transparency-cooperation/administrative-co-operation-and-mutual-assistance/directive-administrative-cooperation-dac/dac8_en) įpareigoja šiuos teikėjus rinkti duomenis apie ES gyvenančių naudotojų sandorius ir teikti juos mokesčių administratoriams, o šie nuo 2027 m. jais keisis su kitų valstybių narių administratoriais. Tokios duomenų bazės gali nutekėti, o bitkoinų turinčių žmonių sąrašas su namų adresais nusikaltėliams akivaizdžiai įdomus.

Bitkoinų galima įsigyti ir lygiarangėse (angl. peer-to-peer) rinkose, kuriose keitiesi tiesiogiai su kitu žmogumi ir jokia centrinė įmonė tavo dokumentų nerenka. Daugumoje šalių tai teisėta, tačiau taisyklės skiriasi, todėl pasitikrink, kokios galioja tavo šalyje. Mokestinės prievolės lieka visiškai tokios pat, kad ir kaip bitkoinus įsigijai, todėl įrašus kaupk savarankiškai.

## Kas sužino, kurios monetos tavo

Registre rodomi adresai be vardų, todėl tavo konfidencialumas priklauso nuo tų, kas gali prie jų prisegti tavo vardą.

Pirmiausia tai serveris, į kurį kreipiasi piniginė. Registro nelaikanti piniginė apie kiekvieną savo adresą klausia serverio, o numatytasis serveris priklauso piniginės kūrėjui arba savanoriui. [Programos „Sparrow“ dokumentacijoje](https://sparrowwallet.com/docs/best-practices.html) rašoma, kad viešas serveris sužino tavo likutį, o pagal IP adresą ir buvimo vietą. Gali būti, kad jis nieko neregistruoja, bet to nepatikrinsi.

Antra, tai tavo tapatybę patikrinusi birža, kuri žino tavo vardą ir pavardę, namų adresą ir tai, kur išsiėmei bitkoinus, o į ją gali būti įsilaužta arba ji gali būti įpareigota perduoti savo įrašus. 2025 m. gegužę birža „Coinbase“ pranešė, kad iš jos klientų aptarnavimo sistemų nukopijuoti klientų duomenys, o [jos pranešime institucijoms nurodytas 69 461 žmogus](https://cointelegraph.com/news/70k-impacted-coinbase-data-breach-maine-attorneys). Analitikos įmonės yra stebėtojos, dirbančios su viešuoju registru ir gautais duomenimis.

Nei serverio, nei biržos iš išorės audituoti neįmanoma, todėl praktiška jų atsisakyti ten, kur tai svarbu: susikurti savo mazgą, o kol jo nėra, naudoti Tor, ir bitkoinų įsigyti lygiarangėse rinkose. Už kiekvieną iš šių žingsnių sumoki patogumu. Pradedantiesiems reguliuojama birža nuo sukčių dažnai apsaugo geriau, bet už tai ilgam sumokama privatumu.

## Kaip pasirinkti privatumo įpročius

Privatumą Bitcoin tinkle lemia ne koks nors vienas įrankis, o įpročių visuma. Kiekvienas padeda ir atskirai, todėl pradėk nuo lentelės viršaus.

| Įprotis | Įrankiai | Pastangos | Ką laimi | Kas vis tiek ką nors sužino |
|---|---|---|---|---|
| **Niekada nenaudok adreso pakartotinai** | Bet kuri šiuolaikinė piniginė kiekvienam mokėjimui pateikia naują adresą | Jokių | Nelieka tiesioginės sąsajos, kuri atsiranda, kai į 1 adresą gauni ne kartą. Vėliau išleidžiant monetas mokėjimai vis tiek gali būti susieti | Serveris, į kurį kreipiasi piniginė, vis tiek mato visus šiuos adresus kartu |
| **Atskiros piniginės atskiriems tikslams** | Bet kuri piniginė: santaupoms, išlaidoms, su tapatybės tikrinimu (KYC) įsigytoms monetoms, be tapatybės tikrinimo įsigytoms monetoms | Mažos | Atsiranda mažiau atsitiktinių sąsajų tarp skirtingų tikslų. Bendri serveriai ir vėlesnės transakcijos vis tiek gali juos susieti | Tas pats serveris, jei abi piniginės kreipiasi į jį iš to paties IP adreso |
| **Žymėk monetas ir naudok monetų valdymą (angl. coin control)** | „Sparrow Wallet“, „Nunchuk“, „Electrum“ (visos atvirojo kodo) | Vidutinės | Tu sprendi, kuria moneta mokama, ir per klaidą nesujungi monetų | Naujų stebėtojų neatsiranda, nes žymės lieka tavo piniginės faile. Pasidaryk šio failo atsarginę kopiją |
| **Prisijunk prie savo mazgo** | Žr. 18 skyrių | Didelės (savaitgalis darbo, paskui kelios dienos sinchronizavimo) | Joks išorinis serveris nesužino, kurie adresai tavo | Likučio nesužino niekas. Kiti mazgai mato tavo paskelbtą transakciją, nebent tavo mazgas naudoja Tor |
| **Kasdienėms išlaidoms naudok Lightning** | Žr. 15 skyrių | Mažos | Atskiri mokėjimai į viešąjį registrą neįrašomi | Depozitinė piniginė (angl. custodial) mato kiekvieną mokėjimą. Savarankiško saugojimo programėlės Lightning paslaugų teikėjas (LSP) vis tiek mato dalį jų |
| **Naudok Tor savo piniginėje** | Programoje „Sparrow“ Tor jau įtaisytas. Programoje „Electrum“ ir keliose kitose yra tarpinio serverio nustatymas, kuriam reikia atskirai įdiegto Tor | Nuo mažų iki vidutinių | Serveris, prie kurio jungiesi, nemato tavo IP adreso | Serveris vis tiek mato tavo adresus. Tor retransliatorius (angl. relays) prižiūri savanoriai, ir per juos keliauja šifruotas srautas |
| **Lygiarangis įsigijimas** | „Bisq“ (kompiuterio programa, atvirojo kodo, be įmonės tarpininkės), „RoboSats“ (atvirojo kodo, per Tor ir Lightning), „Hodl Hodl“ (įmonės valdoma žiniatinklio platforma, kelių parašų sąlyginis deponavimas) | Vidutinės | Biržos duomenų bazėje nelieka tavo asmens dokumentų | Kita sandorio šalis, kuri banko pavedime mato tavo vardą ir pavardę. Platforma mato sandorį, bet ne tavo asmens dokumentą |
| **Coinjoin ir payjoin** (pažengusiems, žr. toliau) | Coinjoin: „Wasabi Wallet“ su nepriklausomu koordinatoriumi, „JoinMarket“ (dabar „joinmarket-ng“, su sąsaja „Jam“), „Ashigaru“. Payjoin: „BTCPay Server“, „Bull Bitcoin“, „Cake Wallet“ | Coinjoin: didelės (mokesčiai, laikas, drausmė vėliau). Payjoin: mažos, kai jį palaiko abi pusės | Susilpnina spėjimus apie bendrą nuosavybę ar grąžą, bet tai priklauso nuo protokolo ir nuo to, kaip monetas išleisi vėliau | Koordinatorius mato, kad dalyvauji, bet sistema sukurta taip, kad jis nematytų, kuri išvestis tavo. Kai kurios biržos kelia klausimų dėl coinjoin perėjusių monetų |
| **Iškeisk nedidelę sumą į Monero ir ją išleisk** (pažengusiems, žr. toliau) | Atominio keitimo (angl. atomic swap) programos („eigenwallet“, atvirojo kodo, lėšų neperima) arba lygiarangės rinkos, kuriose prekiaujama Monero („Bisq“) | Nuo vidutinių iki didelių | Daug mažesnė tikimybė, kad mokėjimas bus susietas su tavo tapatybe, nes Monero automatiškai slepia sumas, siuntėjus ir gavėjus | Keitimo sandorio šalis mato bitkoinų pusę. Tai įrankis išlaidoms, o ne santaupoms |

Lightning mokėtoją apsaugo geriau nei gavėją, o depozitinė Lightning piniginė mato visus tavo mokėjimus. Lygiarangės platformos veikia ne visose šalyse, todėl pasitikrink, ar jos veikia tavo šalyje.

Daugumai žmonių protingas derinys būtų toks: nauji adresai, 1 piniginė kiekvienam tikslui, žymės nuo pirmos dienos ir Lightning smulkiems mokėjimams, o vėliau, kai tam ateis laikas, savo mazgas. Paskutinės 2 eilutės skirtos pažengusiems, ir jas paaiškina kiti 3 skirsniai.

## Coinjoin, payjoin ir maišyklės

3 dėsningumai remiasi spėjimais, o kai kurie įrankiai sukurti tam, kad tie spėjimai nepasitvirtintų. Naudojant **coinjoin** keli žmonės kartu sudaro 1 transakciją su daug įvesčių ir daug vienodų sumų išvesčių, todėl vien iš šios transakcijos sunkiau nustatyti, kuri išvestis kam priklauso. Sumos, laikas ir vėlesni mokėjimai vis tiek gali duoti užuominų. Niekas neatiduoda savo lėšų saugoti kitam, nes kiekvienas dalyvis pasirašo tik tada, kai transakcijoje yra jo išvestis. Naudojant **payjoin** įvesčių į mokėjimą įdeda ir siuntėjas, ir gavėjas, todėl nebegalioja prielaida, kad visos transakcijos įvestys priklauso 1 žmogui, ir paslepiama iš tikrųjų sumokėta suma. **Maišyklės** (angl. mixers) yra senesnis būdas, t. y. paslauga, kuri paima tavo monetas ir atsiunčia kitas. Tokia paslauga depozitinė, todėl operatorius gali pasilikti pinigus arba veiklos įrašus.

2026 m. rugsėjo mėn. duomenimis, coinjoin galima naudoti piniginėje [„Wasabi Wallet“](https://docs.wasabiwallet.io/using-wasabi/CoinJoin.html): nuo tada, kai jos kūrėja 2024 m. birželį uždarė savo koordinatorių, tai daroma per nepriklausomus koordinatorius. Coinjoin veikia ir lygiarangėje rinkoje be koordinatoriaus „JoinMarket“, kuri [nuo 2026 m. balandžio, kai pirminė kodo saugykla buvo archyvuota, tęsiama pavadinimu „joinmarket-ng“](https://atlas21.com/coinjoin-comparison-of-tools-to-improve-privacy-on-bitcoin/), ir piniginėje „Ashigaru“, piniginės „Samourai Wallet“ atšakoje (angl. fork), kuri [2025 m. birželį iš naujo paleido „Whirlpool“ coinjoin](https://ashigaru.rs/news/announcement-whirlpool/). Payjoin veikia prekybininkams skirtoje programoje „BTCPay Server“, o nuo 2025 m. ir [programėlėse „Bull Bitcoin“ bei „Cake Wallet“](https://bitcoinops.org/en/topics/payjoin/).

## Naudotis teisėta, o operatoriai persekiojami

Daugumoje šalių šiais įrankiais saugoti savo finansinį privatumą teisėta, tačiau įstatymai įvairiose šalyse skiriasi ir keičiasi, todėl pasitikrink, kas galioja tavo šalyje. Tai, ką privalai deklaruoti, lieka tas pats. Iki šiol baudžiamasis persekiojimas buvo nukreiptas į operatorius. Jungtinėse Valstijose 2 piniginės „Samourai Wallet“ įkūrėjai, suimti 2024 m. balandį, prisipažino kalti dėl susitarimo vykdyti nelicencijuotą pinigų pervedimo veiklą, kai sąmoningai buvo pervedamos nusikalstamu būdu gautos lėšos, ir [2025 m. lapkritį buvo nuteisti kalėti 5 ir 4 metus](https://www.irs.gov/compliance/criminal-investigation/founders-of-samourai-wallet-cryptocurrency-mixing-service-sentenced-to-five-and-four-years-in-prison). Roman Storm, vienas iš Ethereum tinkle veikiančios maišyklės „Tornado Cash“ kūrėjų, [2025 m. rugpjūčio 6 d. pripažintas kaltu dėl panašaus nusikaltimo](https://www.irs.gov/compliance/criminal-investigation/founder-of-tornado-cash-crypto-mixing-service-convicted-of-knowingly-transmitting-criminal-proceeds). Dėl kaltinimų pinigų plovimu ir sankcijų pažeidimu prisiekusieji verdikto nepriėmė, todėl dalis bylos, 2026 m. rugsėjo mėn. duomenimis, lieka neišspręsta, nors JAV iždo departamentas [2025 m. kovo 21 d. buvo panaikinęs „Tornado Cash“ taikytas sankcijas](https://home.treasury.gov/news/press-releases/sb0057).

Nyderlanduose kitas „Tornado Cash“ kūrėjas Alexey Pertsev [2024 m. gegužę nuteistas kalėti 64 mėnesius](https://www.coindesk.com/policy/2024/05/14/tornado-cash-developer-alexey-pertsev-found-guilty-of-money-laundering) ir pateikė apeliacinį skundą. Nė vienas iš šių kūrėjų nekaltinamas ką nors pavogęs. Jiems priekaištaujama dėl to, kad parašė programinę įrangą ir užtikrino jos veikimą, o ja naudojosi ir nusikaltėliai, ir žmonės, siekę įprasto finansinio privatumo. Šie šaltiniai neleidžia nustatyti, kokia naudotojų dalis priklausė kiekvienai grupei. Daugelio programuotojų ir pilietinių laisvių gynimo organizacijų nuomone, tai rimtas išpuolis prieš saviraiškos laisvę ir laisvę kurti, nes kodo skelbimas yra viena iš saviraiškos formų, o privatumo įrankis naudotojų nesirenka, kaip jų nesirenka nei šifravimas, nei grynieji pinigai. Kelios iš šių bylų, 2026 m. rugsėjo mėn. duomenimis, vis dar nagrinėjamos teismuose.

Šios bylos paaiškina, kodėl koordinatoriai užsidaro arba nepriima naudotojų iš kai kurių šalių ir kodėl kai kurios biržos kelia klausimų dėl monetų, perėjusių coinjoin. Pradedantiesiems nuo to pradėti nebūtina.

## Monero išlaidoms, o ne santaupoms

Kai kurie pažengę naudotojai bitkoinus laiko kaip ilgalaikį turtą, o nedidelę sumą iškeičia į Monero tada, kai nori, kad būtų mažesnė tikimybė, jog mokėjimas bus susietas su jų tapatybe. Monero yra atskira valiuta, kurios paskirtis panaši (pinigai, kuriuos gali laikyti savarankiškai), o sumos, siuntėjai ir gavėjai joje slepiami automatiškai, ir tai tikroji jos stiprybė.

Tačiau vertei laikyti ji mažiau saugi, nes yra daug mažiau likvidi ir daug rečiau priimama, jos kliento programinę įrangą kuria mažesnė ir labiau centralizuota grupė, o daug mažesnį jos tinklą pašalinei jėgai lengviau užpulti. 2025 m. rugsėjį nedidelis kasėjų telkinys (angl. mining pool) „Qubic“ per [18 blokų apėmusį grandinės pertvarkymą (angl. reorg) atšaukė 118 patvirtintų transakcijų](https://www.coindesk.com/web3/2025/09/15/monero-suffers-deepest-ever-blockchain-reorganization-invalidating-118-transactions) (žr. 12 skyrių).

Keičiama lėšų neperimančiomis atominio keitimo programomis, tokiomis kaip „eigenwallet“, arba lygiarangėse rinkose, tokiose kaip „Bisq“, nes Europoje reguliuojamos platformos Monero atsisako. [2024 m. ES kovos su pinigų plovimu reglamentas](https://eur-lex.europa.eu/eli/reg/2024/1624/oj) nuo 2027 m. liepos 10 d. draudžia joms tvarkyti sąskaitas, kuriose naudojamos „anonimiškumą didinančios monetos“. Yra ir akimirksninio keitimo svetainių, tačiau keitimo metu jos laiko tavo monetas. Teisinės ir mokestinės prievolės galioja ir čia, o daugelyje šalių keitimas yra apmokestinamas įvykis. 12 skyriuje palyginta, kaip Bitcoin ir Monero tinka vertei saugoti.

## Žingsnis po žingsnio

Pavyzdyje naudojama programa „Sparrow Wallet“ kompiuteryje. Piniginės „Nunchuk“ ir „Electrum“ siūlo tas pačias funkcijas, tik šiek tiek kitaip pavadintas.

1. **Kiekvienam tikslui susikurk 1 piniginę.** Pavyzdžiui, santaupoms, išlaidoms ir atskirą piniginę monetoms, gautoms iš tapatybę tikrinančios biržos.
2. **Kiekvieną mokėjimą priimk nauju adresu.** Ekrane „Receive“ (gauti) naujas adresas pasiūlomas automatiškai. Niekada nekopijuok seno adreso iš istorijos.
3. **Pažymėk kiekvieną mokėjimą, kai tik jis ateina.** Užsirašyk, iš kur jis, pavyzdžiui, „birža, kovas“ arba „pardaviau dviratį Tomui“. Po 6 mėnesių nebeprisiminsi.
4. **Pasirink, kuria moneta mokėsi.** Prieš siunčiant atverk monetų sąrašą (programa „Sparrow“ jį vadina „UTXOs“, t. y. nepanaudotos transakcijų išvestys), pasirink tinkamą monetą ir siųsk iš jos. Venk jungti monetas iš skirtingų šaltinių.
5. **Pažymėk grąžą.** Tau grįžtanti moneta paveldi mokėjimo istoriją, todėl tai užsirašyk.
6. **Smulkius pirkinius apmokėk per Lightning** (žr. 15 skyrių), o pagrindinės grandinės (angl. on-chain) transakcijas pasilik didesniems ir retesniems pervedimams.
7. **Įjunk Tor** piniginės serverio arba tinklo nustatymuose, jei vis dar naudoji viešą serverį. Vėliau viešą serverį pakeisk savo mazgu (žr. 18 skyrių). Tor tik paslepia tavo IP adresą nuo to serverio, o mazgas yra tas žingsnis, kuriuo pašalinama trečioji šalis, nes klausimai apie tavo adresus nebeiškeliauja iš tavo namų.

## Klaidos, kurių verta vengti

- **Viešai skelbti adresus ar likučius.** Socialiniuose tinkluose paskelbta piniginės ekrano nuotrauka susieja tavo vardą su tavo monetomis, o vėliau ištrynus įrašą to nebeatitaisysi, nes kopijos plinta, o registras išsaugo viską.
- **Sujungti su KYC ir be KYC įsigytas monetas.** Jas sujungianti transakcija kiekvienam stebėtojui pasako, kad jos priklauso tam pačiam žmogui, todėl laikyk jas atskirose piniginėse. Tikslas yra nerodyti prekybininkui visos savo istorijos, o tai, ką privalai deklaruoti, nuo to nesikeičia.
- **Pakartotinai naudoti aukų adresą.** Vienas nekintamas adresas kiekvienam aukotojui parodo, kiek paaukojo visi kiti ir ką su tomis lėšomis padarei. Naudok įrankį, kuris kiekvienam aukotojui sugeneruoja naują adresą, arba Lightning.
- **Tikėti, kad VPN padaro Bitcoin privatų.** VPN paslepia tavo IP adresą nuo serverio. Registro, kuris viešas visiems, jis niekaip nepakeičia.
- **Kalbėti apie tai, kiek turi.** Analitikai dirba su registru, bet pokalbis tą pačią informaciją atskleidžia greičiau. Šio skaičiaus niekam nereikia žinoti nei internete, nei prie vakarienės stalo.
- **Siekti tobulumo ir nieko nedaryti.** Žymes ir atskiras pinigines gali pradėti naudoti jau šiandien, o mazgas ir pažengusiems skirti būdai gali palaukti.

## Norintiems daugiau

- **PROOF konferencijoje:** „CBDC, KYC ir kova dėl monetarinio privatumo“, pranešimą skaito Linas K. Kodėl privatūs pinigai svarbūs ir ką keičia tapatybės tikrinimas.
- **Pagrindinis tekstas:** „Bitcoin Wiki“ puslapis „Privacy“ (en.bitcoin.it). Ilgas, bet išsamus.
- **Coinjoin ir payjoin paaiškinimai:** „Wasabi Wallet“ dokumentacija (docs.wasabiwallet.io) ir projektas „Payjoin“ (payjoin.org).
- **Praktiniai vadovai:** „Bitcoiner.Guide“, parengė BitcoinQ+A (bitcoiner.guide), ir „Sparrow Wallet“ dokumentacija (sparrowwallet.com/docs) apie žymes ir monetų valdymą.
- **Kitas skyrius:** aparatinės piniginės.

## Šaltiniai

- [Protect your privacy](https://bitcoin.org/en/protect-your-privacy), „Bitcoin.org“, tikrinta 2026 m. spalio 22 d.
- [DAC8, the directive on the reporting of crypto-asset transactions](https://taxation-customs.ec.europa.eu/taxation/tax-transparency-cooperation/administrative-co-operation-and-mutual-assistance/directive-administrative-cooperation-dac/dac8_en), Europos Komisija, taikoma nuo 2026 m. sausio 1 d.
- [Markets in Crypto-Assets Regulation (MiCA)](https://www.esma.europa.eu/esmas-activities/digital-finance-and-innovation/markets-crypto-assets-regulation-mica), Europos vertybinių popierių ir rinkų institucija (ESMA), puslapis žiūrėtas 2026 m. rugsėjį.
- [Regulation (EU) 2024/1624 on the prevention of money laundering](https://eur-lex.europa.eu/eli/reg/2024/1624/oj), priimtas 2024 m. gegužės 31 d. ir paskelbtas Europos Sąjungos oficialiajame leidinyje 2024 m. birželio 19 d.
- [Monero Suffers Deepest-Ever Blockchain Reorganization, Invalidating 118 Transactions](https://www.coindesk.com/web3/2025/09/15/monero-suffers-deepest-ever-blockchain-reorganization-invalidating-118-transactions), „CoinDesk“, 2025 m. rugsėjo 15 d.
- [Notveräußerung von fast 50.000 Bitcoins abgeschlossen](https://www.medienservice.sachsen.de/medien/news/1077662), Drezdeno generalinė prokuratūra („Generalstaatsanwaltschaft Dresden“), Saksonijos laisvoji žemė, 2024 m. liepos 16 d. (vokiečių kalba).
- [German gov't $354M BTC sell-off](https://cointelegraph.com/news/german-government-354m-btc-sell-off), „Cointelegraph“, 2024 m. liepos 10 d.
- [Coinjoin](https://docs.wasabiwallet.io/using-wasabi/CoinJoin.html), „Wasabi Wallet“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [CoinJoin in 2026: Wasabi, JoinMarket and Ashigaru compared](https://atlas21.com/coinjoin-comparison-of-tools-to-improve-privacy-on-bitcoin/), „Atlas21“, atnaujinta 2026 m. birželio 10 d.
- [Announcement: new Zerolink coinjoin coordinator](https://ashigaru.rs/news/announcement-whirlpool/), „Ashigaru“, 2025 m. birželio mėn.
- [Payjoin](https://bitcoinops.org/en/topics/payjoin/), „Bitcoin Optech“, žiūrėta 2026 m. rugsėjį.
- [Founders of Samourai Wallet cryptocurrency mixing service sentenced to five and four years in prison](https://www.irs.gov/compliance/criminal-investigation/founders-of-samourai-wallet-cryptocurrency-mixing-service-sentenced-to-five-and-four-years-in-prison), „IRS Criminal Investigation“, 2025 m. lapkričio 19 d.
- [Founder of Tornado Cash crypto mixing service convicted of knowingly transmitting criminal proceeds](https://www.irs.gov/compliance/criminal-investigation/founder-of-tornado-cash-crypto-mixing-service-convicted-of-knowingly-transmitting-criminal-proceeds), „IRS Criminal Investigation“, 2025 m. rugpjūčio 6 d.
- [Tornado Cash Developer Alexey Pertsev Found Guilty of Money Laundering](https://www.coindesk.com/policy/2024/05/14/tornado-cash-developer-alexey-pertsev-found-guilty-of-money-laundering), „CoinDesk“, 2024 m. gegužės 14 d.
- [Tornado Cash delisting](https://home.treasury.gov/news/press-releases/sb0057), JAV iždo departamentas, 2025 m. kovo 21 d.
- [Ledger Co-Founder's Kidnapping Highlights Threat of Crypto Robberies](https://www.coindesk.com/policy/2025/01/24/ledger-co-founder-s-kidnapping-sheds-light-on-soaring-crypto-robberies), „CoinDesk“, 2025 m. sausio 24 d.
- [Known physical bitcoin attacks](https://github.com/jlopp/physical-bitcoin-attacks), Jameson Lopp, sąrašas nuolat atnaujinamas.
- [Best practices](https://sparrowwallet.com/docs/best-practices.html), „Sparrow Wallet“ dokumentacija, žiūrėta 2026 m. rugsėjį.
- [Coinbase breach hit almost 70k users](https://cointelegraph.com/news/70k-impacted-coinbase-data-breach-maine-attorneys), „Cointelegraph“, 2025 m. gegužės 21 d.

## Tavo veiksmų sąrašas

- [ ] Patikrink, ar piniginė kiekvienam mokėjimui rodo naują adresą (5 min.)
- [ ] Surask visus viešai paskelbtus savo adresus ir likučius ir nebepriimk mokėjimų į tuos adresus (5 min.)
- [ ] Susikurk atskiras pinigines santaupoms, išlaidoms ir iš biržos išsiimtoms lėšoms (1 val.)
- [ ] Prie kiekvienos turimos monetos pažymėk, iš kur ji (1 val.)
- [ ] Po 18 skyriaus prijunk piniginę prie savo mazgo (savaitgalis)
